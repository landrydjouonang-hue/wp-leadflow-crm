<?php
/**
 * Settings store.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Reads settings with registry defaults applied.
 *
 * Only values the user saved are stored; defaults are resolved at read
 * time, so new fields work without a migration.
 */
final class Settings {

	/** Option name. */
	public const OPTION = 'leadflow_crm_settings';

	/** Settings API option group. */
	public const GROUP = 'leadflow_crm_settings';

	/**
	 * Constructor.
	 *
	 * @param Registry $registry Field registry.
	 */
	public function __construct( private Registry $registry ) {}

	/**
	 * All settings with defaults applied.
	 *
	 * @return array<string, mixed>
	 */
	public function all(): array {
		$stored = get_option( self::OPTION, array() );

		return array_merge( $this->registry->defaults(), is_array( $stored ) ? $stored : array() );
	}

	/**
	 * One setting.
	 *
	 * @param string $key      Field id.
	 * @param mixed  $fallback Returned when the field is unknown.
	 * @return mixed
	 */
	public function get( string $key, mixed $fallback = null ): mixed {
		$all = $this->all();

		return array_key_exists( $key, $all ) ? $all[ $key ] : $fallback;
	}

	/**
	 * Creates the option (autoloaded) if missing.
	 *
	 * @return void
	 */
	public function ensure_option(): void {
		add_option( self::OPTION, array(), '', true );
	}
}
