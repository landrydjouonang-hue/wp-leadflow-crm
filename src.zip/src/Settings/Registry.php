<?php
/**
 * Settings registry.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Settings;

use LeadFlow\CRM\Contracts\Hookable;
use LeadFlow\CRM\Security\Capabilities;

defined( 'ABSPATH' ) || exit;

/**
 * Declarative settings framework on top of the WordPress Settings API.
 *
 * Modules add tabs and fields during boot:
 *
 *     $registry->add_tab( 'email', __( 'Email', 'wp-leadflow-crm' ), 30 );
 *     $registry->add_field( 'from_name', array(
 *         'tab'     => 'email',
 *         'label'   => __( 'From name', 'wp-leadflow-crm' ),
 *         'type'    => 'text',
 *         'default' => get_bloginfo( 'name' ),
 *     ) );
 *
 * All values live in a single autoloaded option (Settings::OPTION).
 */
final class Registry implements Hookable {

	/** Supported field types. */
	public const TYPES = array( 'text', 'email', 'url', 'number', 'textarea', 'select', 'checkbox' );

	/** Hidden input telling sanitize() which tab was submitted. */
	private const TAB_FIELD = '__tab';

	/**
	 * Tabs keyed by id.
	 *
	 * @var array<string, array{id: string, label: string, order: int, render: callable|null}>
	 */
	private array $tabs = array();

	/**
	 * Fields keyed by id.
	 *
	 * @var array<string, array<string, mixed>>
	 */
	private array $fields = array();

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_filter( 'option_page_capability_' . Settings::GROUP, array( $this, 'capability' ) );
	}

	/**
	 * Capability required to save settings through options.php.
	 *
	 * @return string
	 */
	public function capability(): string {
		return Capabilities::MANAGE_SETTINGS;
	}

	/**
	 * Adds a tab.
	 *
	 * @param string        $id     Tab id.
	 * @param string        $label  Visible label.
	 * @param int           $order  Sort order.
	 * @param callable|null $render Custom renderer for tabs without fields.
	 * @return void
	 */
	public function add_tab( string $id, string $label, int $order = 50, ?callable $render = null ): void {
		$id = sanitize_key( $id );

		$this->tabs[ $id ] = array(
			'id'     => $id,
			'label'  => $label,
			'order'  => $order,
			'render' => $render,
		);
	}

	/**
	 * Adds a field.
	 *
	 * @param string               $id   Field id (option array key).
	 * @param array<string, mixed> $args {
	 *     Field definition.
	 *
	 *     @type string   $tab         Tab id. Required.
	 *     @type string   $label       Label. Required.
	 *     @type string   $type        One of self::TYPES. Default 'text'.
	 *     @type mixed    $default     Default value.
	 *     @type string   $description Help text below the field.
	 *     @type array    $options     Value => label, for select fields.
	 *     @type int      $min         Minimum, for number fields.
	 *     @type int      $max         Maximum, for number fields.
	 *     @type callable $sanitize    Custom sanitizer, receives the raw value.
	 * }
	 * @return void
	 */
	public function add_field( string $id, array $args ): void {
		$id   = sanitize_key( $id );
		$args = wp_parse_args(
			$args,
			array(
				'tab'         => 'general',
				'label'       => $id,
				'type'        => 'text',
				'default'     => '',
				'description' => '',
				'options'     => array(),
				'min'         => null,
				'max'         => null,
				'sanitize'    => null,
			)
		);

		if ( ! in_array( $args['type'], self::TYPES, true ) ) {
			_doing_it_wrong( __METHOD__, esc_html( sprintf( 'Unsupported settings field type "%s".', $args['type'] ) ), '0.1.0' );
			return;
		}

		$args['id']          = $id;
		$this->fields[ $id ] = $args;
	}

	/**
	 * Tabs the current user may see, sorted.
	 *
	 * @return array<string, array{id: string, label: string, order: int, render: callable|null}>
	 */
	public function tabs(): array {
		$tabs = $this->tabs;

		uasort( $tabs, static fn( array $a, array $b ): int => $a['order'] <=> $b['order'] );

		return $tabs;
	}

	/**
	 * All fields, optionally limited to one tab.
	 *
	 * @param string|null $tab Tab id.
	 * @return array<string, array<string, mixed>>
	 */
	public function fields( ?string $tab = null ): array {
		if ( null === $tab ) {
			return $this->fields;
		}

		return array_filter( $this->fields, static fn( array $field ): bool => $field['tab'] === $tab );
	}

	/**
	 * Default values keyed by field id.
	 *
	 * @return array<string, mixed>
	 */
	public function defaults(): array {
		return array_map( static fn( array $field ): mixed => $field['default'], $this->fields );
	}

	/**
	 * Settings API page slug for a tab.
	 *
	 * @param string $tab Tab id.
	 * @return string
	 */
	public static function page_id( string $tab ): string {
		return 'leadflow-crm-settings-' . $tab;
	}

	/**
	 * Registers the option, sections and fields with the Settings API.
	 *
	 * @return void
	 */
	public function register_settings(): void {
		register_setting(
			Settings::GROUP,
			Settings::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( $this, 'sanitize' ),
				'default'           => array(),
				'show_in_rest'      => false,
			)
		);

		foreach ( $this->tabs() as $tab ) {
			$fields = $this->fields( $tab['id'] );

			if ( empty( $fields ) ) {
				continue;
			}

			$page = self::page_id( $tab['id'] );

			add_settings_section( 'leadflow_crm_' . $tab['id'], '', '__return_false', $page );

			foreach ( $fields as $field ) {
				add_settings_field(
					$field['id'],
					esc_html( $field['label'] ),
					array( $this, 'render_field' ),
					$page,
					'leadflow_crm_' . $tab['id'],
					array(
						'field'     => $field,
						'label_for' => 'checkbox' === $field['type'] ? null : 'leadflow-setting-' . $field['id'],
					)
				);
			}
		}
	}

	/**
	 * Sanitizes a submitted settings array.
	 *
	 * Only fields of the submitted tab are processed; values of other tabs
	 * are preserved. Invalid values keep their previous value.
	 *
	 * @param mixed $input Raw input.
	 * @return array<string, mixed>
	 */
	public function sanitize( mixed $input ): array {
		$input   = is_array( $input ) ? $input : array();
		$current = get_option( Settings::OPTION, array() );
		$current = is_array( $current ) ? $current : array();
		$output  = $current;

		$tab    = isset( $input[ self::TAB_FIELD ] ) ? sanitize_key( (string) $input[ self::TAB_FIELD ] ) : null;
		$fields = null !== $tab && isset( $this->tabs[ $tab ] ) ? $this->fields( $tab ) : array_intersect_key( $this->fields, $input );

		foreach ( $fields as $id => $field ) {
			$raw      = $input[ $id ] ?? null;
			$previous = $current[ $id ] ?? $field['default'];
			$value    = $this->sanitize_value( $field, $raw, $previous );

			$output[ $id ] = $value;
		}

		// Values of unknown fields (e.g. from a disabled module) are kept.
		return $output;
	}

	/**
	 * Sanitizes one value according to its field definition.
	 *
	 * @param array<string, mixed> $field    Field definition.
	 * @param mixed                $raw      Raw value.
	 * @param mixed                $previous Value to keep when invalid.
	 * @return mixed
	 */
	private function sanitize_value( array $field, mixed $raw, mixed $previous ): mixed {
		if ( is_callable( $field['sanitize'] ) ) {
			return call_user_func( $field['sanitize'], $raw, $field );
		}

		if ( 'checkbox' === $field['type'] ) {
			return (bool) rest_sanitize_boolean( $raw ?? false );
		}

		if ( ! is_scalar( $raw ) ) {
			return $previous;
		}

		$raw = (string) $raw;

		switch ( $field['type'] ) {
			case 'email':
				$value = sanitize_email( $raw );
				if ( '' !== $raw && '' === $value ) {
					$this->error( $field, __( 'Please enter a valid email address.', 'wp-leadflow-crm' ) );
					return $previous;
				}
				return $value;

			case 'url':
				return esc_url_raw( $raw );

			case 'number':
				if ( ! is_numeric( $raw ) ) {
					$this->error( $field, __( 'Please enter a number.', 'wp-leadflow-crm' ) );
					return $previous;
				}
				$value = (int) $raw;
				if ( null !== $field['min'] ) {
					$value = max( (int) $field['min'], $value );
				}
				if ( null !== $field['max'] ) {
					$value = min( (int) $field['max'], $value );
				}
				return $value;

			case 'select':
				if ( ! array_key_exists( $raw, (array) $field['options'] ) ) {
					$this->error( $field, __( 'Please choose one of the available options.', 'wp-leadflow-crm' ) );
					return $previous;
				}
				return $raw;

			case 'textarea':
				return sanitize_textarea_field( $raw );

			default:
				return sanitize_text_field( $raw );
		}
	}

	/**
	 * Adds a Settings API error for a field.
	 *
	 * @param array<string, mixed> $field   Field definition.
	 * @param string               $message Message.
	 * @return void
	 */
	private function error( array $field, string $message ): void {
		// Only available on admin screens; sanitize() may also run elsewhere.
		if ( ! function_exists( 'add_settings_error' ) ) {
			return;
		}

		add_settings_error(
			Settings::OPTION,
			'leadflow-invalid-' . $field['id'],
			sprintf( '%1$s: %2$s', $field['label'], $message )
		);
	}

	/**
	 * Outputs the hidden tab marker inside the form.
	 *
	 * @param string $tab Tab id.
	 * @return void
	 */
	public function tab_marker( string $tab ): void {
		printf(
			'<input type="hidden" name="%1$s[%2$s]" value="%3$s" />',
			esc_attr( Settings::OPTION ),
			esc_attr( self::TAB_FIELD ),
			esc_attr( $tab )
		);
	}

	/**
	 * Renders a field control. Settings API callback.
	 *
	 * @param array{field: array<string, mixed>} $args Callback args.
	 * @return void
	 */
	public function render_field( array $args ): void {
		$field       = $args['field'];
		$id          = 'leadflow-setting-' . $field['id'];
		$name        = Settings::OPTION . '[' . $field['id'] . ']';
		$stored      = get_option( Settings::OPTION, array() );
		$value       = is_array( $stored ) && array_key_exists( $field['id'], $stored ) ? $stored[ $field['id'] ] : $field['default'];
		$description = (string) $field['description'];
		$desc_id     = $id . '-description';
		$describedby = '' !== $description ? ' aria-describedby="' . esc_attr( $desc_id ) . '"' : '';

		switch ( $field['type'] ) {
			case 'checkbox':
				printf(
					'<label for="%1$s"><input type="checkbox" id="%1$s" name="%2$s" value="1" %3$s%4$s /> %5$s</label>',
					esc_attr( $id ),
					esc_attr( $name ),
					checked( (bool) $value, true, false ),
					$describedby, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above.
					esc_html( $field['label'] )
				);
				break;

			case 'select':
				printf( '<select id="%1$s" name="%2$s"%3$s>', esc_attr( $id ), esc_attr( $name ), $describedby ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above.
				foreach ( (array) $field['options'] as $option_value => $option_label ) {
					printf(
						'<option value="%1$s" %2$s>%3$s</option>',
						esc_attr( (string) $option_value ),
						selected( (string) $value, (string) $option_value, false ),
						esc_html( (string) $option_label )
					);
				}
				echo '</select>';
				break;

			case 'textarea':
				printf(
					'<textarea id="%1$s" name="%2$s" rows="5" class="large-text"%3$s>%4$s</textarea>',
					esc_attr( $id ),
					esc_attr( $name ),
					$describedby, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above.
					esc_textarea( (string) $value )
				);
				break;

			case 'number':
				printf(
					'<input type="number" id="%1$s" name="%2$s" value="%3$s" class="small-text"%4$s%5$s%6$s />',
					esc_attr( $id ),
					esc_attr( $name ),
					esc_attr( (string) $value ),
					null !== $field['min'] ? ' min="' . esc_attr( (string) $field['min'] ) . '"' : '',
					null !== $field['max'] ? ' max="' . esc_attr( (string) $field['max'] ) . '"' : '',
					$describedby // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above.
				);
				break;

			default:
				printf(
					'<input type="%1$s" id="%2$s" name="%3$s" value="%4$s" class="regular-text"%5$s />',
					esc_attr( $field['type'] ),
					esc_attr( $id ),
					esc_attr( $name ),
					esc_attr( (string) $value ),
					$describedby // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above.
				);
		}

		if ( '' !== $description ) {
			printf( '<p class="description" id="%1$s">%2$s</p>', esc_attr( $desc_id ), esc_html( $description ) );
		}
	}
}
