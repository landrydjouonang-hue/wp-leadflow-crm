<?php
/**
 * Base model.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data;

defined( 'ABSPATH' ) || exit;

/**
 * Read-only record hydrated from a database row.
 *
 * Models never talk to the database; repositories load and save them.
 * Values are cast by the owning repository's schema, so `get()` returns
 * int|float|bool|string|array|null as declared.
 */
abstract class Model implements \JsonSerializable {

	/**
	 * Constructor.
	 *
	 * @param array<string, mixed> $attributes Cast attributes.
	 */
	final public function __construct( protected array $attributes ) {}

	/**
	 * Primary key.
	 *
	 * @return int
	 */
	public function id(): int {
		return (int) ( $this->attributes['id'] ?? 0 );
	}

	/**
	 * Attribute value.
	 *
	 * @param string $key      Column.
	 * @param mixed  $fallback Returned when missing.
	 * @return mixed
	 */
	public function get( string $key, mixed $fallback = null ): mixed {
		return array_key_exists( $key, $this->attributes ) ? $this->attributes[ $key ] : $fallback;
	}

	/**
	 * Whether the record is in the trash.
	 *
	 * @return bool
	 */
	public function is_trashed(): bool {
		return ! empty( $this->attributes['deleted_at'] );
	}

	/**
	 * All attributes.
	 *
	 * @return array<string, mixed>
	 */
	public function to_array(): array {
		return $this->attributes;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @return array<string, mixed>
	 */
	public function jsonSerialize(): array {
		return $this->to_array();
	}
}
