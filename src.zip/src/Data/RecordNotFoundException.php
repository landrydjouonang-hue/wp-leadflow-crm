<?php
/**
 * Missing record.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data;

defined( 'ABSPATH' ) || exit;

/**
 * Thrown when updating or deleting a record that does not exist.
 */
final class RecordNotFoundException extends \RuntimeException {

	/**
	 * Constructor.
	 *
	 * @param string $entity Entity name.
	 * @param int    $id     Record id.
	 */
	public function __construct( string $entity, int $id ) {
		parent::__construct( esc_html( sprintf( 'LeadFlow CRM: %s #%d not found.', $entity, $id ) ) );
	}
}
