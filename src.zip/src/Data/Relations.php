<?php
/**
 * Relationship retrieval.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data;

use LeadFlow\CRM\Data\Models\Activity;
use LeadFlow\CRM\Data\Models\Company;
use LeadFlow\CRM\Data\Models\Contact;
use LeadFlow\CRM\Data\Models\FollowUp;
use LeadFlow\CRM\Data\Models\Lead;
use LeadFlow\CRM\Data\Models\Note;
use LeadFlow\CRM\Data\Models\Task;
use LeadFlow\CRM\Data\Repositories\ActivityRepository;
use LeadFlow\CRM\Data\Repositories\CompanyRepository;
use LeadFlow\CRM\Data\Repositories\ContactRepository;
use LeadFlow\CRM\Data\Repositories\FollowUpRepository;
use LeadFlow\CRM\Data\Repositories\LeadRepository;
use LeadFlow\CRM\Data\Repositories\NoteRepository;
use LeadFlow\CRM\Data\Repositories\TaskRepository;

defined( 'ABSPATH' ) || exit;

/**
 * Navigates between CRM entities. Trashed records are excluded.
 */
final class Relations {

	/**
	 * Constructor.
	 *
	 * @param CompanyRepository  $companies  Companies.
	 * @param ContactRepository  $contacts   Contacts.
	 * @param LeadRepository     $leads      Leads.
	 * @param ActivityRepository $activities Activities.
	 * @param NoteRepository     $notes      Notes.
	 * @param TaskRepository     $tasks      Tasks.
	 * @param FollowUpRepository $follow_ups Follow-ups.
	 */
	public function __construct(
		private CompanyRepository $companies,
		private ContactRepository $contacts,
		private LeadRepository $leads,
		private ActivityRepository $activities,
		private NoteRepository $notes,
		private TaskRepository $tasks,
		private FollowUpRepository $follow_ups
	) {}

	// Company ←→ contacts / leads ------------------------------------------

	/**
	 * Company of a contact.
	 *
	 * @param Contact $contact Contact.
	 * @return Company|null
	 */
	public function company_of_contact( Contact $contact ): ?Company {
		$id = $contact->company_id();

		return null === $id ? null : $this->companies->find( $id );
	}

	/**
	 * Contacts of a company.
	 *
	 * @param int                  $company_id Company id.
	 * @param array<string, mixed> $args       Extra query arguments.
	 * @return Contact[]
	 */
	public function contacts_of_company( int $company_id, array $args = array() ): array {
		return $this->contacts->query( $this->where( $args, 'company_id', $company_id, 'last_name', 'ASC' ) );
	}

	/**
	 * Leads of a company.
	 *
	 * @param int                  $company_id Company id.
	 * @param array<string, mixed> $args       Extra query arguments.
	 * @return Lead[]
	 */
	public function leads_of_company( int $company_id, array $args = array() ): array {
		return $this->leads->query( $this->where( $args, 'company_id', $company_id ) );
	}

	/**
	 * Leads of a contact.
	 *
	 * @param int                  $contact_id Contact id.
	 * @param array<string, mixed> $args       Extra query arguments.
	 * @return Lead[]
	 */
	public function leads_of_contact( int $contact_id, array $args = array() ): array {
		return $this->leads->query( $this->where( $args, 'contact_id', $contact_id ) );
	}

	/**
	 * Company of a lead.
	 *
	 * @param Lead $lead Lead.
	 * @return Company|null
	 */
	public function company_of_lead( Lead $lead ): ?Company {
		$id = $lead->get( 'company_id' );

		return null === $id ? null : $this->companies->find( (int) $id );
	}

	/**
	 * Contact of a lead.
	 *
	 * @param Lead $lead Lead.
	 * @return Contact|null
	 */
	public function contact_of_lead( Lead $lead ): ?Contact {
		$id = $lead->get( 'contact_id' );

		return null === $id ? null : $this->contacts->find( (int) $id );
	}

	/**
	 * Companies of many records in one query (avoids N+1 in lists).
	 *
	 * @param Model[] $records Contacts or leads.
	 * @return array<int, Company> Company id => company.
	 */
	public function companies_for( array $records ): array {
		return $this->companies->find_many( array_map( static fn( Model $m ): int => (int) $m->get( 'company_id', 0 ), $records ) );
	}

	/**
	 * Contacts of many leads in one query.
	 *
	 * @param Lead[] $leads Leads.
	 * @return array<int, Contact> Contact id => contact.
	 */
	public function contacts_for( array $leads ): array {
		return $this->contacts->find_many( array_map( static fn( Model $m ): int => (int) $m->get( 'contact_id', 0 ), $leads ) );
	}

	// Company / contact / lead → related records ------------------------

	/**
	 * Timeline, newest first.
	 *
	 * @param string $parent company|contact|lead.
	 * @param int    $id     Parent id.
	 * @param int    $limit  Max entries.
	 * @return Activity[]
	 */
	public function activities_of( string $parent, int $id, int $limit = 50 ): array {
		return $this->activities->timeline( $parent, $id, $limit );
	}

	/**
	 * Notes, pinned first.
	 *
	 * @param string $parent company|contact|lead.
	 * @param int    $id     Parent id.
	 * @param int    $limit  Max notes.
	 * @return Note[]
	 */
	public function notes_of( string $parent, int $id, int $limit = 50 ): array {
		return $this->notes->for_parent_pinned_first( $parent, $id, $limit );
	}

	/**
	 * Tasks, soonest due first.
	 *
	 * @param string               $parent company|contact|lead.
	 * @param int                  $id     Parent id.
	 * @param array<string, mixed> $args   Extra query arguments.
	 * @return Task[]
	 */
	public function tasks_of( string $parent, int $id, array $args = array() ): array {
		return $this->tasks->for_parent( $parent, $id, array_merge( array( 'orderby' => 'due_at', 'order' => 'ASC' ), $args ) );
	}

	/**
	 * Follow-ups, soonest first.
	 *
	 * @param string               $parent company|contact|lead.
	 * @param int                  $id     Parent id.
	 * @param array<string, mixed> $args   Extra query arguments.
	 * @return FollowUp[]
	 */
	public function follow_ups_of( string $parent, int $id, array $args = array() ): array {
		return $this->follow_ups->for_parent( $parent, $id, array_merge( array( 'orderby' => 'scheduled_at', 'order' => 'ASC' ), $args ) );
	}

	/**
	 * Counts of everything linked to a record (for profile headers).
	 *
	 * @param string $parent company|contact|lead.
	 * @param int    $id     Parent id.
	 * @return array<string, int>
	 */
	public function summary( string $parent, int $id ): array {
		$summary = array(
			'activities'           => $this->activities->count_for_parent( $parent, $id ),
			'notes'                => $this->notes->count_for_parent( $parent, $id ),
			'open_tasks'           => $this->tasks->count_for_parent(
				$parent,
				$id,
				array(
					'where' => array(
						'status' => array(
							'op'    => 'NOT IN',
							'value' => Task::CLOSED_STATUSES,
						),
					),
				)
			),
			'scheduled_follow_ups' => $this->follow_ups->count_for_parent( $parent, $id, array( 'where' => array( 'status' => 'scheduled' ) ) ),
		);

		if ( 'company' === $parent ) {
			$summary['contacts'] = $this->contacts->count( array( 'where' => array( 'company_id' => $id ) ) );
		}

		if ( 'lead' !== $parent ) {
			$column              = 'company' === $parent ? 'company_id' : 'contact_id';
			$summary['leads']    = $this->leads->count( array( 'where' => array( $column => $id ) ) );
			$summary['open_leads'] = $this->leads->count(
				array(
					'where' => array(
						$column  => $id,
						'status' => 'open',
					),
				)
			);
		}

		return $summary;
	}

	/**
	 * Adds a parent filter and default order to query arguments.
	 *
	 * @param array<string, mixed> $args    Arguments.
	 * @param string               $column  Column.
	 * @param int                  $id      Value.
	 * @param string               $orderby Default order column.
	 * @param string               $order   Default direction.
	 * @return array<string, mixed>
	 */
	private function where( array $args, string $column, int $id, string $orderby = 'created_at', string $order = 'DESC' ): array {
		$args['where']            = (array) ( $args['where'] ?? array() );
		$args['where'][ $column ] = $id;

		return array_merge(
			array(
				'orderby'  => $orderby,
				'order'    => $order,
				'per_page' => 100,
			),
			$args
		);
	}
}
