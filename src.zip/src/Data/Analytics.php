<?php
/**
 * Aggregate queries for the dashboard.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data;

use LeadFlow\CRM\Data\Models\Task;
use LeadFlow\CRM\Database\Schema;
use LeadFlow\CRM\Database\Table;

defined( 'ABSPATH' ) || exit;

/**
 * Read-only aggregates for analytics.
 *
 * Every method is one prepared GROUP BY / conditional-SUM query that uses
 * an index (see docs/DATABASE.md, "Analytics"): no rows are loaded into PHP.
 * `$owner` limits lead figures to `owner_id` and task / follow-up figures
 * to `assigned_to`. Trashed rows are always excluded.
 */
final class Analytics {

	/**
	 * Leads created in a period, grouped by current stage and source.
	 *
	 * @param string   $start UTC start (inclusive).
	 * @param string   $end   UTC end (exclusive).
	 * @param int|null $owner Owner filter.
	 * @return array<int, array{stage: string, source: string, status: string, total: int}>
	 */
	public function created_breakdown( string $start, string $end, ?int $owner ): array {
		global $wpdb;

		list( $owner_sql, $owner_args ) = self::owner( 'owner_id', $owner );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $owner_sql is a fixed placeholder fragment.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT stage, source, status, COUNT(*) AS total FROM %i WHERE deleted_at IS NULL AND created_at >= %s AND created_at < %s{$owner_sql} GROUP BY stage, source, status", array_merge( array( Table::name( Schema::LEADS ), $start, $end ), $owner_args ) ), ARRAY_A );

		return array_map(
			static fn( array $row ): array => array(
				'stage'  => (string) $row['stage'],
				'source' => (string) $row['source'],
				'status' => (string) $row['status'],
				'total'  => (int) $row['total'],
			),
			(array) $rows
		);
	}

	/**
	 * Number of leads created in a period.
	 *
	 * @param string   $start UTC start (inclusive).
	 * @param string   $end   UTC end (exclusive).
	 * @param int|null $owner Owner filter.
	 * @return int
	 */
	public function count_created( string $start, string $end, ?int $owner ): int {
		global $wpdb;

		list( $owner_sql, $owner_args ) = self::owner( 'owner_id', $owner );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- See created_breakdown().
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i WHERE deleted_at IS NULL AND created_at >= %s AND created_at < %s{$owner_sql}", array_merge( array( Table::name( Schema::LEADS ), $start, $end ), $owner_args ) ) );
	}

	/**
	 * All leads (not trashed).
	 *
	 * @param int|null $owner Owner filter.
	 * @return int
	 */
	public function count_all( ?int $owner ): int {
		global $wpdb;

		list( $owner_sql, $owner_args ) = self::owner( 'owner_id', $owner );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- See created_breakdown().
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i WHERE deleted_at IS NULL{$owner_sql}", array_merge( array( Table::name( Schema::LEADS ) ), $owner_args ) ) );
	}

	/**
	 * Leads won or lost in a period (by closing date), per currency.
	 *
	 * @param string   $start UTC start (inclusive).
	 * @param string   $end   UTC end (exclusive).
	 * @param int|null $owner Owner filter.
	 * @return array<int, array{status: string, currency: string, total: int, value: float}>
	 */
	public function closed( string $start, string $end, ?int $owner ): array {
		global $wpdb;

		list( $owner_sql, $owner_args ) = self::owner( 'owner_id', $owner );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- See created_breakdown().
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT status, currency, COUNT(*) AS total, SUM(amount) AS value FROM %i WHERE status IN ('won', 'lost') AND closed_at >= %s AND closed_at < %s AND deleted_at IS NULL{$owner_sql} GROUP BY status, currency", array_merge( array( Table::name( Schema::LEADS ), $start, $end ), $owner_args ) ), ARRAY_A );

		return array_map(
			static fn( array $row ): array => array(
				'status'   => (string) $row['status'],
				'currency' => (string) $row['currency'],
				'total'    => (int) $row['total'],
				'value'    => (float) $row['value'],
			),
			(array) $rows
		);
	}

	/**
	 * Current open pipeline per stage and currency, with weighted value
	 * (amount × probability).
	 *
	 * @param int|null $owner Owner filter.
	 * @return array<int, array{stage: string, currency: string, total: int, value: float, weighted: float}>
	 */
	public function open_pipeline( ?int $owner ): array {
		global $wpdb;

		list( $owner_sql, $owner_args ) = self::owner( 'owner_id', $owner );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- See created_breakdown().
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT stage, currency, COUNT(*) AS total, SUM(amount) AS value, SUM(amount * COALESCE(probability, 0)) / 100 AS weighted FROM %i WHERE status = 'open' AND deleted_at IS NULL{$owner_sql} GROUP BY stage, currency", array_merge( array( Table::name( Schema::LEADS ) ), $owner_args ) ), ARRAY_A );

		return array_map(
			static fn( array $row ): array => array(
				'stage'    => (string) $row['stage'],
				'currency' => (string) $row['currency'],
				'total'    => (int) $row['total'],
				'value'    => (float) $row['value'],
				'weighted' => (float) $row['weighted'],
			),
			(array) $rows
		);
	}

	/**
	 * Leads created and leads won per month (one conditional SUM per month).
	 *
	 * @param array<int, array{key: string, start: string, end: string}> $months UTC month bounds, ascending.
	 * @param int|null                                                  $owner  Owner filter.
	 * @return array{created: array<string, int>, won: array<string, int>, lost: array<string, int>} Month key => count.
	 */
	public function monthly( array $months, ?int $owner ): array {
		global $wpdb;

		$result = array(
			'created' => array(),
			'won'     => array(),
			'lost'    => array(),
		);

		if ( empty( $months ) ) {
			return $result;
		}

		$first = reset( $months )['start'];
		$last  = end( $months )['end'];
		$table = Table::name( Schema::LEADS );

		list( $owner_sql, $owner_args ) = self::owner( 'owner_id', $owner );

		// Created per month.
		$sums = array();
		$args = array();

		foreach ( $months as $i => $month ) {
			$sums[] = "SUM(created_at >= %s AND created_at < %s) AS m{$i}";
			array_push( $args, $month['start'], $month['end'] );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- Built from placeholders only.
		$row = (array) $wpdb->get_row( $wpdb->prepare( 'SELECT ' . implode( ', ', $sums ) . " FROM %i WHERE deleted_at IS NULL AND created_at >= %s AND created_at < %s{$owner_sql}", array_merge( $args, array( $table, $first, $last ), $owner_args ) ), ARRAY_A );

		foreach ( $months as $i => $month ) {
			$result['created'][ $month['key'] ] = (int) ( $row[ "m{$i}" ] ?? 0 );
		}

		// Won and lost per month (by closing date).
		$sums = array();
		$args = array();

		foreach ( $months as $i => $month ) {
			$sums[] = "SUM(status = 'won' AND closed_at >= %s AND closed_at < %s) AS w{$i}, SUM(status = 'lost' AND closed_at >= %s AND closed_at < %s) AS l{$i}";
			array_push( $args, $month['start'], $month['end'], $month['start'], $month['end'] );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- Built from placeholders only.
		$row = (array) $wpdb->get_row( $wpdb->prepare( 'SELECT ' . implode( ', ', $sums ) . " FROM %i WHERE status IN ('won', 'lost') AND closed_at >= %s AND closed_at < %s AND deleted_at IS NULL{$owner_sql}", array_merge( $args, array( $table, $first, $last ), $owner_args ) ), ARRAY_A );

		foreach ( $months as $i => $month ) {
			$result['won'][ $month['key'] ]  = (int) ( $row[ "w{$i}" ] ?? 0 );
			$result['lost'][ $month['key'] ] = (int) ( $row[ "l{$i}" ] ?? 0 );
		}

		return $result;
	}

	/**
	 * Open and overdue tasks right now.
	 *
	 * @param string   $now      UTC now.
	 * @param int|null $assignee Assignee filter.
	 * @return array{open: int, overdue: int}
	 */
	public function tasks( string $now, ?int $assignee ): array {
		global $wpdb;

		list( $owner_sql, $owner_args ) = self::owner( 'assigned_to', $assignee );

		$closed = Task::CLOSED_STATUSES;
		$marks  = implode( ', ', array_fill( 0, count( $closed ), '%s' ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- Built from placeholders only.
		$row = (array) $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) AS open_total, COALESCE(SUM(due_at < %s), 0) AS overdue FROM %i WHERE status NOT IN ({$marks}) AND deleted_at IS NULL{$owner_sql}", array_merge( array( $now, Table::name( Schema::TASKS ) ), $closed, $owner_args ) ), ARRAY_A );

		return array(
			'open'    => (int) ( $row['open_total'] ?? 0 ),
			'overdue' => (int) ( $row['overdue'] ?? 0 ),
		);
	}

	/**
	 * Scheduled follow-ups: due between now and $until, and overdue.
	 *
	 * @param string   $now      UTC now.
	 * @param string   $until    UTC end of the "upcoming" window.
	 * @param int|null $assignee Assignee filter.
	 * @return array{upcoming: int, overdue: int}
	 */
	public function follow_ups( string $now, string $until, ?int $assignee ): array {
		global $wpdb;

		list( $owner_sql, $owner_args ) = self::owner( 'assigned_to', $assignee );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- See created_breakdown().
		$row = (array) $wpdb->get_row( $wpdb->prepare( "SELECT COALESCE(SUM(scheduled_at >= %s), 0) AS upcoming, COALESCE(SUM(scheduled_at < %s), 0) AS overdue FROM %i WHERE status = 'scheduled' AND scheduled_at < %s AND deleted_at IS NULL{$owner_sql}", array_merge( array( $now, $now, Table::name( Schema::FOLLOW_UPS ), $until ), $owner_args ) ), ARRAY_A );

		return array(
			'upcoming' => (int) ( $row['upcoming'] ?? 0 ),
			'overdue'  => (int) ( $row['overdue'] ?? 0 ),
		);
	}

	/**
	 * Owner condition fragment and its argument.
	 *
	 * @param string   $column Allow-listed column.
	 * @param int|null $user   User id or null for everyone.
	 * @return array{0: string, 1: array<int, mixed>}
	 */
	private static function owner( string $column, ?int $user ): array {
		if ( null === $user ) {
			return array( '', array() );
		}

		return array( ' AND %i = %d', array( $column, $user ) );
	}
}
