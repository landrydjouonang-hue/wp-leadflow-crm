<?php
/**
 * Database transactions.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data;

defined( 'ABSPATH' ) || exit;

/**
 * Runs a callback inside a transaction. Nested calls join the outer
 * transaction. On non-transactional engines the statements simply run.
 */
final class Transaction {

	/**
	 * Nesting depth.
	 *
	 * @var int
	 */
	private static int $depth = 0;

	/**
	 * Runs the callback; commits on success, rolls back on any throwable.
	 *
	 * @template T
	 * @param callable(): T $callback Work to run.
	 * @return T
	 * @throws \Throwable Re-thrown after rollback.
	 */
	public static function run( callable $callback ): mixed {
		global $wpdb;

		if ( self::$depth > 0 ) {
			return $callback();
		}

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Transaction control.
		$wpdb->query( 'START TRANSACTION' );
		++self::$depth;

		try {
			$result = $callback();
			--self::$depth;
			$wpdb->query( 'COMMIT' );

			return $result;
		} catch ( \Throwable $e ) {
			--self::$depth;
			$wpdb->query( 'ROLLBACK' );

			throw $e;
		}
		// phpcs:enable
	}
}
