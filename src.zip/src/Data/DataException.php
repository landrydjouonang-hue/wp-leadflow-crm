<?php
/**
 * Database failure.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data;

defined( 'ABSPATH' ) || exit;

/**
 * Thrown when a query fails at the database level.
 */
final class DataException extends \RuntimeException {

	/**
	 * Builds the exception from the last wpdb error.
	 *
	 * @param string $operation Short description, e.g. "insert into companies".
	 * @return self
	 */
	public static function from_wpdb( string $operation ): self {
		global $wpdb;

		return new self( esc_html( sprintf( 'LeadFlow CRM: %s failed: %s', $operation, (string) $wpdb->last_error ) ) );
	}
}
