<?php
/**
 * Note model.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data\Models;

use LeadFlow\CRM\Data\Model;

defined( 'ABSPATH' ) || exit;

/**
 * A user-written note.
 */
final class Note extends Model {

	/**
	 * Content (sanitized HTML).
	 *
	 * @return string
	 */
	public function content(): string {
		return (string) $this->get( 'content', '' );
	}

	/**
	 * Whether pinned to the top.
	 *
	 * @return bool
	 */
	public function is_pinned(): bool {
		return (bool) $this->get( 'is_pinned', false );
	}
}
