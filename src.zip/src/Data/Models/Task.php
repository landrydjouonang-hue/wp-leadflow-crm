<?php
/**
 * Task model.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data\Models;

use LeadFlow\CRM\Data\Model;

defined( 'ABSPATH' ) || exit;

/**
 * An internal to-do.
 */
final class Task extends Model {

	public const STATUSES   = array( 'pending', 'in_progress', 'completed', 'cancelled' );
	public const PRIORITIES = array( 'low', 'normal', 'high' );

	/** Statuses that count as finished. */
	public const CLOSED_STATUSES = array( 'completed', 'cancelled' );

	/**
	 * Whether the task is finished.
	 *
	 * @return bool
	 */
	public function is_closed(): bool {
		return in_array( $this->get( 'status' ), self::CLOSED_STATUSES, true );
	}

	/**
	 * Whether the task is open and past its due date.
	 *
	 * @return bool
	 */
	public function is_overdue(): bool {
		$due = $this->get( 'due_at' );

		return ! $this->is_closed() && null !== $due && $due < current_time( 'mysql', true );
	}
}
