<?php
/**
 * Lead model.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data\Models;

use LeadFlow\CRM\Data\Model;

defined( 'ABSPATH' ) || exit;

/**
 * A sales opportunity.
 */
final class Lead extends Model {

	public const STATUSES   = array( 'open', 'won', 'lost' );
	public const PRIORITIES = array( 'low', 'normal', 'high' );

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function title(): string {
		return (string) $this->get( 'title', '' );
	}

	/**
	 * Whether the lead is still being worked.
	 *
	 * @return bool
	 */
	public function is_open(): bool {
		return 'open' === $this->get( 'status' );
	}

	/**
	 * Deal value.
	 *
	 * @return float
	 */
	public function amount(): float {
		return (float) $this->get( 'amount', 0 );
	}

	/**
	 * Amount weighted by probability (expected revenue).
	 *
	 * @return float
	 */
	public function weighted_amount(): float {
		$probability = $this->get( 'probability' );

		return null === $probability ? 0.0 : round( $this->amount() * (int) $probability / 100, 2 );
	}
}
