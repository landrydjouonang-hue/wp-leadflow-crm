<?php
/**
 * Email model.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data\Models;

use LeadFlow\CRM\Data\Model;

defined( 'ABSPATH' ) || exit;

/**
 * An email sent (or attempted) from the CRM.
 */
final class Email extends Model {

	public const STATUSES = array( 'sent', 'failed' );

	/**
	 * Subject.
	 *
	 * @return string
	 */
	public function subject(): string {
		return (string) $this->get( 'subject', '' );
	}

	/**
	 * Body (sanitized HTML, placeholders already replaced).
	 *
	 * @return string
	 */
	public function body(): string {
		return (string) $this->get( 'body', '' );
	}

	/**
	 * Recipient address.
	 *
	 * @return string
	 */
	public function to_email(): string {
		return (string) $this->get( 'to_email', '' );
	}

	/**
	 * Recipient as "Name <email>" or just the address.
	 *
	 * @return string
	 */
	public function recipient(): string {
		$name = (string) $this->get( 'to_name', '' );

		return '' !== $name ? sprintf( '%1$s <%2$s>', $name, $this->to_email() ) : $this->to_email();
	}

	/**
	 * Whether delivery to the mail server succeeded.
	 *
	 * @return bool
	 */
	public function is_sent(): bool {
		return 'sent' === $this->get( 'status' );
	}

	/**
	 * Cc addresses.
	 *
	 * @return string[]
	 */
	public function cc(): array {
		return self::split( (string) $this->get( 'cc', '' ) );
	}

	/**
	 * Bcc addresses.
	 *
	 * @return string[]
	 */
	public function bcc(): array {
		return self::split( (string) $this->get( 'bcc', '' ) );
	}

	/**
	 * Splits a stored comma-separated address list.
	 *
	 * @param string $list List.
	 * @return string[]
	 */
	private static function split( string $list ): array {
		return array_values( array_filter( array_map( 'trim', explode( ',', $list ) ) ) );
	}
}
