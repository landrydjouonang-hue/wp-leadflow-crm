<?php
/**
 * Email template model.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data\Models;

use LeadFlow\CRM\Data\Model;

defined( 'ABSPATH' ) || exit;

/**
 * A reusable email with {{placeholders}}.
 */
final class EmailTemplate extends Model {

	public const STATUSES = array( 'active', 'inactive' );

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function name(): string {
		return (string) $this->get( 'name', '' );
	}

	/**
	 * Subject.
	 *
	 * @return string
	 */
	public function subject(): string {
		return (string) $this->get( 'subject', '' );
	}

	/**
	 * Body (sanitized HTML).
	 *
	 * @return string
	 */
	public function body(): string {
		return (string) $this->get( 'body', '' );
	}
}
