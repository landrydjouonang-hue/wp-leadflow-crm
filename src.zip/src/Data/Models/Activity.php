<?php
/**
 * Activity model.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data\Models;

use LeadFlow\CRM\Data\Model;

defined( 'ABSPATH' ) || exit;

/**
 * A timeline entry.
 */
final class Activity extends Model {

	public const TYPES = array( 'note', 'call', 'email', 'meeting', 'task', 'follow_up', 'status_change', 'created', 'updated', 'system' );

	/**
	 * Activity type.
	 *
	 * @return string
	 */
	public function type(): string {
		return (string) $this->get( 'type', '' );
	}

	/**
	 * Extra structured data.
	 *
	 * @return array<string, mixed>
	 */
	public function meta(): array {
		return (array) $this->get( 'meta', array() );
	}
}
