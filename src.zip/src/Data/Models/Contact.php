<?php
/**
 * Contact model.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data\Models;

use LeadFlow\CRM\Data\Model;

defined( 'ABSPATH' ) || exit;

/**
 * A person.
 */
final class Contact extends Model {

	public const STATUSES = array( 'active', 'inactive' );

	/**
	 * "First Last", falling back to the email address.
	 *
	 * @return string
	 */
	public function full_name(): string {
		$name = trim( $this->get( 'first_name', '' ) . ' ' . $this->get( 'last_name', '' ) );

		return '' !== $name ? $name : (string) $this->get( 'email', '' );
	}

	/**
	 * Company id, if any.
	 *
	 * @return int|null
	 */
	public function company_id(): ?int {
		return $this->get( 'company_id' );
	}
}
