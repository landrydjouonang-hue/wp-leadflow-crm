<?php
/**
 * Follow-up model.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data\Models;

use LeadFlow\CRM\Data\Model;

defined( 'ABSPATH' ) || exit;

/**
 * A scheduled customer touchpoint.
 */
final class FollowUp extends Model {

	public const TYPES    = array( 'call', 'email', 'meeting', 'other' );
	public const STATUSES = array( 'scheduled', 'completed', 'cancelled', 'missed' );

	/**
	 * Whether still scheduled and past its time.
	 *
	 * @return bool
	 */
	public function is_overdue(): bool {
		return 'scheduled' === $this->get( 'status' ) && (string) $this->get( 'scheduled_at' ) < current_time( 'mysql', true );
	}

	/**
	 * Whether a reminder should be sent now.
	 *
	 * @return bool
	 */
	public function reminder_due(): bool {
		$remind_at = $this->get( 'remind_at' );

		return 'scheduled' === $this->get( 'status' )
			&& null === $this->get( 'reminder_sent_at' )
			&& null !== $remind_at
			&& $remind_at <= current_time( 'mysql', true );
	}
}
