<?php
/**
 * Company model.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data\Models;

use LeadFlow\CRM\Data\Model;

defined( 'ABSPATH' ) || exit;

/**
 * An organization.
 */
final class Company extends Model {

	public const STATUSES = array( 'prospect', 'customer', 'partner', 'inactive' );

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function name(): string {
		return (string) $this->get( 'name', '' );
	}

	/**
	 * Status.
	 *
	 * @return string
	 */
	public function status(): string {
		return (string) $this->get( 'status', 'prospect' );
	}
}
