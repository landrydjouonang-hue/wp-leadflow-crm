<?php
/**
 * Pipeline stage model.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data\Models;

use LeadFlow\CRM\Data\Model;

defined( 'ABSPATH' ) || exit;

/**
 * A column of the sales pipeline.
 */
final class Stage extends Model {

	/** Stage types; the type decides the lead status. */
	public const TYPES = array( 'open', 'won', 'lost' );

	/**
	 * Name.
	 *
	 * @return string
	 */
	public function name(): string {
		return (string) $this->get( 'name', '' );
	}

	/**
	 * Slug (stable identifier stored on leads).
	 *
	 * @return string
	 */
	public function slug(): string {
		return (string) $this->get( 'slug', '' );
	}

	/**
	 * open | won | lost.
	 *
	 * @return string
	 */
	public function type(): string {
		return (string) $this->get( 'type', 'open' );
	}

	/**
	 * Hex color.
	 *
	 * @return string
	 */
	public function color(): string {
		return (string) $this->get( 'color', '#64748b' );
	}

	/**
	 * Default win probability for leads entering the stage.
	 *
	 * @return int|null
	 */
	public function probability(): ?int {
		$value = $this->get( 'probability' );

		return null === $value ? null : (int) $value;
	}
}
