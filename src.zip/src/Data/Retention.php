<?php
/**
 * Data retention clean-up.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data;

use LeadFlow\CRM\Data\Repositories\CompanyRepository;
use LeadFlow\CRM\Data\Repositories\ContactRepository;
use LeadFlow\CRM\Data\Repositories\EmailTemplateRepository;
use LeadFlow\CRM\Data\Repositories\FollowUpRepository;
use LeadFlow\CRM\Data\Repositories\LeadRepository;
use LeadFlow\CRM\Data\Repositories\NoteRepository;
use LeadFlow\CRM\Data\Repositories\TaskRepository;
use LeadFlow\CRM\Database\Schema;
use LeadFlow\CRM\Database\Table;
use LeadFlow\CRM\Plugin;
use LeadFlow\CRM\Settings\Settings;
use LeadFlow\CRM\Support\Logger;

defined( 'ABSPATH' ) || exit;

/**
 * Deletes data that a site no longer wants to keep:
 *
 * - timeline activities older than N months;
 * - sent emails older than N months;
 * - records that have been in the trash for more than N days.
 *
 * All three are off by default (0 = keep forever) and are configured in
 * *Settings → Data*. The clean-up runs daily through WP-Cron and can be
 * started by hand; it works in batches, so a large site is cleaned over
 * several runs instead of timing out. Trashed records go through their
 * repository, so related rows follow the usual delete rules.
 */
final class Retention {

	/** Daily cron hook. */
	public const CRON_HOOK = 'leadflow_crm_retention';

	/** Option holding the result of the last run. */
	public const LAST_RUN_OPTION = 'leadflow_crm_retention_last';

	/** Rows deleted per table and run. */
	public const BATCH = 500;

	/** Trashed records deleted per run. */
	public const TRASH_BATCH = 200;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( private Plugin $plugin ) {}

	/**
	 * Settings fields and their meaning.
	 *
	 * @return array<string, array{label: string, description: string, unit: string, max: int}>
	 */
	public static function policies(): array {
		return array(
			'retention_activities_months' => array(
				'label'       => __( 'Delete activities older than', 'wp-leadflow-crm' ),
				'description' => __( 'Timeline entries (calls, emails logged, stage changes). 0 keeps them forever.', 'wp-leadflow-crm' ),
				'unit'        => __( 'months', 'wp-leadflow-crm' ),
				'max'         => 120,
			),
			'retention_emails_months'     => array(
				'label'       => __( 'Delete sent emails older than', 'wp-leadflow-crm' ),
				'description' => __( 'Copies of emails sent from the CRM, with their content. 0 keeps them forever.', 'wp-leadflow-crm' ),
				'unit'        => __( 'months', 'wp-leadflow-crm' ),
				'max'         => 120,
			),
			'retention_trash_days'        => array(
				'label'       => __( 'Empty the trash after', 'wp-leadflow-crm' ),
				'description' => __( 'Permanently deletes records that have been in the trash for this long. 0 keeps them until you delete them.', 'wp-leadflow-crm' ),
				'unit'        => __( 'days', 'wp-leadflow-crm' ),
				'max'         => 3650,
			),
		);
	}

	/**
	 * Whether any policy is active.
	 *
	 * @return bool
	 */
	public function active(): bool {
		foreach ( array_keys( self::policies() ) as $key ) {
			if ( $this->months( $key ) > 0 ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Value of a policy setting.
	 *
	 * @param string $key Setting.
	 * @return int
	 */
	private function months( string $key ): int {
		return max( 0, (int) $this->plugin->get( Settings::class )->get( $key, 0 ) );
	}

	/**
	 * Runs the clean-up.
	 *
	 * @return array{activities: int, emails: int, trashed: int, more: bool}
	 */
	public function run(): array {
		$result = array(
			'activities' => 0,
			'emails'     => 0,
			'trashed'    => 0,
			'more'       => false,
		);

		$activities = $this->months( 'retention_activities_months' );
		$emails     = $this->months( 'retention_emails_months' );
		$days       = $this->months( 'retention_trash_days' );

		if ( $activities > 0 ) {
			$result['activities'] = $this->delete_older( Schema::ACTIVITIES, 'occurred_at', $activities * 30 );
		}

		if ( $emails > 0 ) {
			$result['emails'] = $this->delete_older( Schema::EMAILS, 'created_at', $emails * 30 );
		}

		if ( $days > 0 ) {
			$result['trashed'] = $this->empty_trash( $days );
		}

		$result['more'] = self::BATCH === $result['activities'] || self::BATCH === $result['emails'] || self::TRASH_BATCH === $result['trashed'];

		update_option(
			self::LAST_RUN_OPTION,
			array(
				'time'   => time(),
				'counts' => array_slice( $result, 0, 3 ),
			),
			false
		);

		if ( $result['activities'] + $result['emails'] + $result['trashed'] > 0 ) {
			Logger::info( 'Retention clean-up', $result );
		}

		/**
		 * Fires after a retention run.
		 *
		 * @param array<string, int|bool> $result Deleted counts and whether more remain.
		 */
		do_action( 'leadflow_crm_retention_ran', $result );

		return $result;
	}

	/**
	 * Result of the last run.
	 *
	 * @return array{time: int, counts: array<string, int>}|null
	 */
	public static function last_run(): ?array {
		$last = get_option( self::LAST_RUN_OPTION );

		return is_array( $last ) && isset( $last['time'] ) ? $last : null;
	}

	/**
	 * Deletes old rows of an append-only table.
	 *
	 * @param string $table  Short table name.
	 * @param string $column Date column.
	 * @param int    $days   Age in days.
	 * @return int Rows deleted.
	 */
	private function delete_older( string $table, string $column, int $days ): int {
		global $wpdb;

		$before = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Maintenance batch on a custom table.
		$deleted = (int) $wpdb->query( $wpdb->prepare( 'DELETE FROM %i WHERE %i < %s ORDER BY %i ASC LIMIT %d', Table::name( $table ), $column, $before, $column, self::BATCH ) );

		if ( $deleted > 0 ) {
			Repository::flush_cache( $table );
		}

		return $deleted;
	}

	/**
	 * Permanently deletes records trashed long enough, through their
	 * repositories so related rows are handled.
	 *
	 * @param int $days Age in days.
	 * @return int Records deleted.
	 */
	private function empty_trash( int $days ): int {
		global $wpdb;

		$before = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
		$budget = self::TRASH_BATCH;
		$total  = 0;

		// Children first, so parents do not delete rows we already counted.
		$order = array(
			Schema::NOTES           => NoteRepository::class,
			Schema::TASKS           => TaskRepository::class,
			Schema::FOLLOW_UPS      => FollowUpRepository::class,
			Schema::EMAIL_TEMPLATES => EmailTemplateRepository::class,
			Schema::LEADS           => LeadRepository::class,
			Schema::CONTACTS        => ContactRepository::class,
			Schema::COMPANIES       => CompanyRepository::class,
		);

		foreach ( $order as $table => $class ) {
			if ( $budget <= 0 ) {
				break;
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Maintenance batch.
			$ids = $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM %i WHERE deleted_at IS NOT NULL AND deleted_at < %s ORDER BY deleted_at ASC LIMIT %d', Table::name( $table ), $before, $budget ) );

			$repository = $this->plugin->get( $class );

			foreach ( (array) $ids as $id ) {
				try {
					if ( $repository->delete( (int) $id ) ) {
						++$total;
						--$budget;
					}
				} catch ( DataException $e ) {
					Logger::warning( 'Could not delete a trashed record', array( 'table' => $table, 'id' => (int) $id ) );
				}
			}
		}

		return $total;
	}

}
