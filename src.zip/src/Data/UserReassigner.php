<?php
/**
 * Keeps user ownership columns valid when a WordPress user is deleted.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data;

use LeadFlow\CRM\Contracts\Hookable;
use LeadFlow\CRM\Database\Schema;
use LeadFlow\CRM\Database\Table;

defined( 'ABSPATH' ) || exit;

/**
 * User ids are not foreign keys (WordPress manages users, and the users
 * table is shared across a network), so references are maintained here:
 *
 * - ownership/assignment (owner_id, assigned_to) moves to the user chosen
 *   in "Attribute all content to", or becomes NULL;
 * - audit columns (created_by, updated_by, deleted_by, completed_by,
 *   activities.user_id) follow the same rule.
 */
final class UserReassigner implements Hookable {

	/**
	 * User columns per table.
	 */
	public const USER_COLUMNS = array(
		Schema::COMPANIES  => array( 'owner_id', 'created_by', 'updated_by', 'deleted_by' ),
		Schema::CONTACTS   => array( 'owner_id', 'created_by', 'updated_by', 'deleted_by' ),
		Schema::LEADS      => array( 'owner_id', 'created_by', 'updated_by', 'deleted_by' ),
		Schema::ACTIVITIES => array( 'user_id', 'created_by', 'updated_by' ),
		Schema::NOTES      => array( 'created_by', 'updated_by', 'deleted_by' ),
		Schema::TASKS      => array( 'assigned_to', 'completed_by', 'created_by', 'updated_by', 'deleted_by' ),
		Schema::FOLLOW_UPS      => array( 'assigned_to', 'created_by', 'updated_by', 'deleted_by' ),
		Schema::PIPELINE_STAGES => array( 'created_by', 'updated_by' ),
		Schema::EMAIL_TEMPLATES => array( 'created_by', 'updated_by', 'deleted_by' ),
		Schema::EMAILS          => array( 'sent_by', 'created_by', 'updated_by' ),
	);

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_action( 'deleted_user', array( $this, 'on_deleted_user' ), 10, 2 );
	}

	/**
	 * Handles a deleted user on every site that has CRM tables.
	 *
	 * @param int      $user_id  Deleted user.
	 * @param int|null $reassign User receiving the content, or null.
	 * @return void
	 */
	public function on_deleted_user( int $user_id, mixed $reassign = null ): void {
		$reassign = is_numeric( $reassign ) && (int) $reassign > 0 ? (int) $reassign : null;

		if ( ! is_multisite() ) {
			$this->reassign( $user_id, $reassign );
			return;
		}

		foreach ( get_sites(
			array(
				'fields' => 'ids',
				'number' => 0,
			)
		) as $site_id ) {
			switch_to_blog( (int) $site_id );
			$this->reassign( $user_id, $reassign );
			restore_current_blog();
		}
	}

	/**
	 * Rewrites user references on the current site.
	 *
	 * @param int      $user_id  Old user.
	 * @param int|null $reassign New user or null.
	 * @return void
	 */
	public function reassign( int $user_id, ?int $reassign ): void {
		global $wpdb;

		foreach ( self::USER_COLUMNS as $short => $columns ) {
			$table = Table::name( $short );

			if ( ! Table::exists( $table ) ) {
				continue;
			}

			foreach ( $columns as $column ) {
				// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Bulk update of a custom table.
				if ( null === $reassign ) {
					$wpdb->query( $wpdb->prepare( 'UPDATE %i SET %i = NULL WHERE %i = %d', $table, $column, $column, $user_id ) );
				} else {
					$wpdb->query( $wpdb->prepare( 'UPDATE %i SET %i = %d WHERE %i = %d', $table, $column, $reassign, $column, $user_id ) );
				}
				// phpcs:enable
			}

			Repository::flush_cache( $short );
		}
	}
}
