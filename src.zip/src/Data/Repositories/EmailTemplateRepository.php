<?php
/**
 * Email template repository.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data\Repositories;

use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\EmailTemplate;
use LeadFlow\CRM\Data\Repository;
use LeadFlow\CRM\Data\ValidationException;
use LeadFlow\CRM\Database\Schema;
use LeadFlow\CRM\Email\TemplateRenderer;

defined( 'ABSPATH' ) || exit;

/**
 * Data access for email templates. Unknown placeholders are rejected.
 *
 * @method EmailTemplate|null find( int $id, bool $with_trashed = false )
 * @method EmailTemplate      create( array $data )
 * @method EmailTemplate      update( int $id, array $data )
 * @method EmailTemplate[]    query( array $args = array() )
 */
final class EmailTemplateRepository extends Repository {

	protected const TABLE  = Schema::EMAIL_TEMPLATES;
	protected const ENTITY = 'email_template';
	protected const MODEL  = EmailTemplate::class;

	/**
	 * {@inheritDoc}
	 */
	protected function schema(): array {
		return array(
			'name'    => array(
				'type'     => 'string',
				'max'      => 191,
				'required' => true,
			),
			'subject' => array(
				'type'     => 'string',
				'max'      => 255,
				'required' => true,
			),
			'body'    => array(
				'type'     => 'html',
				'required' => true,
			),
			'status'  => array(
				'type'    => 'enum',
				'values'  => EmailTemplate::STATUSES,
				'default' => 'active',
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function searchable(): array {
		return array( 'name', 'subject' );
	}

	/**
	 * Rejects placeholders that do not exist.
	 *
	 * {@inheritDoc}
	 */
	protected function before_save( array $data, ?Model $existing ): array {
		$errors = array();

		foreach ( array( 'subject', 'body' ) as $field ) {
			if ( ! isset( $data[ $field ] ) ) {
				continue;
			}

			$unknown = TemplateRenderer::unknown_placeholders( (string) $data[ $field ] );

			if ( ! empty( $unknown ) ) {
				$errors[ $field ] = sprintf(
					/* translators: %s: Comma-separated placeholders. */
					_n( 'Unknown placeholder: %s', 'Unknown placeholders: %s', count( $unknown ), 'wp-leadflow-crm' ),
					implode( ', ', array_map( static fn( string $p ): string => '{{' . $p . '}}', $unknown ) )
				);
			}
		}

		if ( ! empty( $errors ) ) {
			throw new ValidationException( $errors );
		}

		return $data;
	}

	/**
	 * Sent emails keep their content but lose the template link.
	 *
	 * {@inheritDoc}
	 */
	protected function before_delete( int $id ): void {
		self::unlink( Schema::EMAILS, 'template_id', $id );
	}

	/**
	 * Active templates for pickers.
	 *
	 * @return array<int, string> Id => name.
	 */
	public function active_options(): array {
		$options = array();

		foreach ( $this->query(
			array(
				'where'    => array( 'status' => 'active' ),
				'orderby'  => 'name',
				'order'    => 'ASC',
				'per_page' => self::MAX_PER_PAGE,
			)
		) as $template ) {
			$options[ $template->id() ] = $template->name();
		}

		return $options;
	}
}
