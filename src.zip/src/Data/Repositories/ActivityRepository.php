<?php
/**
 * Activity repository.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data\Repositories;

use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\Activity;
use LeadFlow\CRM\Database\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Data access for the activity timeline. Activities are not soft-deleted.
 *
 * @method Activity|null find( int $id, bool $with_trashed = false )
 * @method Activity      create( array $data )
 * @method Activity[]    query( array $args = array() )
 */
final class ActivityRepository extends RelatedRecordRepository {

	protected const TABLE        = Schema::ACTIVITIES;
	protected const ENTITY       = 'activity';
	protected const MODEL        = Activity::class;
	protected const SOFT_DELETES = false;

	/**
	 * Allowed activity types.
	 *
	 * @return string[]
	 */
	public static function types(): array {
		/**
		 * Filters the allowed activity types.
		 *
		 * @param string[] $types Types.
		 */
		return array_values( array_unique( (array) apply_filters( 'leadflow_crm_activity_types', Activity::TYPES ) ) );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function schema(): array {
		// History may reference trashed records (e.g. "Moved to the trash").
		$parents = array_map(
			static fn( array $def ): array => $def + array( 'allow_trashed' => true ),
			$this->parent_schema()
		);

		return array_merge(
			$parents,
			array(
				'type'        => array(
					'type'     => 'enum',
					'values'   => self::types(),
					'required' => true,
				),
				'subject'     => array(
					'type' => 'string',
					'max'  => 255,
				),
				'description' => array(
					'type'     => 'text',
					'nullable' => true,
				),
				'meta'        => array(
					'type'     => 'json',
					'nullable' => true,
				),
				'user_id'     => array(
					'type'     => 'user',
					'nullable' => true,
				),
				'occurred_at' => array( 'type' => 'datetime' ),
			)
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function searchable(): array {
		return array( 'subject', 'description' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function before_save( array $data, ?Model $existing ): array {
		$data = parent::before_save( $data, $existing );
		$data = self::default_to_current_user( $data, 'user_id', $existing );

		if ( null === $existing && empty( $data['occurred_at'] ) ) {
			$data['occurred_at'] = self::now();
		}

		return $data;
	}

	/**
	 * Records an activity.
	 *
	 * @param string               $type        One of types().
	 * @param array<string, int>   $parents     e.g. array( 'lead_id' => 5 ).
	 * @param string               $subject     Short summary.
	 * @param string               $description Details.
	 * @param array<string, mixed> $meta        Structured data.
	 * @return Activity
	 */
	public function log( string $type, array $parents, string $subject = '', string $description = '', array $meta = array() ): Activity {
		$data = array_merge(
			array_intersect_key( $parents, array_flip( self::PARENTS ) ),
			array(
				'type'        => $type,
				'subject'     => $subject,
				'description' => $description,
				'meta'        => empty( $meta ) ? null : $meta,
			)
		);

		return $this->create( $data );
	}

	/**
	 * Timeline of a parent, newest first.
	 *
	 * @param string $parent company|contact|lead.
	 * @param int    $id     Parent id.
	 * @param int    $limit  Max entries.
	 * @param int    $page   Page.
	 * @return Activity[]
	 */
	public function timeline( string $parent, int $id, int $limit = 50, int $page = 1 ): array {
		return $this->for_parent(
			$parent,
			$id,
			array(
				'orderby'  => 'occurred_at',
				'order'    => 'DESC',
				'per_page' => $limit,
				'page'     => $page,
			)
		);
	}
}
