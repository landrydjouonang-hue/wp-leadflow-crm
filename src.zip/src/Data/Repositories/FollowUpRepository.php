<?php
/**
 * Follow-up repository.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data\Repositories;

use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\FollowUp;
use LeadFlow\CRM\Data\ValidationException;
use LeadFlow\CRM\Database\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Data access for follow-ups.
 *
 * @method FollowUp|null find( int $id, bool $with_trashed = false )
 * @method FollowUp      create( array $data )
 * @method FollowUp      update( int $id, array $data )
 * @method FollowUp[]    query( array $args = array() )
 */
final class FollowUpRepository extends RelatedRecordRepository {

	protected const TABLE  = Schema::FOLLOW_UPS;
	protected const ENTITY = 'follow_up';
	protected const MODEL  = FollowUp::class;

	/**
	 * {@inheritDoc}
	 */
	protected function schema(): array {
		return array_merge(
			$this->parent_schema(),
			array(
				'type'             => array(
					'type'    => 'enum',
					'values'  => FollowUp::TYPES,
					'default' => 'call',
				),
				'subject'          => array(
					'type'     => 'string',
					'max'      => 255,
					'required' => true,
				),
				'notes'            => array(
					'type'     => 'text',
					'nullable' => true,
				),
				'status'           => array(
					'type'    => 'enum',
					'values'  => FollowUp::STATUSES,
					'default' => 'scheduled',
				),
				'scheduled_at'     => array(
					'type'     => 'datetime',
					'required' => true,
				),
				'remind_at'        => array(
					'type'     => 'datetime',
					'nullable' => true,
				),
				'reminder_sent_at' => array(
					'type'     => 'datetime',
					'nullable' => true,
				),
				'completed_at'     => array(
					'type'     => 'datetime',
					'nullable' => true,
				),
				'outcome'          => array(
					'type' => 'string',
					'max'  => 255,
				),
				'assigned_to'      => array(
					'type'     => 'user',
					'nullable' => true,
				),
			)
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function searchable(): array {
		return array( 'subject', 'notes', 'outcome' );
	}

	/**
	 * Assignee default, reminder consistency and completion stamp.
	 *
	 * {@inheritDoc}
	 */
	protected function before_save( array $data, ?Model $existing ): array {
		$data = parent::before_save( $data, $existing );
		$data = self::default_to_current_user( $data, 'assigned_to', $existing );

		$scheduled = $data['scheduled_at'] ?? ( null !== $existing ? $existing->get( 'scheduled_at' ) : null );
		$remind    = array_key_exists( 'remind_at', $data ) ? $data['remind_at'] : ( null !== $existing ? $existing->get( 'remind_at' ) : null );

		if ( null !== $remind && null !== $scheduled && $remind > $scheduled ) {
			throw new ValidationException(
				array( 'remind_at' => __( 'The reminder must be before the scheduled time.', 'wp-leadflow-crm' ) )
			);
		}

		// Rescheduling re-arms the reminder.
		if ( null !== $existing && ( array_key_exists( 'remind_at', $data ) || array_key_exists( 'scheduled_at', $data ) ) && ! array_key_exists( 'reminder_sent_at', $data ) ) {
			$data['reminder_sent_at'] = null;
		}

		if ( isset( $data['status'] ) ) {
			if ( 'completed' === $data['status'] ) {
				$data['completed_at'] = $data['completed_at'] ?? ( null !== $existing && null !== $existing->get( 'completed_at' ) ? $existing->get( 'completed_at' ) : self::now() );
			} else {
				$data['completed_at'] = null;
			}
		}

		return $data;
	}

	/**
	 * Upcoming scheduled follow-ups of a user.
	 *
	 * @param int $user_id User id.
	 * @param int $limit   Max rows.
	 * @return FollowUp[]
	 */
	public function upcoming_for_user( int $user_id, int $limit = 50 ): array {
		return $this->query(
			array(
				'where'    => array(
					'assigned_to'  => $user_id,
					'status'       => 'scheduled',
					'scheduled_at' => array(
						'op'    => '>=',
						'value' => self::now(),
					),
				),
				'orderby'  => 'scheduled_at',
				'order'    => 'ASC',
				'per_page' => $limit,
			)
		);
	}

	/**
	 * Next scheduled follow-up per lead (one query).
	 *
	 * @param int[] $lead_ids Lead ids.
	 * @return array<int, string> Lead id => earliest scheduled_at (UTC).
	 */
	public function next_for_leads( array $lead_ids ): array {
		global $wpdb;

		$lead_ids = array_values( array_filter( array_map( 'intval', $lead_ids ) ) );

		if ( empty( $lead_ids ) ) {
			return array();
		}

		$placeholders = implode( ',', array_fill( 0, count( $lead_ids ), '%d' ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Placeholders only.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT lead_id, MIN(scheduled_at) AS next_at FROM %i WHERE status = 'scheduled' AND deleted_at IS NULL AND lead_id IN ({$placeholders}) GROUP BY lead_id", array_merge( array( $this->table() ), $lead_ids ) ), ARRAY_A );

		$next = array();

		foreach ( (array) $rows as $row ) {
			$next[ (int) $row['lead_id'] ] = (string) $row['next_at'];
		}

		return $next;
	}

	/**
	 * Scheduled follow-ups of a user up to N days ahead (overdue included).
	 *
	 * @param int $user_id User id.
	 * @param int $days    Days ahead.
	 * @param int $limit   Max rows.
	 * @return FollowUp[]
	 */
	public function due_for_user( int $user_id, int $days = 7, int $limit = 10 ): array {
		return $this->query(
			array(
				'where'    => array(
					'assigned_to'  => $user_id,
					'status'       => 'scheduled',
					'scheduled_at' => array(
						'op'    => '<',
						'value' => gmdate( 'Y-m-d H:i:s', time() + $days * DAY_IN_SECONDS ),
					),
				),
				'orderby'  => 'scheduled_at',
				'order'    => 'ASC',
				'per_page' => $limit,
			)
		);
	}

	/**
	 * Follow-ups whose reminder is due and not yet sent.
	 *
	 * @param int $limit Max rows.
	 * @return FollowUp[]
	 */
	public function reminders_due( int $limit = 100 ): array {
		return $this->query(
			array(
				'where'    => array(
					'status'           => 'scheduled',
					'reminder_sent_at' => null,
					'remind_at'        => array(
						'op'    => '<=',
						'value' => self::now(),
					),
				),
				'orderby'  => 'remind_at',
				'order'    => 'ASC',
				'per_page' => $limit,
			)
		);
	}

	/**
	 * Marks a reminder as sent.
	 *
	 * @param int $id Follow-up id.
	 * @return FollowUp
	 */
	public function mark_reminder_sent( int $id ): FollowUp {
		return $this->update( $id, array( 'reminder_sent_at' => self::now() ) );
	}
}
