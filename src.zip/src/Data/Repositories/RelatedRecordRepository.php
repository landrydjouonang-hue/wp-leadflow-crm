<?php
/**
 * Base for records attached to companies, contacts and leads.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data\Repositories;

use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Repository;
use LeadFlow\CRM\Data\ValidationException;
use LeadFlow\CRM\Database\Schema;
use LeadFlow\CRM\Database\Table;

defined( 'ABSPATH' ) || exit;

/**
 * Activities, notes, tasks and follow-ups.
 *
 * Parent inheritance: when a lead is given, its contact and company are
 * filled in; when a contact is given, its company is filled in. This keeps
 * a company's timeline complete (it includes the records of its contacts
 * and leads) without joins.
 */
abstract class RelatedRecordRepository extends Repository {

	/** Parent type => column. */
	public const PARENTS = array(
		'company' => 'company_id',
		'contact' => 'contact_id',
		'lead'    => 'lead_id',
	);

	/** Whether at least one parent is mandatory. */
	protected const REQUIRES_PARENT = true;

	/**
	 * Parent column definitions to merge into schema().
	 *
	 * @return array<string, array<string, mixed>>
	 */
	protected function parent_schema(): array {
		return array(
			'company_id' => array(
				'type'     => 'relation',
				'table'    => Schema::COMPANIES,
				'nullable' => true,
			),
			'contact_id' => array(
				'type'     => 'relation',
				'table'    => Schema::CONTACTS,
				'nullable' => true,
			),
			'lead_id'    => array(
				'type'     => 'relation',
				'table'    => Schema::LEADS,
				'nullable' => true,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function before_save( array $data, ?Model $existing ): array {
		$data = $this->inherit_parents( $data, $existing );

		if ( static::REQUIRES_PARENT ) {
			$has_parent = false;

			foreach ( self::PARENTS as $column ) {
				$value = array_key_exists( $column, $data ) ? $data[ $column ] : ( null !== $existing ? $existing->get( $column ) : null );

				if ( null !== $value ) {
					$has_parent = true;
					break;
				}
			}

			if ( ! $has_parent ) {
				throw new ValidationException(
					array( 'lead_id' => __( 'Please link this record to a company, contact or lead.', 'wp-leadflow-crm' ) )
				);
			}
		}

		return $data;
	}

	/**
	 * Records of one parent.
	 *
	 * @param string               $parent company|contact|lead.
	 * @param int                  $id     Parent id.
	 * @param array<string, mixed> $args   Extra query() arguments.
	 * @return Model[]
	 */
	public function for_parent( string $parent, int $id, array $args = array() ): array {
		return $this->query( $this->parent_args( $parent, $id, $args ) );
	}

	/**
	 * Number of records of one parent.
	 *
	 * @param string               $parent company|contact|lead.
	 * @param int                  $id     Parent id.
	 * @param array<string, mixed> $args   Extra query() arguments.
	 * @return int
	 */
	public function count_for_parent( string $parent, int $id, array $args = array() ): int {
		return $this->count( $this->parent_args( $parent, $id, $args ) );
	}

	/**
	 * Merges a parent filter into query arguments.
	 *
	 * @param string               $parent Parent type.
	 * @param int                  $id     Parent id.
	 * @param array<string, mixed> $args   Arguments.
	 * @return array<string, mixed>
	 */
	private function parent_args( string $parent, int $id, array $args ): array {
		if ( ! isset( self::PARENTS[ $parent ] ) ) {
			throw new \InvalidArgumentException( esc_html( sprintf( 'Unknown parent type "%s".', $parent ) ) );
		}

		$args['where']                            = (array) ( $args['where'] ?? array() );
		$args['where'][ self::PARENTS[ $parent ] ] = $id;

		return $args;
	}

	/**
	 * Fills company/contact from a more specific parent when not given.
	 *
	 * @param array<string, mixed> $data     Validated data.
	 * @param Model|null           $existing Current record.
	 * @return array<string, mixed>
	 */
	private function inherit_parents( array $data, ?Model $existing ): array {
		global $wpdb;

		if ( ! empty( $data['lead_id'] ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Lookup of the parent's own parents.
			$lead = $wpdb->get_row( $wpdb->prepare( 'SELECT company_id, contact_id FROM %i WHERE id = %d', Table::name( Schema::LEADS ), (int) $data['lead_id'] ), ARRAY_A );

			if ( is_array( $lead ) ) {
				foreach ( array( 'contact_id', 'company_id' ) as $column ) {
					if ( empty( $data[ $column ] ) && null !== $lead[ $column ] ) {
						$data[ $column ] = (int) $lead[ $column ];
					}
				}
			}
		}

		if ( ! empty( $data['contact_id'] ) && empty( $data['company_id'] ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Lookup of the parent's own parent.
			$company = $wpdb->get_var( $wpdb->prepare( 'SELECT company_id FROM %i WHERE id = %d', Table::name( Schema::CONTACTS ), (int) $data['contact_id'] ) );

			if ( null !== $company ) {
				$data['company_id'] = (int) $company;
			}
		}

		return $data;
	}
}
