<?php
/**
 * Contact repository.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data\Repositories;

use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\Contact;
use LeadFlow\CRM\Data\Repository;
use LeadFlow\CRM\Data\ValidationException;
use LeadFlow\CRM\Database\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Data access for contacts.
 *
 * @method Contact|null find( int $id, bool $with_trashed = false )
 * @method Contact      create( array $data )
 * @method Contact      update( int $id, array $data )
 * @method Contact[]    query( array $args = array() )
 */
final class ContactRepository extends Repository {

	protected const TABLE  = Schema::CONTACTS;
	protected const ENTITY = 'contact';
	protected const MODEL  = Contact::class;

	/**
	 * {@inheritDoc}
	 */
	protected function schema(): array {
		return array(
			'company_id'     => array(
				'type'     => 'relation',
				'table'    => Schema::COMPANIES,
				'nullable' => true,
			),
			'first_name'     => array(
				'type' => 'string',
				'max'  => 100,
			),
			'last_name'      => array(
				'type' => 'string',
				'max'  => 100,
			),
			'email'          => array(
				'type' => 'email',
				'max'  => 100,
			),
			'phone'          => array(
				'type' => 'phone',
				'max'  => 50,
			),
			'mobile'         => array(
				'type' => 'phone',
				'max'  => 50,
			),
			'job_title'      => array(
				'type' => 'string',
				'max'  => 150,
			),
			'address_line_1' => array(
				'type' => 'string',
				'max'  => 255,
			),
			'address_line_2' => array(
				'type' => 'string',
				'max'  => 255,
			),
			'city'           => array(
				'type' => 'string',
				'max'  => 100,
			),
			'state'          => array(
				'type' => 'string',
				'max'  => 100,
			),
			'postal_code'    => array(
				'type' => 'string',
				'max'  => 20,
			),
			'country'        => array( 'type' => 'country' ),
			'source'         => array(
				'type' => 'slug',
				'max'  => 50,
			),
			'status'         => array(
				'type'    => 'enum',
				'values'  => Contact::STATUSES,
				'default' => 'active',
			),
			'owner_id'       => array(
				'type'     => 'user',
				'nullable' => true,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function searchable(): array {
		return array( 'first_name', 'last_name', 'email', 'phone', 'mobile' );
	}

	/**
	 * A contact needs a first name, last name or email address.
	 *
	 * {@inheritDoc}
	 */
	protected function before_save( array $data, ?Model $existing ): array {
		$identity = '';

		foreach ( array( 'first_name', 'last_name', 'email' ) as $column ) {
			$identity .= array_key_exists( $column, $data ) ? (string) $data[ $column ] : ( null !== $existing ? (string) $existing->get( $column, '' ) : '' );
		}

		if ( '' === trim( $identity ) ) {
			throw new ValidationException(
				array( 'first_name' => __( 'Please enter a name or an email address.', 'wp-leadflow-crm' ) )
			);
		}

		return self::default_to_current_user( $data, 'owner_id', $existing );
	}

	/**
	 * Leads are unlinked (kept); records that belong only to this contact
	 * are removed, records that also belong to a lead are unlinked.
	 *
	 * @param int $id Contact id.
	 * @return void
	 */
	protected function before_delete( int $id ): void {
		self::detach_related( 'contact_id', $id, array( 'lead_id' ) );
		self::unlink( Schema::LEADS, 'contact_id', $id );
	}
}
