<?php
/**
 * Task repository.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data\Repositories;

use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\Task;
use LeadFlow\CRM\Database\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Data access for tasks. Tasks may exist without a parent.
 *
 * @method Task|null find( int $id, bool $with_trashed = false )
 * @method Task      create( array $data )
 * @method Task      update( int $id, array $data )
 * @method Task[]    query( array $args = array() )
 */
final class TaskRepository extends RelatedRecordRepository {

	protected const TABLE           = Schema::TASKS;
	protected const ENTITY          = 'task';
	protected const MODEL           = Task::class;
	protected const REQUIRES_PARENT = false;

	/**
	 * {@inheritDoc}
	 */
	protected function schema(): array {
		return array_merge(
			$this->parent_schema(),
			array(
				'title'        => array(
					'type'     => 'string',
					'max'      => 255,
					'required' => true,
				),
				'description'  => array(
					'type'     => 'text',
					'nullable' => true,
				),
				'status'       => array(
					'type'    => 'enum',
					'values'  => Task::STATUSES,
					'default' => 'pending',
				),
				'priority'     => array(
					'type'    => 'enum',
					'values'  => Task::PRIORITIES,
					'default' => 'normal',
				),
				'due_at'       => array(
					'type'     => 'datetime',
					'nullable' => true,
				),
				'completed_at' => array(
					'type'     => 'datetime',
					'nullable' => true,
				),
				'completed_by' => array(
					'type'     => 'user',
					'nullable' => true,
				),
				'assigned_to'  => array(
					'type'     => 'user',
					'nullable' => true,
				),
			)
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function searchable(): array {
		return array( 'title', 'description' );
	}

	/**
	 * Assignee default and completion stamps.
	 *
	 * {@inheritDoc}
	 */
	protected function before_save( array $data, ?Model $existing ): array {
		$data = parent::before_save( $data, $existing );
		$data = self::default_to_current_user( $data, 'assigned_to', $existing );

		if ( isset( $data['status'] ) ) {
			$was_completed = null !== $existing && 'completed' === $existing->get( 'status' );

			if ( 'completed' === $data['status'] && ! $was_completed ) {
				$data['completed_at'] = $data['completed_at'] ?? self::now();
				$data['completed_by'] = $data['completed_by'] ?? self::current_user();
			} elseif ( 'completed' !== $data['status'] ) {
				$data['completed_at'] = null;
				$data['completed_by'] = null;
			}
		}

		return $data;
	}

	/**
	 * Open tasks of a user, soonest due first (undated last).
	 *
	 * @param int $user_id User id.
	 * @param int $limit   Max tasks.
	 * @return Task[]
	 */
	public function open_for_user( int $user_id, int $limit = 50 ): array {
		$tasks = $this->query(
			array(
				'where'    => array(
					'assigned_to' => $user_id,
					'status'      => array(
						'op'    => 'NOT IN',
						'value' => Task::CLOSED_STATUSES,
					),
				),
				'orderby'  => 'due_at',
				'order'    => 'ASC',
				'per_page' => $limit,
			)
		);

		usort(
			$tasks,
			static fn( Task $a, Task $b ): int => ( null === $a->get( 'due_at' ) ) <=> ( null === $b->get( 'due_at' ) )
		);

		return $tasks;
	}

	/**
	 * Query arguments matching open tasks past their due date.
	 *
	 * @param int|null $user_id Limit to an assignee.
	 * @return array<string, mixed>
	 */
	public static function overdue_args( ?int $user_id = null ): array {
		$where = array(
			'status' => array(
				'op'    => 'NOT IN',
				'value' => Task::CLOSED_STATUSES,
			),
			'due_at' => array(
				'op'    => '<',
				'value' => self::now(),
			),
		);

		if ( null !== $user_id ) {
			$where['assigned_to'] = $user_id;
		}

		return array( 'where' => $where );
	}

	/**
	 * Number of overdue tasks.
	 *
	 * @param int|null $user_id Limit to an assignee.
	 * @return int
	 */
	public function overdue_count( ?int $user_id = null ): int {
		return $this->count( self::overdue_args( $user_id ) );
	}

	/**
	 * Open tasks past their due date.
	 *
	 * @param int|null $user_id Limit to an assignee.
	 * @param int      $limit   Max tasks.
	 * @return Task[]
	 */
	public function overdue( ?int $user_id = null, int $limit = 100 ): array {
		$where = array(
			'status' => array(
				'op'    => 'NOT IN',
				'value' => Task::CLOSED_STATUSES,
			),
			'due_at' => array(
				'op'    => '<',
				'value' => self::now(),
			),
		);

		if ( null !== $user_id ) {
			$where['assigned_to'] = $user_id;
		}

		return $this->query(
			array(
				'where'    => $where,
				'orderby'  => 'due_at',
				'order'    => 'ASC',
				'per_page' => $limit,
			)
		);
	}
}
