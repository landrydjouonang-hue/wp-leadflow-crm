<?php
/**
 * Note repository.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data\Repositories;

use LeadFlow\CRM\Data\Models\Note;
use LeadFlow\CRM\Database\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Data access for notes.
 *
 * @method Note|null find( int $id, bool $with_trashed = false )
 * @method Note      create( array $data )
 * @method Note      update( int $id, array $data )
 * @method Note[]    query( array $args = array() )
 */
final class NoteRepository extends RelatedRecordRepository {

	protected const TABLE  = Schema::NOTES;
	protected const ENTITY = 'note';
	protected const MODEL  = Note::class;

	/**
	 * {@inheritDoc}
	 */
	protected function schema(): array {
		return array_merge(
			$this->parent_schema(),
			array(
				'content'   => array(
					'type'     => 'html',
					'required' => true,
				),
				'is_pinned' => array( 'type' => 'bool' ),
			)
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function searchable(): array {
		return array( 'content' );
	}

	/**
	 * Notes of a parent: pinned first, then newest first.
	 *
	 * @param string $parent company|contact|lead.
	 * @param int    $id     Parent id.
	 * @param int    $limit  Max notes.
	 * @return Note[]
	 */
	public function for_parent_pinned_first( string $parent, int $id, int $limit = 50 ): array {
		$notes = $this->for_parent(
			$parent,
			$id,
			array(
				'orderby'  => 'created_at',
				'order'    => 'DESC',
				'per_page' => $limit,
			)
		);

		usort(
			$notes,
			static fn( Note $a, Note $b ): int => (int) $b->is_pinned() <=> (int) $a->is_pinned()
		);

		return $notes;
	}
}
