<?php
/**
 * Pipeline stage repository.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data\Repositories;

use LeadFlow\CRM\Data\DataException;
use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\Stage;
use LeadFlow\CRM\Data\Repository;
use LeadFlow\CRM\Data\Transaction;
use LeadFlow\CRM\Data\ValidationException;
use LeadFlow\CRM\Database\Schema;
use LeadFlow\CRM\Database\Table;

defined( 'ABSPATH' ) || exit;

/**
 * Data access for pipeline stages (hard deletes; leads must be moved first).
 *
 * @method Stage|null find( int $id, bool $with_trashed = false )
 * @method Stage      create( array $data )
 * @method Stage      update( int $id, array $data )
 */
final class StageRepository extends Repository {

	protected const TABLE        = Schema::PIPELINE_STAGES;
	protected const ENTITY       = 'stage';
	protected const MODEL        = Stage::class;
	protected const SOFT_DELETES = false;

	/**
	 * Per-request cache of all stages, ordered.
	 *
	 * @var Stage[]|null
	 */
	private ?array $all = null;

	/**
	 * {@inheritDoc}
	 */
	protected function schema(): array {
		return array(
			'name'        => array(
				'type'     => 'string',
				'max'      => 100,
				'required' => true,
			),
			'slug'        => array(
				'type' => 'slug',
				'max'  => 50,
			),
			'color'       => array(
				'type'    => 'color',
				'default' => '#64748b',
			),
			'probability' => array(
				'type'     => 'int',
				'min'      => 0,
				'max'      => 100,
				'nullable' => true,
			),
			'type'        => array(
				'type'    => 'enum',
				'values'  => Stage::TYPES,
				'default' => 'open',
			),
			'position'    => array( 'type' => 'int' ),
		);
	}

	/**
	 * Slug is generated from the name on create, unique and immutable.
	 *
	 * {@inheritDoc}
	 */
	protected function before_save( array $data, ?Model $existing ): array {
		global $wpdb;

		if ( null !== $existing ) {
			unset( $data['slug'] );
			$this->all = null;

			return $data;
		}

		$base = '' !== (string) ( $data['slug'] ?? '' ) ? (string) $data['slug'] : sanitize_title( (string) $data['name'] );
		$base = substr( '' !== $base ? $base : 'stage', 0, 40 );
		$slug = $base;
		$i    = 2;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Uniqueness check.
		while ( null !== $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM %i WHERE slug = %s', $this->table(), $slug ) ) ) {
			$slug = $base . '-' . $i++;
		}

		$data['slug'] = $slug;

		if ( empty( $data['position'] ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Next position.
			$data['position'] = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COALESCE(MAX(position), 0) + 10 FROM %i', $this->table() ) );
		}

		$this->all = null;

		return $data;
	}

	/**
	 * All stages in pipeline order.
	 *
	 * @return Stage[]
	 */
	public function all(): array {
		if ( null === $this->all ) {
			$this->all = $this->query(
				array(
					'orderby'  => 'position',
					'order'    => 'ASC',
					'per_page' => self::MAX_PER_PAGE,
				)
			);

			// query() orders by position then id DESC; keep ties stable by id ASC.
			usort( $this->all, static fn( Stage $a, Stage $b ): int => array( $a->get( 'position' ), $a->id() ) <=> array( $b->get( 'position' ), $b->id() ) );
		}

		return $this->all;
	}

	/**
	 * Forgets the per-request stage list (after external changes).
	 *
	 * @return void
	 */
	public function flush_local(): void {
		$this->all = null;
	}

	/**
	 * Stage by slug.
	 *
	 * @param string $slug Slug.
	 * @return Stage|null
	 */
	public function find_by_slug( string $slug ): ?Stage {
		foreach ( $this->all() as $stage ) {
			if ( $stage->slug() === $slug ) {
				return $stage;
			}
		}

		return null;
	}

	/**
	 * First stage of a type in pipeline order.
	 *
	 * @param string $type open|won|lost.
	 * @return Stage|null
	 */
	public function first_of_type( string $type ): ?Stage {
		foreach ( $this->all() as $stage ) {
			if ( $stage->type() === $type ) {
				return $stage;
			}
		}

		return null;
	}

	/**
	 * Slug => name map (for selects).
	 *
	 * @return array<string, string>
	 */
	public function options(): array {
		$options = array();

		foreach ( $this->all() as $stage ) {
			$options[ $stage->slug() ] = $stage->name();
		}

		return $options;
	}

	/**
	 * Number of (non-trashed and trashed) leads per stage slug.
	 *
	 * @return array<string, int>
	 */
	public function lead_counts(): array {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Aggregate.
		$rows   = $wpdb->get_results( $wpdb->prepare( 'SELECT stage, COUNT(*) AS total FROM %i GROUP BY stage', Table::name( Schema::LEADS ) ), ARRAY_A );
		$counts = array();

		foreach ( (array) $rows as $row ) {
			$counts[ (string) $row['stage'] ] = (int) $row['total'];
		}

		return $counts;
	}

	/**
	 * Applies a full stage configuration atomically.
	 *
	 * @param array<int, array<string, mixed>> $rows    Existing stages: id => fields (name, color, probability, type).
	 * @param int[]                            $order   Stage ids in the desired order (existing ids; new rows appended).
	 * @param array<int, array<string, mixed>> $new     New stages to add.
	 * @param array<int, string>               $deletes Stage id => slug to move its leads to.
	 * @return void
	 * @throws ValidationException When the result would be invalid.
	 */
	public function apply_configuration( array $rows, array $order, array $new, array $deletes ): void {
		$current = array();

		foreach ( $this->all() as $stage ) {
			$current[ $stage->id() ] = $stage;
		}

		// Resulting types, to enforce at least one open, won and lost stage.
		$types = array();
		foreach ( $current as $id => $stage ) {
			if ( ! isset( $deletes[ $id ] ) ) {
				$types[] = (string) ( $rows[ $id ]['type'] ?? $stage->type() );
			}
		}
		foreach ( $new as $row ) {
			$types[] = (string) ( $row['type'] ?? 'open' );
		}

		$missing = array_diff( Stage::TYPES, $types );

		if ( ! empty( $missing ) ) {
			throw new ValidationException(
				array( 'stages' => __( 'The pipeline needs at least one open stage, one won stage and one lost stage.', 'wp-leadflow-crm' ) )
			);
		}

		foreach ( $deletes as $id => $target ) {
			if ( ! isset( $current[ $id ] ) ) {
				continue;
			}

			$target_ok = false;
			foreach ( $current as $other_id => $other ) {
				if ( $other_id !== $id && ! isset( $deletes[ $other_id ] ) && $other->slug() === $target ) {
					$target_ok = true;
				}
			}

			$has_leads = ( $this->lead_counts()[ $current[ $id ]->slug() ] ?? 0 ) > 0;

			if ( $has_leads && ! $target_ok ) {
				throw new ValidationException(
					array(
						/* translators: %s: Stage name. */
						'stages' => sprintf( __( 'Choose where to move the leads of “%s” before deleting it.', 'wp-leadflow-crm' ), $current[ $id ]->name() ),
					)
				);
			}
		}

		Transaction::run(
			function () use ( $current, $rows, $order, $new, $deletes ): void {
				global $wpdb;

				$position = 10;

				foreach ( $order as $id ) {
					if ( isset( $current[ $id ] ) && ! isset( $deletes[ $id ] ) ) {
						$this->update( $id, array_merge( (array) ( $rows[ $id ] ?? array() ), array( 'position' => $position ) ) );
						$position += 10;
					}
				}

				foreach ( $new as $row ) {
					$this->create( array_merge( $row, array( 'position' => $position ) ) );
					$position += 10;
				}

				foreach ( $deletes as $id => $target ) {
					if ( ! isset( $current[ $id ] ) ) {
						continue;
					}

					$slug = $current[ $id ]->slug();

					if ( '' !== $target ) {
						$stage = $this->find_by_slug( $target );

						// Status follows the stage type; closed_at is set on close, cleared on reopen.
						// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Bulk move of leads.
						if ( null !== $stage && false === $wpdb->query( $wpdb->prepare( "UPDATE %i SET stage = %s, status = %s, closed_at = CASE WHEN %s = 'open' THEN NULL ELSE COALESCE(closed_at, UTC_TIMESTAMP()) END WHERE stage = %s", Table::name( Schema::LEADS ), $target, $stage->type(), $stage->type(), $slug ) ) ) {
							throw DataException::from_wpdb( 'move leads' );
						}

						Repository::flush_cache( Schema::LEADS );
					}

					$this->delete( $id );
				}
			}
		);

		$this->all = null;
	}
}
