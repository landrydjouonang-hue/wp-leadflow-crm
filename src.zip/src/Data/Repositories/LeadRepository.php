<?php
/**
 * Lead repository.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data\Repositories;

use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\Lead;
use LeadFlow\CRM\Data\RecordNotFoundException;
use LeadFlow\CRM\Data\Repository;
use LeadFlow\CRM\Data\Transaction;
use LeadFlow\CRM\Data\ValidationException;
use LeadFlow\CRM\Database\Schema;
use LeadFlow\CRM\Database\Table;
use LeadFlow\CRM\Settings\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Data access for leads.
 *
 * Stage rules:
 * - `stage` must be the slug of an existing pipeline stage;
 * - `status` always follows the stage type (open/won/lost). Setting only
 *   the status moves the lead to the first stage of that type;
 * - entering a stage sets the stage's default probability unless one is given;
 * - won/lost stamps `closed_at`, reopening clears it;
 * - `position` orders cards inside a pipeline column (gaps of 1024).
 *
 * @method Lead|null find( int $id, bool $with_trashed = false )
 * @method Lead      create( array $data )
 * @method Lead      update( int $id, array $data )
 * @method Lead[]    query( array $args = array() )
 */
final class LeadRepository extends Repository {

	protected const TABLE  = Schema::LEADS;
	protected const ENTITY = 'lead';
	protected const MODEL  = Lead::class;

	/** Gap between card positions. */
	public const POSITION_GAP = 1024;

	/**
	 * Constructor.
	 *
	 * @param Settings        $settings Settings (default currency).
	 * @param StageRepository $stages   Pipeline stages.
	 */
	public function __construct(
		private Settings $settings,
		private StageRepository $stages
	) {}

	/**
	 * {@inheritDoc}
	 */
	protected function schema(): array {
		return array(
			'title'               => array(
				'type'     => 'string',
				'max'      => 191,
				'required' => true,
			),
			'company_id'          => array(
				'type'     => 'relation',
				'table'    => Schema::COMPANIES,
				'nullable' => true,
			),
			'contact_id'          => array(
				'type'     => 'relation',
				'table'    => Schema::CONTACTS,
				'nullable' => true,
			),
			'email'               => array(
				'type' => 'email',
				'max'  => 100,
			),
			'phone'               => array(
				'type' => 'phone',
				'max'  => 50,
			),
			'status'              => array(
				'type'    => 'enum',
				'values'  => Lead::STATUSES,
				'default' => 'open',
			),
			'stage'               => array(
				'type' => 'slug',
				'max'  => 50,
			),
			'position'            => array( 'type' => 'int' ),
			'source'              => array(
				'type' => 'slug',
				'max'  => 50,
			),
			'priority'            => array(
				'type'    => 'enum',
				'values'  => Lead::PRIORITIES,
				'default' => 'normal',
			),
			'amount'              => array(
				'type' => 'decimal',
				'min'  => 0,
				'max'  => 9999999999999.99,
			),
			'currency'            => array( 'type' => 'currency' ),
			'probability'         => array(
				'type'     => 'int',
				'min'      => 0,
				'max'      => 100,
				'nullable' => true,
			),
			'expected_close_date' => array(
				'type'     => 'date',
				'nullable' => true,
			),
			'closed_at'           => array(
				'type'     => 'datetime',
				'nullable' => true,
			),
			'lost_reason'         => array(
				'type' => 'string',
				'max'  => 255,
			),
			'description'         => array(
				'type'     => 'text',
				'nullable' => true,
			),
			'owner_id'            => array(
				'type'     => 'user',
				'nullable' => true,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function searchable(): array {
		return array( 'title', 'email', 'phone', 'source' );
	}

	/**
	 * Defaults, parent inheritance, stage/status sync and closing logic.
	 *
	 * {@inheritDoc}
	 */
	protected function before_save( array $data, ?Model $existing ): array {
		global $wpdb;

		$data = self::default_to_current_user( $data, 'owner_id', $existing );

		if ( null === $existing && empty( $data['currency'] ) ) {
			$data['currency'] = strtoupper( (string) $this->settings->get( 'default_currency', 'USD' ) );
		}

		// Inherit company, email and phone from the contact when missing.
		if ( ! empty( $data['contact_id'] ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Parent lookup.
			$contact = $wpdb->get_row( $wpdb->prepare( 'SELECT company_id, email, phone, mobile FROM %i WHERE id = %d', Table::name( Schema::CONTACTS ), (int) $data['contact_id'] ), ARRAY_A );

			if ( is_array( $contact ) ) {
				$company_after = array_key_exists( 'company_id', $data ) ? $data['company_id'] : $existing?->get( 'company_id' );

				if ( null === $company_after && null !== $contact['company_id'] ) {
					$data['company_id'] = (int) $contact['company_id'];
				}

				if ( null === $existing ) {
					if ( empty( $data['email'] ) ) {
						$data['email'] = (string) $contact['email'];
					}

					if ( empty( $data['phone'] ) ) {
						$data['phone'] = '' !== (string) $contact['phone'] ? (string) $contact['phone'] : (string) $contact['mobile'];
					}
				}
			}
		}

		$data = $this->sync_stage( $data, $existing );

		// Closing: won/lost stamps closed_at, reopening clears it.
		if ( isset( $data['status'] ) ) {
			$was_open = null === $existing || 'open' === $existing->get( 'status' );

			if ( 'open' === $data['status'] ) {
				$data['closed_at'] = null;
			} elseif ( $was_open && empty( $data['closed_at'] ) ) {
				$data['closed_at'] = self::now();
			}
		}

		return $data;
	}

	/**
	 * Keeps stage, status, probability and position consistent.
	 *
	 * @param array<string, mixed> $data     Data being saved.
	 * @param Model|null           $existing Current record.
	 * @return array<string, mixed>
	 * @throws ValidationException When the stage does not exist.
	 */
	private function sync_stage( array $data, ?Model $existing ): array {
		$stage_given  = isset( $data['stage'] ) && '' !== $data['stage'];
		$status_given = array_key_exists( 'status', $data ) && ( null === $existing || $data['status'] !== $existing->get( 'status' ) );

		if ( $stage_given ) {
			$stage = $this->stages->find_by_slug( (string) $data['stage'] );

			if ( null === $stage ) {
				throw new ValidationException( array( 'stage' => __( 'Please choose a valid pipeline stage.', 'wp-leadflow-crm' ) ) );
			}
		} elseif ( null === $existing || $status_given ) {
			// No stage given: use the first stage matching the (new) status.
			$status = (string) ( $data['status'] ?? $existing?->get( 'status' ) ?? 'open' );

			if ( null !== $existing && $this->stage_type( (string) $existing->get( 'stage' ) ) === $status ) {
				return $data;
			}

			$stage = $this->stages->first_of_type( $status );

			if ( null === $stage ) {
				throw new ValidationException( array( 'stage' => __( 'The pipeline has no stage for this status.', 'wp-leadflow-crm' ) ) );
			}

			$data['stage'] = $stage->slug();
		} else {
			unset( $data['stage'] );

			return $data;
		}

		$changed = null === $existing || $stage->slug() !== $existing->get( 'stage' );

		$data['status'] = $stage->type();

		if ( $changed ) {
			// An empty probability means "use the stage default".
			$explicit_probability = null !== ( $data['probability'] ?? null );

			if ( ! $explicit_probability && null !== $stage->probability() ) {
				$data['probability'] = $stage->probability();
			}

			// On update any given position wins (0 is valid); on create, 0 means "not given".
			$position_given = array_key_exists( 'position', $data ) && ( null !== $existing || 0 !== (int) $data['position'] );

			if ( ! $position_given ) {
				$data['position'] = $this->top_position( $stage->slug() );
			}
		}

		return $data;
	}

	/**
	 * Type of a stage slug ('' if unknown).
	 *
	 * @param string $slug Slug.
	 * @return string
	 */
	private function stage_type( string $slug ): string {
		$stage = $this->stages->find_by_slug( $slug );

		return null === $stage ? '' : $stage->type();
	}

	/**
	 * Every related record of the lead is removed with it.
	 *
	 * @param int $id Lead id.
	 * @return void
	 */
	protected function before_delete( int $id ): void {
		self::detach_related( 'lead_id', $id, array() );
	}

	// ---------------------------------------------------------------------
	// Pipeline.
	// ---------------------------------------------------------------------

	/**
	 * Moves a lead to a stage, optionally before another card.
	 *
	 * @param int      $id        Lead id.
	 * @param string   $stage     Target stage slug.
	 * @param int|null $before_id Card to place the lead before (null = end of column).
	 * @return Lead
	 * @throws RecordNotFoundException When the lead does not exist or is trashed.
	 * @throws ValidationException     When the stage does not exist.
	 */
	public function move( int $id, string $stage, ?int $before_id = null ): Lead {
		return Transaction::run(
			function () use ( $id, $stage, $before_id ): Lead {
				if ( null === $this->find( $id ) ) {
					throw new RecordNotFoundException( static::ENTITY, $id );
				}

				if ( null === $this->stages->find_by_slug( $stage ) ) {
					throw new ValidationException( array( 'stage' => __( 'Please choose a valid pipeline stage.', 'wp-leadflow-crm' ) ) );
				}

				return $this->update(
					$id,
					array(
						'stage'    => $stage,
						'position' => $this->position_before( $stage, $id, $before_id ),
					)
				);
			}
		);
	}

	/**
	 * Position that places a card before $before_id (or at the end).
	 *
	 * @param string   $stage     Stage slug.
	 * @param int      $moving_id Lead being moved (excluded).
	 * @param int|null $before_id Neighbour below the drop point.
	 * @return int
	 */
	private function position_before( string $stage, int $moving_id, ?int $before_id ): int {
		global $wpdb;

		$before = null !== $before_id && $before_id !== $moving_id ? $this->find( $before_id ) : null;

		if ( null === $before || $before->get( 'stage' ) !== $stage ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Column bounds.
			$max = $wpdb->get_var( $wpdb->prepare( 'SELECT MAX(position) FROM %i WHERE stage = %s AND id <> %d AND deleted_at IS NULL', $this->table(), $stage, $moving_id ) );

			return null === $max ? 0 : (int) $max + self::POSITION_GAP;
		}

		for ( $attempt = 0; $attempt < 2; $attempt++ ) {
			$next = (int) $this->find( $before->id() )->get( 'position' );

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Neighbour lookup.
			$prev = $wpdb->get_var( $wpdb->prepare( 'SELECT MAX(position) FROM %i WHERE stage = %s AND position < %d AND id <> %d AND deleted_at IS NULL', $this->table(), $stage, $next, $moving_id ) );
			$prev = null === $prev ? $next - 2 * self::POSITION_GAP : (int) $prev;

			if ( $next - $prev > 1 ) {
				return intdiv( $prev + $next, 2 );
			}

			$this->renumber( $stage );
		}

		return (int) $this->find( $before->id() )->get( 'position' ) - 1;
	}

	/**
	 * Position at the top of a column.
	 *
	 * @param string $stage Stage slug.
	 * @return int
	 */
	private function top_position( string $stage ): int {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Column bounds.
		$min = $wpdb->get_var( $wpdb->prepare( 'SELECT MIN(position) FROM %i WHERE stage = %s AND deleted_at IS NULL', $this->table(), $stage ) );

		return null === $min ? 0 : (int) $min - self::POSITION_GAP;
	}

	/**
	 * Re-spaces the positions of a column (keeps the current order).
	 *
	 * @param string $stage Stage slug.
	 * @return void
	 */
	private function renumber( string $stage ): void {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Column order.
		$ids = $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM %i WHERE stage = %s AND deleted_at IS NULL ORDER BY position ASC, id ASC', $this->table(), $stage ) );

		foreach ( (array) $ids as $index => $lead_id ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Cosmetic reorder, no audit change.
			$wpdb->update( $this->table(), array( 'position' => ( $index + 1 ) * self::POSITION_GAP ), array( 'id' => (int) $lead_id ), array( '%d' ), array( '%d' ) );
		}

		self::flush_cache( static::TABLE );
	}

	/**
	 * Count and value per stage, honouring the same filters as query().
	 *
	 * @param array<string, mixed> $args Query arguments (where, search).
	 * @return array<string, array{count: int, amounts: array<string, float>}> Stage slug => totals.
	 */
	public function stage_totals( array $args = array() ): array {
		global $wpdb;

		$params = array( $this->table() );
		$where  = $this->build_where( $args, $params );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $where is built from placeholders.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT stage, currency, COUNT(*) AS total, SUM(amount) AS value FROM %i WHERE {$where} GROUP BY stage, currency", $params ), ARRAY_A );

		$totals = array();

		foreach ( (array) $rows as $row ) {
			$stage = (string) $row['stage'];

			$totals[ $stage ]['count']                              = ( $totals[ $stage ]['count'] ?? 0 ) + (int) $row['total'];
			$totals[ $stage ]['amounts'][ (string) $row['currency'] ] = (float) $row['value'];
		}

		return $totals;
	}

	/**
	 * Sum of open deal values per currency.
	 *
	 * @return array<string, float> Currency => total.
	 */
	public function open_value_by_currency(): array {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Aggregate over a custom table.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT currency, SUM(amount) AS total FROM %i WHERE status = 'open' AND deleted_at IS NULL GROUP BY currency", $this->table() ), ARRAY_A );

		$totals = array();

		foreach ( (array) $rows as $row ) {
			$totals[ (string) $row['currency'] ] = (float) $row['total'];
		}

		return $totals;
	}
}
