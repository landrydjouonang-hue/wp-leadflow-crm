<?php
/**
 * Company repository.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data\Repositories;

use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\Company;
use LeadFlow\CRM\Data\Repository;
use LeadFlow\CRM\Database\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Data access for companies.
 *
 * @method Company|null find( int $id, bool $with_trashed = false )
 * @method Company      create( array $data )
 * @method Company      update( int $id, array $data )
 * @method Company[]    query( array $args = array() )
 */
final class CompanyRepository extends Repository {

	protected const TABLE  = Schema::COMPANIES;
	protected const ENTITY = 'company';
	protected const MODEL  = Company::class;

	/**
	 * {@inheritDoc}
	 */
	protected function schema(): array {
		return array(
			'name'           => array(
				'type'     => 'string',
				'max'      => 191,
				'required' => true,
			),
			'industry'       => array(
				'type' => 'string',
				'max'  => 100,
			),
			'website'        => array(
				'type' => 'url',
				'max'  => 255,
			),
			'email'          => array(
				'type' => 'email',
				'max'  => 100,
			),
			'phone'          => array(
				'type' => 'phone',
				'max'  => 50,
			),
			'address_line_1' => array(
				'type' => 'string',
				'max'  => 255,
			),
			'address_line_2' => array(
				'type' => 'string',
				'max'  => 255,
			),
			'city'           => array(
				'type' => 'string',
				'max'  => 100,
			),
			'state'          => array(
				'type' => 'string',
				'max'  => 100,
			),
			'postal_code'    => array(
				'type' => 'string',
				'max'  => 20,
			),
			'country'        => array( 'type' => 'country' ),
			'description'    => array(
				'type'     => 'text',
				'nullable' => true,
			),
			'status'         => array(
				'type'    => 'enum',
				'values'  => Company::STATUSES,
				'default' => 'prospect',
			),
			'owner_id'       => array(
				'type'     => 'user',
				'nullable' => true,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function searchable(): array {
		return array( 'name', 'email', 'website', 'phone', 'city' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function before_save( array $data, ?Model $existing ): array {
		return self::default_to_current_user( $data, 'owner_id', $existing );
	}

	/**
	 * Contacts and leads are unlinked (kept); records that belong only to
	 * this company are removed, the others are unlinked.
	 *
	 * @param int $id Company id.
	 * @return void
	 */
	protected function before_delete( int $id ): void {
		self::detach_related( 'company_id', $id, array( 'contact_id', 'lead_id' ) );
		self::unlink( Schema::CONTACTS, 'company_id', $id );
		self::unlink( Schema::LEADS, 'company_id', $id );
	}
}
