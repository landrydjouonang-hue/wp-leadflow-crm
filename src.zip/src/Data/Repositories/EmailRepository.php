<?php
/**
 * Email log repository.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data\Repositories;

use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\Email;
use LeadFlow\CRM\Data\ValidationException;
use LeadFlow\CRM\Database\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Data access for sent emails. Emails are history: they are never trashed
 * or edited from the UI, and they are removed with their lead (or with a
 * company/contact they belong to exclusively) like other related records.
 *
 * @method Email|null find( int $id, bool $with_trashed = false )
 * @method Email      create( array $data )
 * @method Email[]    query( array $args = array() )
 */
final class EmailRepository extends RelatedRecordRepository {

	protected const TABLE        = Schema::EMAILS;
	protected const ENTITY       = 'email';
	protected const MODEL        = Email::class;
	protected const SOFT_DELETES = false;

	/** Maximum addresses in Cc or Bcc. */
	public const MAX_COPIES = 10;

	/**
	 * {@inheritDoc}
	 */
	protected function schema(): array {
		return array_merge(
			$this->parent_schema(),
			array(
				'template_id' => array(
					'type'          => 'relation',
					'table'         => Schema::EMAIL_TEMPLATES,
					'nullable'      => true,
					'allow_trashed' => true,
				),
				'to_email'    => array(
					'type'     => 'email',
					'max'      => 191,
					'required' => true,
				),
				'to_name'     => array(
					'type' => 'string',
					'max'  => 191,
				),
				'cc'          => array(
					'type'     => 'text',
					'nullable' => true,
				),
				'bcc'         => array(
					'type'     => 'text',
					'nullable' => true,
				),
				'from_name'   => array(
					'type' => 'string',
					'max'  => 191,
				),
				'from_email'  => array(
					'type' => 'email',
					'max'  => 191,
				),
				'reply_to'    => array(
					'type' => 'email',
					'max'  => 191,
				),
				'subject'     => array(
					'type'     => 'string',
					'max'      => 255,
					'required' => true,
				),
				'body'        => array(
					'type'     => 'html',
					'required' => true,
				),
				'status'      => array(
					'type'    => 'enum',
					'values'  => Email::STATUSES,
					'default' => 'sent',
				),
				'error'       => array(
					'type'     => 'text',
					'nullable' => true,
				),
				'meta'        => array(
					'type'     => 'json',
					'nullable' => true,
				),
				'sent_by'     => array(
					'type'     => 'user',
					'nullable' => true,
				),
				'sent_at'     => array(
					'type'     => 'datetime',
					'nullable' => true,
				),
			)
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function searchable(): array {
		return array( 'subject', 'to_email', 'to_name' );
	}

	/**
	 * Validates Cc/Bcc lists and stamps the sender.
	 *
	 * {@inheritDoc}
	 */
	protected function before_save( array $data, ?Model $existing ): array {
		$data   = parent::before_save( $data, $existing );
		$data   = self::default_to_current_user( $data, 'sent_by', $existing );
		$errors = array();

		foreach ( array( 'cc', 'bcc' ) as $column ) {
			if ( ! array_key_exists( $column, $data ) || null === $data[ $column ] ) {
				continue;
			}

			$list = self::parse_addresses( (string) $data[ $column ] );

			if ( null === $list ) {
				$errors[ $column ] = __( 'Please enter valid email addresses separated by commas.', 'wp-leadflow-crm' );
				continue;
			}

			if ( count( $list ) > self::MAX_COPIES ) {
				/* translators: %d: Maximum number of addresses. */
				$errors[ $column ] = sprintf( __( 'Please enter at most %d addresses.', 'wp-leadflow-crm' ), self::MAX_COPIES );
				continue;
			}

			$data[ $column ] = empty( $list ) ? null : implode( ', ', $list );
		}

		if ( ! empty( $errors ) ) {
			throw new ValidationException( $errors );
		}

		return $data;
	}

	/**
	 * Parses "a@x.com, b@y.com; c@z.com" into unique addresses.
	 *
	 * @param string $list Raw list.
	 * @return string[]|null Null when an address is invalid.
	 */
	public static function parse_addresses( string $list ): ?array {
		$addresses = array();

		foreach ( preg_split( '/[,;\s]+/', $list ) ?: array() as $part ) {
			$part = trim( $part );

			if ( '' === $part ) {
				continue;
			}

			$email = sanitize_email( $part );

			if ( '' === $email || ! is_email( $email ) || strtolower( $email ) !== strtolower( $part ) ) {
				return null;
			}

			$addresses[ strtolower( $email ) ] = $email;
		}

		return array_values( $addresses );
	}

	/**
	 * Emails a user sent (or tried to send) since a point in time.
	 *
	 * @param int    $user_id User.
	 * @param string $since   UTC datetime.
	 * @return int
	 */
	public function count_sent_by_since( int $user_id, string $since ): int {
		return $this->count(
			array(
				'where' => array(
					'sent_by'    => $user_id,
					'created_at' => array(
						'op'    => '>=',
						'value' => $since,
					),
				),
			)
		);
	}
}
