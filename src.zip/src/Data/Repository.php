<?php
/**
 * Base repository.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data;

use LeadFlow\CRM\Database\Schema;
use LeadFlow\CRM\Database\Table;

defined( 'ABSPATH' ) || exit;

/**
 * Data access for one CRM table.
 *
 * - All SQL lives here; identifiers are allow-listed and passed as %i,
 *   values always go through $wpdb->prepare() or the insert/update helpers.
 * - Input is validated and normalized from the schema() definition.
 * - created_at/updated_at (UTC) and created_by/updated_by are managed
 *   automatically; soft deletes use deleted_at/deleted_by.
 * - Single-record lookups use the object cache, invalidated on every write.
 *
 * Column definition keys:
 *   type      string|email|url|phone|text|html|enum|slug|int|decimal|bool|
 *             date|datetime|json|user|relation|country|currency|color
 *   required  bool   Must be non-empty on create and cannot be emptied.
 *   nullable  bool   Empty input is stored as NULL.
 *   default   mixed  Value used on create when not provided.
 *   max       int    Max length (strings) or max value (numbers).
 *   min       int    Min value (numbers).
 *   values    array  Allowed values (enum).
 *   table     string Referenced short table name (relation).
 *
 * Fires `leadflow_crm_{entity}_created|updated|trashed|restored|deleted`.
 */
abstract class Repository {

	/** Short table name, e.g. "companies". */
	protected const TABLE = '';

	/** Entity name used in hooks and messages, e.g. "company". */
	protected const ENTITY = '';

	/** Model class. */
	protected const MODEL = Model::class;

	/** Whether the table uses deleted_at/deleted_by. */
	protected const SOFT_DELETES = true;

	/** Maximum page size. */
	public const MAX_PER_PAGE = 500;

	/** Columns maintained by the repository, never taken from input. */
	private const SYSTEM_COLUMNS = array(
		'id'         => array( 'type' => 'int' ),
		'created_by' => array( 'type' => 'user' ),
		'updated_by' => array( 'type' => 'user' ),
		'created_at' => array( 'type' => 'datetime' ),
		'updated_at' => array( 'type' => 'datetime' ),
	);

	/** Soft-delete columns. */
	private const SOFT_DELETE_COLUMNS = array(
		'deleted_at' => array( 'type' => 'datetime' ),
		'deleted_by' => array( 'type' => 'user' ),
	);

	/** Allowed comparison operators for query(). */
	private const OPERATORS = array( '=', '!=', '<', '<=', '>', '>=', 'IN', 'NOT IN', 'IS NULL', 'IS NOT NULL' );

	/**
	 * Writable column definitions.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	abstract protected function schema(): array;

	/**
	 * Columns searched by the `search` query argument.
	 *
	 * @return string[]
	 */
	protected function searchable(): array {
		return array();
	}

	/**
	 * Hook to derive or adjust values before saving.
	 *
	 * @param array<string, mixed> $data     Validated data being written.
	 * @param Model|null           $existing Current record on update.
	 * @return array<string, mixed>
	 */
	protected function before_save( array $data, ?Model $existing ): array {
		return $data;
	}

	/**
	 * Hook to clean up dependent rows before a permanent delete.
	 * Runs inside the delete transaction.
	 *
	 * @param int $id Record id.
	 * @return void
	 */
	protected function before_delete( int $id ): void {}

	// ---------------------------------------------------------------------
	// Reading.
	// ---------------------------------------------------------------------

	/**
	 * Full table name.
	 *
	 * @return string
	 */
	public function table(): string {
		return Table::name( static::TABLE );
	}

	/**
	 * Finds a record by id.
	 *
	 * @param int  $id           Record id.
	 * @param bool $with_trashed Also return trashed records.
	 * @return Model|null
	 */
	public function find( int $id, bool $with_trashed = false ): ?Model {
		global $wpdb;

		if ( $id <= 0 ) {
			return null;
		}

		$group = self::cache_group( static::TABLE );
		$key   = $id . ':' . wp_cache_get_last_changed( $group );
		$row   = wp_cache_get( $key, $group );

		if ( false === $row ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Custom table; cached above.
			$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE id = %d', $this->table(), $id ), ARRAY_A );
			$row = is_array( $row ) ? $row : array();
			wp_cache_set( $key, $row, $group );
		}

		if ( empty( $row ) ) {
			return null;
		}

		$model = $this->hydrate( $row );

		return ( $with_trashed || ! $model->is_trashed() ) ? $model : null;
	}

	/**
	 * Finds several records by id (missing ids are skipped).
	 *
	 * @param int[] $ids Record ids.
	 * @return array<int, Model> Keyed by id.
	 */
	public function find_many( array $ids ): array {
		$ids = array_values( array_unique( array_filter( array_map( 'intval', $ids ), static fn( int $id ): bool => $id > 0 ) ) );

		if ( empty( $ids ) ) {
			return array();
		}

		$models = array();

		foreach ( $this->query(
			array(
				'where'    => array( 'id' => $ids ),
				'per_page' => self::MAX_PER_PAGE,
			)
		) as $model ) {
			$models[ $model->id() ] = $model;
		}

		return $models;
	}

	/**
	 * Queries records.
	 *
	 * @param array<string, mixed> $args {
	 *     @type array  $where    Column => value. A scalar means "=", null means
	 *                            IS NULL, a list means IN, and
	 *                            array( 'op' => '<=', 'value' => ... ) any
	 *                            allowed operator.
	 *     @type string $search   Text searched in searchable() columns.
	 *     @type string $trashed  without (default) | with | only.
	 *     @type string $orderby  Column. Default 'id'.
	 *     @type string $order    ASC | DESC. Default DESC.
	 *     @type int    $per_page 1–500. Default 20.
	 *     @type int    $page     Default 1.
	 *     @type bool   $nulls_last Sort rows with an empty orderby column last.
	 * }
	 * @return Model[]
	 */
	public function query( array $args = array() ): array {
		global $wpdb;

		$params  = array( $this->table() );
		$where   = $this->build_where( $args, $params );
		$orderby = isset( $args['orderby'] ) ? (string) $args['orderby'] : 'id';
		$order   = isset( $args['order'] ) && 'ASC' === strtoupper( (string) $args['order'] ) ? 'ASC' : 'DESC';

		if ( ! isset( $this->columns()[ $orderby ] ) ) {
			throw new \InvalidArgumentException( esc_html( sprintf( 'Cannot order by unknown column "%s".', $orderby ) ) );
		}

		$per_page = max( 1, min( self::MAX_PER_PAGE, (int) ( $args['per_page'] ?? 20 ) ) );
		$page     = max( 1, (int) ( $args['page'] ?? 1 ) );

		// Optional: rows with an empty sort column last (e.g. undated tasks).
		$nulls = '';

		if ( ! empty( $args['nulls_last'] ) ) {
			$nulls    = '%i IS NULL, ';
			$params[] = $orderby;
		}

		$params[] = $orderby;
		$params[] = $per_page;
		$params[] = ( $page - 1 ) * $per_page;

		// $where, $nulls and $order are built from allow-lists; every value is a placeholder.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM %i WHERE {$where} ORDER BY {$nulls}%i {$order}, id {$order} LIMIT %d OFFSET %d", $params ), ARRAY_A );

		if ( null === $rows && '' !== $wpdb->last_error ) {
			throw DataException::from_wpdb( 'query ' . static::TABLE );
		}

		// Prime the find() cache so per-row lookups (e.g. capability checks) are free.
		$group        = self::cache_group( static::TABLE );
		$last_changed = wp_cache_get_last_changed( $group );

		foreach ( (array) $rows as $row ) {
			wp_cache_set( $row['id'] . ':' . $last_changed, $row, $group );
		}

		return array_map( array( $this, 'hydrate' ), (array) $rows );
	}

	/**
	 * Selected columns of every non-trashed row (duplicate detection, lookups).
	 *
	 * @param string[] $columns Declared columns.
	 * @param int      $limit   Safety limit.
	 * @return array<int, array<string, mixed>> Rows including 'id'.
	 */
	public function pluck( array $columns, int $limit = 200000 ): array {
		global $wpdb;

		$known = $this->columns();

		foreach ( $columns as $column ) {
			if ( ! isset( $known[ $column ] ) ) {
				throw new \InvalidArgumentException( esc_html( sprintf( 'Unknown column "%s".', (string) $column ) ) );
			}
		}

		$columns      = array_values( array_unique( array_merge( array( 'id' ), $columns ) ) );
		$placeholders = implode( ', ', array_fill( 0, count( $columns ), '%i' ) );
		$trashed      = static::SOFT_DELETES ? 'WHERE deleted_at IS NULL' : '';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- Identifiers allow-listed and passed as %i.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT {$placeholders} FROM %i {$trashed} ORDER BY id ASC LIMIT %d", array_merge( $columns, array( $this->table(), max( 1, $limit ) ) ) ), ARRAY_A );

		return (array) $rows;
	}

	/**
	 * Validates data exactly like create()/update() would, without saving.
	 *
	 * @param array<string, mixed> $data     Raw input.
	 * @param Model|null           $existing Record that would be updated.
	 * @return array<string, string> Field => message (empty when valid).
	 */
	public function check( array $data, ?Model $existing = null ): array {
		try {
			$this->before_save( $this->validate( $data, $existing ), $existing );
		} catch ( ValidationException $e ) {
			return $e->errors();
		}

		return array();
	}

	/**
	 * Column definitions (system, writable and soft-delete columns), used
	 * to derive REST schemas.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public function definitions(): array {
		return $this->columns();
	}

	/**
	 * Writable column definitions.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public function writable(): array {
		return $this->schema();
	}

	/**
	 * Whether records are trashed before being deleted.
	 *
	 * @return bool
	 */
	public function soft_deletes(): bool {
		return static::SOFT_DELETES;
	}

	/**
	 * Entity key, e.g. "company".
	 *
	 * @return string
	 */
	public function entity(): string {
		return static::ENTITY;
	}

	/**
	 * Distinct non-empty values of a column (for filter dropdowns).
	 *
	 * @param string $column Declared column.
	 * @param int    $limit  Max values.
	 * @return string[]
	 */
	public function distinct_values( string $column, int $limit = 200 ): array {
		global $wpdb;

		if ( ! isset( $this->schema()[ $column ] ) ) {
			throw new \InvalidArgumentException( esc_html( sprintf( 'Unknown column "%s".', $column ) ) );
		}

		$trashed = static::SOFT_DELETES ? 'AND deleted_at IS NULL' : '';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $trashed is a constant fragment.
		$values = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT %i FROM %i WHERE %i <> '' {$trashed} ORDER BY %i ASC LIMIT %d", $column, $this->table(), $column, $column, max( 1, $limit ) ) );

		return array_map( 'strval', (array) $values );
	}

	/**
	 * Counts rows grouped by a column (e.g. records per status).
	 *
	 * @param string               $column Declared column.
	 * @param array<string, mixed> $where  Optional equality filters.
	 * @return array<string, int> Value => count (non-trashed rows).
	 */
	public function count_by( string $column, array $where = array() ): array {
		global $wpdb;

		$columns = $this->columns();

		if ( ! isset( $columns[ $column ] ) ) {
			throw new \InvalidArgumentException( esc_html( sprintf( 'Unknown column "%s".', $column ) ) );
		}

		$params = array( $column, $this->table() );
		$sql    = 'SELECT %i AS value, COUNT(*) AS total FROM %i WHERE 1=1';

		if ( static::SOFT_DELETES ) {
			$sql .= ' AND deleted_at IS NULL';
		}

		foreach ( $where as $key => $value ) {
			if ( ! isset( $columns[ $key ] ) ) {
				throw new \InvalidArgumentException( esc_html( sprintf( 'Unknown column "%s".', (string) $key ) ) );
			}

			if ( is_array( $value ) ) {
				$values = array_values( array_map( 'intval', $value ) );

				if ( empty( $values ) ) {
					return array();
				}

				$sql     .= ' AND %i IN (' . implode( ',', array_fill( 0, count( $values ), '%d' ) ) . ')';
				$params[] = $key;
				array_push( $params, ...$values );
				continue;
			}

			$sql     .= ' AND %i = ' . $this->format_for( $columns[ $key ] );
			$params[] = $key;
			$params[] = $value;
		}

		$sql     .= ' GROUP BY %i';
		$params[] = $column;

		$group  = self::cache_group( static::TABLE );
		$key    = 'count_by:' . md5( (string) wp_json_encode( array( $sql, $params ) ) ) . ':' . wp_cache_get_last_changed( $group );
		$cached = wp_cache_get( $key, $group );

		if ( is_array( $cached ) ) {
			return $cached;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.NotPrepared -- Cached above; built from placeholders only.
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );

		$counts = array();

		foreach ( (array) $rows as $row ) {
			$counts[ (string) $row['value'] ] = (int) $row['total'];
		}

		wp_cache_set( $key, $counts, $group );

		return $counts;
	}

	/**
	 * Counts records matching the same arguments as query().
	 *
	 * @param array<string, mixed> $args Query arguments (paging/order ignored).
	 * @return int
	 */
	public function count( array $args = array() ): int {
		global $wpdb;

		$params = array( $this->table() );
		$where  = $this->build_where( $args, $params );
		$group  = self::cache_group( static::TABLE );
		$key    = 'count:' . md5( (string) wp_json_encode( array( $where, $params ) ) ) . ':' . wp_cache_get_last_changed( $group );
		$cached = wp_cache_get( $key, $group );

		if ( false !== $cached ) {
			return (int) $cached;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- Cached above; see query().
		$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i WHERE {$where}", $params ) );

		wp_cache_set( $key, $total, $group );

		return $total;
	}

	/**
	 * Paginated query.
	 *
	 * @param array<string, mixed> $args Query arguments.
	 * @return array{items: Model[], total: int, page: int, per_page: int, pages: int}
	 */
	public function paginate( array $args = array() ): array {
		$per_page = max( 1, min( self::MAX_PER_PAGE, (int) ( $args['per_page'] ?? 20 ) ) );
		$page     = max( 1, (int) ( $args['page'] ?? 1 ) );
		$total    = $this->count( $args );

		return array(
			'items'    => $this->query( array_merge( $args, array( 'per_page' => $per_page, 'page' => $page ) ) ),
			'total'    => $total,
			'page'     => $page,
			'per_page' => $per_page,
			'pages'    => (int) ceil( $total / $per_page ),
		);
	}

	/**
	 * Whether a record exists (and is not trashed).
	 *
	 * @param int $id Record id.
	 * @return bool
	 */
	public function exists( int $id ): bool {
		return null !== $this->find( $id );
	}

	// ---------------------------------------------------------------------
	// Writing.
	// ---------------------------------------------------------------------

	/**
	 * Creates a record.
	 *
	 * @param array<string, mixed> $data Column => raw value.
	 * @return Model
	 * @throws ValidationException When the data is invalid.
	 * @throws DataException       When the insert fails.
	 */
	public function create( array $data ): Model {
		global $wpdb;

		$clean = $this->before_save( $this->validate( $data, null ), null );
		$now   = self::now();
		$user  = self::current_user();

		$clean['created_at'] = $now;
		$clean['updated_at'] = $now;
		$clean['created_by'] = $user;
		$clean['updated_by'] = $user;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Custom table insert.
		if ( false === $wpdb->insert( $this->table(), $clean, $this->formats( $clean ) ) ) {
			throw DataException::from_wpdb( 'insert into ' . static::TABLE );
		}

		self::flush_cache( static::TABLE );

		$model = $this->find( (int) $wpdb->insert_id, true );

		if ( null === $model ) {
			throw DataException::from_wpdb( 'reload from ' . static::TABLE );
		}

		/**
		 * Fires after a CRM record was created.
		 *
		 * @param Model $model Created record.
		 */
		do_action( 'leadflow_crm_' . static::ENTITY . '_created', $model );

		return $model;
	}

	/**
	 * Updates a record. Only the given columns change.
	 *
	 * @param int                  $id   Record id (trashed records can be updated).
	 * @param array<string, mixed> $data Column => raw value.
	 * @return Model Updated record.
	 * @throws RecordNotFoundException When the record does not exist.
	 * @throws ValidationException     When the data is invalid.
	 * @throws DataException           When the update fails.
	 */
	public function update( int $id, array $data ): Model {
		global $wpdb;

		$existing = $this->find( $id, true );

		if ( null === $existing ) {
			throw new RecordNotFoundException( static::ENTITY, $id );
		}

		$clean = $this->before_save( $this->validate( $data, $existing ), $existing );

		if ( empty( $clean ) ) {
			return $existing;
		}

		$clean['updated_at'] = self::now();
		$clean['updated_by'] = self::current_user();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table update.
		if ( false === $wpdb->update( $this->table(), $clean, array( 'id' => $id ), $this->formats( $clean ), array( '%d' ) ) ) {
			throw DataException::from_wpdb( 'update ' . static::TABLE );
		}

		self::flush_cache( static::TABLE );

		$model = $this->find( $id, true );

		/**
		 * Fires after a CRM record was updated.
		 *
		 * @param Model $model    Updated record.
		 * @param Model $previous Record before the update.
		 */
		do_action( 'leadflow_crm_' . static::ENTITY . '_updated', $model, $existing );

		return $model;
	}

	/**
	 * Moves a record to the trash.
	 *
	 * @param int $id Record id.
	 * @return bool False when missing or already trashed.
	 */
	public function trash( int $id ): bool {
		$this->assert_soft_deletes();

		$changed = $this->set_deleted( $id, self::now(), self::current_user(), 'IS NULL' );

		if ( $changed ) {
			/** Fires after a CRM record was trashed. */
			do_action( 'leadflow_crm_' . static::ENTITY . '_trashed', $id );
		}

		return $changed;
	}

	/**
	 * Restores a trashed record.
	 *
	 * @param int $id Record id.
	 * @return bool False when missing or not trashed.
	 */
	public function restore( int $id ): bool {
		$this->assert_soft_deletes();

		$changed = $this->set_deleted( $id, null, null, 'IS NOT NULL' );

		if ( $changed ) {
			/** Fires after a CRM record was restored from the trash. */
			do_action( 'leadflow_crm_' . static::ENTITY . '_restored', $id );
		}

		return $changed;
	}

	/**
	 * Permanently deletes a record and its dependent rows.
	 *
	 * @param int $id Record id.
	 * @return bool False when the record did not exist.
	 */
	public function delete( int $id ): bool {
		global $wpdb;

		$deleted = Transaction::run(
			function () use ( $wpdb, $id ): bool {
				$this->before_delete( $id );

				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table delete.
				$result = $wpdb->delete( $this->table(), array( 'id' => $id ), array( '%d' ) );

				if ( false === $result ) {
					throw DataException::from_wpdb( 'delete from ' . static::TABLE );
				}

				return $result > 0;
			}
		);

		self::flush_cache( static::TABLE );

		if ( $deleted ) {
			/** Fires after a CRM record was permanently deleted. */
			do_action( 'leadflow_crm_' . static::ENTITY . '_deleted', $id );
		}

		return $deleted;
	}

	// ---------------------------------------------------------------------
	// Validation.
	// ---------------------------------------------------------------------

	/**
	 * Validates and normalizes input.
	 *
	 * On create, missing columns get their default and required columns
	 * must be present. On update, only given columns are processed.
	 * Unknown and system columns are ignored.
	 *
	 * @param array<string, mixed> $data     Raw input.
	 * @param Model|null           $existing Current record on update.
	 * @return array<string, mixed> Clean data ready for $wpdb.
	 * @throws ValidationException When any column is invalid.
	 */
	protected function validate( array $data, ?Model $existing ): array {
		$clean  = array();
		$errors = array();

		foreach ( $this->schema() as $column => $def ) {
			$provided = array_key_exists( $column, $data );

			if ( ! $provided && null !== $existing ) {
				continue;
			}

			$raw = $provided ? $data[ $column ] : ( $def['default'] ?? null );

			try {
				$value = $this->normalize( $column, $def, $raw );
			} catch ( \InvalidArgumentException $e ) {
				$errors[ $column ] = $e->getMessage();
				continue;
			}

			if ( ! empty( $def['required'] ) && ( null === $value || '' === $value ) ) {
				$errors[ $column ] = __( 'This field is required.', 'wp-leadflow-crm' );
				continue;
			}

			$clean[ $column ] = $value;
		}

		if ( ! empty( $errors ) ) {
			throw new ValidationException( $errors );
		}

		return $clean;
	}

	/**
	 * Normalizes one value.
	 *
	 * @param string               $column Column.
	 * @param array<string, mixed> $def    Definition.
	 * @param mixed                $raw    Raw value.
	 * @return mixed Clean value (null for empty nullable columns).
	 * @throws \InvalidArgumentException With a translated message when invalid.
	 */
	private function normalize( string $column, array $def, mixed $raw ): mixed {
		$type     = (string) $def['type'];
		$nullable = ! empty( $def['nullable'] );

		if ( is_string( $raw ) ) {
			$raw = trim( $raw );
		}

		if ( null === $raw || '' === $raw || ( in_array( $type, array( 'user', 'relation' ), true ) && 0 === (int) $raw && is_numeric( $raw ) ) ) {
			if ( $nullable ) {
				return null;
			}

			if ( in_array( $type, array( 'int', 'decimal', 'bool' ), true ) ) {
				return 'decimal' === $type ? '0.00' : 0;
			}

			return '';
		}

		if ( ! is_scalar( $raw ) && 'json' !== $type ) {
			throw new \InvalidArgumentException( __( 'Invalid value.', 'wp-leadflow-crm' ) );
		}

		switch ( $type ) {
			case 'string':
				return $this->check_length( sanitize_text_field( (string) $raw ), $def );

			case 'text':
				return sanitize_textarea_field( (string) $raw );

			case 'html':
				return wp_kses_post( (string) $raw );

			case 'email':
				$email = sanitize_email( (string) $raw );
				if ( '' === $email || ! is_email( $email ) ) {
					throw new \InvalidArgumentException( __( 'Please enter a valid email address.', 'wp-leadflow-crm' ) );
				}
				return $this->check_length( $email, $def );

			case 'url':
				$url = esc_url_raw( (string) $raw, array( 'http', 'https' ) );
				if ( '' === $url ) {
					throw new \InvalidArgumentException( __( 'Please enter a valid URL.', 'wp-leadflow-crm' ) );
				}
				return $this->check_length( $url, $def );

			case 'phone':
				$phone = trim( (string) preg_replace( '/[^0-9+().\-\s#xX]/', '', (string) $raw ) );
				if ( '' === $phone || ! preg_match( '/\d/', $phone ) ) {
					throw new \InvalidArgumentException( __( 'Please enter a valid phone number.', 'wp-leadflow-crm' ) );
				}
				return $this->check_length( $phone, $def );

			case 'enum':
				$value = (string) $raw;
				if ( ! in_array( $value, (array) $def['values'], true ) ) {
					throw new \InvalidArgumentException( __( 'Please choose one of the allowed values.', 'wp-leadflow-crm' ) );
				}
				return $value;

			case 'slug':
				// "Web Form" → "web-form" (sanitize_key would give "webform").
				return $this->check_length( sanitize_title( (string) $raw ), $def );

			case 'int':
				if ( is_bool( $raw ) || false === filter_var( $raw, FILTER_VALIDATE_INT ) ) {
					throw new \InvalidArgumentException( __( 'Please enter a whole number.', 'wp-leadflow-crm' ) );
				}
				return $this->check_range( (int) $raw, $def );

			case 'decimal':
				if ( ! is_numeric( $raw ) ) {
					throw new \InvalidArgumentException( __( 'Please enter a number.', 'wp-leadflow-crm' ) );
				}
				$this->check_range( (float) $raw, $def );
				return number_format( (float) $raw, 2, '.', '' );

			case 'bool':
				return rest_sanitize_boolean( $raw ) ? 1 : 0;

			case 'date':
				return $this->check_date( (string) $raw, 'Y-m-d' );

			case 'datetime':
				return $this->check_date( (string) $raw, 'Y-m-d H:i:s' );

			case 'json':
				if ( ! is_array( $raw ) ) {
					throw new \InvalidArgumentException( __( 'Invalid value.', 'wp-leadflow-crm' ) );
				}
				return (string) wp_json_encode( $raw );

			case 'user':
				$user_id = is_numeric( $raw ) ? (int) $raw : 0;
				if ( $user_id <= 0 || false === get_userdata( $user_id ) ) {
					throw new \InvalidArgumentException( __( 'The selected user does not exist.', 'wp-leadflow-crm' ) );
				}
				return $user_id;

			case 'relation':
				$related = is_numeric( $raw ) ? (int) $raw : 0;
				if ( $related <= 0 || ! self::row_exists( (string) $def['table'], $related, ! empty( $def['allow_trashed'] ) ) ) {
					throw new \InvalidArgumentException( __( 'The linked record does not exist.', 'wp-leadflow-crm' ) );
				}
				return $related;

			case 'country':
				$country = strtoupper( (string) $raw );
				if ( 1 !== preg_match( '/^[A-Z]{2}$/', $country ) ) {
					throw new \InvalidArgumentException( __( 'Please use a two-letter country code.', 'wp-leadflow-crm' ) );
				}
				return $country;

			case 'color':
				$color = sanitize_hex_color( (string) $raw );
				if ( null === $color || '' === $color || 7 !== strlen( $color ) ) {
					throw new \InvalidArgumentException( __( 'Please choose a color (#RRGGBB).', 'wp-leadflow-crm' ) );
				}
				return strtolower( $color );

			case 'currency':
				$currency = strtoupper( (string) $raw );
				if ( 1 !== preg_match( '/^[A-Z]{3}$/', $currency ) ) {
					throw new \InvalidArgumentException( __( 'Please use a three-letter currency code.', 'wp-leadflow-crm' ) );
				}
				return $currency;
		}

		throw new \LogicException( esc_html( sprintf( 'Unknown column type "%s" for %s.', $type, $column ) ) );
	}

	/**
	 * Enforces a max length.
	 *
	 * @param string               $value Value.
	 * @param array<string, mixed> $def   Definition.
	 * @return string
	 */
	private function check_length( string $value, array $def ): string {
		if ( isset( $def['max'] ) && mb_strlen( $value ) > (int) $def['max'] ) {
			/* translators: %d: Maximum number of characters. */
			throw new \InvalidArgumentException( sprintf( __( 'Please use at most %d characters.', 'wp-leadflow-crm' ), (int) $def['max'] ) );
		}

		return $value;
	}

	/**
	 * Enforces min/max for numbers.
	 *
	 * @param int|float            $value Value.
	 * @param array<string, mixed> $def   Definition.
	 * @return int|float
	 */
	private function check_range( int|float $value, array $def ): int|float {
		if ( isset( $def['min'] ) && $value < $def['min'] ) {
			/* translators: %s: Minimum value. */
			throw new \InvalidArgumentException( sprintf( __( 'The value must be at least %s.', 'wp-leadflow-crm' ), (string) $def['min'] ) );
		}

		if ( isset( $def['max'] ) && $value > $def['max'] ) {
			/* translators: %s: Maximum value. */
			throw new \InvalidArgumentException( sprintf( __( 'The value must be at most %s.', 'wp-leadflow-crm' ), (string) $def['max'] ) );
		}

		return $value;
	}

	/**
	 * Validates a date string in a strict format.
	 *
	 * @param string $value  Value.
	 * @param string $format Format.
	 * @return string
	 */
	private function check_date( string $value, string $format ): string {
		// Accept "Y-m-d H:i" for datetimes.
		if ( 'Y-m-d H:i:s' === $format && 1 === preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $value ) ) {
			$value .= ':00';
		}

		$date = \DateTimeImmutable::createFromFormat( '!' . $format, $value, new \DateTimeZone( 'UTC' ) );

		if ( false === $date || $date->format( $format ) !== $value ) {
			throw new \InvalidArgumentException(
				'Y-m-d' === $format
					? __( 'Please enter a valid date (YYYY-MM-DD).', 'wp-leadflow-crm' )
					: __( 'Please enter a valid date and time (YYYY-MM-DD HH:MM:SS).', 'wp-leadflow-crm' )
			);
		}

		return $value;
	}

	// ---------------------------------------------------------------------
	// Internals.
	// ---------------------------------------------------------------------

	/**
	 * All queryable columns with definitions.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	protected function columns(): array {
		$columns = array_merge( self::SYSTEM_COLUMNS, $this->schema() );

		if ( static::SOFT_DELETES ) {
			$columns = array_merge( $columns, self::SOFT_DELETE_COLUMNS );
		}

		return $columns;
	}

	/**
	 * Builds the WHERE clause; appends values to $params.
	 *
	 * @param array<string, mixed> $args   Query arguments.
	 * @param array<int, mixed>    $params Prepared-statement values (by reference).
	 * @return string SQL with placeholders only.
	 */
	protected function build_where( array $args, array &$params ): string {
		global $wpdb;

		$columns = $this->columns();
		$clauses = array( '1=1' );

		if ( static::SOFT_DELETES ) {
			$trashed = $args['trashed'] ?? 'without';

			if ( 'only' === $trashed ) {
				$clauses[] = 'deleted_at IS NOT NULL';
			} elseif ( 'with' !== $trashed ) {
				$clauses[] = 'deleted_at IS NULL';
			}
		}

		foreach ( (array) ( $args['where'] ?? array() ) as $column => $condition ) {
			if ( ! isset( $columns[ $column ] ) ) {
				throw new \InvalidArgumentException( esc_html( sprintf( 'Cannot filter by unknown column "%s".', (string) $column ) ) );
			}

			$format = $this->format_for( $columns[ $column ] );

			if ( null === $condition ) {
				$operator = 'IS NULL';
				$value    = null;
			} elseif ( is_array( $condition ) && array_key_exists( 'op', $condition ) ) {
				$operator = strtoupper( (string) $condition['op'] );
				$value    = $condition['value'] ?? null;
			} elseif ( is_array( $condition ) ) {
				$operator = 'IN';
				$value    = $condition;
			} else {
				$operator = '=';
				$value    = $condition;
			}

			if ( ! in_array( $operator, self::OPERATORS, true ) ) {
				throw new \InvalidArgumentException( esc_html( sprintf( 'Unsupported operator "%s".', $operator ) ) );
			}

			$params[] = $column;

			if ( 'IS NULL' === $operator || 'IS NOT NULL' === $operator ) {
				$clauses[] = "%i {$operator}";
				continue;
			}

			if ( 'IN' === $operator || 'NOT IN' === $operator ) {
				$values = array_values( (array) $value );

				if ( empty( $values ) ) {
					array_pop( $params );
					$clauses[] = 'IN' === $operator ? '1=0' : '1=1';
					continue;
				}

				$clauses[] = "%i {$operator} (" . implode( ',', array_fill( 0, count( $values ), $format ) ) . ')';
				array_push( $params, ...$values );
				continue;
			}

			$clauses[] = "%i {$operator} {$format}";
			$params[]  = $value;
		}

		$search = isset( $args['search'] ) ? trim( (string) $args['search'] ) : '';

		if ( '' !== $search && ! empty( $this->searchable() ) ) {
			$like  = '%' . $wpdb->esc_like( $search ) . '%';
			$parts = array();

			foreach ( $this->searchable() as $column ) {
				$parts[]  = '%i LIKE %s';
				$params[] = $column;
				$params[] = $like;
			}

			$clauses[] = '(' . implode( ' OR ', $parts ) . ')';
		}

		return implode( ' AND ', $clauses );
	}

	/**
	 * Sets or clears the soft-delete columns.
	 *
	 * @param int         $id        Record id.
	 * @param string|null $timestamp deleted_at value.
	 * @param int|null    $user      deleted_by value.
	 * @param string      $current   Required current state: 'IS NULL' | 'IS NOT NULL'.
	 * @return bool Whether a row changed.
	 */
	private function set_deleted( int $id, ?string $timestamp, ?int $user, string $current ): bool {
		global $wpdb;

		$current = 'IS NULL' === $current ? 'IS NULL' : 'IS NOT NULL';

		// NULLIF(%d, 0) stores NULL for guests/cron instead of user id 0.
		if ( null === $timestamp ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $current is allow-listed.
			$result = $wpdb->query( $wpdb->prepare( "UPDATE %i SET deleted_at = NULL, deleted_by = NULL, updated_at = %s, updated_by = NULLIF(%d, 0) WHERE id = %d AND deleted_at {$current}", $this->table(), self::now(), (int) self::current_user(), $id ) );
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $current is allow-listed.
			$result = $wpdb->query( $wpdb->prepare( "UPDATE %i SET deleted_at = %s, deleted_by = NULLIF(%d, 0) WHERE id = %d AND deleted_at {$current}", $this->table(), $timestamp, (int) $user, $id ) );
		}

		if ( false === $result ) {
			throw DataException::from_wpdb( 'soft delete on ' . static::TABLE );
		}

		self::flush_cache( static::TABLE );

		return $result > 0;
	}

	/**
	 * Builds a model with values cast by column type.
	 *
	 * @param array<string, mixed> $row Database row.
	 * @return Model
	 */
	protected function hydrate( array $row ): Model {
		$columns = $this->columns();

		foreach ( $row as $column => $value ) {
			if ( null === $value || ! isset( $columns[ $column ] ) ) {
				continue;
			}

			switch ( $columns[ $column ]['type'] ) {
				case 'int':
				case 'user':
				case 'relation':
					$row[ $column ] = (int) $value;
					break;
				case 'bool':
					$row[ $column ] = (bool) (int) $value;
					break;
				case 'decimal':
					$row[ $column ] = (float) $value;
					break;
				case 'json':
					$decoded        = json_decode( (string) $value, true );
					$row[ $column ] = is_array( $decoded ) ? $decoded : array();
					break;
			}
		}

		$class = static::MODEL;

		return new $class( $row );
	}

	/**
	 * $wpdb formats for a data array.
	 *
	 * @param array<string, mixed> $data Column => value.
	 * @return string[]
	 */
	private function formats( array $data ): array {
		$columns = $this->columns();

		return array_map(
			fn( string $column ): string => $this->format_for( $columns[ $column ] ?? array( 'type' => 'string' ) ),
			array_keys( $data )
		);
	}

	/**
	 * Placeholder for a column definition.
	 *
	 * @param array<string, mixed> $def Definition.
	 * @return string
	 */
	private function format_for( array $def ): string {
		return in_array( $def['type'], array( 'int', 'bool', 'user', 'relation' ), true ) ? '%d' : '%s';
	}

	/**
	 * Throws when the table has no soft deletes.
	 *
	 * @return void
	 */
	private function assert_soft_deletes(): void {
		if ( ! static::SOFT_DELETES ) {
			throw new \LogicException( esc_html( static::ENTITY . ' records cannot be trashed.' ) );
		}
	}

	/**
	 * Sets a user column to the current user on create when empty.
	 *
	 * @param array<string, mixed> $data     Data being saved.
	 * @param string               $column   Column, e.g. owner_id.
	 * @param Model|null           $existing Current record (null on create).
	 * @return array<string, mixed>
	 */
	protected static function default_to_current_user( array $data, string $column, ?Model $existing ): array {
		if ( null === $existing && empty( $data[ $column ] ) ) {
			$data[ $column ] = self::current_user();
		}

		return $data;
	}

	/**
	 * Handles related rows (activities, notes, tasks, follow-ups) before a
	 * parent is permanently deleted:
	 *
	 * - rows whose most specific parent is this record are deleted;
	 * - rows that also belong to a more specific parent are unlinked.
	 *
	 * Foreign keys enforce the same outcome where available; doing it here
	 * keeps behavior identical on engines without them.
	 *
	 * @param string   $column        Parent column, e.g. company_id.
	 * @param int      $id            Parent id.
	 * @param string[] $more_specific Columns that, when set, keep the row alive.
	 * @return void
	 */
	protected static function detach_related( string $column, int $id, array $more_specific ): void {
		global $wpdb;

		foreach ( Schema::RELATED_TABLES as $short ) {
			$table  = Table::name( $short );
			$sql    = 'DELETE FROM %i WHERE %i = %d';
			$params = array( $table, $column, $id );

			foreach ( $more_specific as $other ) {
				$sql     .= ' AND %i IS NULL';
				$params[] = $other;
			}

			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Built from placeholders only.
			if ( false === $wpdb->query( $wpdb->prepare( $sql, $params ) )
				|| false === $wpdb->query( $wpdb->prepare( 'UPDATE %i SET %i = NULL WHERE %i = %d', $table, $column, $column, $id ) ) ) {
				throw DataException::from_wpdb( 'detach ' . $short );
			}
			// phpcs:enable

			self::flush_cache( $short );
		}
	}

	/**
	 * Sets a reference column to NULL in another table.
	 *
	 * @param string $short  Short table name.
	 * @param string $column Column.
	 * @param int    $id     Referenced id.
	 * @return void
	 */
	protected static function unlink( string $short, string $column, int $id ): void {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Referential cleanup.
		if ( false === $wpdb->query( $wpdb->prepare( 'UPDATE %i SET %i = NULL WHERE %i = %d', Table::name( $short ), $column, $column, $id ) ) ) {
			throw DataException::from_wpdb( 'unlink ' . $short );
		}

		self::flush_cache( $short );
	}

	/**
	 * Whether a row exists in another CRM table.
	 *
	 * @param string $table         Short table name.
	 * @param int    $id            Row id.
	 * @param bool   $allow_trashed Also accept trashed rows.
	 * @return bool
	 */
	protected static function row_exists( string $table, int $id, bool $allow_trashed = false ): bool {
		global $wpdb;

		if ( $allow_trashed ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Referential check.
			return (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT 1 FROM %i WHERE id = %d', Table::name( $table ), $id ) );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Referential check.
		return (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT 1 FROM %i WHERE id = %d AND deleted_at IS NULL', Table::name( $table ), $id ) );
	}

	/**
	 * Current UTC time in MySQL format.
	 *
	 * @return string
	 */
	protected static function now(): string {
		return current_time( 'mysql', true );
	}

	/**
	 * Current user id, or null for guests/cron.
	 *
	 * @return int|null
	 */
	protected static function current_user(): ?int {
		$id = get_current_user_id();

		return $id > 0 ? $id : null;
	}

	/**
	 * Object-cache group of a table.
	 *
	 * @param string $table Short table name.
	 * @return string
	 */
	protected static function cache_group( string $table ): string {
		return 'leadflow_crm_' . $table;
	}

	/**
	 * Invalidates cached rows of a table.
	 *
	 * @param string $table Short table name.
	 * @return void
	 */
	public static function flush_cache( string $table ): void {
		wp_cache_set_last_changed( self::cache_group( $table ) );
	}
}
