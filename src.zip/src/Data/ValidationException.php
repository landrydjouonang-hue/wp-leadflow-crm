<?php
/**
 * Validation failure.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Data;

defined( 'ABSPATH' ) || exit;

/**
 * Thrown by repositories when input data is invalid.
 */
final class ValidationException extends \InvalidArgumentException {

	/**
	 * Constructor.
	 *
	 * @param array<string, string> $errors Field => translated message.
	 */
	public function __construct( private array $errors ) {
		parent::__construct( esc_html( implode( ' ', $errors ) ) );
	}

	/**
	 * Field errors.
	 *
	 * @return array<string, string>
	 */
	public function errors(): array {
		return $this->errors;
	}

	/**
	 * As a WP_Error (for REST and AJAX responses).
	 *
	 * @return \WP_Error
	 */
	public function to_wp_error(): \WP_Error {
		return new \WP_Error(
			'leadflow_crm_invalid_data',
			__( 'Some fields are invalid.', 'wp-leadflow-crm' ),
			array(
				'status' => 400,
				'errors' => $this->errors,
			)
		);
	}
}
