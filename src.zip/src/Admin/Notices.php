<?php
/**
 * Admin notices.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Admin;

use LeadFlow\CRM\Contracts\Hookable;
use LeadFlow\CRM\Core\Activator;
use LeadFlow\CRM\Database\Migrator;
use LeadFlow\CRM\Security\Capabilities;

defined( 'ABSPATH' ) || exit;

/**
 * System notices plus per-user flash messages for post/redirect/get flows.
 */
final class Notices implements Hookable {

	/** Allowed notice types. */
	private const TYPES = array( 'success', 'error', 'warning', 'info' );

	/**
	 * Constructor.
	 *
	 * @param Menu     $menu     Menu registry.
	 * @param Migrator $migrator Migrator.
	 */
	public function __construct(
		private Menu $menu,
		private Migrator $migrator
	) {}

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_action( 'admin_notices', array( $this, 'render' ) );
	}

	/**
	 * Queues a message for the current user's next CRM page load.
	 *
	 * @param string $type    success|error|warning|info.
	 * @param string $message Plain-text message.
	 * @return void
	 */
	public static function flash( string $type, string $message ): void {
		$type     = in_array( $type, self::TYPES, true ) ? $type : 'info';
		$key      = self::flash_key();
		$messages = get_transient( $key );
		$messages = is_array( $messages ) ? $messages : array();

		$messages[] = array(
			'type'    => $type,
			'message' => $message,
		);

		set_transient( $key, $messages, 5 * MINUTE_IN_SECONDS );
	}

	/**
	 * Renders notices.
	 *
	 * @return void
	 */
	public function render(): void {
		$this->render_activated();
		$this->render_migration_error();

		if ( $this->menu->is_current_screen() ) {
			$this->render_flash();
		}
	}

	/**
	 * One-time notice after activation.
	 *
	 * @return void
	 */
	private function render_activated(): void {
		if ( false === get_transient( Activator::NOTICE_TRANSIENT ) || ! current_user_can( Capabilities::ACCESS_CRM ) ) {
			return;
		}

		delete_transient( Activator::NOTICE_TRANSIENT );

		printf(
			'<div class="notice notice-success is-dismissible"><p>%1$s <a href="%2$s">%3$s</a></p></div>',
			esc_html__( 'WP LeadFlow CRM is ready.', 'wp-leadflow-crm' ),
			esc_url( Menu::url() ),
			esc_html__( 'Open the CRM dashboard', 'wp-leadflow-crm' )
		);
	}

	/**
	 * Persistent notice when a database migration failed.
	 *
	 * @return void
	 */
	private function render_migration_error(): void {
		if ( ! current_user_can( Capabilities::MANAGE_SETTINGS ) ) {
			return;
		}

		$error = $this->migrator->last_error();

		if ( null === $error ) {
			return;
		}

		printf(
			'<div class="notice notice-error"><p><strong>%1$s</strong> %2$s</p><p><code>%3$s</code>: %4$s</p></div>',
			esc_html__( 'WP LeadFlow CRM database update failed.', 'wp-leadflow-crm' ),
			esc_html__( 'Some CRM features may not work. The update will be retried automatically.', 'wp-leadflow-crm' ),
			esc_html( (string) ( $error['migration'] ?? '' ) ),
			esc_html( (string) ( $error['message'] ?? '' ) )
		);
	}

	/**
	 * Flash messages for the current user.
	 *
	 * @return void
	 */
	private function render_flash(): void {
		$key      = self::flash_key();
		$messages = get_transient( $key );

		if ( ! is_array( $messages ) || empty( $messages ) ) {
			return;
		}

		delete_transient( $key );

		foreach ( $messages as $item ) {
			$type = (string) $item['type'];

			// Errors interrupt (assertive); everything else is announced politely.
			printf(
				'<div class="notice notice-%1$s is-dismissible" role="%2$s"%3$s><p>%4$s</p></div>',
				esc_attr( $type ),
				'error' === $type ? 'alert' : 'status',
				'error' === $type ? '' : ' aria-live="polite"',
				esc_html( (string) $item['message'] )
			);
		}
	}

	/**
	 * Transient key for the current user's flash messages.
	 *
	 * @return string
	 */
	private static function flash_key(): string {
		return 'leadflow_crm_flash_' . get_current_user_id();
	}
}
