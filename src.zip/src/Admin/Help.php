<?php
/**
 * Contextual help.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Admin;

use LeadFlow\CRM\Contracts\Hookable;
use LeadFlow\CRM\Modules\Access\AccessModule;
use LeadFlow\CRM\Modules\Settings\SettingsModule;

defined( 'ABSPATH' ) || exit;

/**
 * Adds the "Help" tab of each CRM screen (top right of the admin) with a
 * short explanation, what the current user can do there, and links to the
 * documentation.
 *
 * Documentation lives in the plugin's `docs/` folder. Sites that publish
 * it (for example on GitHub) can point the links at it:
 *
 *     add_filter( 'leadflow_crm_docs_url', fn() => 'https://example.com/docs/' );
 */
final class Help implements Hookable {

	/**
	 * Constructor.
	 *
	 * @param Menu $menu Menu registry.
	 */
	public function __construct( private Menu $menu ) {}

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_action( 'current_screen', array( $this, 'add_help' ) );
	}

	/**
	 * Base URL of the published documentation ('' when not published).
	 *
	 * @return string
	 */
	public static function docs_url(): string {
		/**
		 * Filters the base URL of the published documentation.
		 *
		 * @param string $url Base URL, with a trailing slash.
		 */
		$url = trim( (string) apply_filters( 'leadflow_crm_docs_url', '' ) );

		// Empty means "not published": show file names instead of links.
		return '' === $url ? '' : trailingslashit( $url );
	}

	/**
	 * Link to a documentation file, or its name when not published.
	 *
	 * @param string $file  File in docs/, e.g. "API.md".
	 * @param string $label Link text.
	 * @return string Escaped HTML.
	 */
	public static function doc_link( string $file, string $label ): string {
		$base = self::docs_url();

		if ( '' === $base ) {
			return sprintf(
				'%1$s <code>%2$s</code>',
				esc_html( $label ),
				esc_html( 'docs/' . $file )
			);
		}

		return sprintf(
			'<a href="%1$s" target="_blank" rel="noopener noreferrer">%2$s<span class="screen-reader-text"> %3$s</span></a>',
			esc_url( $base . $file ),
			esc_html( $label ),
			esc_html__( '(opens in a new tab)', 'wp-leadflow-crm' )
		);
	}

	/**
	 * Adds help tabs on CRM screens.
	 *
	 * @param \WP_Screen $screen Current screen.
	 * @return void
	 */
	public function add_help( \WP_Screen $screen ): void {
		if ( ! $this->menu->is_plugin_screen( (string) $screen->id ) ) {
			return;
		}

		$page  = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( (string) $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen detection.
		$topic = $this->topic( $page );

		$screen->add_help_tab(
			array(
				'id'      => 'leadflow-crm-overview',
				'title'   => __( 'Overview', 'wp-leadflow-crm' ),
				'content' => '<p>' . esc_html( $topic['overview'] ) . '</p>'
					. ( empty( $topic['points'] ) ? '' : '<ul><li>' . implode( '</li><li>', array_map( 'esc_html', $topic['points'] ) ) . '</li></ul>' ),
			)
		);

		$screen->add_help_tab(
			array(
				'id'      => 'leadflow-crm-permissions',
				'title'   => __( 'Who can do what', 'wp-leadflow-crm' ),
				'content' => '<p>' . esc_html__( 'Administrators and CRM Managers can see and change everything. Sales Agents see the whole CRM but edit only the records they own, and cannot change settings.', 'wp-leadflow-crm' ) . '</p>'
					. ( current_user_can( \LeadFlow\CRM\Security\Permissions::MANAGE_USERS )
						? '<p><a href="' . esc_url( AccessModule::url() ) . '">' . esc_html__( 'Change what each role may do', 'wp-leadflow-crm' ) . '</a></p>'
						: '' ),
			)
		);

		$screen->set_help_sidebar(
			'<p><strong>' . esc_html__( 'Documentation', 'wp-leadflow-crm' ) . '</strong></p>'
			. '<p>' . self::doc_link( 'ARCHITECTURE.md', __( 'How the plugin works', 'wp-leadflow-crm' ) ) . '</p>'
			. '<p>' . self::doc_link( 'API.md', __( 'REST API reference', 'wp-leadflow-crm' ) ) . '</p>'
			. '<p>' . self::doc_link( 'DATABASE.md', __( 'Database and data rules', 'wp-leadflow-crm' ) ) . '</p>'
			. ( current_user_can( \LeadFlow\CRM\Security\Capabilities::MANAGE_SETTINGS )
				? '<p><a href="' . esc_url( Menu::url( SettingsModule::PAGE_SLUG, array( 'tab' => 'status' ) ) ) . '">' . esc_html__( 'System status', 'wp-leadflow-crm' ) . '</a></p>'
				: '' )
		);
	}

	/**
	 * Help text of a screen.
	 *
	 * @param string $page Page slug.
	 * @return array{overview: string, points: string[]}
	 */
	private function topic( string $page ): array {
		$topics = array(
			'leadflow-crm'                => array(
				'overview' => __( 'Your sales at a glance: key figures and charts for the period you choose, followed by your own work.', 'wp-leadflow-crm' ),
				'points'   => array(
					__( 'Change the period or whose figures you see with the filters at the top.', 'wp-leadflow-crm' ),
					__( 'Every chart has a data table below it for exact numbers.', 'wp-leadflow-crm' ),
				),
			),
			'leadflow-crm-leads'          => array(
				'overview' => __( 'Leads are your sales opportunities. Each one moves through the pipeline stages until it is won or lost.', 'wp-leadflow-crm' ),
				'points'   => array(
					__( 'Use the Pipeline screen to drag leads between stages.', 'wp-leadflow-crm' ),
					__( 'A lead keeps its history: notes, tasks, follow-ups, emails and an activity timeline.', 'wp-leadflow-crm' ),
				),
			),
			'leadflow-crm-pipeline'       => array(
				'overview' => __( 'The pipeline board shows open leads by stage. Drag a card, or use its "Move to" menu with the keyboard.', 'wp-leadflow-crm' ),
				'points'   => array( __( 'Stages, their colours and win probabilities are configured in Settings → Pipeline.', 'wp-leadflow-crm' ) ),
			),
			'leadflow-crm-companies'      => array(
				'overview' => __( 'Companies are the organizations you work with. Contacts and leads can be linked to them.', 'wp-leadflow-crm' ),
				'points'   => array( __( 'A company profile collects everything about it, including its contacts’ notes.', 'wp-leadflow-crm' ) ),
			),
			'leadflow-crm-contacts'       => array(
				'overview' => __( 'Contacts are the people you talk to. A contact can belong to a company.', 'wp-leadflow-crm' ),
				'points'   => array( __( 'A contact needs at least a first name, a last name or an email address.', 'wp-leadflow-crm' ) ),
			),
			'leadflow-crm-tasks'          => array(
				'overview' => __( 'Tasks are your to-dos. They can stand alone or belong to a lead, contact or company.', 'wp-leadflow-crm' ),
				'points'   => array( __( 'Overdue tasks are highlighted, and their number appears next to the Tasks menu.', 'wp-leadflow-crm' ) ),
			),
			'leadflow-crm-emails'         => array(
				'overview' => __( 'Every email sent from the CRM is kept here, with its content and whether it was delivered to the mail server.', 'wp-leadflow-crm' ),
				'points'   => array( __( 'Send emails from a lead, contact or company with the "Send email" button.', 'wp-leadflow-crm' ) ),
			),
			'leadflow-crm-templates'      => array(
				'overview' => __( 'Email templates are reusable messages with placeholders such as {{first_name}} that are filled in per recipient.', 'wp-leadflow-crm' ),
				'points'   => array( __( 'The live preview shows exactly what a recipient will read.', 'wp-leadflow-crm' ) ),
			),
			'leadflow-crm-import-export'  => array(
				'overview' => __( 'Import leads, contacts and companies from CSV files, or export them again. Nothing is written until you confirm the preview.', 'wp-leadflow-crm' ),
				'points'   => array(
					__( 'Duplicates are detected and you choose whether to skip or update them.', 'wp-leadflow-crm' ),
					__( 'A complete JSON backup of everything is available at the bottom of the Export tab.', 'wp-leadflow-crm' ),
				),
			),
			'leadflow-crm-access'         => array(
				'overview' => __( 'Decide what each role may do and who is part of the CRM team.', 'wp-leadflow-crm' ),
				'points'   => array(
					__( 'Administrators always keep every permission, so nobody can lock themselves out.', 'wp-leadflow-crm' ),
					__( 'The API tab explains how other applications can connect safely.', 'wp-leadflow-crm' ),
				),
			),
			'leadflow-crm-settings'       => array(
				'overview' => __( 'Business name, currency, pipeline stages, email sending, data retention and the system status report.', 'wp-leadflow-crm' ),
				'points'   => array(
					__( 'Data → retention deletes old activities, emails and trashed records automatically.', 'wp-leadflow-crm' ),
					__( 'Advanced → debug logging records what the plugin does while you troubleshoot.', 'wp-leadflow-crm' ),
				),
			),
		);

		return $topics[ $page ] ?? array(
			'overview' => __( 'LeadFlow CRM keeps your leads, companies, contacts, tasks and customer conversations in WordPress.', 'wp-leadflow-crm' ),
			'points'   => array(),
		);
	}
}
