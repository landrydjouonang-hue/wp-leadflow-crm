<?php
/**
 * Plugins screen links.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Admin;

use LeadFlow\CRM\Contracts\Hookable;
use LeadFlow\CRM\Modules\Settings\SettingsModule;
use LeadFlow\CRM\Security\Capabilities;

defined( 'ABSPATH' ) || exit;

/**
 * Adds "Dashboard" and "Settings" links to the plugin row.
 */
final class PluginLinks implements Hookable {

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_filter( 'plugin_action_links_' . LEADFLOW_CRM_BASENAME, array( $this, 'action_links' ) );
	}

	/**
	 * Prepends plugin action links.
	 *
	 * @param string[] $links Existing links.
	 * @return string[]
	 */
	public function action_links( array $links ): array {
		$ours = array();

		if ( current_user_can( Capabilities::ACCESS_CRM ) ) {
			$ours['dashboard'] = sprintf(
				'<a href="%1$s">%2$s</a>',
				esc_url( Menu::url() ),
				esc_html__( 'Dashboard', 'wp-leadflow-crm' )
			);
		}

		if ( current_user_can( Capabilities::MANAGE_SETTINGS ) ) {
			$ours['settings'] = sprintf(
				'<a href="%1$s">%2$s</a>',
				esc_url( Menu::url( SettingsModule::PAGE_SLUG ) ),
				esc_html__( 'Settings', 'wp-leadflow-crm' )
			);
		}

		return array_merge( $ours, $links );
	}
}
