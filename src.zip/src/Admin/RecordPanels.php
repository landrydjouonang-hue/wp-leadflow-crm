<?php
/**
 * Tabbed panels on record screens.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Admin;

use LeadFlow\CRM\Data\Model;

defined( 'ABSPATH' ) || exit;

/**
 * Collects the panels shown below a company, contact or lead
 * (Activity, Leads, Tasks, Follow-ups, Notes, ...) and renders them as
 * accessible tabs. Without JavaScript all panels are shown one after
 * another.
 *
 * Modules add panels on `leadflow_crm_record_panels`:
 *
 *     add_action( 'leadflow_crm_record_panels', function ( RecordPanels $panels, string $type, Model $record ) {
 *         $panels->add( 'tasks', array(
 *             'title'  => __( 'Tasks', 'wp-leadflow-crm' ),
 *             'count'  => 3,
 *             'order'  => 30,
 *             'render' => fn() => ...,
 *         ) );
 *     }, 10, 3 );
 */
final class RecordPanels {

	/**
	 * Panels keyed by id.
	 *
	 * @var array<string, array{id: string, title: string, count: int|null, order: int, render: callable}>
	 */
	private array $panels = array();

	/**
	 * Adds a panel.
	 *
	 * @param string               $id   Panel id.
	 * @param array<string, mixed> $args title, count (int|null), order, render (callable).
	 * @return void
	 */
	public function add( string $id, array $args ): void {
		if ( ! isset( $args['render'] ) || ! is_callable( $args['render'] ) ) {
			return;
		}

		$id = sanitize_key( $id );

		$this->panels[ $id ] = array(
			'id'     => $id,
			'title'  => (string) ( $args['title'] ?? $id ),
			'count'  => isset( $args['count'] ) ? (int) $args['count'] : null,
			'order'  => (int) ( $args['order'] ?? 50 ),
			'render' => $args['render'],
		);
	}

	/**
	 * Panels in order.
	 *
	 * @return array<string, array{id: string, title: string, count: int|null, order: int, render: callable}>
	 */
	public function all(): array {
		$panels = $this->panels;

		uasort( $panels, static fn( array $a, array $b ): int => $a['order'] <=> $b['order'] );

		return $panels;
	}

	/**
	 * Collects and renders the panels of a record.
	 *
	 * @param string $type   company|contact|lead.
	 * @param Model  $record Record.
	 * @return void
	 */
	public static function render_for( string $type, Model $record ): void {
		$registry = new self();

		/**
		 * Lets modules add panels to a record screen.
		 *
		 * @param RecordPanels $registry Panel registry.
		 * @param string       $type     company|contact|lead.
		 * @param Model        $record   Record.
		 */
		do_action( 'leadflow_crm_record_panels', $registry, $type, $record );

		$panels = $registry->all();

		if ( empty( $panels ) ) {
			return;
		}

		View::render(
			'admin/partials/record-panels',
			array(
				'panels' => $panels,
				'type'   => $type,
			)
		);
	}
}
