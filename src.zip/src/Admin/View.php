<?php
/**
 * Template renderer.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Renders PHP templates from /views in an isolated scope.
 *
 * Templates receive a single `$data` array and must escape all output.
 */
final class View {

	/**
	 * Renders a template.
	 *
	 * @param string               $template Path relative to /views, without extension, e.g. "admin/dashboard".
	 * @param array<string, mixed> $data     Template data.
	 * @return void
	 */
	public static function render( string $template, array $data = array() ): void {
		if ( 1 !== preg_match( '#^[a-z0-9\-]+(/[a-z0-9\-]+)*$#', $template ) ) {
			_doing_it_wrong( __METHOD__, esc_html( sprintf( 'Invalid template name "%s".', $template ) ), '0.1.0' );
			return;
		}

		$file = LEADFLOW_CRM_PATH . 'views/' . $template . '.php';

		if ( ! is_readable( $file ) ) {
			_doing_it_wrong( __METHOD__, esc_html( sprintf( 'Template "%s" not found.', $template ) ), '0.1.0' );
			return;
		}

		( static function ( string $leadflow_template_file, array $data ): void {
			include $leadflow_template_file;
		} )( $file, $data );
	}
}
