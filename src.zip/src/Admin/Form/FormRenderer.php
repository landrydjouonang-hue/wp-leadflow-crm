<?php
/**
 * Reusable form components.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Admin\Form;

use LeadFlow\CRM\Support\Countries;

defined( 'ABSPATH' ) || exit;

/**
 * Renders accessible form fields from declarative definitions.
 *
 * Field definition keys:
 *   name         string  Input name (required).
 *   label        string  Visible label (required).
 *   type         string  text|email|url|tel|date|datetime|number|textarea|select|country|user|record
 *                        (datetime: value in the site timezone, "Y-m-d\TH:i")
 *   min/max/step         number/date constraints.
 *   required     bool    Adds required + aria-required and a visual marker.
 *   description  string  Help text (linked with aria-describedby).
 *   placeholder  string
 *   maxlength    int
 *   autocomplete string  HTML autocomplete token.
 *   width        string  full (default) | half
 *   options      array   value => label (select, user, record).
 *   empty_label  string  First empty option for select-like fields.
 *   rows         int     Textarea rows.
 *   search       array   record only: array( 'endpoint' => 'companies', 'label' => '…' )
 *                        enables live search through the REST API.
 *
 * Every value is escaped on output.
 */
final class FormRenderer {

	/**
	 * Id attribute of a field.
	 *
	 * @param string $name Field name.
	 * @return string
	 */
	public static function id( string $name ): string {
		return 'lf-field-' . sanitize_html_class( $name );
	}

	/**
	 * Renders a titled group of fields.
	 *
	 * @param string                              $title       Section title.
	 * @param array<int, array<string, mixed>>    $fields      Field definitions.
	 * @param array<string, mixed>                $values      Current values.
	 * @param array<string, string>               $errors      Field errors.
	 * @param string                              $description Optional intro text.
	 * @return void
	 */
	public static function section( string $title, array $fields, array $values, array $errors, string $description = '' ): void {
		echo '<fieldset class="lf-form-section">';
		echo '<legend class="lf-form-section__title">' . esc_html( $title ) . '</legend>';

		if ( '' !== $description ) {
			echo '<p class="lf-form-section__description">' . esc_html( $description ) . '</p>';
		}

		echo '<div class="lf-form-grid">';

		foreach ( $fields as $field ) {
			self::field( $field, $values[ $field['name'] ] ?? '', $errors[ $field['name'] ] ?? null );
		}

		echo '</div></fieldset>';
	}

	/**
	 * Renders one field with label, help text and error.
	 *
	 * @param array<string, mixed> $field Definition.
	 * @param mixed                $value Current value.
	 * @param string|null          $error Error message.
	 * @return void
	 */
	public static function field( array $field, mixed $value, ?string $error = null ): void {
		$name     = (string) $field['name'];
		$id       = self::id( $name );
		$type     = (string) ( $field['type'] ?? 'text' );
		$required = ! empty( $field['required'] );
		$describe = array();

		if ( ! empty( $field['description'] ) ) {
			$describe[] = $id . '-description';
		}

		if ( null !== $error && '' !== $error ) {
			$describe[] = $id . '-error';
		}

		$classes = array( 'lf-field', 'lf-field--' . ( 'half' === ( $field['width'] ?? 'full' ) ? 'half' : 'full' ), 'lf-field--' . sanitize_html_class( $type ) );

		if ( null !== $error ) {
			$classes[] = 'lf-field--error';
		}

		echo '<div class="' . esc_attr( implode( ' ', $classes ) ) . '">';

		printf(
			'<label class="lf-field__label" for="%1$s">%2$s%3$s</label>',
			esc_attr( $id ),
			esc_html( (string) $field['label'] ),
			$required
				? ' <span class="lf-required" aria-hidden="true">*</span><span class="screen-reader-text"> ' . esc_html__( '(required)', 'wp-leadflow-crm' ) . '</span>'
				: ''
		);

		if ( 'record' === $type && ! empty( $field['search']['endpoint'] ) ) {
			self::record_search( $field, $id );
		}

		$attributes = array(
			'id'   => $id,
			'name' => $name,
		);

		if ( $required ) {
			$attributes['required']      = 'required';
			$attributes['aria-required'] = 'true';
		}

		if ( ! empty( $describe ) ) {
			$attributes['aria-describedby'] = implode( ' ', $describe );
		}

		if ( null !== $error ) {
			$attributes['aria-invalid'] = 'true';
		}

		switch ( $type ) {
			case 'textarea':
				$attributes['rows'] = (string) (int) ( $field['rows'] ?? 5 );
				self::maybe( $attributes, $field, array( 'placeholder', 'maxlength' ) );
				echo '<textarea class="large-text"' . self::attributes( $attributes ) . '>' . esc_textarea( (string) $value ) . '</textarea>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in attributes().
				break;

			case 'select':
			case 'user':
			case 'record':
			case 'country':
				$options = 'country' === $type ? Countries::all() : (array) ( $field['options'] ?? array() );
				self::select( $attributes, $options, (string) $value, $field['empty_label'] ?? null );
				break;

			default:
				$attributes['type']  = 'datetime' === $type ? 'datetime-local' : ( in_array( $type, array( 'email', 'url', 'tel', 'date', 'number' ), true ) ? $type : 'text' );
				$attributes['value'] = (string) $value;
				$attributes['class'] = 'regular-text';
				self::maybe( $attributes, $field, array( 'placeholder', 'maxlength', 'autocomplete', 'min', 'max', 'step', 'inputmode' ) );
				echo '<input' . self::attributes( $attributes ) . ' />'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in attributes().
		}

		if ( ! empty( $field['description'] ) ) {
			printf( '<p class="lf-field__description" id="%1$s-description">%2$s</p>', esc_attr( $id ), esc_html( (string) $field['description'] ) );
		}

		if ( null !== $error ) {
			printf( '<p class="lf-field__error" id="%1$s-error">%2$s</p>', esc_attr( $id ), esc_html( $error ) );
		}

		echo '</div>';
	}

	/**
	 * Error summary shown above the form. Links jump to the fields.
	 *
	 * @param array<string, string>            $errors Field => message.
	 * @param array<int, array<string, mixed>> $fields All field definitions.
	 * @return void
	 */
	public static function error_summary( array $errors, array $fields ): void {
		if ( empty( $errors ) ) {
			return;
		}

		$labels = array();

		foreach ( $fields as $field ) {
			$labels[ $field['name'] ] = (string) $field['label'];
		}

		echo '<div class="notice notice-error lf-error-summary" role="alert" tabindex="-1" data-lf-error-summary>';
		printf(
			'<p><strong>%s</strong></p><ul>',
			esc_html(
				sprintf(
					/* translators: %d: Number of errors. */
					_n( 'Please correct %d problem before saving:', 'Please correct %d problems before saving:', count( $errors ), 'wp-leadflow-crm' ),
					count( $errors )
				)
			)
		);

		foreach ( $errors as $name => $message ) {
			if ( isset( $labels[ $name ] ) ) {
				printf(
					'<li><a href="#%1$s">%2$s: %3$s</a></li>',
					esc_attr( self::id( (string) $name ) ),
					esc_html( $labels[ $name ] ),
					esc_html( $message )
				);
			} else {
				echo '<li>' . esc_html( $message ) . '</li>';
			}
		}

		echo '</ul></div>';
	}

	/**
	 * Renders a <select>.
	 *
	 * @param array<string, string>     $attributes  Attributes.
	 * @param array<int|string, string> $options     Value => label.
	 * @param string                    $value       Selected value.
	 * @param string|null               $empty_label Label of the empty option.
	 * @return void
	 */
	private static function select( array $attributes, array $options, string $value, ?string $empty_label ): void {
		echo '<select' . self::attributes( $attributes ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in attributes().

		if ( null !== $empty_label ) {
			printf( '<option value="">%s</option>', esc_html( $empty_label ) );
		}

		foreach ( $options as $option_value => $label ) {
			printf(
				'<option value="%1$s"%2$s>%3$s</option>',
				esc_attr( (string) $option_value ),
				selected( $value, (string) $option_value, false ),
				esc_html( (string) $label )
			);
		}

		echo '</select>';
	}

	/**
	 * Search box that refines a record <select> through the REST API
	 * (progressive enhancement; hidden when JavaScript is unavailable).
	 *
	 * @param array<string, mixed> $field Definition.
	 * @param string               $id    Select id.
	 * @return void
	 */
	private static function record_search( array $field, string $id ): void {
		printf(
			'<input type="search" class="lf-record-search regular-text hide-if-no-js" data-lf-record-search="%1$s" data-endpoint="%2$s" aria-controls="%1$s" aria-label="%3$s" placeholder="%3$s" autocomplete="off" />',
			esc_attr( $id ),
			esc_attr( (string) $field['search']['endpoint'] ),
			esc_attr( (string) ( $field['search']['label'] ?? __( 'Search…', 'wp-leadflow-crm' ) ) )
		);
	}

	/**
	 * Copies optional definition keys into attributes.
	 *
	 * @param array<string, string> $attributes Attributes (by reference).
	 * @param array<string, mixed>  $field      Definition.
	 * @param string[]              $keys       Keys to copy.
	 * @return void
	 */
	private static function maybe( array &$attributes, array $field, array $keys ): void {
		foreach ( $keys as $key ) {
			if ( isset( $field[ $key ] ) && '' !== (string) $field[ $key ] ) {
				$attributes[ $key ] = (string) $field[ $key ];
			}
		}
	}

	/**
	 * Escaped attribute string.
	 *
	 * @param array<string, string> $attributes Name => value.
	 * @return string
	 */
	private static function attributes( array $attributes ): string {
		$html = '';

		foreach ( $attributes as $name => $value ) {
			$html .= ' ' . esc_attr( $name ) . '="' . esc_attr( $value ) . '"';
		}

		return $html;
	}
}
