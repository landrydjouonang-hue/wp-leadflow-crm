<?php
/**
 * Base list table for CRM entities.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Admin\Crud;

use LeadFlow\CRM\Admin\UI;
use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Repository;
use LeadFlow\CRM\Security\Input;
use LeadFlow\CRM\Support\Format;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( '\WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * WP_List_Table with repository paging, status views (incl. Trash),
 * search, allow-listed sorting, filters and bulk actions.
 */
abstract class EntityListTable extends \WP_List_Table {

	/**
	 * Constructor.
	 *
	 * @param EntityAdmin $admin      Owning admin controller.
	 * @param Repository  $repository Repository.
	 */
	public function __construct( protected EntityAdmin $admin, protected Repository $repository ) {
		parent::__construct(
			array(
				'singular' => $admin->entity(),
				'plural'   => $admin->plural(),
				'ajax'     => false,
				'screen'   => get_current_screen(),
			)
		);
	}

	/**
	 * Extra query arguments from the filter controls.
	 *
	 * @return array<string, mixed>
	 */
	abstract protected function filter_args(): array;

	/**
	 * Renders the filter controls (top tablenav).
	 *
	 * @return void
	 */
	abstract protected function render_filters(): void;

	/**
	 * Default sort column and direction.
	 *
	 * @return array{0: string, 1: string}
	 */
	protected function default_order(): array {
		return array( 'created_at', 'desc' );
	}

	/**
	 * Loads related data for the current page in bulk (avoid N+1).
	 *
	 * @param Model[] $items Page items.
	 * @return void
	 */
	protected function prefetch( array $items ): void {}

	/**
	 * Current status view: all | trash | a status key.
	 *
	 * @return string
	 */
	public function current_status(): string {
		$allowed = array_merge( array( 'all', 'trash' ), array_keys( $this->admin->status_labels() ), array_keys( $this->extra_views() ) );

		return Input::one_of( 'status', $allowed, 'all' );
	}

	/**
	 * Whether the Trash view is shown.
	 *
	 * @return bool
	 */
	public function is_trash(): bool {
		return 'trash' === $this->current_status();
	}

	/**
	 * {@inheritDoc}
	 */
	public function prepare_items(): void {
		$per_page = $this->get_items_per_page( $this->admin->per_page_option(), $this->admin->default_per_page() );
		$allowed  = array();

		foreach ( $this->get_sortable_columns() as $sortable ) {
			$allowed[] = is_array( $sortable ) ? $sortable[0] : $sortable;
		}

		list( $default_by, $default_order ) = $this->default_order();

		$orderby = Input::key( 'orderby' );
		$orderby = in_array( $orderby, $allowed, true ) ? $orderby : $default_by;
		$order   = Input::one_of( 'order', array( 'asc', 'desc' ), $default_order );

		$args = array_merge_recursive(
			$this->filter_args(),
			array(
				'search'   => Input::text( 's' ),
				'orderby'  => $orderby,
				'order'    => $order,
				'per_page' => $per_page,
				'page'     => $this->get_pagenum(),
			)
		);

		$result = $this->repository->paginate( $this->status_args( $args, $this->current_status() ) );

		$this->items = $result['items'];
		$this->prefetch( $this->items );

		$this->set_pagination_args(
			array(
				'total_items' => $result['total'],
				'per_page'    => $per_page,
				'total_pages' => $result['pages'],
			)
		);
	}

	/**
	 * Applies the current status view to the query.
	 *
	 * @param array<string, mixed> $args   Query arguments.
	 * @param string               $status Current view.
	 * @return array<string, mixed>
	 */
	protected function status_args( array $args, string $status ): array {
		if ( 'trash' === $status ) {
			$args['trashed'] = 'only';
		} elseif ( 'all' !== $status ) {
			$args['where']           = (array) ( $args['where'] ?? array() );
			$args['where']['status'] = $status;
		}

		return $args;
	}

	/**
	 * Extra views next to the status links (key => array( label, count )).
	 * Subclasses handle them in status_args().
	 *
	 * @return array<string, array{0: string, 1: int}>
	 */
	protected function extra_views(): array {
		return array();
	}

	/**
	 * Extra row actions (before "Trash").
	 *
	 * @param Model  $item  Row.
	 * @param string $title Record title.
	 * @return array<string, string>
	 */
	protected function extra_row_actions( Model $item, string $title ): array {
		return array();
	}

	/**
	 * Status links above the table.
	 *
	 * @return array<string, string>
	 */
	protected function get_views(): array {
		$counts  = $this->repository->count_by( 'status' );
		$current = $this->current_status();
		$views   = array(
			'all' => $this->view_link( 'all', __( 'All', 'wp-leadflow-crm' ), array_sum( $counts ), $current ),
		);

		foreach ( $this->admin->status_labels() as $status => $label ) {
			if ( ! empty( $counts[ $status ] ) || $current === $status ) {
				$views[ $status ] = $this->view_link( $status, $label, (int) ( $counts[ $status ] ?? 0 ), $current );
			}
		}

		foreach ( $this->extra_views() as $key => list( $label, $count ) ) {
			$views[ $key ] = $this->view_link( $key, $label, $count, $current );
		}

		$trash = $this->repository->count( array( 'trashed' => 'only' ) );

		if ( $trash > 0 || 'trash' === $current ) {
			$views['trash'] = $this->view_link( 'trash', __( 'Trash', 'wp-leadflow-crm' ), $trash, $current );
		}

		return $views;
	}

	/**
	 * One status link.
	 *
	 * @param string $status  Status.
	 * @param string $label   Label.
	 * @param int    $count   Count.
	 * @param string $current Current status.
	 * @return string
	 */
	private function view_link( string $status, string $label, int $count, string $current ): string {
		return sprintf(
			'<a href="%1$s"%2$s>%3$s <span class="count">(%4$s)</span></a>',
			esc_url( $this->admin->url( 'all' === $status ? array() : array( 'status' => $status ) ) ),
			$status === $current ? ' class="current" aria-current="page"' : '',
			esc_html( $label ),
			esc_html( number_format_i18n( $count ) )
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_bulk_actions(): array {
		if ( $this->is_trash() ) {
			return current_user_can( $this->admin->cap( 'delete' ) )
				? array(
					'bulk_restore' => __( 'Restore', 'wp-leadflow-crm' ),
					'bulk_delete'  => __( 'Delete permanently', 'wp-leadflow-crm' ),
				)
				: array();
		}

		$actions = $this->admin->extra_bulk_actions();

		if ( current_user_can( $this->admin->cap( 'delete' ) ) ) {
			$actions['bulk_trash'] = __( 'Move to trash', 'wp-leadflow-crm' );
		}

		return $actions;
	}

	/**
	 * Checkbox column.
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_cb( $item ): string {
		if ( empty( $this->get_bulk_actions() ) ) {
			return '';
		}

		return sprintf(
			'<label class="screen-reader-text" for="lf-cb-%1$d">%2$s</label><input type="checkbox" id="lf-cb-%1$d" name="ids[]" value="%1$d" />',
			$item->id(),
			esc_html(
				sprintf(
					/* translators: %s: Record title. */
					__( 'Select %s', 'wp-leadflow-crm' ),
					$this->admin->title_of( $item )
				)
			)
		);
	}

	/**
	 * Primary column: linked title, optional subtitle and row actions.
	 *
	 * @param Model  $item     Row.
	 * @param string $subtitle Plain-text second line.
	 * @param string $avatar   Escaped avatar HTML.
	 * @return string
	 */
	protected function primary_cell( Model $item, string $subtitle = '', string $avatar = '' ): string {
		$title = $this->admin->title_of( $item );

		return sprintf(
			'<div class="lf-cell-primary">%1$s<div><strong><a class="row-title" href="%2$s">%3$s</a></strong>%4$s</div></div>%5$s',
			$avatar,
			esc_url( $this->admin->view_url( $item->id() ) ),
			esc_html( $title ),
			'' !== $subtitle ? '<span class="lf-cell-subtitle">' . esc_html( $subtitle ) . '</span>' : '',
			$this->row_actions( $this->row_action_links( $item, $title ) )
		);
	}

	/**
	 * Row action links.
	 *
	 * @param Model  $item  Row.
	 * @param string $title Record title (for accessible labels).
	 * @return array<string, string>
	 */
	protected function row_action_links( Model $item, string $title ): array {
		$actions = array();
		$id      = $item->id();

		if ( $this->is_trash() ) {
			if ( current_user_can( $this->admin->meta_cap( 'delete' ), $id ) ) {
				$actions['restore'] = $this->action_link( $this->admin->action_url( 'restore', $id ), __( 'Restore', 'wp-leadflow-crm' ), $title );
				$actions['delete']  = $this->action_link( $this->admin->action_url( 'delete', $id ), __( 'Delete permanently', 'wp-leadflow-crm' ), $title, $this->admin->labels()['delete_confirm'] );
			}

			return $actions;
		}

		$actions['view'] = $this->action_link( $this->admin->view_url( $id ), __( 'View', 'wp-leadflow-crm' ), $title );

		if ( current_user_can( $this->admin->meta_cap( 'edit' ), $id ) ) {
			$actions['edit'] = $this->action_link( $this->admin->edit_url( $id ), __( 'Edit', 'wp-leadflow-crm' ), $title );
		}

		$actions = array_merge( $actions, $this->extra_row_actions( $item, $title ) );

		if ( current_user_can( $this->admin->meta_cap( 'delete' ), $id ) ) {
			$actions['trash'] = $this->action_link( $this->admin->action_url( 'trash', $id ), __( 'Trash', 'wp-leadflow-crm' ), $title );
		}

		return $actions;
	}

	/**
	 * Accessible row action link ("Edit" + hidden "“Acme”").
	 *
	 * @param string $url     URL.
	 * @param string $label   Visible label.
	 * @param string $title   Record title.
	 * @param string $confirm Optional confirmation question.
	 * @return string
	 */
	protected function action_link( string $url, string $label, string $title, string $confirm = '' ): string {
		return sprintf(
			'<a href="%1$s"%2$s>%3$s<span class="screen-reader-text"> “%4$s”</span></a>',
			esc_url( $url ),
			'' !== $confirm ? ' data-lf-confirm="' . esc_attr( $confirm ) . '"' : '',
			esc_html( $label ),
			esc_html( $title )
		);
	}

	/**
	 * Status column.
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_status( Model $item ): string {
		$status = (string) $item->get( 'status', '' );

		return UI::badge( $status, $this->admin->status_labels()[ $status ] ?? $status );
	}

	/**
	 * Owner column.
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_owner_id( Model $item ): string {
		return UI::text( Format::user( $item->get( 'owner_id' ) ) );
	}

	/**
	 * Created column.
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_created_at( Model $item ): string {
		return UI::time( $item->get( 'created_at' ) );
	}

	/**
	 * Fallback column output.
	 *
	 * @param Model  $item        Row.
	 * @param string $column_name Column.
	 * @return string
	 */
	protected function column_default( $item, $column_name ): string {
		return UI::text( (string) $item->get( $column_name, '' ) );
	}

	/**
	 * Filters above the table.
	 *
	 * @param string $which top|bottom.
	 * @return void
	 */
	protected function extra_tablenav( $which ): void {
		if ( 'top' !== $which || $this->is_trash() ) {
			return;
		}

		echo '<div class="alignleft actions lf-filters">';
		$this->render_filters();
		submit_button( __( 'Filter', 'wp-leadflow-crm' ), '', 'filter_action', false, array( 'id' => 'lf-filter-submit' ) );
		echo '</div>';
	}

	/**
	 * Accessible filter dropdown.
	 *
	 * @param string                    $name      Query arg.
	 * @param string                    $label     Accessible label.
	 * @param array<int|string, string> $options   Value => label.
	 * @param string                    $all_label Label of the "any" option.
	 * @return void
	 */
	protected function filter_select( string $name, string $label, array $options, string $all_label ): void {
		$current = Input::text( $name );
		$id      = 'lf-filter-' . sanitize_html_class( $name );

		printf( '<label class="screen-reader-text" for="%1$s">%2$s</label>', esc_attr( $id ), esc_html( $label ) );
		printf( '<select id="%1$s" name="%2$s"><option value="">%3$s</option>', esc_attr( $id ), esc_attr( $name ), esc_html( $all_label ) );

		foreach ( $options as $value => $option_label ) {
			printf(
				'<option value="%1$s"%2$s>%3$s</option>',
				esc_attr( (string) $value ),
				selected( $current, (string) $value, false ),
				esc_html( $option_label )
			);
		}

		echo '</select>';
	}

	/**
	 * Message when there are no rows.
	 *
	 * @return void
	 */
	public function no_items(): void {
		$labels   = $this->admin->labels();
		$filtered = '' !== Input::text( 's' ) || ! empty( array_filter( $this->filter_args()['where'] ?? array() ) ) || 'all' !== $this->current_status();

		if ( $this->is_trash() ) {
			echo esc_html( $labels['not_found_trash'] );
			return;
		}

		// Filtered search vs. a genuinely empty CRM: different help.
		if ( $filtered ) {
			printf(
				'<span class="lf-empty-state__text">%1$s</span> <a href="%2$s">%3$s</a>',
				esc_html( $labels['not_found'] ),
				esc_url( $this->admin->url() ),
				esc_html__( 'Clear filters', 'wp-leadflow-crm' )
			);
			return;
		}

		echo '<div class="lf-empty-state">';
		printf(
			'<span class="dashicons dashicons-%1$s" aria-hidden="true"></span><p class="lf-empty-state__text">%2$s</p>',
			esc_attr( $this->empty_icon() ),
			esc_html( $labels['not_found'] )
		);

		if ( current_user_can( $this->admin->cap( 'edit' ) ) ) {
			printf(
				'<p><a class="button button-primary" href="%1$s">%2$s</a></p>',
				esc_url( $this->admin->new_url() ),
				esc_html( $labels['add_new'] )
			);
		}

		echo '</div>';
	}

	/**
	 * Dashicon shown in the empty state.
	 *
	 * @return string
	 */
	protected function empty_icon(): string {
		return 'portfolio';
	}
}
