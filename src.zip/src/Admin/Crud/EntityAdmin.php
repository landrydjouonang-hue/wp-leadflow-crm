<?php
/**
 * Base admin controller for a CRM entity.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Admin\Crud;

use LeadFlow\CRM\Admin\Menu;
use LeadFlow\CRM\Admin\Notices;
use LeadFlow\CRM\Admin\Page;
use LeadFlow\CRM\Admin\View;
use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\RecordNotFoundException;
use LeadFlow\CRM\Data\Repository;
use LeadFlow\CRM\Data\ValidationException;
use LeadFlow\CRM\Plugin;
use LeadFlow\CRM\Security\Capabilities;
use LeadFlow\CRM\Security\Guard;
use LeadFlow\CRM\Security\Input;
use LeadFlow\CRM\Security\Nonce;
use LeadFlow\CRM\Settings\Settings;
use LeadFlow\CRM\Support\Format;

defined( 'ABSPATH' ) || exit;

/**
 * List / add / edit / view screens for one entity, plus the protected
 * actions behind them.
 *
 * Screens: admin.php?page={slug}[&action=new|edit|view&id=N]
 * Actions: admin-post.php?action=leadflow_crm_{save|trash|restore|delete}_{entity}
 *
 * Capabilities (primitive):
 *   leadflow_view_{plural}         see the screens
 *   leadflow_edit_{plural}         create, and edit records you own
 *   leadflow_edit_others_{plural}  edit anyone's records, change the owner
 *   leadflow_delete_{plural}       trash, restore, delete permanently
 * Meta capabilities (take a record id): leadflow_edit_{entity},
 * leadflow_delete_{entity}.
 *
 * Every state change: nonce → capability → repository → flash → redirect.
 */
abstract class EntityAdmin {

	/** Singular entity key, e.g. "company". */
	protected const ENTITY = '';

	/** Plural key, e.g. "companies". */
	protected const PLURAL = '';

	/** Admin page slug. */
	protected const PAGE_SLUG = '';

	/** Position in the CRM menu. */
	protected const MENU_ORDER = 50;

	/** Bulk actions. */
	private const BULK_ACTIONS = array( 'bulk_trash', 'bulk_restore', 'bulk_delete' );

	/**
	 * List table, built on `load-{page}` so its columns are registered
	 * before WordPress caches the screen's column headers.
	 *
	 * @var EntityListTable|null
	 */
	private ?EntityListTable $table = null;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( protected Plugin $plugin ) {}

	// ------------------------------------------------------------------
	// Entity definition (implemented by subclasses).
	// ------------------------------------------------------------------

	/**
	 * Repository.
	 *
	 * @return Repository
	 */
	abstract public function repository(): Repository;

	/**
	 * Translated labels: singular, plural, add_new, edit, search, not_found,
	 * not_found_trash, created, updated, trashed, restored, deleted,
	 * delete_confirm.
	 *
	 * @return array<string, string>
	 */
	abstract public function labels(): array;

	/**
	 * Status value => translated label.
	 *
	 * @return array<string, string>
	 */
	abstract public function status_labels(): array;

	/**
	 * Main form sections: list of array( title, description?, fields ).
	 *
	 * @param Model|null $model Record being edited.
	 * @return array<int, array<string, mixed>>
	 */
	abstract protected function form_sections( ?Model $model ): array;

	/**
	 * Sidebar fields (status, owner, ...).
	 *
	 * @param Model|null $model Record being edited.
	 * @return array<int, array<string, mixed>>
	 */
	abstract protected function sidebar_fields( ?Model $model ): array;

	/**
	 * List table.
	 *
	 * @return EntityListTable
	 */
	abstract protected function create_list_table(): EntityListTable;

	/**
	 * Renders the read-only record screen.
	 *
	 * @param Model $model Record.
	 * @return void
	 */
	abstract protected function render_view( Model $model ): void;

	/**
	 * Display title of a record.
	 *
	 * @param Model $model Record.
	 * @return string
	 */
	abstract public function title_of( Model $model ): string;

	/**
	 * Values pre-filled on the "Add" screen.
	 *
	 * @return array<string, mixed>
	 */
	protected function default_values(): array {
		return array();
	}

	/**
	 * Runs after a successful save (e.g. to store an initial note).
	 *
	 * @param Model                $model   Saved record.
	 * @param bool                 $created Whether it was just created.
	 * @param array<string, mixed> $extra   Non-persisted form values.
	 * @return void
	 */
	protected function after_save( Model $model, bool $created, array $extra ): void {}

	/**
	 * Extra sidebar content on the add/edit screen (help, previews, ...).
	 *
	 * @param Model|null $model Record being edited.
	 * @return void
	 */
	public function form_aside( ?Model $model ): void {}

	/**
	 * Additional bulk actions (key => label), shown outside the Trash view.
	 *
	 * @return array<string, string>
	 */
	public function extra_bulk_actions(): array {
		return array();
	}

	/**
	 * Handles an additional bulk action. The bulk nonce is already verified;
	 * implementations must check capabilities per record.
	 *
	 * @param string $action Action key.
	 * @param int[]  $ids    Selected record ids.
	 * @return string Flash message.
	 */
	protected function handle_extra_bulk( string $action, array $ids ): string {
		return '';
	}

	// ------------------------------------------------------------------
	// Capabilities.
	// ------------------------------------------------------------------

	/**
	 * Entity key.
	 *
	 * @return string
	 */
	public function entity(): string {
		return static::ENTITY;
	}

	/**
	 * Plural key.
	 *
	 * @return string
	 */
	public function plural(): string {
		return static::PLURAL;
	}

	/**
	 * Primitive capability.
	 *
	 * @param string $what view|edit|edit_others|delete.
	 * @return string
	 */
	public function cap( string $what ): string {
		return 'leadflow_' . $what . '_' . static::PLURAL;
	}

	/**
	 * Meta capability taking a record id.
	 *
	 * @param string $what edit|delete.
	 * @return string
	 */
	public function meta_cap( string $what ): string {
		return 'leadflow_' . $what . '_' . static::ENTITY;
	}

	/**
	 * Default role grants (used by ProvidesCapabilities).
	 *
	 * Sales agents may view everything and edit what they own; managers
	 * may edit everything and delete.
	 *
	 * @return array<string, string[]>
	 */
	public function capability_map(): array {
		$all      = array( 'administrator', Capabilities::ROLE_MANAGER, Capabilities::ROLE_AGENT );
		$managers = array( 'administrator', Capabilities::ROLE_MANAGER );

		return array(
			$this->cap( 'view' )        => $all,
			$this->cap( 'edit' )        => $all,
			$this->cap( 'edit_others' ) => $managers,
			$this->cap( 'delete' )      => $managers,
		);
	}

	/**
	 * Maps meta capabilities to primitive ones.
	 *
	 * @param string[] $caps    Required primitive caps.
	 * @param string   $cap     Requested cap.
	 * @param int      $user_id User.
	 * @param mixed[]  $args    Extra args (record id).
	 * @return string[]
	 */
	public function map_meta_cap( array $caps, string $cap, int $user_id, array $args ): array {
		if ( $cap !== $this->meta_cap( 'edit' ) && $cap !== $this->meta_cap( 'delete' ) ) {
			return $caps;
		}

		$model = $this->repository()->find( (int) ( $args[0] ?? 0 ), true );

		if ( null === $model ) {
			return array( 'do_not_allow' );
		}

		if ( $cap === $this->meta_cap( 'delete' ) ) {
			return array( $this->cap( 'delete' ) );
		}

		return (int) $model->get( 'owner_id' ) === $user_id && $user_id > 0
			? array( $this->cap( 'edit' ) )
			: array( $this->cap( 'edit_others' ) );
	}

	// ------------------------------------------------------------------
	// Wiring.
	// ------------------------------------------------------------------

	/**
	 * Registers hooks. Call from the module's boot().
	 *
	 * @return void
	 */
	public function register(): void {
		foreach ( array( 'save', 'trash', 'restore', 'delete' ) as $action ) {
			add_action( 'admin_post_leadflow_crm_' . $action . '_' . static::ENTITY, array( $this, 'handle_' . $action ) );
		}

		add_filter( 'map_meta_cap', array( $this, 'map_meta_cap' ), 10, 4 );
		add_filter( 'set_screen_option_' . $this->per_page_option(), array( $this, 'save_per_page' ), 10, 3 );
	}

	/**
	 * Admin page definition.
	 *
	 * @return Page
	 */
	public function page(): Page {
		$labels = $this->labels();

		return new Page(
			static::PAGE_SLUG,
			$labels['plural'],
			$labels['plural'],
			$this->cap( 'view' ),
			array( $this, 'render' ),
			static::MENU_ORDER,
			array( $this, 'load' )
		);
	}

	/**
	 * Screen-options user meta key for rows per page.
	 *
	 * @return string
	 */
	public function per_page_option(): string {
		return 'leadflow_crm_' . static::PLURAL . '_per_page';
	}

	/**
	 * Default rows per page (plugin setting).
	 *
	 * @return int
	 */
	public function default_per_page(): int {
		return max( 5, (int) $this->plugin->get( Settings::class )->get( 'items_per_page', 20 ) );
	}

	/**
	 * Validates the screen option value.
	 *
	 * @param mixed  $keep   Previous filter value.
	 * @param string $option Option name.
	 * @param mixed  $value  Submitted value.
	 * @return int
	 */
	public function save_per_page( mixed $keep, string $option, mixed $value ): int {
		return max( 1, min( 200, (int) $value ) );
	}

	// ------------------------------------------------------------------
	// URLs.
	// ------------------------------------------------------------------

	/**
	 * Screen URL.
	 *
	 * @param array<string, mixed> $args Query args.
	 * @return string Unescaped URL.
	 */
	public function url( array $args = array() ): string {
		return Menu::url( static::PAGE_SLUG, $args );
	}

	/**
	 * View screen URL.
	 *
	 * @param int $id Record id.
	 * @return string
	 */
	public function view_url( int $id ): string {
		return $this->url(
			array(
				'action' => 'view',
				'id'     => $id,
			)
		);
	}

	/**
	 * Edit screen URL.
	 *
	 * @param int $id Record id.
	 * @return string
	 */
	public function edit_url( int $id ): string {
		return $this->url(
			array(
				'action' => 'edit',
				'id'     => $id,
			)
		);
	}

	/**
	 * Add screen URL.
	 *
	 * @param array<string, mixed> $prefill Extra query args.
	 * @return string
	 */
	public function new_url( array $prefill = array() ): string {
		return $this->url( array_merge( array( 'action' => 'new' ), $prefill ) );
	}

	/**
	 * Nonce-protected admin-post URL for trash/restore/delete.
	 *
	 * @param string $action trash|restore|delete.
	 * @param int    $id     Record id.
	 * @return string Unescaped URL.
	 */
	public function action_url( string $action, int $id ): string {
		return Nonce::url(
			add_query_arg(
				array(
					'action' => 'leadflow_crm_' . $action . '_' . static::ENTITY,
					'id'     => $id,
				),
				admin_url( 'admin-post.php' )
			),
			$action . '_' . static::ENTITY . '_' . $id
		);
	}

	// ------------------------------------------------------------------
	// Screens.
	// ------------------------------------------------------------------

	/**
	 * Current screen: list|new|edit|view.
	 *
	 * @return string
	 */
	protected function screen(): string {
		return Input::one_of( 'action', array( 'new', 'edit', 'view' ), 'list' );
	}

	/**
	 * `load-{page}`: screen options and bulk actions (before output).
	 *
	 * @return void
	 */
	public function load(): void {
		if ( 'list' !== $this->screen() ) {
			return;
		}

		add_screen_option(
			'per_page',
			array(
				'default' => $this->default_per_page(),
				'option'  => $this->per_page_option(),
			)
		);

		$this->handle_bulk();

		// Must exist before admin-header renders Screen Options (column toggles).
		$this->table = $this->create_list_table();
	}

	/**
	 * Page callback.
	 *
	 * @return void
	 */
	public function render(): void {
		Guard::authorize( $this->cap( 'view' ) );

		switch ( $this->screen() ) {
			case 'new':
				Guard::authorize( $this->cap( 'edit' ) );
				$this->render_form( null );
				return;

			case 'edit':
				$model = $this->find_or_die();
				Guard::authorize( $this->meta_cap( 'edit' ), $model->id() );
				$this->render_form( $model );
				return;

			case 'view':
				$this->render_view( $this->find_or_die() );
				return;

			default:
				$this->render_list();
		}
	}

	/**
	 * List screen.
	 *
	 * @return void
	 */
	protected function render_list(): void {
		$table = $this->table ?? $this->create_list_table();
		$table->prepare_items();

		View::render(
			'admin/crud/list',
			array(
				'admin'      => $this,
				'table'      => $table,
				'labels'     => $this->labels(),
				'can_create' => current_user_can( $this->cap( 'edit' ) ),
			)
		);
	}

	/**
	 * Add/edit screen.
	 *
	 * @param Model|null $model Record being edited.
	 * @return void
	 */
	protected function render_form( ?Model $model ): void {
		$values = null === $model ? $this->default_values() : $model->to_array();
		$errors = array();
		$old    = $this->pull_old_input( $model );

		if ( null !== $old ) {
			$values = array_merge( $values, $old['values'] );
			$errors = $old['errors'];
		}

		$sections = $this->form_sections( $model );
		$sidebar  = $this->sidebar_fields( $model );

		// Datetimes are stored in UTC and edited in the site timezone.
		foreach ( $this->flatten_fields( $sections, $sidebar ) as $field ) {
			if ( 'datetime' === ( $field['type'] ?? '' ) ) {
				$values[ $field['name'] ] = Format::to_input( isset( $values[ $field['name'] ] ) ? (string) $values[ $field['name'] ] : null );
			}
		}

		View::render(
			'admin/crud/form',
			array(
				'admin'      => $this,
				'model'      => $model,
				'labels'     => $this->labels(),
				'title'      => null === $model ? $this->labels()['add_new'] : $this->title_of( $model ),
				'sections'   => $sections,
				'sidebar'    => $sidebar,
				'all_fields' => $this->flatten_fields( $sections, $sidebar ),
				'values'     => $values,
				'errors'     => $errors,
				'nonce'      => 'save_' . static::ENTITY . '_' . ( null === $model ? 0 : $model->id() ),
				'cancel_url' => null === $model ? $this->url() : $this->view_url( $model->id() ),
			)
		);
	}

	/**
	 * Header action buttons for the view screen.
	 *
	 * @param Model $model Record.
	 * @return array<int, array<string, mixed>>
	 */
	public function view_actions( Model $model ): array {
		$labels  = $this->labels();
		$actions = array();

		if ( $model->is_trashed() ) {
			if ( current_user_can( $this->meta_cap( 'delete' ), $model->id() ) ) {
				$actions[] = array(
					'label'   => __( 'Restore', 'wp-leadflow-crm' ),
					'url'     => $this->action_url( 'restore', $model->id() ),
					'primary' => true,
				);
				$actions[] = array(
					'label'   => __( 'Delete permanently', 'wp-leadflow-crm' ),
					'url'     => $this->action_url( 'delete', $model->id() ),
					'class'   => 'lf-button-danger',
					'confirm' => $labels['delete_confirm'],
				);
			}

			return $actions;
		}

		if ( current_user_can( $this->meta_cap( 'edit' ), $model->id() ) ) {
			$actions[] = array(
				'label'   => __( 'Edit', 'wp-leadflow-crm' ),
				'url'     => $this->edit_url( $model->id() ),
				'primary' => true,
			);
		}

		/**
		 * Filters the header buttons of a record screen (before "Move to trash").
		 *
		 * @param array<int, array<string, mixed>> $actions Buttons: label, url, primary?, class?, confirm?.
		 * @param string                           $entity  Entity key, e.g. "lead".
		 * @param Model                            $model   Record.
		 */
		$actions = (array) apply_filters( 'leadflow_crm_record_actions', $actions, static::ENTITY, $model );

		if ( current_user_can( $this->meta_cap( 'delete' ), $model->id() ) ) {
			$actions[] = array(
				'label' => __( 'Move to trash', 'wp-leadflow-crm' ),
				'url'   => $this->action_url( 'trash', $model->id() ),
				'class' => 'lf-button-danger',
			);
		}

		return $actions;
	}

	// ------------------------------------------------------------------
	// Actions.
	// ------------------------------------------------------------------

	/**
	 * Creates or updates a record from the form.
	 *
	 * @return void
	 */
	public function handle_save(): void {
		$id = Input::int( 'id', 'post' );

		check_admin_referer( Nonce::action( 'save_' . static::ENTITY . '_' . $id ), Nonce::FIELD );

		$model = null;

		if ( $id > 0 ) {
			$model = $this->repository()->find( $id, true );

			if ( null === $model ) {
				$this->not_found();
			}

			Guard::authorize( $this->meta_cap( 'edit' ), $id );
		} else {
			Guard::authorize( $this->cap( 'edit' ) );
		}

		list( $data, $extra ) = $this->collect_input( $model );

		try {
			$saved = null === $model ? $this->repository()->create( $data ) : $this->repository()->update( $id, $data );
		} catch ( ValidationException $e ) {
			$this->store_old_input( $model, array_merge( $data, $extra ), $e->errors() );
			wp_safe_redirect( null === $model ? $this->new_url() : $this->edit_url( $id ) );
			exit;
		}

		$this->after_save( $saved, null === $model, $extra );

		Notices::flash( 'success', null === $model ? $this->labels()['created'] : $this->labels()['updated'] );
		wp_safe_redirect( $this->view_url( $saved->id() ) );
		exit;
	}

	/**
	 * Moves a record to the trash.
	 *
	 * @return void
	 */
	public function handle_trash(): void {
		$id = $this->verify_record_action( 'trash' );

		if ( $this->repository()->trash( $id ) ) {
			Notices::flash( 'success', $this->labels()['trashed'] );
		}

		wp_safe_redirect( $this->url() );
		exit;
	}

	/**
	 * Restores a record from the trash.
	 *
	 * @return void
	 */
	public function handle_restore(): void {
		$id = $this->verify_record_action( 'restore' );

		if ( $this->repository()->restore( $id ) ) {
			Notices::flash( 'success', $this->labels()['restored'] );
		}

		wp_safe_redirect( $this->view_url( $id ) );
		exit;
	}

	/**
	 * Permanently deletes a trashed record.
	 *
	 * @return void
	 */
	public function handle_delete(): void {
		$id    = $this->verify_record_action( 'delete' );
		$model = $this->repository()->find( $id, true );

		// Only records already in the trash can be deleted permanently.
		if ( null !== $model && $model->is_trashed() && $this->repository()->delete( $id ) ) {
			Notices::flash( 'success', $this->labels()['deleted'] );
		}

		wp_safe_redirect( $this->url( array( 'status' => 'trash' ) ) );
		exit;
	}

	/**
	 * Processes list-table bulk actions.
	 *
	 * @return void
	 */
	private function handle_bulk(): void {
		$allowed = array_merge( self::BULK_ACTIONS, array_keys( $this->extra_bulk_actions() ) );
		$action  = Input::key( 'action' );

		if ( ! in_array( $action, $allowed, true ) ) {
			$action = Input::key( 'action2' );
		}

		if ( ! in_array( $action, $allowed, true ) ) {
			return;
		}

		check_admin_referer( 'bulk-' . static::PLURAL );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce checked above; values cast to int.
		$ids    = array_filter( array_map( 'absint', (array) wp_unslash( $_REQUEST['ids'] ?? array() ) ) );
		$done   = 0;
		$status = Input::key( 'status' );

		if ( ! in_array( $action, self::BULK_ACTIONS, true ) ) {
			$message = $this->handle_extra_bulk( $action, $ids );

			if ( '' !== $message ) {
				Notices::flash( 'info', $message );
			}

			wp_safe_redirect( $this->url( '' !== $status ? array( 'status' => $status ) : array() ) );
			exit;
		}

		foreach ( $ids as $id ) {
			if ( ! current_user_can( $this->meta_cap( 'delete' ), $id ) ) {
				continue;
			}

			$repository = $this->repository();
			$model      = $repository->find( $id, true );

			$ok = match ( $action ) {
				'bulk_trash'   => $repository->trash( $id ),
				'bulk_restore' => $repository->restore( $id ),
				'bulk_delete'  => null !== $model && $model->is_trashed() && $repository->delete( $id ),
			};

			$done += $ok ? 1 : 0;
		}

		$messages = array(
			/* translators: %d: Number of records. */
			'bulk_trash'   => _n( '%d record moved to the trash.', '%d records moved to the trash.', $done, 'wp-leadflow-crm' ),
			/* translators: %d: Number of records. */
			'bulk_restore' => _n( '%d record restored.', '%d records restored.', $done, 'wp-leadflow-crm' ),
			/* translators: %d: Number of records. */
			'bulk_delete'  => _n( '%d record permanently deleted.', '%d records permanently deleted.', $done, 'wp-leadflow-crm' ),
		);

		Notices::flash( $done > 0 ? 'success' : 'warning', sprintf( $messages[ $action ], $done ) );

		wp_safe_redirect( $this->url( '' !== $status ? array( 'status' => $status ) : array() ) );
		exit;
	}

	/**
	 * Verifies nonce and delete capability for a record action link.
	 *
	 * @param string $action trash|restore|delete.
	 * @return int Record id.
	 */
	private function verify_record_action( string $action ): int {
		$id = Input::int( 'id' );

		if ( ! Nonce::verify( Input::text( Nonce::FIELD ), $action . '_' . static::ENTITY . '_' . $id ) ) {
			wp_nonce_ays( '' );
		}

		Guard::authorize( $this->meta_cap( 'delete' ), $id );

		return $id;
	}

	// ------------------------------------------------------------------
	// Helpers.
	// ------------------------------------------------------------------

	/**
	 * Reads submitted values for the rendered fields.
	 *
	 * Fields with `'persist' => false` are returned separately.
	 *
	 * @param Model|null $model Record being edited.
	 * @return array{0: array<string, string>, 1: array<string, string>} Data, extra.
	 */
	protected function collect_input( ?Model $model ): array {
		$data  = array();
		$extra = array();

		foreach ( $this->flatten_fields( $this->form_sections( $model ), $this->sidebar_fields( $model ) ) as $field ) {
			$name  = (string) $field['name'];
			$type  = (string) ( $field['type'] ?? 'text' );
			$value = 'textarea' === $type ? Input::textarea( $name, 'post' ) : Input::text( $name, 'post' );

			if ( 'datetime' === $type && '' !== $value ) {
				$value = Format::to_utc( $value );
			}

			if ( isset( $field['persist'] ) && false === $field['persist'] ) {
				$extra[ $name ] = $value;
			} else {
				$data[ $name ] = $value;
			}
		}

		return array( $data, $extra );
	}

	/**
	 * All fields of the form in one list.
	 *
	 * @param array<int, array<string, mixed>> $sections Sections.
	 * @param array<int, array<string, mixed>> $sidebar  Sidebar fields.
	 * @return array<int, array<string, mixed>>
	 */
	protected function flatten_fields( array $sections, array $sidebar ): array {
		$fields = $sidebar;

		foreach ( $sections as $section ) {
			$fields = array_merge( $fields, (array) $section['fields'] );
		}

		return $fields;
	}

	/**
	 * Loads the record from ?id= or stops with a 404-style message.
	 *
	 * @return Model
	 */
	protected function find_or_die(): Model {
		$model = $this->repository()->find( Input::int( 'id' ), true );

		if ( null === $model ) {
			$this->not_found();
		}

		return $model;
	}

	/**
	 * Stops with a "not found" message. Does not return.
	 *
	 * @return void
	 */
	protected function not_found(): void {
		wp_die(
			esc_html( $this->labels()['not_found'] ),
			esc_html__( 'Not found', 'wp-leadflow-crm' ),
			array(
				'response'  => 404,
				'back_link' => true,
			)
		);
	}

	/**
	 * Transient key for failed-submission data.
	 *
	 * @param Model|null $model Record.
	 * @return string
	 */
	private function old_input_key( ?Model $model ): string {
		return 'leadflow_crm_form_' . get_current_user_id() . '_' . static::ENTITY . '_' . ( null === $model ? 0 : $model->id() );
	}

	/**
	 * Keeps submitted values and errors for the redirect back to the form.
	 *
	 * @param Model|null            $model  Record.
	 * @param array<string, mixed>  $values Submitted values.
	 * @param array<string, string> $errors Errors.
	 * @return void
	 */
	private function store_old_input( ?Model $model, array $values, array $errors ): void {
		set_transient(
			$this->old_input_key( $model ),
			array(
				'values' => $values,
				'errors' => $errors,
			),
			5 * MINUTE_IN_SECONDS
		);
	}

	/**
	 * Returns and clears stored failed-submission data.
	 *
	 * @param Model|null $model Record.
	 * @return array{values: array<string, mixed>, errors: array<string, string>}|null
	 */
	private function pull_old_input( ?Model $model ): ?array {
		$key = $this->old_input_key( $model );
		$old = get_transient( $key );

		if ( ! is_array( $old ) ) {
			return null;
		}

		delete_transient( $key );

		return array(
			'values' => (array) ( $old['values'] ?? array() ),
			'errors' => (array) ( $old['errors'] ?? array() ),
		);
	}
}
