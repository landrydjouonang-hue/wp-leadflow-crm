<?php
/**
 * Admin assets.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Admin;

use LeadFlow\CRM\Contracts\Hookable;
use LeadFlow\CRM\Core\I18n;
use LeadFlow\CRM\Rest\Controller;
use LeadFlow\CRM\Security\Nonce;

defined( 'ABSPATH' ) || exit;

/**
 * Loads CSS/JS on CRM screens only.
 */
final class Assets implements Hookable {

	/** Shared handle for the admin style and script. */
	public const HANDLE = 'leadflow-crm-admin';

	/**
	 * Constructor.
	 *
	 * @param Menu $menu Menu registry.
	 */
	public function __construct( private Menu $menu ) {}

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
		add_filter( 'admin_body_class', array( $this, 'body_class' ) );
	}

	/**
	 * Enqueues assets on CRM screens.
	 *
	 * @param string $hook_suffix Current screen hook suffix.
	 * @return void
	 */
	public function enqueue( string $hook_suffix ): void {
		if ( ! $this->menu->is_plugin_screen( $hook_suffix ) ) {
			return;
		}

		wp_enqueue_style(
			self::HANDLE,
			LEADFLOW_CRM_URL . 'assets/css/admin.css',
			array(),
			$this->version( 'assets/css/admin.css' )
		);

		wp_enqueue_script(
			self::HANDLE,
			LEADFLOW_CRM_URL . 'assets/js/admin.js',
			array( 'wp-i18n', 'wp-api-fetch', 'wp-a11y', 'wp-url' ),
			$this->version( 'assets/js/admin.js' ),
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);

		wp_add_inline_script(
			self::HANDLE,
			'window.leadflowCRM = ' . wp_json_encode(
				array(
					'version'       => LEADFLOW_CRM_VERSION,
					'restNamespace' => Controller::REST_NAMESPACE,
					'ajaxUrl'       => admin_url( 'admin-ajax.php' ),
					// Per-feature nonces; every endpoint still checks capabilities per record.
					'nonces'        => array(
						'task'     => Nonce::create( 'task' ),
						'activity' => Nonce::create( 'activity' ),
						'followUp' => Nonce::create( 'follow_up' ),
						'template' => Nonce::create( 'template' ),
						'import'   => Nonce::create( 'import' ),
						'email'    => Nonce::create( 'email' ),
					),
				)
			) . ';',
			'before'
		);

		wp_set_script_translations( self::HANDLE, I18n::DOMAIN, LEADFLOW_CRM_PATH . 'languages' );
	}

	/**
	 * Adds a body class on CRM screens.
	 *
	 * @param string $classes Space-separated classes.
	 * @return string
	 */
	public function body_class( string $classes ): string {
		return $this->menu->is_current_screen() ? $classes . ' leadflow-crm-screen' : $classes;
	}

	/**
	 * Asset version: file time while developing, plugin version otherwise.
	 *
	 * @param string $relative Path relative to the plugin root.
	 * @return string
	 */
	private function version( string $relative ): string {
		$file = LEADFLOW_CRM_PATH . $relative;

		if ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG && is_readable( $file ) ) {
			return (string) filemtime( $file );
		}

		return LEADFLOW_CRM_VERSION;
	}
}
