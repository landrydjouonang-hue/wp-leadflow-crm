<?php
/**
 * Small reusable UI fragments.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Admin;

use LeadFlow\CRM\Support\Format;

defined( 'ABSPATH' ) || exit;

/**
 * Returns escaped HTML snippets used by list tables and views.
 */
final class UI {

	/**
	 * Status pill.
	 *
	 * @param string $status Status key (used for the color modifier).
	 * @param string $label  Visible label.
	 * @return string Escaped HTML.
	 */
	public static function badge( string $status, string $label ): string {
		return sprintf(
			'<span class="lf-pill lf-pill--%1$s">%2$s</span>',
			esc_attr( sanitize_html_class( $status ) ),
			esc_html( $label )
		);
	}

	/**
	 * Pipeline stage label with a color dot (the text carries the meaning).
	 *
	 * @param string $name  Stage name.
	 * @param string $color Hex color.
	 * @return string Escaped HTML.
	 */
	public static function stage( string $name, string $color ): string {
		$color = sanitize_hex_color( $color );

		return sprintf(
			'<span class="lf-stage"><span class="lf-stage__dot" style="background:%1$s" aria-hidden="true"></span>%2$s</span>',
			esc_attr( null !== $color && '' !== $color ? $color : '#64748b' ),
			esc_html( $name )
		);
	}

	/**
	 * Initials avatar (no external requests).
	 *
	 * @param string $name Name.
	 * @param string $size sm|md|lg.
	 * @return string Escaped HTML.
	 */
	public static function avatar( string $name, string $size = 'md' ): string {
		$hue = abs( crc32( $name ) ) % 360;

		return sprintf(
			'<span class="lf-avatar lf-avatar--%1$s" style="--lf-avatar-hue:%2$d" aria-hidden="true">%3$s</span>',
			esc_attr( in_array( $size, array( 'sm', 'md', 'lg' ), true ) ? $size : 'md' ),
			(int) $hue,
			esc_html( Format::initials( $name ) )
		);
	}

	/**
	 * <time> element showing the local date, full date-time on hover.
	 *
	 * @param string|null $utc Stored UTC datetime.
	 * @return string Escaped HTML.
	 */
	public static function time( ?string $utc ): string {
		if ( null === $utc || '' === $utc ) {
			return '<span aria-hidden="true">—</span>';
		}

		return sprintf(
			'<time datetime="%1$s" title="%2$s">%3$s</time>',
			esc_attr( Format::iso( $utc ) ),
			esc_attr( Format::datetime( $utc ) ),
			esc_html( Format::date( $utc ) )
		);
	}

	/**
	 * Value or an em dash for empty values.
	 *
	 * @param string $value Plain text.
	 * @return string Escaped HTML.
	 */
	public static function text( string $value ): string {
		return '' === $value ? '<span class="lf-muted" aria-hidden="true">—</span>' : esc_html( $value );
	}

	/**
	 * mailto link.
	 *
	 * @param string $email Email.
	 * @return string Escaped HTML.
	 */
	public static function email( string $email ): string {
		return '' === $email ? self::text( '' ) : sprintf( '<a href="mailto:%1$s">%2$s</a>', esc_attr( antispambot( $email ) ), esc_html( $email ) );
	}

	/**
	 * tel link.
	 *
	 * @param string $phone Phone.
	 * @return string Escaped HTML.
	 */
	public static function phone( string $phone ): string {
		$dial = preg_replace( '/[^0-9+]/', '', $phone );

		return '' === $phone ? self::text( '' ) : sprintf( '<a href="tel:%1$s">%2$s</a>', esc_attr( (string) $dial ), esc_html( $phone ) );
	}

	/**
	 * External website link.
	 *
	 * @param string $url URL.
	 * @return string Escaped HTML.
	 */
	public static function website( string $url ): string {
		if ( '' === $url ) {
			return self::text( '' );
		}

		$host = (string) wp_parse_url( $url, PHP_URL_HOST );

		return sprintf(
			'<a href="%1$s" target="_blank" rel="noopener noreferrer nofollow">%2$s<span class="screen-reader-text"> %3$s</span></a>',
			esc_url( $url ),
			esc_html( '' !== $host ? preg_replace( '/^www\./', '', $host ) : $url ),
			esc_html__( '(opens in a new tab)', 'wp-leadflow-crm' )
		);
	}
}
