<?php
/**
 * Admin page definition.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Immutable description of a CRM admin page.
 */
final class Page {

	/**
	 * Constructor.
	 *
	 * @param string   $slug       Page slug (`admin.php?page=`).
	 * @param string   $title      Browser/page title.
	 * @param string   $menu_title Menu label.
	 * @param string   $capability Required capability.
	 * @param callable      $callback   Renders the page.
	 * @param int           $order      Menu position among CRM pages.
	 * @param callable|null $on_load    Runs on `load-{page}` before output
	 *                                  (screen options, form/bulk handling).
	 */
	public function __construct(
		private string $slug,
		private string $title,
		private string $menu_title,
		private string $capability,
		private $callback,
		private int $order = 50,
		private $on_load = null
	) {}

	/**
	 * Load callback, if any.
	 *
	 * @return callable|null
	 */
	public function on_load(): ?callable {
		return is_callable( $this->on_load ) ? $this->on_load : null;
	}

	/**
	 * Slug.
	 *
	 * @return string
	 */
	public function slug(): string {
		return $this->slug;
	}

	/**
	 * Title.
	 *
	 * @return string
	 */
	public function title(): string {
		return $this->title;
	}

	/**
	 * Menu title.
	 *
	 * @return string
	 */
	public function menu_title(): string {
		return $this->menu_title;
	}

	/**
	 * Capability.
	 *
	 * @return string
	 */
	public function capability(): string {
		return $this->capability;
	}

	/**
	 * Render callback.
	 *
	 * @return callable
	 */
	public function callback(): callable {
		return $this->callback;
	}

	/**
	 * Order.
	 *
	 * @return int
	 */
	public function order(): int {
		return $this->order;
	}
}
