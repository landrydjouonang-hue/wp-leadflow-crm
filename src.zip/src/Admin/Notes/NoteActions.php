<?php
/**
 * Note actions shared by every record screen.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Admin\Notes;

use LeadFlow\CRM\Admin\Notices;
use LeadFlow\CRM\Admin\RecordPanels;
use LeadFlow\CRM\Admin\View;
use LeadFlow\CRM\Contracts\Hookable;
use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\Note;
use LeadFlow\CRM\Data\Repositories\ContactRepository;
use LeadFlow\CRM\Data\Repositories\NoteRepository;
use LeadFlow\CRM\Data\ValidationException;
use LeadFlow\CRM\Security\Guard;
use LeadFlow\CRM\Security\Input;
use LeadFlow\CRM\Security\Nonce;
use LeadFlow\CRM\Security\Permissions;

defined( 'ABSPATH' ) || exit;

/**
 * Add, pin/unpin and delete notes on companies, contacts and leads.
 *
 * Permissions: adding a note needs `leadflow_manage_notes` and the edit
 * permission of the record. A note can be pinned or deleted by its author
 * (same requirements) or by anyone with `leadflow_manage_others_notes`.
 */
final class NoteActions implements Hookable {

	/** Parent type => plural (capability suffix). */
	public const PARENTS = array(
		'company' => 'companies',
		'contact' => 'contacts',
		'lead'    => 'leads',
	);

	/**
	 * Constructor.
	 *
	 * @param NoteRepository    $notes    Notes.
	 * @param ContactRepository $contacts Contacts (note origins on companies).
	 */
	public function __construct(
		private NoteRepository $notes,
		private ContactRepository $contacts
	) {}

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_action( 'admin_post_leadflow_crm_add_note', array( $this, 'handle_add' ) );
		add_action( 'admin_post_leadflow_crm_pin_note', array( $this, 'handle_pin' ) );
		add_action( 'admin_post_leadflow_crm_delete_note', array( $this, 'handle_delete' ) );
		add_action( 'leadflow_crm_record_panels', array( $this, 'add_panel' ), 90, 3 );
	}

	/**
	 * Adds the Notes tab to company, contact and lead screens.
	 *
	 * @param RecordPanels $panels Panel registry.
	 * @param string       $type   Record type.
	 * @param Model        $record Record.
	 * @return void
	 */
	public function add_panel( RecordPanels $panels, string $type, Model $record ): void {
		if ( ! isset( self::PARENTS[ $type ] ) ) {
			return;
		}

		$panels->add(
			'notes',
			array(
				'title'  => __( 'Notes', 'wp-leadflow-crm' ),
				'count'  => $this->notes->count_for_parent( $type, $record->id() ),
				'order'  => 90,
				'render' => fn() => $this->render_panel( $type, $record->id(), $record->is_trashed() ),
			)
		);
	}

	/**
	 * Renders the notes panel for a record.
	 *
	 * @param string $parent    company|contact|lead.
	 * @param int    $parent_id Record id.
	 * @param bool   $readonly  Hide the add form (e.g. trashed record).
	 * @return void
	 */
	public function render_panel( string $parent, int $parent_id, bool $readonly = false ): void {
		$notes   = $this->notes->for_parent_pinned_first( $parent, $parent_id, 100 );
		$origins = array();

		// On a company, show which contact each note came from (one query).
		if ( 'company' === $parent ) {
			$contacts = $this->contacts->find_many( array_map( static fn( Note $n ): int => (int) $n->get( 'contact_id', 0 ), $notes ) );

			foreach ( $notes as $note ) {
				$contact = $contacts[ (int) $note->get( 'contact_id', 0 ) ] ?? null;

				if ( null !== $contact ) {
					$origins[ $note->id() ] = $contact->full_name();
				}
			}
		}

		View::render(
			'admin/partials/notes',
			array(
				'parent'    => $parent,
				'parent_id' => $parent_id,
				'notes'     => $notes,
				'origins'   => $origins,
				'can_add'   => ! $readonly && self::can_add( $parent, $parent_id ),
				'actions'   => $this,
			)
		);
	}

	/**
	 * Whether the current user may pin/delete a note.
	 *
	 * @param Note $note Note.
	 * @return bool
	 */
	public function can_manage( Note $note ): bool {
		list( $parent, $parent_id ) = self::owning_parent( $note );

		if ( null === $parent ) {
			return false;
		}

		if ( current_user_can( Permissions::MANAGE_OTHERS_NOTES ) ) {
			return true;
		}

		return (int) $note->get( 'created_by' ) === get_current_user_id()
			&& self::can_add( $parent, $parent_id );
	}

	/**
	 * Whether the current user may add notes to a record.
	 *
	 * @param string $parent    company|contact|lead.
	 * @param int    $parent_id Record id.
	 * @return bool
	 */
	public static function can_add( string $parent, int $parent_id ): bool {
		return current_user_can( Permissions::MANAGE_NOTES ) && current_user_can( 'leadflow_edit_' . $parent, $parent_id );
	}

	/**
	 * Adds a note.
	 *
	 * @return void
	 */
	public function handle_add(): void {
		$parent    = Input::one_of( 'parent', array_keys( self::PARENTS ), '', 'post' );
		$parent_id = Input::int( 'parent_id', 'post' );

		if ( '' === $parent ) {
			wp_die( esc_html__( 'Invalid request.', 'wp-leadflow-crm' ), '', array( 'response' => 400 ) );
		}

		check_admin_referer( Nonce::action( 'add_note_' . $parent . '_' . $parent_id ), Nonce::FIELD );
		Guard::authorize( Permissions::MANAGE_NOTES );
		Guard::authorize( 'leadflow_edit_' . $parent, $parent_id );

		try {
			$this->notes->create(
				array(
					$parent . '_id' => $parent_id,
					'content'       => Input::textarea( 'content', 'post' ),
					'is_pinned'     => Input::bool( 'is_pinned', 'post' ),
				)
			);
			Notices::flash( 'success', __( 'Note added.', 'wp-leadflow-crm' ) );
		} catch ( ValidationException $e ) {
			Notices::flash( 'error', __( 'The note is empty. Please write something before saving.', 'wp-leadflow-crm' ) );
		}

		$this->back();
	}

	/**
	 * Toggles a note's pinned state.
	 *
	 * @return void
	 */
	public function handle_pin(): void {
		$note = $this->verified_note( 'pin_note' );

		$this->notes->update( $note->id(), array( 'is_pinned' => ! $note->is_pinned() ) );
		Notices::flash( 'success', $note->is_pinned() ? __( 'Note unpinned.', 'wp-leadflow-crm' ) : __( 'Note pinned.', 'wp-leadflow-crm' ) );

		$this->back();
	}

	/**
	 * Deletes (trashes) a note.
	 *
	 * @return void
	 */
	public function handle_delete(): void {
		$note = $this->verified_note( 'delete_note' );

		$this->notes->trash( $note->id() );
		Notices::flash( 'success', __( 'Note deleted.', 'wp-leadflow-crm' ) );

		$this->back();
	}

	/**
	 * Most specific parent of a note: lead, then contact, then company.
	 *
	 * @param Note $note Note.
	 * @return array{0: string|null, 1: int}
	 */
	public static function owning_parent( Note $note ): array {
		foreach ( array( 'lead', 'contact', 'company' ) as $type ) {
			$id = $note->get( $type . '_id' );

			if ( null !== $id ) {
				return array( $type, (int) $id );
			}
		}

		return array( null, 0 );
	}

	/**
	 * Loads the posted note after nonce and permission checks.
	 *
	 * @param string $action Nonce action prefix.
	 * @return Note
	 */
	private function verified_note( string $action ): Note {
		$id = Input::int( 'note_id', 'post' );

		check_admin_referer( Nonce::action( $action . '_' . $id ), Nonce::FIELD );

		$note = $this->notes->find( $id );

		if ( ! $note instanceof Note ) {
			wp_die( esc_html__( 'This note no longer exists.', 'wp-leadflow-crm' ), '', array( 'response' => 404, 'back_link' => true ) );
		}

		if ( ! $this->can_manage( $note ) ) {
			Guard::authorize( 'do_not_allow' );
		}

		return $note;
	}

	/**
	 * Returns to the record screen, at the notes panel.
	 *
	 * @return void
	 */
	private function back(): void {
		$referer = wp_get_referer();

		wp_safe_redirect( ( false !== $referer ? remove_query_arg( array( '_leadflow_nonce' ), strtok( $referer, '#' ) ) : admin_url() ) . '#lf-panel-notes' );
		exit;
	}
}
