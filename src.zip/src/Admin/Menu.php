<?php
/**
 * Admin menu registry.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Admin;

use LeadFlow\CRM\Contracts\Hookable;
use LeadFlow\CRM\Security\Capabilities;

defined( 'ABSPATH' ) || exit;

/**
 * Collects pages from modules and builds the "LeadFlow CRM" menu.
 *
 * The page with the lowest order becomes the top-level entry.
 */
final class Menu implements Hookable {

	/** Top-level menu slug (the dashboard). */
	public const SLUG = 'leadflow-crm';

	/**
	 * Pages keyed by slug.
	 *
	 * @var array<string, Page>
	 */
	private array $pages = array();

	/**
	 * Hook suffixes keyed by slug.
	 *
	 * @var array<string, string>
	 */
	private array $hook_suffixes = array();

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_action( 'admin_menu', array( $this, 'register_pages' ) );
	}

	/**
	 * Adds a page. Call during module boot.
	 *
	 * @param Page $page Page.
	 * @return void
	 */
	public function add( Page $page ): void {
		$this->pages[ $page->slug() ] = $page;
	}

	/**
	 * Registered pages, sorted by order.
	 *
	 * @return array<string, Page>
	 */
	public function pages(): array {
		$pages = $this->pages;

		uasort( $pages, static fn( Page $a, Page $b ): int => $a->order() <=> $b->order() );

		return $pages;
	}

	/**
	 * Registers the menu with WordPress.
	 *
	 * @return void
	 */
	public function register_pages(): void {
		$pages = $this->pages();

		if ( empty( $pages ) ) {
			return;
		}

		$top = reset( $pages );

		add_menu_page(
			__( 'LeadFlow CRM', 'wp-leadflow-crm' ),
			__( 'LeadFlow CRM', 'wp-leadflow-crm' ),
			Capabilities::ACCESS_CRM,
			$top->slug(),
			$top->callback(),
			'dashicons-groups',
			26
		);

		foreach ( $pages as $page ) {
			$suffix = add_submenu_page(
				$top->slug(),
				$page->title(),
				$page->menu_title(),
				$page->capability(),
				$page->slug(),
				$page->callback()
			);

			if ( is_string( $suffix ) ) {
				$this->hook_suffixes[ $page->slug() ] = $suffix;

				if ( null !== $page->on_load() ) {
					add_action( 'load-' . $suffix, $page->on_load() );
				}
			}
		}
	}

	/**
	 * Whether a screen hook suffix belongs to a CRM page.
	 *
	 * @param string $hook_suffix Hook suffix from admin_enqueue_scripts.
	 * @return bool
	 */
	public function is_plugin_screen( string $hook_suffix ): bool {
		return in_array( $hook_suffix, $this->hook_suffixes, true );
	}

	/**
	 * Whether the current request is a CRM page.
	 *
	 * @return bool
	 */
	public function is_current_screen(): bool {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		return null !== $screen && $this->is_plugin_screen( (string) $screen->id );
	}

	/**
	 * URL of a CRM page.
	 *
	 * @param string               $slug Page slug.
	 * @param array<string, mixed> $args Extra query args.
	 * @return string Unescaped URL.
	 */
	public static function url( string $slug = self::SLUG, array $args = array() ): string {
		return add_query_arg( array_merge( array( 'page' => $slug ), $args ), admin_url( 'admin.php' ) );
	}
}
