<?php
/**
 * Main plugin class.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM;

use LeadFlow\CRM\Admin\Assets;
use LeadFlow\CRM\Admin\Help;
use LeadFlow\CRM\Admin\Menu;
use LeadFlow\CRM\Admin\Notes\NoteActions;
use LeadFlow\CRM\Admin\Notices;
use LeadFlow\CRM\Admin\PluginLinks;
use LeadFlow\CRM\Contracts\Hookable;
use LeadFlow\CRM\Core\I18n;
use LeadFlow\CRM\Core\Installer;
use LeadFlow\CRM\Core\Multisite;
use LeadFlow\CRM\Core\Upgrader;
use LeadFlow\CRM\Data\Relations;
use LeadFlow\CRM\Data\Retention;
use LeadFlow\CRM\Data\Repositories\ActivityRepository;
use LeadFlow\CRM\Data\Repositories\CompanyRepository;
use LeadFlow\CRM\Data\Repositories\ContactRepository;
use LeadFlow\CRM\Data\Repositories\EmailRepository;
use LeadFlow\CRM\Data\Repositories\EmailTemplateRepository;
use LeadFlow\CRM\Email\EmailSender;
use LeadFlow\CRM\Email\Mailer;
use LeadFlow\CRM\Email\TemplateRenderer;
use LeadFlow\CRM\Data\Repositories\FollowUpRepository;
use LeadFlow\CRM\Data\Repositories\LeadRepository;
use LeadFlow\CRM\Data\Repositories\NoteRepository;
use LeadFlow\CRM\Data\Repositories\StageRepository;
use LeadFlow\CRM\Data\Repositories\TaskRepository;
use LeadFlow\CRM\Data\UserReassigner;
use LeadFlow\CRM\Database\MigrationRepository;
use LeadFlow\CRM\Database\Migrator;
use LeadFlow\CRM\Modules\ModuleManager;
use LeadFlow\CRM\Rest\RestServer;
use LeadFlow\CRM\Security\Capabilities;
use LeadFlow\CRM\Settings\Registry as SettingsRegistry;
use LeadFlow\CRM\Settings\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Composition root: registers services and boots modules.
 */
final class Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var Plugin|null
	 */
	private static ?Plugin $instance = null;

	/**
	 * Service container.
	 *
	 * @var Container
	 */
	private Container $container;

	/**
	 * Whether boot() already ran.
	 *
	 * @var bool
	 */
	private bool $booted = false;

	/**
	 * Returns the singleton instance.
	 *
	 * @return Plugin
	 */
	public static function instance(): Plugin {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		$this->container = new Container();
		$this->register_services();
	}

	/**
	 * Returns the service container.
	 *
	 * @return Container
	 */
	public function container(): Container {
		return $this->container;
	}

	/**
	 * Shortcut to resolve a service.
	 *
	 * @param string $id Service id.
	 * @return mixed
	 */
	public function get( string $id ): mixed {
		return $this->container->get( $id );
	}

	/**
	 * Returns the module manager.
	 *
	 * @return ModuleManager
	 */
	public function modules(): ModuleManager {
		return $this->container->get( ModuleManager::class );
	}

	/**
	 * Boots core services and modules. Runs on `plugins_loaded`.
	 *
	 * @return void
	 */
	public function boot(): void {
		if ( $this->booted ) {
			return;
		}

		$this->booted = true;

		$hookables = array(
			I18n::class,
			Upgrader::class,
			RestServer::class,
			Menu::class,
			Assets::class,
			Help::class,
			Notices::class,
			PluginLinks::class,
			SettingsRegistry::class,
			UserReassigner::class,
			NoteActions::class,
		);

		if ( is_multisite() ) {
			$hookables[] = Multisite::class;
		}

		foreach ( $hookables as $id ) {
			$service = $this->container->get( $id );

			if ( $service instanceof Hookable ) {
				$service->register();
			}
		}

		// Modules use translated strings, which WordPress only allows from `init`.
		add_action( 'init', array( $this, 'boot_modules' ), 0 );
	}

	/**
	 * Boots all modules. Runs on `init` (priority 0, after the text domain).
	 *
	 * @return void
	 */
	public function boot_modules(): void {
		if ( did_action( 'leadflow_crm_booted' ) ) {
			return;
		}

		$this->modules()->boot_all();

		/**
		 * Fires after LeadFlow CRM and all its modules have booted.
		 *
		 * @param Plugin $plugin Plugin instance.
		 */
		do_action( 'leadflow_crm_booted', $this );
	}

	/**
	 * Registers shared services.
	 *
	 * @return void
	 */
	private function register_services(): void {
		$c = $this->container;

		$c->set( ModuleManager::class, fn() => new ModuleManager( $this ) );
		$c->set( MigrationRepository::class, fn() => new MigrationRepository() );
		$c->set(
			Migrator::class,
			fn( Container $c ) => new Migrator( $c->get( MigrationRepository::class ), $c->get( ModuleManager::class ) )
		);
		$c->set( Capabilities::class, fn( Container $c ) => new Capabilities( $c->get( ModuleManager::class ) ) );
		$c->set( SettingsRegistry::class, fn() => new SettingsRegistry() );
		$c->set( Settings::class, fn( Container $c ) => new Settings( $c->get( SettingsRegistry::class ) ) );
		$c->set(
			Installer::class,
			fn( Container $c ) => new Installer(
				$c->get( Migrator::class ),
				$c->get( Capabilities::class ),
				$c->get( Settings::class )
			)
		);
		$c->set(
			Upgrader::class,
			fn( Container $c ) => new Upgrader( $c->get( Installer::class ), $c->get( Capabilities::class ) )
		);
		$c->set( I18n::class, fn() => new I18n() );
		$c->set( Multisite::class, fn( Container $c ) => new Multisite( $c->get( Installer::class ) ) );
		$c->set( RestServer::class, fn( Container $c ) => new RestServer( $c->get( ModuleManager::class ) ) );
		$c->set( Menu::class, fn() => new Menu() );
		$c->set( Assets::class, fn( Container $c ) => new Assets( $c->get( Menu::class ) ) );
		$c->set( Help::class, fn( Container $c ) => new Help( $c->get( Menu::class ) ) );
		$c->set( Retention::class, fn() => new Retention( $this ) );
		$c->set( Notices::class, fn( Container $c ) => new Notices( $c->get( Menu::class ), $c->get( Migrator::class ) ) );
		$c->set( PluginLinks::class, fn() => new PluginLinks() );

		// Data layer.
		$c->set( CompanyRepository::class, fn() => new CompanyRepository() );
		$c->set( ContactRepository::class, fn() => new ContactRepository() );
		$c->set( StageRepository::class, fn() => new StageRepository() );
		$c->set( LeadRepository::class, fn( Container $c ) => new LeadRepository( $c->get( Settings::class ), $c->get( StageRepository::class ) ) );
		$c->set( ActivityRepository::class, fn() => new ActivityRepository() );
		$c->set( NoteRepository::class, fn() => new NoteRepository() );
		$c->set( TaskRepository::class, fn() => new TaskRepository() );
		$c->set( FollowUpRepository::class, fn() => new FollowUpRepository() );
		$c->set(
			Relations::class,
			fn( Container $c ) => new Relations(
				$c->get( CompanyRepository::class ),
				$c->get( ContactRepository::class ),
				$c->get( LeadRepository::class ),
				$c->get( ActivityRepository::class ),
				$c->get( NoteRepository::class ),
				$c->get( TaskRepository::class ),
				$c->get( FollowUpRepository::class )
			)
		);
		$c->set( UserReassigner::class, fn() => new UserReassigner() );
		$c->set( EmailTemplateRepository::class, fn() => new EmailTemplateRepository() );
		$c->set( TemplateRenderer::class, fn() => new TemplateRenderer( $this ) );
		$c->set( EmailRepository::class, fn() => new EmailRepository() );
		$c->set( Mailer::class, fn( Container $c ) => new Mailer( $c->get( Settings::class ) ) );
		$c->set( EmailSender::class, fn() => new EmailSender( $this ) );
		$c->set(
			NoteActions::class,
			fn( Container $c ) => new NoteActions( $c->get( NoteRepository::class ), $c->get( ContactRepository::class ) )
		);
	}
}
