<?php
/**
 * ISO 3166-1 country list.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Support;

defined( 'ABSPATH' ) || exit;

/**
 * Translatable country names keyed by ISO 3166-1 alpha-2 code.
 */
final class Countries {

	/**
	 * Cached, sorted list.
	 *
	 * @var array<string, string>|null
	 */
	private static ?array $list = null;

	/**
	 * All countries, sorted by translated name.
	 *
	 * @return array<string, string> Code => name.
	 */
	public static function all(): array {
		if ( null !== self::$list ) {
			return self::$list;
		}

		$list = array(
			'AF' => __( 'Afghanistan', 'wp-leadflow-crm' ),
			'AX' => __( 'Åland Islands', 'wp-leadflow-crm' ),
			'AL' => __( 'Albania', 'wp-leadflow-crm' ),
			'DZ' => __( 'Algeria', 'wp-leadflow-crm' ),
			'AS' => __( 'American Samoa', 'wp-leadflow-crm' ),
			'AD' => __( 'Andorra', 'wp-leadflow-crm' ),
			'AO' => __( 'Angola', 'wp-leadflow-crm' ),
			'AI' => __( 'Anguilla', 'wp-leadflow-crm' ),
			'AQ' => __( 'Antarctica', 'wp-leadflow-crm' ),
			'AG' => __( 'Antigua and Barbuda', 'wp-leadflow-crm' ),
			'AR' => __( 'Argentina', 'wp-leadflow-crm' ),
			'AM' => __( 'Armenia', 'wp-leadflow-crm' ),
			'AW' => __( 'Aruba', 'wp-leadflow-crm' ),
			'AU' => __( 'Australia', 'wp-leadflow-crm' ),
			'AT' => __( 'Austria', 'wp-leadflow-crm' ),
			'AZ' => __( 'Azerbaijan', 'wp-leadflow-crm' ),
			'BS' => __( 'Bahamas', 'wp-leadflow-crm' ),
			'BH' => __( 'Bahrain', 'wp-leadflow-crm' ),
			'BD' => __( 'Bangladesh', 'wp-leadflow-crm' ),
			'BB' => __( 'Barbados', 'wp-leadflow-crm' ),
			'BY' => __( 'Belarus', 'wp-leadflow-crm' ),
			'BE' => __( 'Belgium', 'wp-leadflow-crm' ),
			'BZ' => __( 'Belize', 'wp-leadflow-crm' ),
			'BJ' => __( 'Benin', 'wp-leadflow-crm' ),
			'BM' => __( 'Bermuda', 'wp-leadflow-crm' ),
			'BT' => __( 'Bhutan', 'wp-leadflow-crm' ),
			'BO' => __( 'Bolivia', 'wp-leadflow-crm' ),
			'BQ' => __( 'Bonaire, Sint Eustatius and Saba', 'wp-leadflow-crm' ),
			'BA' => __( 'Bosnia and Herzegovina', 'wp-leadflow-crm' ),
			'BW' => __( 'Botswana', 'wp-leadflow-crm' ),
			'BV' => __( 'Bouvet Island', 'wp-leadflow-crm' ),
			'BR' => __( 'Brazil', 'wp-leadflow-crm' ),
			'IO' => __( 'British Indian Ocean Territory', 'wp-leadflow-crm' ),
			'BN' => __( 'Brunei', 'wp-leadflow-crm' ),
			'BG' => __( 'Bulgaria', 'wp-leadflow-crm' ),
			'BF' => __( 'Burkina Faso', 'wp-leadflow-crm' ),
			'BI' => __( 'Burundi', 'wp-leadflow-crm' ),
			'CV' => __( 'Cabo Verde', 'wp-leadflow-crm' ),
			'KH' => __( 'Cambodia', 'wp-leadflow-crm' ),
			'CM' => __( 'Cameroon', 'wp-leadflow-crm' ),
			'CA' => __( 'Canada', 'wp-leadflow-crm' ),
			'KY' => __( 'Cayman Islands', 'wp-leadflow-crm' ),
			'CF' => __( 'Central African Republic', 'wp-leadflow-crm' ),
			'TD' => __( 'Chad', 'wp-leadflow-crm' ),
			'CL' => __( 'Chile', 'wp-leadflow-crm' ),
			'CN' => __( 'China', 'wp-leadflow-crm' ),
			'CX' => __( 'Christmas Island', 'wp-leadflow-crm' ),
			'CC' => __( 'Cocos (Keeling) Islands', 'wp-leadflow-crm' ),
			'CO' => __( 'Colombia', 'wp-leadflow-crm' ),
			'KM' => __( 'Comoros', 'wp-leadflow-crm' ),
			'CG' => __( 'Congo', 'wp-leadflow-crm' ),
			'CD' => __( 'Congo (Democratic Republic)', 'wp-leadflow-crm' ),
			'CK' => __( 'Cook Islands', 'wp-leadflow-crm' ),
			'CR' => __( 'Costa Rica', 'wp-leadflow-crm' ),
			'CI' => __( 'Côte d’Ivoire', 'wp-leadflow-crm' ),
			'HR' => __( 'Croatia', 'wp-leadflow-crm' ),
			'CU' => __( 'Cuba', 'wp-leadflow-crm' ),
			'CW' => __( 'Curaçao', 'wp-leadflow-crm' ),
			'CY' => __( 'Cyprus', 'wp-leadflow-crm' ),
			'CZ' => __( 'Czechia', 'wp-leadflow-crm' ),
			'DK' => __( 'Denmark', 'wp-leadflow-crm' ),
			'DJ' => __( 'Djibouti', 'wp-leadflow-crm' ),
			'DM' => __( 'Dominica', 'wp-leadflow-crm' ),
			'DO' => __( 'Dominican Republic', 'wp-leadflow-crm' ),
			'EC' => __( 'Ecuador', 'wp-leadflow-crm' ),
			'EG' => __( 'Egypt', 'wp-leadflow-crm' ),
			'SV' => __( 'El Salvador', 'wp-leadflow-crm' ),
			'GQ' => __( 'Equatorial Guinea', 'wp-leadflow-crm' ),
			'ER' => __( 'Eritrea', 'wp-leadflow-crm' ),
			'EE' => __( 'Estonia', 'wp-leadflow-crm' ),
			'SZ' => __( 'Eswatini', 'wp-leadflow-crm' ),
			'ET' => __( 'Ethiopia', 'wp-leadflow-crm' ),
			'FK' => __( 'Falkland Islands', 'wp-leadflow-crm' ),
			'FO' => __( 'Faroe Islands', 'wp-leadflow-crm' ),
			'FJ' => __( 'Fiji', 'wp-leadflow-crm' ),
			'FI' => __( 'Finland', 'wp-leadflow-crm' ),
			'FR' => __( 'France', 'wp-leadflow-crm' ),
			'GF' => __( 'French Guiana', 'wp-leadflow-crm' ),
			'PF' => __( 'French Polynesia', 'wp-leadflow-crm' ),
			'TF' => __( 'French Southern Territories', 'wp-leadflow-crm' ),
			'GA' => __( 'Gabon', 'wp-leadflow-crm' ),
			'GM' => __( 'Gambia', 'wp-leadflow-crm' ),
			'GE' => __( 'Georgia', 'wp-leadflow-crm' ),
			'DE' => __( 'Germany', 'wp-leadflow-crm' ),
			'GH' => __( 'Ghana', 'wp-leadflow-crm' ),
			'GI' => __( 'Gibraltar', 'wp-leadflow-crm' ),
			'GR' => __( 'Greece', 'wp-leadflow-crm' ),
			'GL' => __( 'Greenland', 'wp-leadflow-crm' ),
			'GD' => __( 'Grenada', 'wp-leadflow-crm' ),
			'GP' => __( 'Guadeloupe', 'wp-leadflow-crm' ),
			'GU' => __( 'Guam', 'wp-leadflow-crm' ),
			'GT' => __( 'Guatemala', 'wp-leadflow-crm' ),
			'GG' => __( 'Guernsey', 'wp-leadflow-crm' ),
			'GN' => __( 'Guinea', 'wp-leadflow-crm' ),
			'GW' => __( 'Guinea-Bissau', 'wp-leadflow-crm' ),
			'GY' => __( 'Guyana', 'wp-leadflow-crm' ),
			'HT' => __( 'Haiti', 'wp-leadflow-crm' ),
			'HM' => __( 'Heard Island and McDonald Islands', 'wp-leadflow-crm' ),
			'VA' => __( 'Holy See', 'wp-leadflow-crm' ),
			'HN' => __( 'Honduras', 'wp-leadflow-crm' ),
			'HK' => __( 'Hong Kong', 'wp-leadflow-crm' ),
			'HU' => __( 'Hungary', 'wp-leadflow-crm' ),
			'IS' => __( 'Iceland', 'wp-leadflow-crm' ),
			'IN' => __( 'India', 'wp-leadflow-crm' ),
			'ID' => __( 'Indonesia', 'wp-leadflow-crm' ),
			'IR' => __( 'Iran', 'wp-leadflow-crm' ),
			'IQ' => __( 'Iraq', 'wp-leadflow-crm' ),
			'IE' => __( 'Ireland', 'wp-leadflow-crm' ),
			'IM' => __( 'Isle of Man', 'wp-leadflow-crm' ),
			'IL' => __( 'Israel', 'wp-leadflow-crm' ),
			'IT' => __( 'Italy', 'wp-leadflow-crm' ),
			'JM' => __( 'Jamaica', 'wp-leadflow-crm' ),
			'JP' => __( 'Japan', 'wp-leadflow-crm' ),
			'JE' => __( 'Jersey', 'wp-leadflow-crm' ),
			'JO' => __( 'Jordan', 'wp-leadflow-crm' ),
			'KZ' => __( 'Kazakhstan', 'wp-leadflow-crm' ),
			'KE' => __( 'Kenya', 'wp-leadflow-crm' ),
			'KI' => __( 'Kiribati', 'wp-leadflow-crm' ),
			'KP' => __( 'Korea (North)', 'wp-leadflow-crm' ),
			'KR' => __( 'Korea (South)', 'wp-leadflow-crm' ),
			'XK' => __( 'Kosovo', 'wp-leadflow-crm' ),
			'KW' => __( 'Kuwait', 'wp-leadflow-crm' ),
			'KG' => __( 'Kyrgyzstan', 'wp-leadflow-crm' ),
			'LA' => __( 'Laos', 'wp-leadflow-crm' ),
			'LV' => __( 'Latvia', 'wp-leadflow-crm' ),
			'LB' => __( 'Lebanon', 'wp-leadflow-crm' ),
			'LS' => __( 'Lesotho', 'wp-leadflow-crm' ),
			'LR' => __( 'Liberia', 'wp-leadflow-crm' ),
			'LY' => __( 'Libya', 'wp-leadflow-crm' ),
			'LI' => __( 'Liechtenstein', 'wp-leadflow-crm' ),
			'LT' => __( 'Lithuania', 'wp-leadflow-crm' ),
			'LU' => __( 'Luxembourg', 'wp-leadflow-crm' ),
			'MO' => __( 'Macao', 'wp-leadflow-crm' ),
			'MG' => __( 'Madagascar', 'wp-leadflow-crm' ),
			'MW' => __( 'Malawi', 'wp-leadflow-crm' ),
			'MY' => __( 'Malaysia', 'wp-leadflow-crm' ),
			'MV' => __( 'Maldives', 'wp-leadflow-crm' ),
			'ML' => __( 'Mali', 'wp-leadflow-crm' ),
			'MT' => __( 'Malta', 'wp-leadflow-crm' ),
			'MH' => __( 'Marshall Islands', 'wp-leadflow-crm' ),
			'MQ' => __( 'Martinique', 'wp-leadflow-crm' ),
			'MR' => __( 'Mauritania', 'wp-leadflow-crm' ),
			'MU' => __( 'Mauritius', 'wp-leadflow-crm' ),
			'YT' => __( 'Mayotte', 'wp-leadflow-crm' ),
			'MX' => __( 'Mexico', 'wp-leadflow-crm' ),
			'FM' => __( 'Micronesia', 'wp-leadflow-crm' ),
			'MD' => __( 'Moldova', 'wp-leadflow-crm' ),
			'MC' => __( 'Monaco', 'wp-leadflow-crm' ),
			'MN' => __( 'Mongolia', 'wp-leadflow-crm' ),
			'ME' => __( 'Montenegro', 'wp-leadflow-crm' ),
			'MS' => __( 'Montserrat', 'wp-leadflow-crm' ),
			'MA' => __( 'Morocco', 'wp-leadflow-crm' ),
			'MZ' => __( 'Mozambique', 'wp-leadflow-crm' ),
			'MM' => __( 'Myanmar', 'wp-leadflow-crm' ),
			'NA' => __( 'Namibia', 'wp-leadflow-crm' ),
			'NR' => __( 'Nauru', 'wp-leadflow-crm' ),
			'NP' => __( 'Nepal', 'wp-leadflow-crm' ),
			'NL' => __( 'Netherlands', 'wp-leadflow-crm' ),
			'NC' => __( 'New Caledonia', 'wp-leadflow-crm' ),
			'NZ' => __( 'New Zealand', 'wp-leadflow-crm' ),
			'NI' => __( 'Nicaragua', 'wp-leadflow-crm' ),
			'NE' => __( 'Niger', 'wp-leadflow-crm' ),
			'NG' => __( 'Nigeria', 'wp-leadflow-crm' ),
			'NU' => __( 'Niue', 'wp-leadflow-crm' ),
			'NF' => __( 'Norfolk Island', 'wp-leadflow-crm' ),
			'MK' => __( 'North Macedonia', 'wp-leadflow-crm' ),
			'MP' => __( 'Northern Mariana Islands', 'wp-leadflow-crm' ),
			'NO' => __( 'Norway', 'wp-leadflow-crm' ),
			'OM' => __( 'Oman', 'wp-leadflow-crm' ),
			'PK' => __( 'Pakistan', 'wp-leadflow-crm' ),
			'PW' => __( 'Palau', 'wp-leadflow-crm' ),
			'PS' => __( 'Palestine', 'wp-leadflow-crm' ),
			'PA' => __( 'Panama', 'wp-leadflow-crm' ),
			'PG' => __( 'Papua New Guinea', 'wp-leadflow-crm' ),
			'PY' => __( 'Paraguay', 'wp-leadflow-crm' ),
			'PE' => __( 'Peru', 'wp-leadflow-crm' ),
			'PH' => __( 'Philippines', 'wp-leadflow-crm' ),
			'PN' => __( 'Pitcairn', 'wp-leadflow-crm' ),
			'PL' => __( 'Poland', 'wp-leadflow-crm' ),
			'PT' => __( 'Portugal', 'wp-leadflow-crm' ),
			'PR' => __( 'Puerto Rico', 'wp-leadflow-crm' ),
			'QA' => __( 'Qatar', 'wp-leadflow-crm' ),
			'RE' => __( 'Réunion', 'wp-leadflow-crm' ),
			'RO' => __( 'Romania', 'wp-leadflow-crm' ),
			'RU' => __( 'Russia', 'wp-leadflow-crm' ),
			'RW' => __( 'Rwanda', 'wp-leadflow-crm' ),
			'BL' => __( 'Saint Barthélemy', 'wp-leadflow-crm' ),
			'SH' => __( 'Saint Helena, Ascension and Tristan da Cunha', 'wp-leadflow-crm' ),
			'KN' => __( 'Saint Kitts and Nevis', 'wp-leadflow-crm' ),
			'LC' => __( 'Saint Lucia', 'wp-leadflow-crm' ),
			'MF' => __( 'Saint Martin (French part)', 'wp-leadflow-crm' ),
			'PM' => __( 'Saint Pierre and Miquelon', 'wp-leadflow-crm' ),
			'VC' => __( 'Saint Vincent and the Grenadines', 'wp-leadflow-crm' ),
			'WS' => __( 'Samoa', 'wp-leadflow-crm' ),
			'SM' => __( 'San Marino', 'wp-leadflow-crm' ),
			'ST' => __( 'Sao Tome and Principe', 'wp-leadflow-crm' ),
			'SA' => __( 'Saudi Arabia', 'wp-leadflow-crm' ),
			'SN' => __( 'Senegal', 'wp-leadflow-crm' ),
			'RS' => __( 'Serbia', 'wp-leadflow-crm' ),
			'SC' => __( 'Seychelles', 'wp-leadflow-crm' ),
			'SL' => __( 'Sierra Leone', 'wp-leadflow-crm' ),
			'SG' => __( 'Singapore', 'wp-leadflow-crm' ),
			'SX' => __( 'Sint Maarten (Dutch part)', 'wp-leadflow-crm' ),
			'SK' => __( 'Slovakia', 'wp-leadflow-crm' ),
			'SI' => __( 'Slovenia', 'wp-leadflow-crm' ),
			'SB' => __( 'Solomon Islands', 'wp-leadflow-crm' ),
			'SO' => __( 'Somalia', 'wp-leadflow-crm' ),
			'ZA' => __( 'South Africa', 'wp-leadflow-crm' ),
			'GS' => __( 'South Georgia and the South Sandwich Islands', 'wp-leadflow-crm' ),
			'SS' => __( 'South Sudan', 'wp-leadflow-crm' ),
			'ES' => __( 'Spain', 'wp-leadflow-crm' ),
			'LK' => __( 'Sri Lanka', 'wp-leadflow-crm' ),
			'SD' => __( 'Sudan', 'wp-leadflow-crm' ),
			'SR' => __( 'Suriname', 'wp-leadflow-crm' ),
			'SJ' => __( 'Svalbard and Jan Mayen', 'wp-leadflow-crm' ),
			'SE' => __( 'Sweden', 'wp-leadflow-crm' ),
			'CH' => __( 'Switzerland', 'wp-leadflow-crm' ),
			'SY' => __( 'Syria', 'wp-leadflow-crm' ),
			'TW' => __( 'Taiwan', 'wp-leadflow-crm' ),
			'TJ' => __( 'Tajikistan', 'wp-leadflow-crm' ),
			'TZ' => __( 'Tanzania', 'wp-leadflow-crm' ),
			'TH' => __( 'Thailand', 'wp-leadflow-crm' ),
			'TL' => __( 'Timor-Leste', 'wp-leadflow-crm' ),
			'TG' => __( 'Togo', 'wp-leadflow-crm' ),
			'TK' => __( 'Tokelau', 'wp-leadflow-crm' ),
			'TO' => __( 'Tonga', 'wp-leadflow-crm' ),
			'TT' => __( 'Trinidad and Tobago', 'wp-leadflow-crm' ),
			'TN' => __( 'Tunisia', 'wp-leadflow-crm' ),
			'TR' => __( 'Türkiye', 'wp-leadflow-crm' ),
			'TM' => __( 'Turkmenistan', 'wp-leadflow-crm' ),
			'TC' => __( 'Turks and Caicos Islands', 'wp-leadflow-crm' ),
			'TV' => __( 'Tuvalu', 'wp-leadflow-crm' ),
			'UG' => __( 'Uganda', 'wp-leadflow-crm' ),
			'UA' => __( 'Ukraine', 'wp-leadflow-crm' ),
			'AE' => __( 'United Arab Emirates', 'wp-leadflow-crm' ),
			'GB' => __( 'United Kingdom', 'wp-leadflow-crm' ),
			'US' => __( 'United States', 'wp-leadflow-crm' ),
			'UM' => __( 'United States Minor Outlying Islands', 'wp-leadflow-crm' ),
			'UY' => __( 'Uruguay', 'wp-leadflow-crm' ),
			'UZ' => __( 'Uzbekistan', 'wp-leadflow-crm' ),
			'VU' => __( 'Vanuatu', 'wp-leadflow-crm' ),
			'VE' => __( 'Venezuela', 'wp-leadflow-crm' ),
			'VN' => __( 'Vietnam', 'wp-leadflow-crm' ),
			'VG' => __( 'Virgin Islands (British)', 'wp-leadflow-crm' ),
			'VI' => __( 'Virgin Islands (U.S.)', 'wp-leadflow-crm' ),
			'WF' => __( 'Wallis and Futuna', 'wp-leadflow-crm' ),
			'EH' => __( 'Western Sahara', 'wp-leadflow-crm' ),
			'YE' => __( 'Yemen', 'wp-leadflow-crm' ),
			'ZM' => __( 'Zambia', 'wp-leadflow-crm' ),
			'ZW' => __( 'Zimbabwe', 'wp-leadflow-crm' ),
		);

		/**
		 * Filters the country list.
		 *
		 * @param array<string, string> $list ISO code => name.
		 */
		$list = (array) apply_filters( 'leadflow_crm_countries', $list );

		asort( $list, SORT_LOCALE_STRING );

		self::$list = $list;

		return $list;
	}

	/**
	 * Name of a country, or the code when unknown.
	 *
	 * @param string $code ISO code.
	 * @return string
	 */
	public static function name( string $code ): string {
		if ( '' === $code ) {
			return '';
		}

		return self::all()[ strtoupper( $code ) ] ?? strtoupper( $code );
	}
}
