<?php
/**
 * Plugin debug log.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Support;

defined( 'ABSPATH' ) || exit;

/**
 * Writes plugin events to a private log file
 * (`uploads/leadflow-crm/logs/leadflow-crm.log`, deny-all protected).
 *
 * Logging is off unless *Settings → Advanced → Debug logging* is enabled
 * or `LEADFLOW_CRM_DEBUG` is true. Errors are always recorded when
 * `WP_DEBUG` is on. The file rotates at MAX_BYTES (one `.1` backup is
 * kept) so it can never fill the disk.
 *
 *     Logger::error( 'Email failed', array( 'to' => $address ) );
 */
final class Logger {

	/** Log levels, least to most severe. */
	public const LEVELS = array( 'debug', 'info', 'warning', 'error' );

	/** Rotate above this size. */
	public const MAX_BYTES = 2097152;

	/** Enabled state cache. */
	private static ?bool $enabled = null;

	/**
	 * Whether logging is switched on.
	 *
	 * @return bool
	 */
	public static function enabled(): bool {
		if ( null === self::$enabled ) {
			$setting = false;

			if ( function_exists( 'leadflow_crm' ) && did_action( 'leadflow_crm_booted' ) ) {
				$setting = (bool) leadflow_crm()->get( \LeadFlow\CRM\Settings\Settings::class )->get( 'debug_logging', false );
			}

			/**
			 * Filters whether the plugin writes its debug log.
			 *
			 * @param bool $enabled Enabled.
			 */
			self::$enabled = (bool) apply_filters( 'leadflow_crm_debug_logging', $setting || ( defined( 'LEADFLOW_CRM_DEBUG' ) && LEADFLOW_CRM_DEBUG ) );
		}

		return self::$enabled;
	}

	/**
	 * Forgets the cached state (after saving the settings).
	 *
	 * @return void
	 */
	public static function reset(): void {
		self::$enabled = null;
	}

	/**
	 * Log file path.
	 *
	 * @return string
	 */
	public static function file(): string {
		return self::directory() . '/leadflow-crm.log';
	}

	/**
	 * Log directory.
	 *
	 * @return string
	 */
	public static function directory(): string {
		return trailingslashit( wp_upload_dir( null, false )['basedir'] ) . 'leadflow-crm/logs';
	}

	/**
	 * Size of the log file in bytes (0 when there is none).
	 *
	 * @return int
	 */
	public static function size(): int {
		$file = self::file();

		return is_readable( $file ) ? (int) filesize( $file ) : 0;
	}

	/**
	 * Debug entry.
	 *
	 * @param string               $message Message.
	 * @param array<string, mixed> $context Extra data.
	 * @return void
	 */
	public static function debug( string $message, array $context = array() ): void {
		self::log( 'debug', $message, $context );
	}

	/**
	 * Informational entry.
	 *
	 * @param string               $message Message.
	 * @param array<string, mixed> $context Extra data.
	 * @return void
	 */
	public static function info( string $message, array $context = array() ): void {
		self::log( 'info', $message, $context );
	}

	/**
	 * Warning entry.
	 *
	 * @param string               $message Message.
	 * @param array<string, mixed> $context Extra data.
	 * @return void
	 */
	public static function warning( string $message, array $context = array() ): void {
		self::log( 'warning', $message, $context );
	}

	/**
	 * Error entry (also written when only WP_DEBUG is on).
	 *
	 * @param string               $message Message.
	 * @param array<string, mixed> $context Extra data.
	 * @return void
	 */
	public static function error( string $message, array $context = array() ): void {
		self::log( 'error', $message, $context );
	}

	/**
	 * Writes one line. Never interrupts the request.
	 *
	 * @param string               $level   One of LEVELS.
	 * @param string               $message Message.
	 * @param array<string, mixed> $context Extra data (secrets are not logged).
	 * @return void
	 */
	public static function log( string $level, string $message, array $context = array() ): void {
		$level   = in_array( $level, self::LEVELS, true ) ? $level : 'info';
		$serious = in_array( $level, array( 'warning', 'error' ), true );

		if ( ! self::enabled() && ! ( $serious && defined( 'WP_DEBUG' ) && WP_DEBUG ) ) {
			return;
		}

		$line = sprintf(
			'[%s] %s: %s%s%s',
			gmdate( 'Y-m-d H:i:s' ),
			strtoupper( $level ),
			$message,
			empty( $context ) ? '' : ' ' . (string) wp_json_encode( self::clean( $context ) ),
			PHP_EOL
		);

		/**
		 * Fires for every log entry (for shipping logs elsewhere).
		 *
		 * @param string               $level   Level.
		 * @param string               $message Message.
		 * @param array<string, mixed> $context Context.
		 */
		do_action( 'leadflow_crm_log', $level, $message, $context );

		$file = self::file();

		if ( '' === self::prepare_directory() ) {
			return;
		}

		if ( self::size() > self::MAX_BYTES ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_rename -- Log rotation.
			@rename( $file, $file . '.1' );
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents, WordPress.PHP.NoSilencedErrors.Discouraged -- Logging must never break a request.
		@file_put_contents( $file, $line, FILE_APPEND | LOCK_EX );
	}

	/**
	 * Last lines of the log, newest first.
	 *
	 * @param int $lines Number of lines.
	 * @return string[]
	 */
	public static function tail( int $lines = 100 ): array {
		$file = self::file();

		if ( ! is_readable( $file ) ) {
			return array();
		}

		// Read at most the last 256 KB, enough for the requested lines.
		$size   = self::size();
		$offset = max( 0, $size - 262144 );
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_get_contents -- Own log file.
		$chunk  = (string) @file_get_contents( $file, false, null, $offset );
		$all    = array_values( array_filter( array_map( 'rtrim', explode( "\n", $chunk ) ) ) );

		if ( $offset > 0 && ! empty( $all ) ) {
			array_shift( $all );
		}

		return array_reverse( array_slice( $all, -max( 1, $lines ) ) );
	}

	/**
	 * Empties the log.
	 *
	 * @return void
	 */
	public static function clear(): void {
		foreach ( array( self::file(), self::file() . '.1' ) as $file ) {
			if ( file_exists( $file ) ) {
				wp_delete_file( $file );
			}
		}
	}

	/**
	 * Creates the protected log directory.
	 *
	 * @return string Path, '' on failure.
	 */
	public static function prepare_directory(): string {
		$dir = self::directory();

		if ( ! wp_mkdir_p( $dir ) ) {
			return '';
		}

		$files = array(
			'.htaccess'  => "# LeadFlow CRM: logs are private.\n<IfModule mod_authz_core.c>\n\tRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n\tDeny from all\n</IfModule>\n",
			'index.php'  => "<?php\n// Silence is golden.\n",
			'web.config' => "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<configuration><system.webServer><authorization><deny users=\"*\" /></authorization></system.webServer></configuration>\n",
		);

		foreach ( $files as $name => $content ) {
			if ( ! file_exists( $dir . '/' . $name ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Protection files.
				@file_put_contents( $dir . '/' . $name, $content );
			}
		}

		return $dir;
	}

	/**
	 * Removes values that must never reach a log file.
	 *
	 * @param array<string, mixed> $context Context.
	 * @return array<string, mixed>
	 */
	private static function clean( array $context ): array {
		$secret = array( 'password', 'pass', 'pwd', 'token', 'nonce', 'secret', 'key', 'authorization', 'cookie' );

		foreach ( $context as $key => $value ) {
			if ( in_array( strtolower( (string) $key ), $secret, true ) ) {
				$context[ $key ] = '***';
			} elseif ( is_array( $value ) ) {
				$context[ $key ] = self::clean( $value );
			} elseif ( is_string( $value ) && strlen( $value ) > 500 ) {
				$context[ $key ] = substr( $value, 0, 500 ) . '…';
			}
		}

		return $context;
	}
}
