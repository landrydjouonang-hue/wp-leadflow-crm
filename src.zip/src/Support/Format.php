<?php
/**
 * Display formatting helpers.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Support;

defined( 'ABSPATH' ) || exit;

/**
 * Converts stored values into display strings (not escaped).
 */
final class Format {

	/**
	 * UTC MySQL datetime → site date and time.
	 *
	 * @param string|null $utc Stored UTC datetime.
	 * @return string
	 */
	public static function datetime( ?string $utc ): string {
		return self::format( $utc, get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) );
	}

	/**
	 * UTC MySQL datetime → site date.
	 *
	 * @param string|null $utc Stored UTC datetime.
	 * @return string
	 */
	public static function date( ?string $utc ): string {
		return self::format( $utc, (string) get_option( 'date_format' ) );
	}

	/**
	 * "3 hours ago" style text.
	 *
	 * @param string|null $utc Stored UTC datetime.
	 * @return string
	 */
	public static function relative( ?string $utc ): string {
		$timestamp = self::timestamp( $utc );

		if ( null === $timestamp ) {
			return '';
		}

		/* translators: %s: Human-readable time difference, e.g. "3 hours". */
		return sprintf( __( '%s ago', 'wp-leadflow-crm' ), human_time_diff( $timestamp ) );
	}

	/**
	 * Machine-readable ISO 8601 (for <time datetime="">).
	 *
	 * @param string|null $utc Stored UTC datetime.
	 * @return string
	 */
	public static function iso( ?string $utc ): string {
		$timestamp = self::timestamp( $utc );

		return null === $timestamp ? '' : gmdate( 'c', $timestamp );
	}

	/**
	 * Stored UTC datetime → value for <input type="datetime-local"> in the
	 * site timezone. Non-matching values are returned unchanged.
	 *
	 * @param string|null $utc Stored UTC datetime.
	 * @return string
	 */
	public static function to_input( ?string $utc ): string {
		if ( null === $utc || 1 !== preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}(:\d{2})?$/', $utc ) ) {
			return (string) $utc;
		}

		return get_date_from_gmt( $utc, 'Y-m-d\TH:i' );
	}

	/**
	 * Site-local datetime from a form (Y-m-d\TH:i or Y-m-d H:i[:s]) → UTC
	 * MySQL datetime. Invalid values are returned unchanged so validation
	 * can report them.
	 *
	 * @param string $local Local datetime.
	 * @return string
	 */
	public static function to_utc( string $local ): string {
		$local = trim( str_replace( 'T', ' ', $local ) );

		if ( 1 !== preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}(:\d{2})?$/', $local ) ) {
			return $local;
		}

		try {
			$date = new \DateTimeImmutable( $local, wp_timezone() );
		} catch ( \Exception $e ) {
			return $local;
		}

		// Reject overflow such as 2026-02-31 (PHP would roll it over).
		if ( $date->format( 'Y-m-d H:i' ) !== substr( $local, 0, 16 ) ) {
			return $local;
		}

		return $date->setTimezone( new \DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
	}

	/**
	 * "Today", "Tomorrow", "Yesterday" or a date, plus the local time.
	 *
	 * @param string|null $utc Stored UTC datetime.
	 * @return string
	 */
	public static function due( ?string $utc ): string {
		$timestamp = self::timestamp( $utc );

		if ( null === $timestamp ) {
			return '';
		}

		$day   = wp_date( 'Y-m-d', $timestamp );
		$today = wp_date( 'Y-m-d' );
		$time  = (string) wp_date( (string) get_option( 'time_format' ), $timestamp );

		if ( $day === $today ) {
			/* translators: %s: Time. */
			return sprintf( __( 'Today, %s', 'wp-leadflow-crm' ), $time );
		}

		if ( wp_date( 'Y-m-d', strtotime( '+1 day', $timestamp ) ) === $today ) {
			/* translators: %s: Time. */
			return sprintf( __( 'Yesterday, %s', 'wp-leadflow-crm' ), $time );
		}

		if ( wp_date( 'Y-m-d', strtotime( '-1 day', $timestamp ) ) === $today ) {
			/* translators: %s: Time. */
			return sprintf( __( 'Tomorrow, %s', 'wp-leadflow-crm' ), $time );
		}

		return self::datetime( $utc );
	}

	/**
	 * Money amount with currency, e.g. "$15,000", "€3,500.50", "250,000 XAF".
	 *
	 * @param float  $amount   Amount.
	 * @param string $currency ISO 4217 code.
	 * @return string
	 */
	public static function money( float $amount, string $currency ): string {
		$symbols  = array(
			'USD' => '$',
			'EUR' => '€',
			'GBP' => '£',
			'JPY' => '¥',
			'INR' => '₹',
			'NGN' => '₦',
		);
		$decimals = ( floor( $amount ) === $amount || in_array( $currency, array( 'JPY', 'XAF', 'XOF' ), true ) ) ? 0 : 2;
		$number   = number_format_i18n( $amount, $decimals );

		if ( isset( $symbols[ $currency ] ) ) {
			return $symbols[ $currency ] . $number;
		}

		return trim( $number . ' ' . $currency );
	}

	/**
	 * Several currency totals, e.g. "$12,000 · €3,000".
	 *
	 * @param array<string, float> $amounts Currency => amount.
	 * @return string
	 */
	public static function money_list( array $amounts ): string {
		$parts = array();

		foreach ( $amounts as $currency => $amount ) {
			$parts[] = self::money( (float) $amount, (string) $currency );
		}

		return empty( $parts ) ? self::money( 0.0, '' ) : implode( ' · ', $parts );
	}

	/**
	 * Display name of a user id.
	 *
	 * @param int|null $user_id User id.
	 * @return string '' when empty, "Deleted user" when missing.
	 */
	public static function user( ?int $user_id ): string {
		if ( empty( $user_id ) ) {
			return '';
		}

		$user = get_userdata( $user_id );

		return false === $user ? __( 'Deleted user', 'wp-leadflow-crm' ) : $user->display_name;
	}

	/**
	 * Initials for avatar placeholders.
	 *
	 * @param string $name Name.
	 * @return string Up to two uppercase letters.
	 */
	public static function initials( string $name ): string {
		$initials = '';

		foreach ( preg_split( '/[\s\-]+/u', trim( $name ) ) ?: array() as $part ) {
			if ( '' !== $part ) {
				$initials .= mb_strtoupper( mb_substr( $part, 0, 1 ) );
			}

			if ( mb_strlen( $initials ) >= 2 ) {
				break;
			}
		}

		return '' !== $initials ? $initials : '?';
	}

	/**
	 * Short plain-text preview of stored HTML.
	 *
	 * Block tags become a space, so "<p>Hi</p><p>Thanks</p>" reads as
	 * "Hi Thanks" instead of running the words together.
	 *
	 * @param string|null $html  Stored text or HTML.
	 * @param int         $words Word limit.
	 * @return string
	 */
	public static function excerpt( ?string $html, int $words ): string {
		$text = (string) preg_replace( '#<(br|/p|/div|/li|/h[1-6]|/tr|/td)[^>]*>#i', ' ', (string) $html );
		$text = html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES, 'UTF-8' );
		$text = trim( (string) preg_replace( '/\s+/u', ' ', $text ) );

		return wp_trim_words( $text, $words );
	}

	/**
	 * Timestamp of a stored UTC datetime.
	 *
	 * @param string|null $utc Stored UTC datetime.
	 * @return int|null
	 */
	private static function timestamp( ?string $utc ): ?int {
		if ( null === $utc || '' === $utc ) {
			return null;
		}

		$timestamp = strtotime( $utc . ' UTC' );

		return false === $timestamp ? null : $timestamp;
	}

	/**
	 * Formats in the site timezone.
	 *
	 * @param string|null $utc    Stored UTC datetime.
	 * @param string      $format PHP date format.
	 * @return string
	 */
	private static function format( ?string $utc, string $format ): string {
		$timestamp = self::timestamp( $utc );

		return null === $timestamp ? '' : (string) wp_date( $format, $timestamp );
	}
}
