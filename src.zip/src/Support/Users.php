<?php
/**
 * CRM user helpers.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Support;

use LeadFlow\CRM\Security\Capabilities;

defined( 'ABSPATH' ) || exit;

/**
 * Lists users who can work in the CRM (for owner/assignee pickers).
 */
final class Users {

	/**
	 * Per-request cache.
	 *
	 * @var array<int, string>|null
	 */
	private static ?array $crm_users = null;

	/**
	 * Users with CRM access, sorted by display name.
	 *
	 * @return array<int, string> User id => display name.
	 */
	public static function crm_users(): array {
		if ( null !== self::$crm_users ) {
			return self::$crm_users;
		}

		$users = get_users(
			array(
				'capability' => Capabilities::ACCESS_CRM,
				'orderby'    => 'display_name',
				'order'      => 'ASC',
				'fields'     => array( 'ID', 'display_name' ),
				'number'     => 500,
			)
		);

		self::$crm_users = array();

		foreach ( $users as $user ) {
			self::$crm_users[ (int) $user->ID ] = (string) $user->display_name;
		}

		return self::$crm_users;
	}
}
