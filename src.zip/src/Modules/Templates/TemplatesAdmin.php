<?php
/**
 * Email template screens.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Templates;

use LeadFlow\CRM\Admin\Crud\EntityAdmin;
use LeadFlow\CRM\Admin\Crud\EntityListTable;
use LeadFlow\CRM\Admin\View;
use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\EmailTemplate;
use LeadFlow\CRM\Data\Repositories\EmailTemplateRepository;
use LeadFlow\CRM\Data\Repository;
use LeadFlow\CRM\Email\TemplateRenderer;
use LeadFlow\CRM\Modules\Tasks\TasksAdmin;
use LeadFlow\CRM\Security\Capabilities;

defined( 'ABSPATH' ) || exit;

/**
 * Manage reusable email templates.
 *
 * Administrators and CRM Managers create and edit templates; Sales Agents
 * may view and preview them. Nothing is sent from these screens.
 */
final class TemplatesAdmin extends EntityAdmin {

	protected const ENTITY     = 'email_template';
	protected const PLURAL     = 'email_templates';
	protected const PAGE_SLUG  = 'leadflow-crm-templates';
	protected const MENU_ORDER = 60;

	/**
	 * {@inheritDoc}
	 */
	public function repository(): Repository {
		return $this->plugin->get( EmailTemplateRepository::class );
	}

	/**
	 * Renderer.
	 *
	 * @return TemplateRenderer
	 */
	public function renderer(): TemplateRenderer {
		return $this->plugin->get( TemplateRenderer::class );
	}

	/**
	 * Only managers edit templates; agents can view them.
	 *
	 * {@inheritDoc}
	 */
	public function capability_map(): array {
		$all      = array( 'administrator', Capabilities::ROLE_MANAGER, Capabilities::ROLE_AGENT );
		$managers = array( 'administrator', Capabilities::ROLE_MANAGER );

		return array(
			$this->cap( 'view' )        => $all,
			$this->cap( 'edit' )        => $managers,
			$this->cap( 'edit_others' ) => $managers,
			$this->cap( 'delete' )      => $managers,
		);
	}

	/**
	 * Templates are shared: no ownership.
	 *
	 * {@inheritDoc}
	 */
	public function map_meta_cap( array $caps, string $cap, int $user_id, array $args ): array {
		if ( $cap !== $this->meta_cap( 'edit' ) && $cap !== $this->meta_cap( 'delete' ) ) {
			return $caps;
		}

		if ( null === $this->repository()->find( (int) ( $args[0] ?? 0 ), true ) ) {
			return array( 'do_not_allow' );
		}

		return array( $cap === $this->meta_cap( 'delete' ) ? $this->cap( 'delete' ) : $this->cap( 'edit' ) );
	}

	/**
	 * {@inheritDoc}
	 */
	public function labels(): array {
		return array(
			'singular'        => __( 'Email template', 'wp-leadflow-crm' ),
			'plural'          => __( 'Email templates', 'wp-leadflow-crm' ),
			'add_new'         => __( 'Add template', 'wp-leadflow-crm' ),
			'search'          => __( 'Search templates', 'wp-leadflow-crm' ),
			'not_found'       => __( 'No email templates found.', 'wp-leadflow-crm' ),
			'not_found_trash' => __( 'No email templates in the trash.', 'wp-leadflow-crm' ),
			'created'         => __( 'Template created.', 'wp-leadflow-crm' ),
			'updated'         => __( 'Template updated.', 'wp-leadflow-crm' ),
			'trashed'         => __( 'Template moved to the trash.', 'wp-leadflow-crm' ),
			'restored'        => __( 'Template restored.', 'wp-leadflow-crm' ),
			'deleted'         => __( 'Template permanently deleted.', 'wp-leadflow-crm' ),
			'delete_confirm'  => __( 'Permanently delete this template? This cannot be undone.', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function status_labels(): array {
		return array(
			'active'   => __( 'Active', 'wp-leadflow-crm' ),
			'inactive' => __( 'Inactive', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function title_of( Model $model ): string {
		return $model instanceof EmailTemplate ? $model->name() : '';
	}

	/**
	 * Menu label "Email templates" is long; use "Templates".
	 *
	 * {@inheritDoc}
	 */
	public function page(): \LeadFlow\CRM\Admin\Page {
		$page = parent::page();

		return new \LeadFlow\CRM\Admin\Page( $page->slug(), $page->title(), __( 'Email templates', 'wp-leadflow-crm' ), $page->capability(), $page->callback(), $page->order(), $page->on_load() );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function form_sections( ?Model $model ): array {
		return array(
			array(
				'title'       => __( 'Template', 'wp-leadflow-crm' ),
				'description' => __( 'Use placeholders such as {{first_name}} — they are replaced with the recipient’s details. Add a fallback after a pipe: {{first_name|there}}.', 'wp-leadflow-crm' ),
				'fields'      => array(
					array(
						'name'        => 'name',
						'label'       => __( 'Template name', 'wp-leadflow-crm' ),
						'required'    => true,
						'maxlength'   => 191,
						'description' => __( 'Only visible to your team.', 'wp-leadflow-crm' ),
					),
					array(
						'name'      => 'subject',
						'label'     => __( 'Subject', 'wp-leadflow-crm' ),
						'required'  => true,
						'maxlength' => 255,
					),
					array(
						'name'        => 'body',
						'label'       => __( 'Message', 'wp-leadflow-crm' ),
						'type'        => 'textarea',
						'rows'        => 14,
						'required'    => true,
						'description' => __( 'Basic HTML is allowed (paragraphs, bold, links, lists).', 'wp-leadflow-crm' ),
					),
				),
			),
		);
	}

	/**
	 * The body keeps its HTML (sanitized by the repository with wp_kses_post).
	 *
	 * {@inheritDoc}
	 */
	protected function collect_input( ?Model $model ): array {
		list( $data, $extra ) = parent::collect_input( $model );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified in handle_save().
		$data['body'] = isset( $_POST['body'] ) ? wp_kses_post( wp_unslash( (string) $_POST['body'] ) ) : '';

		return array( $data, $extra );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function sidebar_fields( ?Model $model ): array {
		return array(
			array(
				'name'     => 'status',
				'label'    => __( 'Status', 'wp-leadflow-crm' ),
				'type'     => 'select',
				'required' => true,
				'options'  => $this->status_labels(),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function default_values(): array {
		return array( 'status' => 'active' );
	}

	/**
	 * Placeholder picker and live preview next to the form.
	 *
	 * {@inheritDoc}
	 */
	public function form_aside( ?Model $model ): void {
		View::render(
			'admin/templates/aside',
			array(
				'placeholders' => TemplateRenderer::placeholders(),
				'records'      => $this->preview_records(),
			)
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function create_list_table(): EntityListTable {
		return new TemplatesListTable( $this, $this->repository() );
	}

	/**
	 * Preview screen.
	 *
	 * {@inheritDoc}
	 */
	protected function render_view( Model $model ): void {
		View::render(
			'admin/templates/view',
			array(
				'admin'    => $this,
				'template' => $model,
				'preview'  => $this->renderer()->render( (string) $model->get( 'subject' ), (string) $model->get( 'body' ), $this->renderer()->sample_values() ),
				'records'  => $this->preview_records(),
			)
		);
	}

	/**
	 * Records offered for previews: recent leads and contacts the user can see.
	 *
	 * @return array<string, array<string, string>> Optgroup label => "type:id" => label.
	 */
	public function preview_records(): array {
		$groups = array();

		if ( current_user_can( 'leadflow_view_leads' ) ) {
			foreach ( ( new TasksAdmin( $this->plugin ) )->lead_options() as $id => $label ) {
				$groups[ __( 'Leads', 'wp-leadflow-crm' ) ][ 'lead:' . $id ] = $label;
			}
		}

		if ( current_user_can( 'leadflow_view_contacts' ) ) {
			foreach ( ( new \LeadFlow\CRM\Modules\Leads\LeadsAdmin( $this->plugin ) )->contact_options() as $id => $label ) {
				$groups[ __( 'Contacts', 'wp-leadflow-crm' ) ][ 'contact:' . $id ] = $label;
			}
		}

		return $groups;
	}
}
