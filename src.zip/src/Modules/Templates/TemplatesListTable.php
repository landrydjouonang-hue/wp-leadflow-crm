<?php
/**
 * Email templates list table.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Templates;

use LeadFlow\CRM\Admin\Crud\EntityListTable;
use LeadFlow\CRM\Admin\UI;
use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Email\TemplateRenderer;
use LeadFlow\CRM\Support\Format;

defined( 'ABSPATH' ) || exit;

/**
 * Templates table.
 */
final class TemplatesListTable extends EntityListTable {

	/**
	 * {@inheritDoc}
	 */
	public function get_columns(): array {
		return array(
			'cb'           => '<input type="checkbox" />',
			'name'         => __( 'Template', 'wp-leadflow-crm' ),
			'subject'      => __( 'Subject', 'wp-leadflow-crm' ),
			'placeholders' => __( 'Placeholders', 'wp-leadflow-crm' ),
			'status'       => __( 'Status', 'wp-leadflow-crm' ),
			'updated_at'   => __( 'Last updated', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_sortable_columns(): array {
		return array(
			'name'       => array( 'name', false ),
			'updated_at' => array( 'updated_at', true ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function default_order(): array {
		return array( 'name', 'asc' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_primary_column_name(): string {
		return 'name';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function filter_args(): array {
		return array();
	}

	/**
	 * {@inheritDoc}
	 */
	protected function render_filters(): void {}

	/**
	 * Name column.
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_name( Model $item ): string {
		return $this->primary_cell( $item, Format::excerpt( (string) $item->get( 'body', '' ), 12 ) );
	}

	/**
	 * Placeholders used.
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_placeholders( Model $item ): string {
		preg_match_all( '/\{\{\s*([a-z0-9_]+)/i', $item->get( 'subject' ) . ' ' . $item->get( 'body' ), $m );

		$keys = array_values( array_unique( array_map( 'strtolower', $m[1] ) ) );
		$all  = TemplateRenderer::placeholders();

		if ( empty( $keys ) ) {
			return UI::text( '' );
		}

		return implode(
			' ',
			array_map(
				static fn( string $key ): string => sprintf( '<code title="%1$s">{{%2$s}}</code>', esc_attr( $all[ $key ]['label'] ?? '' ), esc_html( $key ) ),
				$keys
			)
		);
	}

	/**
	 * Updated column.
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_updated_at( Model $item ): string {
		return esc_html( Format::relative( $item->get( 'updated_at' ) ) );
	}
}
