<?php
/**
 * Email templates module.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Templates;

use LeadFlow\CRM\Admin\Menu;
use LeadFlow\CRM\Contracts\Module;
use LeadFlow\CRM\Contracts\ProvidesCapabilities;
use LeadFlow\CRM\Plugin;
use LeadFlow\CRM\Security\Guard;
use LeadFlow\CRM\Security\Input;

defined( 'ABSPATH' ) || exit;

/**
 * Template management plus an AJAX live preview.
 */
final class TemplatesModule implements Module, ProvidesCapabilities {

	/**
	 * Admin controller.
	 *
	 * @var TemplatesAdmin|null
	 */
	private ?TemplatesAdmin $admin = null;

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'templates';
	}

	/**
	 * {@inheritDoc}
	 */
	public function capabilities(): array {
		return $this->admin()->capability_map();
	}

	/**
	 * {@inheritDoc}
	 */
	public function boot( Plugin $plugin ): void {
		$admin = $this->admin();

		$plugin->get( Menu::class )->add( $admin->page() );
		$admin->register();

		add_action( 'wp_ajax_leadflow_crm_preview_template', array( $this, 'ajax_preview' ) );
	}

	/**
	 * AJAX: renders an (unsaved) subject/body with sample data or a record.
	 *
	 * POST: subject, body, record ("lead:12", "contact:5" or empty).
	 *
	 * @return void
	 */
	public function ajax_preview(): void {
		$admin = $this->admin();

		Guard::verify_ajax( 'template', $admin->cap( 'view' ) );

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified above.
		$subject = isset( $_POST['subject'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['subject'] ) ) : '';
		$body    = isset( $_POST['body'] ) ? wp_kses_post( wp_unslash( (string) $_POST['body'] ) ) : '';
		// phpcs:enable
		$record  = Input::text( 'record', 'post' );
		$values  = $admin->renderer()->sample_values();

		if ( 1 === preg_match( '/^(lead|contact):(\d+)$/', $record, $m ) ) {
			$plural = 'lead' === $m[1] ? 'leads' : 'contacts';

			if ( ! current_user_can( 'leadflow_view_' . $plural ) ) {
				wp_send_json_error( array( 'message' => __( 'You are not allowed to preview with this record.', 'wp-leadflow-crm' ) ), 403 );
			}

			$values = $admin->renderer()->values_for( $m[1], (int) $m[2] );

			if ( null === $values ) {
				wp_send_json_error( array( 'message' => __( 'This record no longer exists.', 'wp-leadflow-crm' ) ), 404 );
			}
		}

		$unknown = \LeadFlow\CRM\Email\TemplateRenderer::unknown_placeholders( $subject . ' ' . $body );

		wp_send_json_success(
			array_merge(
				$admin->renderer()->render( $subject, $body, $values ),
				array( 'unknown' => $unknown )
			)
		);
	}

	/**
	 * Lazily built admin controller.
	 *
	 * @return TemplatesAdmin
	 */
	private function admin(): TemplatesAdmin {
		if ( null === $this->admin ) {
			$this->admin = new TemplatesAdmin( Plugin::instance() );
		}

		return $this->admin;
	}
}
