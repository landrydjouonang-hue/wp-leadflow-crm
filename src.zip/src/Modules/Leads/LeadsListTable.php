<?php
/**
 * Leads list table.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Leads;

use LeadFlow\CRM\Admin\Crud\EntityListTable;
use LeadFlow\CRM\Admin\Menu;
use LeadFlow\CRM\Admin\UI;
use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\Company;
use LeadFlow\CRM\Data\Models\Contact;
use LeadFlow\CRM\Data\Models\Lead;
use LeadFlow\CRM\Data\Relations;
use LeadFlow\CRM\Data\Repositories\FollowUpRepository;
use LeadFlow\CRM\Modules\Contacts\ContactsAdmin;
use LeadFlow\CRM\Security\Input;
use LeadFlow\CRM\Support\Format;
use LeadFlow\CRM\Support\Users;

defined( 'ABSPATH' ) || exit;

/**
 * Leads table.
 */
final class LeadsListTable extends EntityListTable {

	/**
	 * Companies of the current page.
	 *
	 * @var array<int, Company>
	 */
	private array $companies = array();

	/**
	 * Contacts of the current page.
	 *
	 * @var array<int, Contact>
	 */
	private array $contacts = array();

	/**
	 * {@inheritDoc}
	 */
	public function get_columns(): array {
		return array(
			'cb'                  => '<input type="checkbox" />',
			'title'               => __( 'Lead', 'wp-leadflow-crm' ),
			'contact_id'          => __( 'Contact', 'wp-leadflow-crm' ),
			'amount'              => __( 'Value', 'wp-leadflow-crm' ),
			'stage'               => __( 'Stage', 'wp-leadflow-crm' ),
			'status'              => __( 'Status', 'wp-leadflow-crm' ),
			'owner_id'            => __( 'Assigned to', 'wp-leadflow-crm' ),
			'expected_close_date' => __( 'Expected close', 'wp-leadflow-crm' ),
			'next_follow_up'      => __( 'Next follow-up', 'wp-leadflow-crm' ),
			'created_at'          => __( 'Created', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * Next scheduled follow-up per lead of the current page.
	 *
	 * @var array<int, string>
	 */
	private array $next_follow_ups = array();

	/**
	 * Next follow-up column (overdue flagged).
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_next_follow_up( Model $item ): string {
		$next = $this->next_follow_ups[ $item->id() ] ?? null;

		if ( null === $next ) {
			return UI::text( '' );
		}

		$html = sprintf( '<time datetime="%1$s">%2$s</time>', esc_attr( Format::iso( $next ) ), esc_html( Format::due( $next ) ) );

		if ( $next < current_time( 'mysql', true ) ) {
			$html .= ' <span class="lf-pill lf-pill--overdue">' . esc_html__( 'Overdue', 'wp-leadflow-crm' ) . '</span>';
		}

		return $html;
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_sortable_columns(): array {
		return array(
			'title'               => array( 'title', false ),
			'amount'              => array( 'amount', true ),
			'expected_close_date' => array( 'expected_close_date', false ),
			'created_at'          => array( 'created_at', true ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_primary_column_name(): string {
		return 'title';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function filter_args(): array {
		$where = array();

		foreach ( array( 'owner' => 'owner_id', 'company_id' => 'company_id', 'contact_id' => 'contact_id' ) as $param => $column ) {
			$value = Input::int( $param );

			if ( $value > 0 ) {
				$where[ $column ] = $value;
			}
		}

		$stage = Input::key( 'stage' );

		if ( '' !== $stage && null !== $this->admin_leads()->stages()->find_by_slug( $stage ) ) {
			$where['stage'] = $stage;
		}

		$source = sanitize_title( Input::text( 'source' ) );

		if ( '' !== $source ) {
			$where['source'] = $source;
		}

		return array( 'where' => $where );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function render_filters(): void {
		$this->filter_select( 'stage', __( 'Filter by stage', 'wp-leadflow-crm' ), $this->admin_leads()->stages()->options(), __( 'All stages', 'wp-leadflow-crm' ) );
		$this->filter_select( 'owner', __( 'Filter by assignee', 'wp-leadflow-crm' ), Users::crm_users(), __( 'All assignees', 'wp-leadflow-crm' ) );

		if ( current_user_can( 'leadflow_view_companies' ) ) {
			$this->filter_select( 'company_id', __( 'Filter by company', 'wp-leadflow-crm' ), ( new ContactsAdmin( leadflow_crm() ) )->company_options( Input::int( 'company_id' ) ), __( 'All companies', 'wp-leadflow-crm' ) );
		}

		$sources = $this->repository->distinct_values( 'source' );

		if ( ! empty( $sources ) ) {
			$this->filter_select( 'source', __( 'Filter by source', 'wp-leadflow-crm' ), array_combine( $sources, $sources ), __( 'All sources', 'wp-leadflow-crm' ) );
		}
	}

	/**
	 * Adds the "Assign to" picker used by the bulk action.
	 *
	 * @param string $which top|bottom.
	 * @return void
	 */
	protected function extra_tablenav( $which ): void {
		parent::extra_tablenav( $which );

		if ( 'top' !== $which || $this->is_trash() || empty( $this->admin->extra_bulk_actions() ) ) {
			return;
		}

		echo '<div class="alignleft actions lf-bulk-assign">';
		printf( '<label for="lf-assign-to">%s</label> ', esc_html__( 'Assign selected to', 'wp-leadflow-crm' ) );
		printf( '<select id="lf-assign-to" name="assign_to"><option value="">%s</option>', esc_html__( '— Choose —', 'wp-leadflow-crm' ) );

		foreach ( Users::crm_users() as $id => $name ) {
			printf( '<option value="%1$d">%2$s</option>', (int) $id, esc_html( $name ) );
		}

		echo '</select>';
		printf( '<p class="lf-muted lf-bulk-assign__hint">%s</p>', esc_html__( 'Then choose “Assign to…” in Bulk actions.', 'wp-leadflow-crm' ) );
		echo '</div>';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function prefetch( array $items ): void {
		$relations       = leadflow_crm()->get( Relations::class );
		$this->companies       = $relations->companies_for( $items );
		$this->contacts        = $relations->contacts_for( $items );
		$this->next_follow_ups = leadflow_crm()->get( FollowUpRepository::class )->next_for_leads( array_map( static fn( Model $m ): int => $m->id(), $items ) );
	}

	/**
	 * Title column.
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_title( Model $item ): string {
		$company = $this->companies[ (int) $item->get( 'company_id', 0 ) ] ?? null;

		return $this->primary_cell( $item, null !== $company ? $company->name() : '' );
	}

	/**
	 * Contact column.
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_contact_id( Model $item ): string {
		$contact = $this->contacts[ (int) $item->get( 'contact_id', 0 ) ] ?? null;

		if ( null === $contact ) {
			return UI::text( (string) $item->get( 'email', '' ) );
		}

		return sprintf(
			'<a href="%1$s">%2$s</a>',
			esc_url(
				Menu::url(
					'leadflow-crm-contacts',
					array(
						'action' => 'view',
						'id'     => $contact->id(),
					)
				)
			),
			esc_html( $contact->full_name() )
		);
	}

	/**
	 * Value column.
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_amount( Model $item ): string {
		return esc_html( Format::money( (float) $item->get( 'amount', 0 ), (string) $item->get( 'currency', '' ) ) );
	}

	/**
	 * Stage column.
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_stage( Model $item ): string {
		$stage = $this->admin_leads()->stages()->find_by_slug( (string) $item->get( 'stage', '' ) );

		return null === $stage ? UI::text( (string) $item->get( 'stage', '' ) ) : UI::stage( $stage->name(), $stage->color() );
	}

	/**
	 * Expected close column (overdue open leads are flagged).
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_expected_close_date( Model $item ): string {
		$date = $item->get( 'expected_close_date' );

		if ( null === $date ) {
			return UI::text( '' );
		}

		$overdue = $item instanceof Lead && $item->is_open() && $date < current_time( 'Y-m-d' );
		$label   = (string) wp_date( (string) get_option( 'date_format' ), (int) strtotime( $date . ' 12:00:00 UTC' ) );

		return $overdue
			? sprintf( '<span class="lf-overdue">%1$s <span class="lf-pill lf-pill--lost">%2$s</span></span>', esc_html( $label ), esc_html__( 'Overdue', 'wp-leadflow-crm' ) )
			: esc_html( $label );
	}

	/**
	 * Typed admin accessor.
	 *
	 * @return LeadsAdmin
	 */
	private function admin_leads(): LeadsAdmin {
		/** @var LeadsAdmin $admin */
		$admin = $this->admin;

		return $admin;
	}
}
