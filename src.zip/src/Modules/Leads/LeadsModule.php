<?php
/**
 * Leads & pipeline module.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Leads;

use LeadFlow\CRM\Admin\Menu;
use LeadFlow\CRM\Admin\RecordPanels;
use LeadFlow\CRM\Admin\View;
use LeadFlow\CRM\Contracts\Module;
use LeadFlow\CRM\Contracts\ProvidesCapabilities;
use LeadFlow\CRM\Contracts\ProvidesRestControllers;
use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Repositories\LeadRepository;
use LeadFlow\CRM\Data\Repositories\StageRepository;
use LeadFlow\CRM\Modules\Dashboard\Sections;
use LeadFlow\CRM\Plugin;
use LeadFlow\CRM\Security\Capabilities;
use LeadFlow\CRM\Settings\Registry;

defined( 'ABSPATH' ) || exit;

/**
 * Leads, the visual pipeline and stage configuration.
 */
final class LeadsModule implements Module, ProvidesCapabilities, ProvidesRestControllers {

	/**
	 * {@inheritDoc}
	 */
	public function rest_controllers(): array {
		return array( new LeadLookupController( Plugin::instance()->get( LeadRepository::class ) ) );
	}


	/**
	 * Admin controller.
	 *
	 * @var LeadsAdmin|null
	 */
	private ?LeadsAdmin $admin = null;

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'leads';
	}

	/**
	 * {@inheritDoc}
	 */
	public function capabilities(): array {
		return array_merge(
			$this->admin()->capability_map(),
			array( StagesAdmin::CAPABILITY => array( 'administrator', Capabilities::ROLE_MANAGER ) )
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function boot( Plugin $plugin ): void {
		$admin = $this->admin();
		$board = new PipelineBoard( $plugin, $admin );
		$menu  = $plugin->get( Menu::class );

		$menu->add( $board->page() );
		$menu->add( $admin->page() );
		$admin->register();
		$board->register();

		( new StagesAdmin( $plugin->get( StageRepository::class ) ) )->register( $plugin->get( Registry::class ) );

		add_action( 'leadflow_crm_dashboard_sections', array( $this, 'dashboard_sections' ) );
		add_action( 'leadflow_crm_record_panels', array( $this, 'record_panel' ), 20, 3 );
	}

	/**
	 * "Leads" tab on company and contact screens.
	 *
	 * @param RecordPanels $panels Panel registry.
	 * @param string       $type   Record type.
	 * @param Model        $model  Record.
	 * @return void
	 */
	public function record_panel( RecordPanels $panels, string $type, Model $model ): void {
		$admin = $this->admin();

		if ( ! in_array( $type, array( 'company', 'contact' ), true ) || ! current_user_can( $admin->cap( 'view' ) ) ) {
			return;
		}

		$column = $type . '_id';
		$args   = array(
			'where'    => array( $column => $model->id() ),
			'orderby'  => 'created_at',
			'order'    => 'DESC',
			'per_page' => 10,
		);
		$total  = $admin->repository()->count( $args );

		$panels->add(
			'leads',
			array(
				'title'  => __( 'Leads', 'wp-leadflow-crm' ),
				'count'  => $total,
				'order'  => 20,
				'render' => static function () use ( $admin, $args, $total, $column, $model ): void {
					View::render(
						'admin/partials/related-leads',
						array(
							'leads'    => $admin->repository()->query( $args ),
							'total'    => $total,
							'list_url' => $admin->url( array( $column => $model->id() ) ),
							'add_url'  => ! $model->is_trashed() && current_user_can( $admin->cap( 'edit' ) ) ? $admin->new_url( array( $column => $model->id() ) ) : '',
						)
					);
				},
			)
		);
	}

	/**
	 * Replaces the Leads and Sales pipeline placeholders.
	 *
	 * @param Sections $sections Dashboard sections.
	 * @return void
	 */
	public function dashboard_sections( Sections $sections ): void {
		$sections->add(
			'pipeline',
			array(
				'title'      => __( 'Sales pipeline', 'wp-leadflow-crm' ),
				'icon'       => 'chart-bar',
				'order'      => 10,
				'wide'       => true,
				'capability' => $this->admin()->cap( 'view' ),
				'render'     => array( $this, 'render_pipeline_section' ),
			)
		);

		$sections->add(
			'leads',
			array(
				'title'      => __( 'Leads', 'wp-leadflow-crm' ),
				'icon'       => 'id-alt',
				'order'      => 20,
				'capability' => $this->admin()->cap( 'view' ),
				'render'     => array( $this, 'render_leads_section' ),
			)
		);
	}

	/**
	 * Pipeline widget: leads and value per stage.
	 *
	 * @return void
	 */
	public function render_pipeline_section(): void {
		$plugin = Plugin::instance();

		View::render(
			'admin/partials/pipeline-widget',
			array(
				'stages'     => $plugin->get( StageRepository::class )->all(),
				'totals'     => $plugin->get( LeadRepository::class )->stage_totals(),
				'open_value' => $plugin->get( LeadRepository::class )->open_value_by_currency(),
				'board_url'  => PipelineBoard::url(),
			)
		);
	}

	/**
	 * Leads widget.
	 *
	 * @return void
	 */
	public function render_leads_section(): void {
		$admin      = $this->admin();
		$repository = $admin->repository();

		View::render(
			'admin/partials/entity-widget',
			array(
				'admin'    => $admin,
				'counts'   => $repository->count_by( 'status' ),
				'statuses' => $admin->status_labels(),
				'recent'   => $repository->query( array( 'per_page' => 5 ) ),
				'can_add'  => current_user_can( $admin->cap( 'edit' ) ),
			)
		);
	}

	/**
	 * Lazily built admin controller.
	 *
	 * @return LeadsAdmin
	 */
	private function admin(): LeadsAdmin {
		if ( null === $this->admin ) {
			$this->admin = new LeadsAdmin( Plugin::instance() );
		}

		return $this->admin;
	}
}
