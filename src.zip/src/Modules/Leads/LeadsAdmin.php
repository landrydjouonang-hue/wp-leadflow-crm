<?php
/**
 * Leads admin screens.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Leads;

use LeadFlow\CRM\Admin\Crud\EntityAdmin;
use LeadFlow\CRM\Admin\Crud\EntityListTable;
use LeadFlow\CRM\Admin\Notes\NoteActions;
use LeadFlow\CRM\Admin\View;
use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\Lead;
use LeadFlow\CRM\Data\Relations;
use LeadFlow\CRM\Data\Repositories\CompanyRepository;
use LeadFlow\CRM\Data\Repositories\ContactRepository;
use LeadFlow\CRM\Data\Repositories\LeadRepository;
use LeadFlow\CRM\Data\Models\Task;
use LeadFlow\CRM\Data\Repositories\FollowUpRepository;
use LeadFlow\CRM\Data\Repositories\NoteRepository;
use LeadFlow\CRM\Data\Repositories\TaskRepository;
use LeadFlow\CRM\Data\Repositories\StageRepository;
use LeadFlow\CRM\Data\Repository;
use LeadFlow\CRM\Modules\Companies\CompaniesAdmin;
use LeadFlow\CRM\Modules\Contacts\ContactsAdmin;
use LeadFlow\CRM\Modules\Settings\SettingsModule;
use LeadFlow\CRM\Security\Input;
use LeadFlow\CRM\Settings\Settings;
use LeadFlow\CRM\Support\Format;
use LeadFlow\CRM\Support\Users;

defined( 'ABSPATH' ) || exit;

/**
 * List, add, edit and view leads.
 */
final class LeadsAdmin extends EntityAdmin {

	protected const ENTITY     = 'lead';
	protected const PLURAL     = 'leads';
	protected const PAGE_SLUG  = 'leadflow-crm-leads';
	protected const MENU_ORDER = 20;

	/** Records loaded into pickers before search is needed. */
	private const OPTIONS_LIMIT = 200;

	/**
	 * {@inheritDoc}
	 */
	public function repository(): Repository {
		return $this->plugin->get( LeadRepository::class );
	}

	/**
	 * Stage repository.
	 *
	 * @return StageRepository
	 */
	public function stages(): StageRepository {
		return $this->plugin->get( StageRepository::class );
	}

	/**
	 * {@inheritDoc}
	 */
	public function labels(): array {
		return array(
			'singular'        => __( 'Lead', 'wp-leadflow-crm' ),
			'plural'          => __( 'Leads', 'wp-leadflow-crm' ),
			'add_new'         => __( 'Add lead', 'wp-leadflow-crm' ),
			'search'          => __( 'Search leads', 'wp-leadflow-crm' ),
			'not_found'       => __( 'No leads found.', 'wp-leadflow-crm' ),
			'not_found_trash' => __( 'No leads in the trash.', 'wp-leadflow-crm' ),
			'created'         => __( 'Lead created.', 'wp-leadflow-crm' ),
			'updated'         => __( 'Lead updated.', 'wp-leadflow-crm' ),
			'trashed'         => __( 'Lead moved to the trash.', 'wp-leadflow-crm' ),
			'restored'        => __( 'Lead restored.', 'wp-leadflow-crm' ),
			'deleted'         => __( 'Lead permanently deleted.', 'wp-leadflow-crm' ),
			'delete_confirm'  => __( 'Permanently delete this lead and all of its notes? This cannot be undone.', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * Status follows the stage type.
	 *
	 * {@inheritDoc}
	 */
	public function status_labels(): array {
		return array(
			'open' => __( 'Open', 'wp-leadflow-crm' ),
			'won'  => __( 'Won', 'wp-leadflow-crm' ),
			'lost' => __( 'Lost', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function title_of( Model $model ): string {
		return $model instanceof Lead ? $model->title() : (string) $model->get( 'title', '' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function form_sections( ?Model $model ): array {
		$company = array(
			'name'        => 'company_id',
			'label'       => __( 'Company', 'wp-leadflow-crm' ),
			'type'        => 'record',
			'width'       => 'half',
			'options'     => ( new ContactsAdmin( $this->plugin ) )->company_options( null !== $model ? (int) $model->get( 'company_id', 0 ) : Input::int( 'company_id' ) ),
			'empty_label' => __( 'No company', 'wp-leadflow-crm' ),
		);

		if ( current_user_can( 'leadflow_view_companies' ) ) {
			$company['search'] = array(
				'endpoint' => 'lookup/companies',
				'label'    => __( 'Search companies…', 'wp-leadflow-crm' ),
			);
		}

		$contact = array(
			'name'        => 'contact_id',
			'label'       => __( 'Contact', 'wp-leadflow-crm' ),
			'type'        => 'record',
			'width'       => 'half',
			'options'     => $this->contact_options( null !== $model ? (int) $model->get( 'contact_id', 0 ) : Input::int( 'contact_id' ) ),
			'empty_label' => __( 'No contact', 'wp-leadflow-crm' ),
		);

		if ( current_user_can( 'leadflow_view_contacts' ) ) {
			$contact['search'] = array(
				'endpoint' => 'lookup/contacts',
				'label'    => __( 'Search contacts…', 'wp-leadflow-crm' ),
			);
		}

		$sections = array(
			array(
				'title'  => __( 'Lead details', 'wp-leadflow-crm' ),
				'fields' => array(
					array(
						'name'      => 'title',
						'label'     => __( 'Lead name', 'wp-leadflow-crm' ),
						'required'  => true,
						'maxlength' => 191,
						'placeholder' => __( 'e.g. Website redesign for Acme', 'wp-leadflow-crm' ),
					),
					array(
						'name'      => 'amount',
						'label'     => __( 'Value', 'wp-leadflow-crm' ),
						'type'      => 'number',
						'width'     => 'half',
						'min'       => '0',
						'step'      => '0.01',
						'inputmode' => 'decimal',
					),
					array(
						'name'    => 'currency',
						'label'   => __( 'Currency', 'wp-leadflow-crm' ),
						'type'    => 'select',
						'width'   => 'half',
						'options' => SettingsModule::currencies(),
					),
					array(
						'name'        => 'source',
						'label'       => __( 'Source', 'wp-leadflow-crm' ),
						'width'       => 'half',
						'maxlength'   => 50,
						'placeholder' => __( 'e.g. website, referral', 'wp-leadflow-crm' ),
					),
					array(
						'name'  => 'expected_close_date',
						'label' => __( 'Expected close date', 'wp-leadflow-crm' ),
						'type'  => 'date',
						'width' => 'half',
					),
				),
			),
			array(
				'title'       => __( 'Customer', 'wp-leadflow-crm' ),
				'description' => __( 'Email and phone are copied from the contact when left empty.', 'wp-leadflow-crm' ),
				'fields'      => array(
					$company,
					$contact,
					array(
						'name'         => 'email',
						'label'        => __( 'Email', 'wp-leadflow-crm' ),
						'type'         => 'email',
						'width'        => 'half',
						'maxlength'    => 100,
						'autocomplete' => 'off',
					),
					array(
						'name'         => 'phone',
						'label'        => __( 'Phone', 'wp-leadflow-crm' ),
						'type'         => 'tel',
						'width'        => 'half',
						'maxlength'    => 50,
						'autocomplete' => 'off',
					),
				),
			),
			array(
				'title'  => __( 'Description', 'wp-leadflow-crm' ),
				'fields' => array(
					array(
						'name'  => 'description',
						'label' => __( 'Description', 'wp-leadflow-crm' ),
						'type'  => 'textarea',
						'rows'  => 5,
					),
				),
			),
		);

		if ( null === $model && current_user_can( \LeadFlow\CRM\Security\Permissions::MANAGE_NOTES ) ) {
			$sections[] = CompaniesAdmin::initial_note_section();
		}

		return $sections;
	}

	/**
	 * {@inheritDoc}
	 */
	protected function sidebar_fields( ?Model $model ): array {
		$fields = array(
			array(
				'name'        => 'stage',
				'label'       => __( 'Sales stage', 'wp-leadflow-crm' ),
				'type'        => 'select',
				'required'    => true,
				'options'     => $this->stages()->options(),
				'description' => __( 'The status (open, won, lost) follows the stage.', 'wp-leadflow-crm' ),
			),
			array(
				'name'        => 'probability',
				'label'       => __( 'Win probability (%)', 'wp-leadflow-crm' ),
				'type'        => 'number',
				'min'         => '0',
				'max'         => '100',
				'step'        => '1',
				'description' => __( 'Leave empty to use the stage default.', 'wp-leadflow-crm' ),
			),
		);

		if ( current_user_can( $this->cap( 'edit_others' ) ) ) {
			$fields[] = CompaniesAdmin::owner_field( $model, __( 'Assigned to', 'wp-leadflow-crm' ) );
		}

		$fields[] = array(
			'name'        => 'lost_reason',
			'label'       => __( 'Lost reason', 'wp-leadflow-crm' ),
			'maxlength'   => 255,
			'description' => __( 'Optional. Why the deal was lost.', 'wp-leadflow-crm' ),
		);

		return $fields;
	}

	/**
	 * {@inheritDoc}
	 */
	protected function default_values(): array {
		$first  = $this->stages()->first_of_type( 'open' );
		$values = array(
			'stage'    => null !== $first ? $first->slug() : '',
			'currency' => strtoupper( (string) $this->plugin->get( Settings::class )->get( 'default_currency', 'USD' ) ),
			'owner_id' => get_current_user_id(),
		);

		$stage = Input::key( 'stage' );

		if ( null !== $this->stages()->find_by_slug( $stage ) ) {
			$values['stage'] = $stage;
		}

		$company = Input::int( 'company_id' );

		if ( $company > 0 && null !== $this->plugin->get( CompanyRepository::class )->find( $company ) ) {
			$values['company_id'] = $company;
		}

		$contact = Input::int( 'contact_id' );

		if ( $contact > 0 ) {
			$model = $this->plugin->get( ContactRepository::class )->find( $contact );

			if ( null !== $model ) {
				$values['contact_id'] = $contact;
				$values['company_id'] = $values['company_id'] ?? $model->get( 'company_id' );
			}
		}

		return $values;
	}

	/**
	 * {@inheritDoc}
	 */
	protected function after_save( Model $model, bool $created, array $extra ): void {
		CompaniesAdmin::save_initial_note( $this->plugin->get( NoteRepository::class ), 'lead_id', $model->id(), $extra );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function create_list_table(): EntityListTable {
		return new LeadsListTable( $this, $this->repository() );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function render_view( Model $model ): void {
		$relations = $this->plugin->get( Relations::class );

		View::render(
			'admin/leads/view',
			array(
				'admin'         => $this,
				'lead'          => $model,
				'stages'        => $this->stages()->all(),
				'stage'         => $this->stages()->find_by_slug( (string) $model->get( 'stage' ) ),
				'company'       => $model instanceof Lead ? $relations->company_of_lead( $model ) : null,
				'contact'       => $model instanceof Lead ? $relations->contact_of_lead( $model ) : null,
				'company_admin' => new CompaniesAdmin( $this->plugin ),
				'contact_admin' => new ContactsAdmin( $this->plugin ),
				'can_edit'      => ! $model->is_trashed() && current_user_can( $this->meta_cap( 'edit' ), $model->id() ),
				'can_assign'    => ! $model->is_trashed() && current_user_can( $this->cap( 'edit_others' ) ),
				'users'         => Users::crm_users(),
				'note_actions'  => $this->plugin->get( NoteActions::class ),
				'next_follow_up' => $this->plugin->get( FollowUpRepository::class )->next_for_leads( array( $model->id() ) )[ $model->id() ] ?? null,
				'open_tasks'     => $this->plugin->get( TaskRepository::class )->count_for_parent(
					'lead',
					$model->id(),
					array(
						'where' => array(
							'status' => array(
								'op'    => 'NOT IN',
								'value' => Task::CLOSED_STATUSES,
							),
						),
					)
				),
				'overdue_tasks'  => $this->plugin->get( TaskRepository::class )->count( array_merge_recursive( TaskRepository::overdue_args(), array( 'where' => array( 'lead_id' => $model->id() ) ) ) ),
			)
		);
	}

	/**
	 * Bulk "Assign to…" for users who can edit others' leads.
	 *
	 * {@inheritDoc}
	 */
	public function extra_bulk_actions(): array {
		return current_user_can( $this->cap( 'edit_others' ) )
			? array( 'bulk_assign' => __( 'Assign to…', 'wp-leadflow-crm' ) )
			: array();
	}

	/**
	 * {@inheritDoc}
	 */
	protected function handle_extra_bulk( string $action, array $ids ): string {
		if ( 'bulk_assign' !== $action || ! current_user_can( $this->cap( 'edit_others' ) ) ) {
			return '';
		}

		$user = Input::int( 'assign_to' );

		if ( ! isset( Users::crm_users()[ $user ] ) ) {
			return __( 'Choose a team member to assign the selected leads to.', 'wp-leadflow-crm' );
		}

		$done = 0;

		foreach ( $ids as $id ) {
			if ( current_user_can( $this->meta_cap( 'edit' ), $id ) && null !== $this->repository()->find( $id ) ) {
				$this->repository()->update( $id, array( 'owner_id' => $user ) );
				++$done;
			}
		}

		return sprintf(
			/* translators: 1: Number of leads, 2: User name. */
			_n( '%1$d lead assigned to %2$s.', '%1$d leads assigned to %2$s.', $done, 'wp-leadflow-crm' ),
			$done,
			Format::user( $user )
		);
	}

	/**
	 * Contacts for pickers: the first N by last name, plus the selected one.
	 *
	 * @param int $include Contact id that must be present.
	 * @return array<int, string> Id => name.
	 */
	public function contact_options( int $include = 0 ): array {
		$contacts = $this->plugin->get( ContactRepository::class );
		$options  = array();

		foreach ( $contacts->query(
			array(
				'orderby'  => 'last_name',
				'order'    => 'ASC',
				'per_page' => self::OPTIONS_LIMIT,
			)
		) as $contact ) {
			$options[ $contact->id() ] = $contact->full_name();
		}

		if ( $include > 0 && ! isset( $options[ $include ] ) ) {
			$current = $contacts->find( $include, true );

			if ( null !== $current ) {
				$options[ $include ] = $current->full_name();
			}
		}

		return $options;
	}
}
