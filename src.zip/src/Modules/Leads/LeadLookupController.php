<?php
/**
 * Lead lookup REST endpoint.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Leads;

use LeadFlow\CRM\Data\Models\Lead;
use LeadFlow\CRM\Data\Repositories\LeadRepository;
use LeadFlow\CRM\Rest\Controller;

defined( 'ABSPATH' ) || exit;

/**
 * GET /wp-json/leadflow-crm/v1/lookup/leads?search=website&per_page=20
 *
 * Id/name search used by lead pickers (open leads first).
 */
final class LeadLookupController extends Controller {

	/**
	 * Constructor.
	 *
	 * @param LeadRepository $leads Leads.
	 */
	public function __construct( private LeadRepository $leads ) {}

	/**
	 * {@inheritDoc}
	 */
	public function register_routes(): void {
		register_rest_route(
			self::REST_NAMESPACE,
			'/lookup/leads',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'search' ),
					'permission_callback' => $this->require_capability( 'leadflow_view_leads' ),
					'args'                => array(
						'search'   => array(
							'type'              => 'string',
							'default'           => '',
							'sanitize_callback' => 'sanitize_text_field',
						),
						'per_page' => array(
							'type'    => 'integer',
							'default' => 20,
							'minimum' => 1,
							'maximum' => 50,
						),
					),
				),
			)
		);
	}

	/**
	 * Returns matching leads.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public function search( \WP_REST_Request $request ): \WP_REST_Response {
		$leads = $this->leads->query(
			array(
				'search'   => (string) $request->get_param( 'search' ),
				'orderby'  => 'title',
				'order'    => 'ASC',
				'per_page' => (int) $request->get_param( 'per_page' ),
			)
		);

		usort( $leads, static fn( Lead $a, Lead $b ): int => (int) ! $a->is_open() <=> (int) ! $b->is_open() );

		return rest_ensure_response(
			array_map(
				static fn( Lead $lead ): array => array(
					'id'     => $lead->id(),
					'name'   => $lead->title(),
					'status' => (string) $lead->get( 'status' ),
				),
				$leads
			)
		);
	}
}
