<?php
/**
 * Pipeline stage configuration (Settings → Pipeline).
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Leads;

use LeadFlow\CRM\Admin\Menu;
use LeadFlow\CRM\Admin\Notices;
use LeadFlow\CRM\Admin\View;
use LeadFlow\CRM\Data\Models\Stage;
use LeadFlow\CRM\Data\Repositories\StageRepository;
use LeadFlow\CRM\Data\ValidationException;
use LeadFlow\CRM\Modules\Settings\SettingsModule;
use LeadFlow\CRM\Security\Guard;
use LeadFlow\CRM\Security\Nonce;
use LeadFlow\CRM\Settings\Registry;

defined( 'ABSPATH' ) || exit;

/**
 * Add, rename, recolor, reorder and delete pipeline stages.
 *
 * One form, one handler: all changes are validated first and applied in a
 * single transaction (see StageRepository::apply_configuration()).
 */
final class StagesAdmin {

	/** Capability. */
	public const CAPABILITY = 'leadflow_manage_pipeline';

	/**
	 * Constructor.
	 *
	 * @param StageRepository $stages Stages.
	 */
	public function __construct( private StageRepository $stages ) {}

	/**
	 * Registers the settings tab and the save handler.
	 *
	 * @param Registry $registry Settings registry.
	 * @return void
	 */
	public function register( Registry $registry ): void {
		$registry->add_tab( 'pipeline', __( 'Pipeline', 'wp-leadflow-crm' ), 20, array( $this, 'render' ) );
		add_action( 'admin_post_leadflow_crm_save_stages', array( $this, 'handle_save' ) );
	}

	/**
	 * Settings tab URL.
	 *
	 * @return string
	 */
	public static function url(): string {
		return Menu::url( SettingsModule::PAGE_SLUG, array( 'tab' => 'pipeline' ) );
	}

	/**
	 * Renders the stage editor.
	 *
	 * @return void
	 */
	public function render(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			echo '<p>' . esc_html__( 'You are not allowed to change the pipeline.', 'wp-leadflow-crm' ) . '</p>';
			return;
		}

		View::render(
			'admin/leads/stages',
			array(
				'stages' => $this->stages->all(),
				'counts' => $this->stages->lead_counts(),
				'types'  => self::type_labels(),
			)
		);
	}

	/**
	 * Stage type labels.
	 *
	 * @return array<string, string>
	 */
	public static function type_labels(): array {
		return array(
			'open' => __( 'Open', 'wp-leadflow-crm' ),
			'won'  => __( 'Won', 'wp-leadflow-crm' ),
			'lost' => __( 'Lost', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * Saves the whole stage configuration.
	 *
	 * @return void
	 */
	public function handle_save(): void {
		check_admin_referer( Nonce::action( 'save_stages' ), Nonce::FIELD );
		Guard::authorize( self::CAPABILITY );

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified above.
		$posted   = isset( $_POST['stages'] ) && is_array( $_POST['stages'] ) ? wp_unslash( $_POST['stages'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized per field below.
		$order    = isset( $_POST['order'] ) && is_array( $_POST['order'] ) ? array_map( 'absint', wp_unslash( $_POST['order'] ) ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$deletes  = isset( $_POST['delete'] ) && is_array( $_POST['delete'] ) ? array_map( 'absint', array_keys( wp_unslash( $_POST['delete'] ) ) ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$reassign = isset( $_POST['reassign'] ) && is_array( $_POST['reassign'] ) ? wp_unslash( $_POST['reassign'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$new      = isset( $_POST['new'] ) && is_array( $_POST['new'] ) ? wp_unslash( $_POST['new'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$move     = isset( $_POST['move'] ) ? sanitize_text_field( wp_unslash( $_POST['move'] ) ) : '';
		// phpcs:enable

		$rows = array();

		foreach ( $posted as $id => $row ) {
			if ( is_array( $row ) ) {
				$rows[ absint( $id ) ] = $this->sanitize_row( $row );
			}
		}

		$order = $this->apply_move( array_values( array_filter( $order ) ), $move );

		$delete_map = array();

		foreach ( $deletes as $id ) {
			$delete_map[ $id ] = sanitize_title( (string) ( $reassign[ $id ] ?? '' ) );
		}

		$new_rows = array();

		foreach ( $new as $row ) {
			if ( is_array( $row ) && '' !== trim( (string) ( $row['name'] ?? '' ) ) ) {
				$new_rows[] = $this->sanitize_row( $row );
			}
		}

		try {
			$this->stages->apply_configuration( $rows, $order, $new_rows, $delete_map );
			Notices::flash( 'success', __( 'Pipeline saved.', 'wp-leadflow-crm' ) );
		} catch ( ValidationException $e ) {
			Notices::flash( 'error', implode( ' ', $e->errors() ) );
		}

		wp_safe_redirect( self::url() );
		exit;
	}

	/**
	 * Keeps the editable fields of a posted row (validated by the repository).
	 *
	 * @param array<string, mixed> $row Posted row.
	 * @return array<string, mixed>
	 */
	private function sanitize_row( array $row ): array {
		return array(
			'name'        => sanitize_text_field( (string) ( $row['name'] ?? '' ) ),
			'color'       => sanitize_text_field( (string) ( $row['color'] ?? '' ) ),
			'probability' => sanitize_text_field( (string) ( $row['probability'] ?? '' ) ),
			'type'        => in_array( $row['type'] ?? '', Stage::TYPES, true ) ? $row['type'] : 'open',
		);
	}

	/**
	 * Applies a "move up/down" button ("{id}:up" or "{id}:down").
	 *
	 * @param int[]  $order Current order.
	 * @param string $move  Button value.
	 * @return int[]
	 */
	private function apply_move( array $order, string $move ): array {
		if ( 1 !== preg_match( '/^(\d+):(up|down)$/', $move, $m ) ) {
			return $order;
		}

		$index = array_search( (int) $m[1], $order, true );

		if ( false === $index ) {
			return $order;
		}

		$swap = 'up' === $m[2] ? $index - 1 : $index + 1;

		if ( $swap < 0 || $swap >= count( $order ) ) {
			return $order;
		}

		list( $order[ $index ], $order[ $swap ] ) = array( $order[ $swap ], $order[ $index ] );

		return $order;
	}
}
