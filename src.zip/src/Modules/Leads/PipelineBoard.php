<?php
/**
 * Visual sales pipeline (Kanban board).
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Leads;

use LeadFlow\CRM\Admin\Menu;
use LeadFlow\CRM\Admin\Notices;
use LeadFlow\CRM\Admin\Page;
use LeadFlow\CRM\Admin\View;
use LeadFlow\CRM\Data\Models\Lead;
use LeadFlow\CRM\Data\RecordNotFoundException;
use LeadFlow\CRM\Data\Relations;
use LeadFlow\CRM\Data\Repositories\LeadRepository;
use LeadFlow\CRM\Data\ValidationException;
use LeadFlow\CRM\Plugin;
use LeadFlow\CRM\Security\Guard;
use LeadFlow\CRM\Security\Input;
use LeadFlow\CRM\Security\Nonce;
use LeadFlow\CRM\Support\Format;
use LeadFlow\CRM\Support\Users;

defined( 'ABSPATH' ) || exit;

/**
 * Board screen plus the stage-change and assignment actions.
 *
 * Moves are sent with AJAX (admin-ajax.php?action=leadflow_crm_move_lead);
 * the same move is available as a plain form POST for no-JS use and for
 * the stage bar on the lead screen.
 */
final class PipelineBoard {

	/** Page slug. */
	public const PAGE_SLUG = 'leadflow-crm-pipeline';

	/** Cards rendered per column. */
	public const CARDS_PER_STAGE = 100;

	/**
	 * Constructor.
	 *
	 * @param Plugin     $plugin Plugin.
	 * @param LeadsAdmin $leads  Leads admin controller.
	 */
	public function __construct(
		private Plugin $plugin,
		private LeadsAdmin $leads
	) {}

	/**
	 * Registers hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'wp_ajax_leadflow_crm_move_lead', array( $this, 'ajax_move' ) );
		add_action( 'admin_post_leadflow_crm_move_lead', array( $this, 'handle_move' ) );
		add_action( 'admin_post_leadflow_crm_assign_lead', array( $this, 'handle_assign' ) );
	}

	/**
	 * Admin page definition.
	 *
	 * @return Page
	 */
	public function page(): Page {
		return new Page(
			self::PAGE_SLUG,
			__( 'Sales pipeline', 'wp-leadflow-crm' ),
			__( 'Pipeline', 'wp-leadflow-crm' ),
			$this->leads->cap( 'view' ),
			array( $this, 'render' ),
			15
		);
	}

	/**
	 * Board URL.
	 *
	 * @param array<string, mixed> $args Query args.
	 * @return string
	 */
	public static function url( array $args = array() ): string {
		return Menu::url( self::PAGE_SLUG, $args );
	}

	/**
	 * Filters applied to the board (and to totals returned by AJAX).
	 *
	 * @param string $source get|post.
	 * @return array<string, mixed> Repository query arguments.
	 */
	private function filter_args( string $source = 'get' ): array {
		$where = array();
		$owner = Input::int( 'owner', $source );

		if ( $owner > 0 ) {
			$where['owner_id'] = $owner;
		}

		return array(
			'where'  => $where,
			'search' => Input::text( 's', $source ),
		);
	}

	/**
	 * Renders the board.
	 *
	 * @return void
	 */
	public function render(): void {
		Guard::authorize( $this->leads->cap( 'view' ) );

		/** @var LeadRepository $repository */
		$repository = $this->leads->repository();
		$filters    = $this->filter_args();
		$columns    = array();
		$all_leads  = array();

		foreach ( $this->leads->stages()->all() as $stage ) {
			$args                   = $filters;
			$args['where']['stage'] = $stage->slug();

			$cards = $repository->query(
				array_merge(
					$args,
					array(
						'orderby'  => 'position',
						'order'    => 'ASC',
						'per_page' => self::CARDS_PER_STAGE,
					)
				)
			);

			$columns[]  = array(
				'stage' => $stage,
				'cards' => $cards,
			);
			$all_leads = array_merge( $all_leads, $cards );
		}

		$relations = $this->plugin->get( Relations::class );

		View::render(
			'admin/leads/board',
			array(
				'admin'     => $this->leads,
				'columns'   => $columns,
				'totals'    => $repository->stage_totals( $filters ),
				'companies' => $relations->companies_for( $all_leads ),
				'users'     => Users::crm_users(),
				'filters'   => array(
					's'     => Input::text( 's' ),
					'owner' => Input::int( 'owner' ),
				),
				'nonce'     => Nonce::create( 'move_lead' ),
			)
		);
	}

	/**
	 * AJAX: moves a lead to another stage / position.
	 *
	 * POST: lead_id, stage, before_id (optional), _leadflow_nonce, plus the
	 * board filters (s, owner) so updated column totals match the view.
	 *
	 * @return void
	 */
	public function ajax_move(): void {
		Guard::verify_ajax( 'move_lead', $this->leads->cap( 'view' ) );

		$id     = Input::int( 'lead_id', 'post' );
		$stage  = Input::key( 'stage', 'post' );
		$before = Input::int( 'before_id', 'post' );

		if ( ! current_user_can( $this->leads->meta_cap( 'edit' ), $id ) ) {
			wp_send_json_error( array( 'message' => __( 'You are not allowed to move this lead.', 'wp-leadflow-crm' ) ), 403 );
		}

		try {
			$lead = $this->repository()->move( $id, $stage, $before > 0 ? $before : null );
		} catch ( ValidationException $e ) {
			wp_send_json_error( array( 'message' => implode( ' ', $e->errors() ) ), 400 );
		} catch ( RecordNotFoundException $e ) {
			wp_send_json_error( array( 'message' => __( 'This lead no longer exists. Please reload the page.', 'wp-leadflow-crm' ) ), 404 );
		}

		$stage_model = $this->leads->stages()->find_by_slug( (string) $lead->get( 'stage' ) );
		$raw_totals  = $this->repository()->stage_totals( $this->filter_args( 'post' ) );
		$totals      = array();

		// Every stage is returned so emptied columns reset to zero.
		foreach ( $this->leads->stages()->all() as $stage ) {
			$total = $raw_totals[ $stage->slug() ] ?? array(
				'count'   => 0,
				'amounts' => array(),
			);

			$totals[ $stage->slug() ] = array(
				'count' => $total['count'],
				'value' => Format::money_list( $total['amounts'] ),
			);
		}

		wp_send_json_success(
			array(
				'lead'    => array(
					'id'          => $lead->id(),
					'stage'       => (string) $lead->get( 'stage' ),
					'status'      => (string) $lead->get( 'status' ),
					'probability' => $lead->get( 'probability' ),
				),
				'totals'  => $totals,
				'message' => sprintf(
					/* translators: 1: Lead name, 2: Stage name. */
					__( 'Moved “%1$s” to %2$s.', 'wp-leadflow-crm' ),
					$lead->title(),
					null !== $stage_model ? $stage_model->name() : $stage
				),
			)
		);
	}

	/**
	 * Form POST: moves a lead (no-JS board, stage bar on the lead screen).
	 *
	 * @return void
	 */
	public function handle_move(): void {
		$id = Input::int( 'lead_id', 'post' );

		check_admin_referer( Nonce::action( 'move_lead_' . $id ), Nonce::FIELD );
		Guard::authorize( $this->leads->meta_cap( 'edit' ), $id );

		try {
			$lead  = $this->repository()->move( $id, Input::key( 'stage', 'post' ) );
			$stage = $this->leads->stages()->find_by_slug( (string) $lead->get( 'stage' ) );
			Notices::flash(
				'success',
				sprintf(
					/* translators: %s: Stage name. */
					__( 'Lead moved to %s.', 'wp-leadflow-crm' ),
					null !== $stage ? $stage->name() : ''
				)
			);
		} catch ( ValidationException | RecordNotFoundException $e ) {
			Notices::flash( 'error', __( 'The lead could not be moved. Please try again.', 'wp-leadflow-crm' ) );
		}

		$this->back( $this->leads->view_url( $id ) );
	}

	/**
	 * Form POST: assigns a lead to a team member (or unassigns it).
	 *
	 * @return void
	 */
	public function handle_assign(): void {
		$id = Input::int( 'lead_id', 'post' );

		check_admin_referer( Nonce::action( 'assign_lead_' . $id ), Nonce::FIELD );
		Guard::authorize( $this->leads->cap( 'edit_others' ) );
		Guard::authorize( $this->leads->meta_cap( 'edit' ), $id );

		$user = Input::int( 'owner_id', 'post' );

		if ( 0 !== $user && ! isset( Users::crm_users()[ $user ] ) ) {
			Notices::flash( 'error', __( 'Choose a team member with CRM access.', 'wp-leadflow-crm' ) );
			$this->back( $this->leads->view_url( $id ) );
		}

		$this->repository()->update( $id, array( 'owner_id' => 0 === $user ? null : $user ) );

		Notices::flash(
			'success',
			0 === $user
				? __( 'Lead unassigned.', 'wp-leadflow-crm' )
				/* translators: %s: User name. */
				: sprintf( __( 'Lead assigned to %s.', 'wp-leadflow-crm' ), Format::user( $user ) )
		);

		$this->back( $this->leads->view_url( $id ) );
	}

	/**
	 * Lead repository.
	 *
	 * @return LeadRepository
	 */
	private function repository(): LeadRepository {
		/** @var LeadRepository $repository */
		$repository = $this->leads->repository();

		return $repository;
	}

	/**
	 * Redirects to the referring screen (or a fallback).
	 *
	 * @param string $fallback Fallback URL.
	 * @return void
	 */
	private function back( string $fallback ): void {
		$referer = wp_get_referer();

		wp_safe_redirect( false !== $referer ? $referer : $fallback );
		exit;
	}
}
