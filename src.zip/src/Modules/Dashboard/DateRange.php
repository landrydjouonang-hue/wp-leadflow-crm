<?php
/**
 * Dashboard date range.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Dashboard;

use LeadFlow\CRM\Security\Input;

defined( 'ABSPATH' ) || exit;

/**
 * An inclusive range of calendar days in the site timezone, with its UTC
 * bounds for queries (start inclusive, end exclusive).
 *
 * Built from `?range=` (a preset) or `?range=custom&from=Y-m-d&to=Y-m-d`.
 * Invalid input falls back to the default preset; reversed dates are
 * swapped; ranges are limited to MAX_DAYS.
 */
final class DateRange {

	/** Default preset. */
	public const DEFAULT_PRESET = 'last_30_days';

	/** Longest allowed range. */
	public const MAX_DAYS = 1830;

	/**
	 * Constructor.
	 *
	 * @param \DateTimeImmutable $from   First day (00:00, site timezone).
	 * @param \DateTimeImmutable $to     Last day (00:00, site timezone).
	 * @param string             $preset Preset key or "custom".
	 */
	private function __construct(
		private \DateTimeImmutable $from,
		private \DateTimeImmutable $to,
		private string $preset
	) {}

	/**
	 * Preset keys and labels.
	 *
	 * @return array<string, string>
	 */
	public static function presets(): array {
		return array(
			'last_7_days'    => __( 'Last 7 days', 'wp-leadflow-crm' ),
			'last_30_days'   => __( 'Last 30 days', 'wp-leadflow-crm' ),
			'last_90_days'   => __( 'Last 90 days', 'wp-leadflow-crm' ),
			'this_month'     => __( 'This month', 'wp-leadflow-crm' ),
			'last_month'     => __( 'Last month', 'wp-leadflow-crm' ),
			'this_quarter'   => __( 'This quarter', 'wp-leadflow-crm' ),
			'this_year'      => __( 'This year', 'wp-leadflow-crm' ),
			'last_12_months' => __( 'Last 12 months', 'wp-leadflow-crm' ),
			'custom'         => __( 'Custom range', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * Range from the current request.
	 *
	 * @return self
	 */
	public static function from_request(): self {
		$preset = Input::one_of( 'range', array_keys( self::presets() ), self::DEFAULT_PRESET );

		if ( 'custom' === $preset ) {
			$from = self::parse( Input::text( 'from' ) );
			$to   = self::parse( Input::text( 'to' ) );

			if ( null !== $from && null !== $to ) {
				return self::custom( $from, $to );
			}

			$preset = self::DEFAULT_PRESET;
		}

		return self::preset( $preset );
	}

	/**
	 * Range for a preset, relative to today.
	 *
	 * @param string                  $preset Preset key.
	 * @param \DateTimeImmutable|null $today  Today (site timezone), for tests.
	 * @return self
	 */
	public static function preset( string $preset, ?\DateTimeImmutable $today = null ): self {
		$today = ( $today ?? new \DateTimeImmutable( 'now', wp_timezone() ) )->setTime( 0, 0 );
		$month = $today->modify( 'first day of this month' );

		switch ( $preset ) {
			case 'last_7_days':
				return new self( $today->modify( '-6 days' ), $today, $preset );
			case 'last_90_days':
				return new self( $today->modify( '-89 days' ), $today, $preset );
			case 'this_month':
				return new self( $month, $today, $preset );
			case 'last_month':
				return new self( $month->modify( '-1 month' ), $month->modify( '-1 day' ), $preset );
			case 'this_quarter':
				$quarter = (int) floor( ( (int) $today->format( 'n' ) - 1 ) / 3 ) * 3 + 1;
				return new self( $today->setDate( (int) $today->format( 'Y' ), $quarter, 1 ), $today, $preset );
			case 'this_year':
				return new self( $today->setDate( (int) $today->format( 'Y' ), 1, 1 ), $today, $preset );
			case 'last_12_months':
				return new self( $month->modify( '-11 months' ), $today, $preset );
			default:
				return new self( $today->modify( '-29 days' ), $today, 'last_30_days' );
		}
	}

	/**
	 * Custom range (swapped when reversed, shortened to MAX_DAYS).
	 *
	 * @param \DateTimeImmutable $from First day.
	 * @param \DateTimeImmutable $to   Last day.
	 * @return self
	 */
	public static function custom( \DateTimeImmutable $from, \DateTimeImmutable $to ): self {
		if ( $from > $to ) {
			list( $from, $to ) = array( $to, $from );
		}

		if ( (int) $from->diff( $to )->days >= self::MAX_DAYS ) {
			$from = $to->modify( '-' . ( self::MAX_DAYS - 1 ) . ' days' );
		}

		return new self( $from, $to, 'custom' );
	}

	/**
	 * Parses Y-m-d in the site timezone (strict; null when invalid).
	 *
	 * @param string $value Date.
	 * @return \DateTimeImmutable|null
	 */
	public static function parse( string $value ): ?\DateTimeImmutable {
		$date = \DateTimeImmutable::createFromFormat( '!Y-m-d', $value, wp_timezone() );

		if ( false === $date || $date->format( 'Y-m-d' ) !== $value || (int) $date->format( 'Y' ) < 2000 || (int) $date->format( 'Y' ) > 2100 ) {
			return null;
		}

		return $date;
	}

	/**
	 * Preset key or "custom".
	 *
	 * @return string
	 */
	public function key(): string {
		return $this->preset;
	}

	/**
	 * First day, Y-m-d.
	 *
	 * @return string
	 */
	public function from(): string {
		return $this->from->format( 'Y-m-d' );
	}

	/**
	 * Last day, Y-m-d.
	 *
	 * @return string
	 */
	public function to(): string {
		return $this->to->format( 'Y-m-d' );
	}

	/**
	 * Number of days (inclusive).
	 *
	 * @return int
	 */
	public function days(): int {
		return (int) $this->from->diff( $this->to )->days + 1;
	}

	/**
	 * UTC start (inclusive), MySQL format.
	 *
	 * @return string
	 */
	public function start_utc(): string {
		return self::utc( $this->from );
	}

	/**
	 * UTC end (exclusive: the day after the last day), MySQL format.
	 *
	 * @return string
	 */
	public function end_utc(): string {
		return self::utc( $this->to->modify( '+1 day' ) );
	}

	/**
	 * The range of equal length just before this one (for trends).
	 *
	 * @return self
	 */
	public function previous(): self {
		$days = $this->days();

		return new self( $this->from->modify( "-{$days} days" ), $this->from->modify( '-1 day' ), 'custom' );
	}

	/**
	 * Month buckets covering the range, at least $minimum months ending
	 * with the range's last month.
	 *
	 * @param int $minimum Minimum number of months.
	 * @return array<int, array{key: string, label: string, start: string, end: string}> UTC bounds.
	 */
	public function months( int $minimum = 6 ): array {
		$last  = $this->to->modify( 'first day of this month' );
		$first = $this->from->modify( 'first day of this month' );
		$count = ( (int) $last->format( 'Y' ) - (int) $first->format( 'Y' ) ) * 12 + (int) $last->format( 'n' ) - (int) $first->format( 'n' ) + 1;

		if ( $count < $minimum ) {
			$first = $last->modify( '-' . ( $minimum - 1 ) . ' months' );
		}

		$months = array();

		for ( $month = $first; $month <= $last; $month = $month->modify( '+1 month' ) ) {
			$months[] = array(
				'key'   => $month->format( 'Y-m' ),
				'label' => (string) wp_date( 'M Y', $month->getTimestamp() ),
				'start' => self::utc( $month ),
				'end'   => self::utc( $month->modify( '+1 month' ) ),
			);
		}

		return $months;
	}

	/**
	 * Human label, e.g. "Aug 24, 2026 – Sep 22, 2026".
	 *
	 * @return string
	 */
	public function label(): string {
		$format = (string) get_option( 'date_format' );

		return sprintf(
			/* translators: 1: Start date, 2: End date. */
			__( '%1$s – %2$s', 'wp-leadflow-crm' ),
			wp_date( $format, $this->from->getTimestamp() ),
			wp_date( $format, $this->to->getTimestamp() )
		);
	}

	/**
	 * Query args that reproduce this range.
	 *
	 * @return array<string, string>
	 */
	public function query_args(): array {
		return 'custom' === $this->preset
			? array(
				'range' => 'custom',
				'from'  => $this->from(),
				'to'    => $this->to(),
			)
			: array( 'range' => $this->preset );
	}

	/**
	 * Local midnight → UTC MySQL datetime.
	 *
	 * @param \DateTimeImmutable $local Local date-time.
	 * @return string
	 */
	private static function utc( \DateTimeImmutable $local ): string {
		return $local->setTimezone( new \DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
	}
}
