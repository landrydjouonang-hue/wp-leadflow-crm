<?php
/**
 * Dashboard module.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Dashboard;

use LeadFlow\CRM\Admin\Assets;
use LeadFlow\CRM\Admin\Menu;
use LeadFlow\CRM\Admin\Page;
use LeadFlow\CRM\Admin\View;
use LeadFlow\CRM\Contracts\Module;
use LeadFlow\CRM\Data\Analytics;
use LeadFlow\CRM\Modules\Settings\SettingsModule;
use LeadFlow\CRM\Plugin;
use LeadFlow\CRM\Security\Capabilities;
use LeadFlow\CRM\Security\Guard;
use LeadFlow\CRM\Security\Input;
use LeadFlow\CRM\Support\Users;

defined( 'ABSPATH' ) || exit;

/**
 * The CRM landing page: analytics (KPIs + charts, filtered by period and
 * owner) followed by the work widgets registered by modules.
 *
 * Analytics need `leadflow_view_leads`. Everyone who can see leads may
 * switch between "Everyone" and "Only me"; users who can edit others'
 * leads may also pick any CRM user.
 */
final class DashboardModule implements Module {

	/** Chart script handle. */
	public const CHARTS_HANDLE = 'leadflow-crm-charts';

	/**
	 * Plugin.
	 *
	 * @var Plugin|null
	 */
	private ?Plugin $plugin = null;

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'dashboard';
	}

	/**
	 * {@inheritDoc}
	 */
	public function boot( Plugin $plugin ): void {
		$this->plugin = $plugin;

		$plugin->get( Menu::class )->add(
			new Page(
				Menu::SLUG,
				__( 'CRM Dashboard', 'wp-leadflow-crm' ),
				__( 'Dashboard', 'wp-leadflow-crm' ),
				Capabilities::ACCESS_CRM,
				array( $this, 'render' ),
				0,
				array( $this, 'load' )
			)
		);
	}

	/**
	 * `load-{page}`: chart assets for this screen only.
	 *
	 * @return void
	 */
	public function load(): void {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ), 20 );
	}

	/**
	 * Enqueues the chart renderer (no third-party library).
	 *
	 * @return void
	 */
	public function enqueue(): void {
		$file = LEADFLOW_CRM_PATH . 'assets/js/charts.js';

		wp_enqueue_script(
			self::CHARTS_HANDLE,
			LEADFLOW_CRM_URL . 'assets/js/charts.js',
			array( 'wp-i18n', Assets::HANDLE ),
			defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG && is_readable( $file ) ? (string) filemtime( $file ) : LEADFLOW_CRM_VERSION,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);

		wp_set_script_translations( self::CHARTS_HANDLE, 'wp-leadflow-crm', LEADFLOW_CRM_PATH . 'languages' );
	}

	/**
	 * Renders the dashboard.
	 *
	 * @return void
	 */
	public function render(): void {
		Guard::authorize( Capabilities::ACCESS_CRM );

		$sections = new Sections();
		$this->add_placeholders( $sections );

		/**
		 * Lets modules add or replace dashboard sections.
		 *
		 * @param Sections $sections Section registry.
		 */
		do_action( 'leadflow_crm_dashboard_sections', $sections );

		$user      = wp_get_current_user();
		$analytics = current_user_can( 'leadflow_view_leads' );
		$range     = DateRange::from_request();
		$owner     = $analytics ? $this->owner_filter() : array( 'all', null );

		View::render(
			'admin/dashboard',
			array(
				'user_name'    => $user->display_name,
				'sections'     => $sections->visible(),
				'settings_url' => current_user_can( Capabilities::MANAGE_SETTINGS ) ? Menu::url( SettingsModule::PAGE_SLUG ) : '',
				'analytics'    => $analytics,
				'range'        => $range,
				'owner'        => $owner[0],
				'owners'       => $analytics ? $this->owner_options() : array(),
				'report'       => $analytics ? $this->report()->build( $range, $owner[1] ) : null,
			)
		);
	}

	/**
	 * Analytics service.
	 *
	 * @return AnalyticsReport
	 */
	public function report(): AnalyticsReport {
		return new AnalyticsReport( $this->plugin ?? Plugin::instance(), new Analytics() );
	}

	/**
	 * Owner filter from `?owner=` (all | me | user id).
	 *
	 * @return array{0: string, 1: int|null} Selected value, user id (null = everyone).
	 */
	public function owner_filter(): array {
		$value = Input::key( 'owner', 'get', 'all' );

		if ( 'me' === $value ) {
			return array( 'me', get_current_user_id() );
		}

		$id = (int) $value;

		if ( $id > 0 && current_user_can( 'leadflow_edit_others_leads' ) && isset( Users::crm_users()[ $id ] ) ) {
			return array( (string) $id, $id );
		}

		return array( 'all', null );
	}

	/**
	 * Owner filter options.
	 *
	 * @return array<string, string>
	 */
	private function owner_options(): array {
		$options = array(
			'all' => __( 'Everyone', 'wp-leadflow-crm' ),
			'me'  => __( 'Only me', 'wp-leadflow-crm' ),
		);

		if ( current_user_can( 'leadflow_edit_others_leads' ) ) {
			foreach ( Users::crm_users() as $id => $name ) {
				if ( get_current_user_id() !== $id ) {
					$options[ (string) $id ] = $name;
				}
			}
		}

		return $options;
	}

	/**
	 * Placeholder sections for modules that are not built yet.
	 *
	 * @param Sections $sections Registry.
	 * @return void
	 */
	private function add_placeholders( Sections $sections ): void {
		$sections->add(
			'pipeline',
			array(
				'title'       => __( 'Sales pipeline', 'wp-leadflow-crm' ),
				'description' => __( 'See every open deal by stage and move it forward with drag and drop.', 'wp-leadflow-crm' ),
				'icon'        => 'chart-bar',
				'order'       => 10,
				'wide'        => true,
				'features'    => array(
					__( 'Customizable stages', 'wp-leadflow-crm' ),
					__( 'Deal value per stage', 'wp-leadflow-crm' ),
					__( 'Win/loss tracking', 'wp-leadflow-crm' ),
				),
			)
		);

		$sections->add(
			'leads',
			array(
				'title'       => __( 'Leads', 'wp-leadflow-crm' ),
				'description' => __( 'Capture, qualify and assign new business opportunities.', 'wp-leadflow-crm' ),
				'icon'        => 'id-alt',
				'order'       => 20,
				'features'    => array(
					__( 'Lead sources and owners', 'wp-leadflow-crm' ),
					__( 'Deal value and close dates', 'wp-leadflow-crm' ),
				),
			)
		);

		$sections->add(
			'companies',
			array(
				'title'       => __( 'Companies', 'wp-leadflow-crm' ),
				'description' => __( 'Keep organizations, their details and their people in one place.', 'wp-leadflow-crm' ),
				'icon'        => 'building',
				'order'       => 30,
				'features'    => array(
					__( 'Company profiles', 'wp-leadflow-crm' ),
					__( 'Linked contacts and deals', 'wp-leadflow-crm' ),
				),
			)
		);

		$sections->add(
			'contacts',
			array(
				'title'       => __( 'Contacts', 'wp-leadflow-crm' ),
				'description' => __( 'Manage the people you do business with.', 'wp-leadflow-crm' ),
				'icon'        => 'businessperson',
				'order'       => 40,
				'features'    => array(
					__( 'Contact details and history', 'wp-leadflow-crm' ),
					__( 'Search and filters', 'wp-leadflow-crm' ),
				),
			)
		);

		$sections->add(
			'tasks',
			array(
				'title'       => __( 'Tasks', 'wp-leadflow-crm' ),
				'description' => __( 'Plan the work that moves each deal forward.', 'wp-leadflow-crm' ),
				'icon'        => 'yes-alt',
				'order'       => 50,
				'features'    => array(
					__( 'Assignees and priorities', 'wp-leadflow-crm' ),
					__( 'Due dates and overdue alerts', 'wp-leadflow-crm' ),
				),
			)
		);

		$sections->add(
			'follow-ups',
			array(
				'title'       => __( 'Follow-ups', 'wp-leadflow-crm' ),
				'description' => __( 'Never miss the next call, email or meeting.', 'wp-leadflow-crm' ),
				'icon'        => 'calendar-alt',
				'order'       => 60,
				'features'    => array(
					__( 'Scheduled reminders', 'wp-leadflow-crm' ),
					__( 'Email notifications', 'wp-leadflow-crm' ),
				),
			)
		);

		$sections->add(
			'activities',
			array(
				'title'       => __( 'Activities', 'wp-leadflow-crm' ),
				'description' => __( 'A timeline of notes, calls, emails and changes across your CRM.', 'wp-leadflow-crm' ),
				'icon'        => 'backup',
				'order'       => 70,
				'wide'        => true,
				'features'    => array(
					__( 'Notes and call logs', 'wp-leadflow-crm' ),
					__( 'Automatic change history', 'wp-leadflow-crm' ),
					__( 'Customer communication log', 'wp-leadflow-crm' ),
				),
			)
		);
	}
}
