<?php
/**
 * Dashboard section registry.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Dashboard;

use LeadFlow\CRM\Security\Capabilities;

defined( 'ABSPATH' ) || exit;

/**
 * Sections shown on the CRM dashboard.
 *
 * Sections without a render callback are displayed as placeholders.
 * A module replaces its placeholder by adding a section with the same id
 * and a renderer, from the `leadflow_crm_dashboard_sections` action:
 *
 *     add_action( 'leadflow_crm_dashboard_sections', function ( Sections $sections ) {
 *         $sections->add( 'leads', array(
 *             'title'      => __( 'Leads', 'wp-leadflow-crm' ),
 *             'capability' => 'leadflow_view_leads',
 *             'render'     => array( $widget, 'render' ),
 *         ) );
 *     } );
 */
final class Sections {

	/**
	 * Sections keyed by id.
	 *
	 * @var array<string, array<string, mixed>>
	 */
	private array $sections = array();

	/**
	 * Adds or replaces a section.
	 *
	 * @param string               $id   Section id.
	 * @param array<string, mixed> $args {
	 *     Section definition.
	 *
	 *     @type string        $title       Heading.
	 *     @type string        $description Short description.
	 *     @type string        $icon        Dashicon name without the "dashicons-" prefix.
	 *     @type int           $order       Sort order.
	 *     @type bool          $wide        Span the full grid width.
	 *     @type string        $capability  Capability required to see it.
	 *     @type callable|null $render      Renderer; null shows a placeholder.
	 *     @type string[]      $features    Planned features listed in the placeholder.
	 * }
	 * @return void
	 */
	public function add( string $id, array $args ): void {
		$id = sanitize_key( $id );

		$this->sections[ $id ] = wp_parse_args(
			$args,
			array(
				'id'          => $id,
				'title'       => $id,
				'description' => '',
				'icon'        => 'admin-generic',
				'order'       => 50,
				'wide'        => false,
				'capability'  => Capabilities::ACCESS_CRM,
				'render'      => null,
				'features'    => array(),
			)
		);

		$this->sections[ $id ]['id'] = $id;
	}

	/**
	 * Removes a section.
	 *
	 * @param string $id Section id.
	 * @return void
	 */
	public function remove( string $id ): void {
		unset( $this->sections[ $id ] );
	}

	/**
	 * Sections visible to the current user, sorted.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public function visible(): array {
		$sections = array_filter(
			$this->sections,
			static fn( array $section ): bool => current_user_can( (string) $section['capability'] )
		);

		uasort( $sections, static fn( array $a, array $b ): int => (int) $a['order'] <=> (int) $b['order'] );

		return $sections;
	}
}
