<?php
/**
 * Dashboard analytics.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Dashboard;

use LeadFlow\CRM\Admin\Menu;
use LeadFlow\CRM\Data\Analytics;
use LeadFlow\CRM\Data\Models\Stage;
use LeadFlow\CRM\Data\Repositories\StageRepository;
use LeadFlow\CRM\Database\Schema;
use LeadFlow\CRM\Modules\Leads\PipelineBoard;
use LeadFlow\CRM\Plugin;
use LeadFlow\CRM\Settings\Settings;
use LeadFlow\CRM\Support\Format;

defined( 'ABSPATH' ) || exit;

/**
 * Turns aggregates into KPI cards and chart data for a date range and an
 * optional owner.
 *
 * Definitions (also shown in the UI):
 * - Total leads: every lead in the CRM (not trashed).
 * - New leads: leads created in the period.
 * - Qualified leads: leads created in the period that are now at or beyond
 *   the qualification stage, or won.
 * - Won / Lost leads: leads closed in the period.
 * - Pipeline value: value of all open leads now (weighted by probability
 *   in the subtitle).
 * - Conversion rate: won ÷ (won + lost) in the period.
 * - Open / overdue tasks and upcoming follow-ups (next 7 days): right now.
 *
 * Results are cached in the object cache for 5 minutes and invalidated as
 * soon as leads, stages, tasks or follow-ups change.
 */
final class AnalyticsReport {

	/** Object-cache group. */
	private const CACHE_GROUP = 'leadflow_crm_analytics';

	/** Days counted as "upcoming" for follow-ups. */
	public const UPCOMING_DAYS = 7;

	/** Sources shown individually before "Other". */
	private const MAX_SOURCES = 7;

	/**
	 * Constructor.
	 *
	 * @param Plugin    $plugin    Plugin.
	 * @param Analytics $analytics Aggregate queries.
	 */
	public function __construct( private Plugin $plugin, private Analytics $analytics ) {}

	/**
	 * KPI cards and charts.
	 *
	 * @param DateRange $range Period.
	 * @param int|null  $owner Owner / assignee filter (null = everyone).
	 * @return array{kpis: array<string, array<string, mixed>>, charts: array<string, array<string, mixed>>, currency: string}
	 */
	public function build( DateRange $range, ?int $owner ): array {
		$now = current_time( 'mysql', true );
		$key = md5(
			(string) wp_json_encode(
				array(
					$range->start_utc(),
					$range->end_utc(),
					$owner,
					substr( $now, 0, 16 ),
					determine_locale(),
					wp_cache_get_last_changed( 'leadflow_crm_' . Schema::LEADS ),
					wp_cache_get_last_changed( 'leadflow_crm_' . Schema::PIPELINE_STAGES ),
					wp_cache_get_last_changed( 'leadflow_crm_' . Schema::TASKS ),
					wp_cache_get_last_changed( 'leadflow_crm_' . Schema::FOLLOW_UPS ),
				)
			)
		);

		$cached = wp_cache_get( $key, self::CACHE_GROUP );

		if ( is_array( $cached ) ) {
			return $cached;
		}

		$report = $this->compute( $range, $owner, $now );

		wp_cache_set( $key, $report, self::CACHE_GROUP, 5 * MINUTE_IN_SECONDS );

		return $report;
	}

	/**
	 * Runs the queries and shapes the result.
	 *
	 * @param DateRange $range Period.
	 * @param int|null  $owner Owner filter.
	 * @param string    $now   UTC now.
	 * @return array{kpis: array<string, array<string, mixed>>, charts: array<string, array<string, mixed>>, currency: string}
	 */
	private function compute( DateRange $range, ?int $owner, string $now ): array {
		$previous  = $range->previous();
		$stages    = $this->plugin->get( StageRepository::class )->all();
		$breakdown = $this->analytics->created_breakdown( $range->start_utc(), $range->end_utc(), $owner );
		$closed    = $this->summarize_closed( $this->analytics->closed( $range->start_utc(), $range->end_utc(), $owner ) );
		$closed_pv = $this->summarize_closed( $this->analytics->closed( $previous->start_utc(), $previous->end_utc(), $owner ) );
		$pipeline  = $this->analytics->open_pipeline( $owner );
		$tasks     = $this->analytics->tasks( $now, $owner );
		$follow    = $this->analytics->follow_ups( $now, gmdate( 'Y-m-d H:i:s', strtotime( $now . ' UTC' ) + self::UPCOMING_DAYS * DAY_IN_SECONDS ), $owner );
		$new       = array_sum( array_column( $breakdown, 'total' ) );
		$new_prev  = $this->analytics->count_created( $previous->start_utc(), $previous->end_utc(), $owner );
		$qualified = $this->count_qualified( $breakdown, $stages );
		$currency  = $this->primary_currency( $pipeline );

		$open_value  = array();
		$weighted    = array();
		$open_deals  = 0;

		foreach ( $pipeline as $row ) {
			$open_value[ $row['currency'] ] = ( $open_value[ $row['currency'] ] ?? 0 ) + $row['value'];
			$weighted[ $row['currency'] ]   = ( $weighted[ $row['currency'] ] ?? 0 ) + $row['weighted'];
			$open_deals                    += $row['total'];
		}

		$rate      = self::rate( $closed['won'], $closed['lost'] );
		$rate_prev = self::rate( $closed_pv['won'], $closed_pv['lost'] );
		$leads_url = fn( array $args = array() ): string => Menu::url( 'leadflow-crm-leads', null !== $owner ? array_merge( $args, array( 'owner' => $owner ) ) : $args );

		$kpis = array(
			'total_leads'  => array(
				'label' => __( 'Total leads', 'wp-leadflow-crm' ),
				'value' => number_format_i18n( $this->analytics->count_all( $owner ) ),
				'hint'  => __( 'All leads in the CRM', 'wp-leadflow-crm' ),
				'icon'  => 'id-alt',
				'url'   => $leads_url(),
			),
			'new_leads'    => array(
				'label' => __( 'New leads', 'wp-leadflow-crm' ),
				'value' => number_format_i18n( $new ),
				'hint'  => __( 'Created in the period', 'wp-leadflow-crm' ),
				'icon'  => 'plus-alt',
				'trend' => self::trend( $new, $new_prev ),
			),
			'qualified'    => array(
				'label' => __( 'Qualified leads', 'wp-leadflow-crm' ),
				'value' => number_format_i18n( $qualified ),
				'hint'  => $new > 0
					/* translators: %s: Percentage. */
					? sprintf( __( '%s of new leads', 'wp-leadflow-crm' ), number_format_i18n( $qualified / $new * 100 ) . '%' )
					: __( 'New leads that reached qualification', 'wp-leadflow-crm' ),
				'icon'  => 'star-filled',
			),
			'won'          => array(
				'label' => __( 'Won leads', 'wp-leadflow-crm' ),
				'value' => number_format_i18n( $closed['won'] ),
				'hint'  => empty( $closed['won_value'] ) ? __( 'Closed as won in the period', 'wp-leadflow-crm' ) : Format::money_list( $closed['won_value'] ),
				'icon'  => 'awards',
				'tone'  => 'ok',
				'trend' => self::trend( $closed['won'], $closed_pv['won'] ),
				'url'   => $leads_url( array( 'status' => 'won' ) ),
			),
			'lost'         => array(
				'label' => __( 'Lost leads', 'wp-leadflow-crm' ),
				'value' => number_format_i18n( $closed['lost'] ),
				'hint'  => empty( $closed['lost_value'] ) ? __( 'Closed as lost in the period', 'wp-leadflow-crm' ) : Format::money_list( $closed['lost_value'] ),
				'icon'  => 'dismiss',
				'tone'  => 'error',
				'trend' => self::trend( $closed['lost'], $closed_pv['lost'], true ),
				'url'   => $leads_url( array( 'status' => 'lost' ) ),
			),
			'pipeline'     => array(
				'label' => __( 'Pipeline value', 'wp-leadflow-crm' ),
				'value' => Format::money_list( $open_value ?: array( $currency => 0.0 ) ),
				'hint'  => sprintf(
					/* translators: 1: Number of open deals, 2: Weighted value. */
					_n( '%1$s open deal · weighted %2$s', '%1$s open deals · weighted %2$s', $open_deals, 'wp-leadflow-crm' ),
					number_format_i18n( $open_deals ),
					Format::money_list( $weighted ?: array( $currency => 0.0 ) )
				),
				'icon'  => 'chart-area',
				'url'   => PipelineBoard::url(),
			),
			'conversion'   => array(
				'label' => __( 'Conversion rate', 'wp-leadflow-crm' ),
				'value' => null === $rate ? '—' : number_format_i18n( $rate, 1 ) . '%',
				'hint'  => sprintf(
					/* translators: 1: Won leads, 2: Closed leads. */
					__( '%1$s won of %2$s closed', 'wp-leadflow-crm' ),
					number_format_i18n( $closed['won'] ),
					number_format_i18n( $closed['won'] + $closed['lost'] )
				),
				'icon'  => 'performance',
				'trend' => null === $rate || null === $rate_prev ? null : self::points( $rate - $rate_prev ),
			),
			'open_tasks'   => array(
				'label' => __( 'Open tasks', 'wp-leadflow-crm' ),
				'value' => number_format_i18n( $tasks['open'] ),
				'hint'  => null === $owner ? __( 'Everyone’s open tasks', 'wp-leadflow-crm' ) : __( 'Assigned open tasks', 'wp-leadflow-crm' ),
				'icon'  => 'yes-alt',
				'url'   => Menu::url( 'leadflow-crm-tasks' ),
			),
			'overdue'      => array(
				'label' => __( 'Overdue tasks', 'wp-leadflow-crm' ),
				'value' => number_format_i18n( $tasks['overdue'] ),
				'hint'  => __( 'Past their due date', 'wp-leadflow-crm' ),
				'icon'  => 'warning',
				'tone'  => $tasks['overdue'] > 0 ? 'error' : '',
				'url'   => Menu::url( 'leadflow-crm-tasks', array( 'status' => 'overdue' ) ),
			),
			'follow_ups'   => array(
				'label' => __( 'Upcoming follow-ups', 'wp-leadflow-crm' ),
				'value' => number_format_i18n( $follow['upcoming'] ),
				'hint'  => $follow['overdue'] > 0
					/* translators: %s: Number of overdue follow-ups. */
					? sprintf( _n( 'Next 7 days · %s overdue', 'Next 7 days · %s overdue', $follow['overdue'], 'wp-leadflow-crm' ), number_format_i18n( $follow['overdue'] ) )
					: __( 'Next 7 days', 'wp-leadflow-crm' ),
				'icon'  => 'calendar-alt',
				'tone'  => $follow['overdue'] > 0 ? 'warning' : '',
			),
		);

		return array(
			'kpis'     => $kpis,
			'charts'   => array(
				'stage'    => $this->stage_chart( $breakdown, $stages ),
				'source'   => $this->source_chart( $breakdown ),
				'monthly'  => $this->monthly_chart( $range, $owner ),
				'won_lost' => $this->won_lost_chart( $closed, $rate ),
				'pipeline' => $this->pipeline_chart( $pipeline, $stages, $currency ),
			),
			'currency' => $currency,
		);
	}

	/**
	 * Leads created in the period by current stage.
	 *
	 * @param array<int, array<string, mixed>> $breakdown Created breakdown.
	 * @param Stage[]                          $stages    Stages in order.
	 * @return array<string, mixed>
	 */
	private function stage_chart( array $breakdown, array $stages ): array {
		$counts = array();

		foreach ( $breakdown as $row ) {
			$counts[ $row['stage'] ] = ( $counts[ $row['stage'] ] ?? 0 ) + $row['total'];
		}

		$labels = array();
		$data   = array();
		$colors = array();

		foreach ( $stages as $stage ) {
			$labels[] = $stage->name();
			$data[]   = (int) ( $counts[ $stage->slug() ] ?? 0 );
			$colors[] = $stage->color();
			unset( $counts[ $stage->slug() ] );
		}

		// Leads on stages that no longer exist.
		if ( array_sum( $counts ) > 0 ) {
			$labels[] = __( 'Other', 'wp-leadflow-crm' );
			$data[]   = array_sum( $counts );
			$colors[] = '#94a3b8';
		}

		return array(
			'type'        => 'bar',
			'title'       => __( 'Leads by stage', 'wp-leadflow-crm' ),
			'description' => __( 'New leads of the period, by their current stage.', 'wp-leadflow-crm' ),
			'labels'      => $labels,
			'datasets'    => array(
				array(
					'label'  => __( 'Leads', 'wp-leadflow-crm' ),
					'data'   => $data,
					'colors' => $colors,
				),
			),
			'format'      => array( 'style' => 'number' ),
		);
	}

	/**
	 * Leads created in the period by source.
	 *
	 * @param array<int, array<string, mixed>> $breakdown Created breakdown.
	 * @return array<string, mixed>
	 */
	private function source_chart( array $breakdown ): array {
		$counts = array();

		foreach ( $breakdown as $row ) {
			$counts[ $row['source'] ] = ( $counts[ $row['source'] ] ?? 0 ) + $row['total'];
		}

		arsort( $counts );

		$labels  = array();
		$data    = array();
		$others  = 0;
		$palette = array( '#4f46e5', '#0ea5e9', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899' );

		foreach ( $counts as $source => $count ) {
			if ( count( $labels ) >= self::MAX_SOURCES ) {
				$others += $count;
				continue;
			}

			$labels[] = self::source_label( (string) $source );
			$data[]   = $count;
		}

		$colors = array_slice( $palette, 0, count( $labels ) );

		if ( $others > 0 ) {
			$labels[] = __( 'Other sources', 'wp-leadflow-crm' );
			$data[]   = $others;
			$colors[] = '#94a3b8';
		}

		return array(
			'type'        => 'doughnut',
			'title'       => __( 'Leads by source', 'wp-leadflow-crm' ),
			'description' => __( 'Where the new leads of the period came from.', 'wp-leadflow-crm' ),
			'labels'      => $labels,
			'datasets'    => array(
				array(
					'label'  => __( 'Leads', 'wp-leadflow-crm' ),
					'data'   => $data,
					'colors' => $colors,
				),
			),
			'center'      => number_format_i18n( array_sum( $data ) ),
			'center_label' => __( 'leads', 'wp-leadflow-crm' ),
			'format'      => array( 'style' => 'number' ),
		);
	}

	/**
	 * New and won leads per month.
	 *
	 * @param DateRange $range Period.
	 * @param int|null  $owner Owner filter.
	 * @return array<string, mixed>
	 */
	private function monthly_chart( DateRange $range, ?int $owner ): array {
		$months  = $range->months( 6 );
		$monthly = $this->analytics->monthly( $months, $owner );
		$first   = reset( $months );
		$note    = count( $months ) > 0 && $first['start'] < $range->start_utc()
			? __( 'Shows at least the last 6 months.', 'wp-leadflow-crm' )
			: '';

		return array(
			'type'        => 'combo',
			'title'       => __( 'Monthly leads', 'wp-leadflow-crm' ),
			'description' => trim( __( 'New leads (bars) and leads won (line) per month.', 'wp-leadflow-crm' ) . ' ' . $note ),
			'labels'      => array_column( $months, 'label' ),
			'datasets'    => array(
				array(
					'label' => __( 'New leads', 'wp-leadflow-crm' ),
					'data'  => array_values( $monthly['created'] ),
					'color' => '#4f46e5',
				),
				array(
					'label' => __( 'Won', 'wp-leadflow-crm' ),
					'data'  => array_values( $monthly['won'] ),
					'color' => '#16a34a',
					'type'  => 'line',
				),
			),
			'format'      => array( 'style' => 'number' ),
		);
	}

	/**
	 * Won vs lost in the period.
	 *
	 * @param array<string, mixed> $closed Closed summary.
	 * @param float|null           $rate   Conversion rate.
	 * @return array<string, mixed>
	 */
	private function won_lost_chart( array $closed, ?float $rate ): array {
		return array(
			'type'         => 'doughnut',
			'title'        => __( 'Won vs lost', 'wp-leadflow-crm' ),
			'description'  => __( 'Leads closed in the period.', 'wp-leadflow-crm' ),
			'labels'       => array( __( 'Won', 'wp-leadflow-crm' ), __( 'Lost', 'wp-leadflow-crm' ) ),
			'datasets'     => array(
				array(
					'label'   => __( 'Leads', 'wp-leadflow-crm' ),
					'data'    => array( $closed['won'], $closed['lost'] ),
					'colors'  => array( '#16a34a', '#dc2626' ),
					'display' => array(
						number_format_i18n( $closed['won'] ) . ( empty( $closed['won_value'] ) ? '' : ' · ' . Format::money_list( $closed['won_value'] ) ),
						number_format_i18n( $closed['lost'] ) . ( empty( $closed['lost_value'] ) ? '' : ' · ' . Format::money_list( $closed['lost_value'] ) ),
					),
				),
			),
			'center'       => null === $rate ? '—' : number_format_i18n( $rate, 0 ) . '%',
			'center_label' => __( 'win rate', 'wp-leadflow-crm' ),
			'format'       => array( 'style' => 'number' ),
		);
	}

	/**
	 * Open pipeline value per open stage, in the primary currency.
	 *
	 * @param array<int, array<string, mixed>> $pipeline Open pipeline rows.
	 * @param Stage[]                          $stages   Stages in order.
	 * @param string                           $currency Currency shown.
	 * @return array<string, mixed>
	 */
	private function pipeline_chart( array $pipeline, array $stages, string $currency ): array {
		$values   = array();
		$weighted = array();
		$others   = array();

		foreach ( $pipeline as $row ) {
			if ( $row['currency'] !== $currency ) {
				$others[ $row['currency'] ] = ( $others[ $row['currency'] ] ?? 0 ) + $row['value'];
				continue;
			}

			$values[ $row['stage'] ]   = ( $values[ $row['stage'] ] ?? 0 ) + $row['value'];
			$weighted[ $row['stage'] ] = ( $weighted[ $row['stage'] ] ?? 0 ) + $row['weighted'];
		}

		$labels = array();
		$value  = array();
		$weight = array();

		foreach ( $stages as $stage ) {
			if ( 'open' !== $stage->type() ) {
				continue;
			}

			$labels[] = $stage->name();
			$value[]  = round( (float) ( $values[ $stage->slug() ] ?? 0 ), 2 );
			$weight[] = round( (float) ( $weighted[ $stage->slug() ] ?? 0 ), 2 );
		}

		$description = sprintf(
			/* translators: %s: Currency code. */
			__( 'Value of open leads by stage today, in %s.', 'wp-leadflow-crm' ),
			$currency
		);

		if ( ! empty( $others ) ) {
			/* translators: %s: Amounts in other currencies. */
			$description .= ' ' . sprintf( __( 'Not included (other currencies): %s.', 'wp-leadflow-crm' ), Format::money_list( $others ) );
		}

		return array(
			'type'        => 'bar',
			'title'       => __( 'Pipeline value', 'wp-leadflow-crm' ),
			'description' => $description,
			'labels'      => $labels,
			'datasets'    => array(
				array(
					'label'   => __( 'Value', 'wp-leadflow-crm' ),
					'data'    => $value,
					'color'   => '#4f46e5',
					'display' => array_map( static fn( float $v ): string => Format::money( $v, $currency ), $value ),
				),
				array(
					'label'   => __( 'Weighted value', 'wp-leadflow-crm' ),
					'data'    => $weight,
					'color'   => '#a5b4fc',
					'display' => array_map( static fn( float $v ): string => Format::money( $v, $currency ), $weight ),
				),
			),
			'format'      => array(
				'style'    => 'currency',
				'currency' => $currency,
			),
		);
	}

	/**
	 * Counts and values of won and lost leads.
	 *
	 * @param array<int, array<string, mixed>> $rows Closed rows.
	 * @return array{won: int, lost: int, won_value: array<string, float>, lost_value: array<string, float>}
	 */
	private function summarize_closed( array $rows ): array {
		$summary = array(
			'won'        => 0,
			'lost'       => 0,
			'won_value'  => array(),
			'lost_value' => array(),
		);

		foreach ( $rows as $row ) {
			$status = 'won' === $row['status'] ? 'won' : 'lost';

			$summary[ $status ] += $row['total'];

			if ( $row['value'] > 0 ) {
				$summary[ $status . '_value' ][ $row['currency'] ] = ( $summary[ $status . '_value' ][ $row['currency'] ] ?? 0 ) + $row['value'];
			}
		}

		return $summary;
	}

	/**
	 * New leads of the period now at/after the qualification stage, or won.
	 *
	 * @param array<int, array<string, mixed>> $breakdown Created breakdown.
	 * @param Stage[]                          $stages    Stages in order.
	 * @return int
	 */
	private function count_qualified( array $breakdown, array $stages ): int {
		$qualified = array_flip( self::qualified_stages( $stages ) );
		$count     = 0;

		foreach ( $breakdown as $row ) {
			if ( 'won' === $row['status'] || ( 'open' === $row['status'] && isset( $qualified[ $row['stage'] ] ) ) ) {
				$count += $row['total'];
			}
		}

		return $count;
	}

	/**
	 * Open stages that count as qualified: the qualification stage (slug
	 * `qualified`, filterable) and every open stage after it. Without such a
	 * stage, every open stage after the first.
	 *
	 * @param Stage[] $stages Stages in order.
	 * @return string[] Slugs.
	 */
	public static function qualified_stages( array $stages ): array {
		$open = array_values( array_filter( $stages, static fn( Stage $s ): bool => 'open' === $s->type() ) );

		/**
		 * Filters the slug of the stage from which a lead counts as qualified.
		 *
		 * @param string $slug Stage slug.
		 */
		$slug  = (string) apply_filters( 'leadflow_crm_qualified_stage', 'qualified' );
		$index = null;

		foreach ( $open as $i => $stage ) {
			if ( $stage->slug() === $slug ) {
				$index = $i;
				break;
			}
		}

		$index ??= min( 1, max( 0, count( $open ) - 1 ) );

		return array_map( static fn( Stage $s ): string => $s->slug(), array_slice( $open, $index ) );
	}

	/**
	 * Currency for money charts: the default currency when it has open
	 * deals, otherwise the currency with the largest open value.
	 *
	 * @param array<int, array<string, mixed>> $pipeline Open pipeline rows.
	 * @return string
	 */
	private function primary_currency( array $pipeline ): string {
		$default = strtoupper( (string) $this->plugin->get( Settings::class )->get( 'default_currency', 'USD' ) );
		$totals  = array();

		foreach ( $pipeline as $row ) {
			$totals[ $row['currency'] ] = ( $totals[ $row['currency'] ] ?? 0 ) + $row['value'];
		}

		if ( empty( $totals ) || isset( $totals[ $default ] ) ) {
			return $default;
		}

		arsort( $totals );

		return (string) array_key_first( $totals );
	}

	/**
	 * Win rate in percent.
	 *
	 * @param int $won  Won.
	 * @param int $lost Lost.
	 * @return float|null Null when nothing was closed.
	 */
	private static function rate( int $won, int $lost ): ?float {
		return $won + $lost > 0 ? $won / ( $won + $lost ) * 100 : null;
	}

	/**
	 * Change vs the previous period.
	 *
	 * @param int  $current  Current value.
	 * @param int  $previous Previous value.
	 * @param bool $inverse  Whether an increase is bad (e.g. lost leads).
	 * @return array{text: string, direction: string, good: bool}|null
	 */
	private static function trend( int $current, int $previous, bool $inverse = false ): ?array {
		if ( 0 === $previous && 0 === $current ) {
			return null;
		}

		$direction = $current <=> $previous;

		if ( 0 === $previous ) {
			$text = __( 'New', 'wp-leadflow-crm' );
		} else {
			$change = ( $current - $previous ) / $previous * 100;
			$text   = ( $change > 0 ? '+' : '' ) . number_format_i18n( $change, 0 ) . '%';
		}

		return array(
			'text'      => $text,
			'direction' => 1 === $direction ? 'up' : ( -1 === $direction ? 'down' : 'flat' ),
			'good'      => 0 === $direction ? true : ( ( 1 === $direction ) xor $inverse ),
			'label'     => __( 'vs previous period', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * Change in percentage points.
	 *
	 * @param float $delta Points.
	 * @return array{text: string, direction: string, good: bool}
	 */
	private static function points( float $delta ): array {
		$rounded = round( $delta, 1 );

		return array(
			/* translators: %s: Signed number of percentage points. */
			'text'      => sprintf( __( '%s pts', 'wp-leadflow-crm' ), ( $rounded > 0 ? '+' : '' ) . number_format_i18n( $rounded, 1 ) ),
			'direction' => $rounded > 0 ? 'up' : ( $rounded < 0 ? 'down' : 'flat' ),
			'good'      => $rounded >= 0,
			'label'     => __( 'vs previous period', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * Display label of a source slug.
	 *
	 * @param string $source Slug.
	 * @return string
	 */
	public static function source_label( string $source ): string {
		return '' === $source ? __( 'Not set', 'wp-leadflow-crm' ) : ucwords( str_replace( array( '-', '_' ), ' ', $source ) );
	}
}
