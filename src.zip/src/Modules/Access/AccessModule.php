<?php
/**
 * Access control module.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Access;

use LeadFlow\CRM\Admin\Menu;
use LeadFlow\CRM\Admin\Notices;
use LeadFlow\CRM\Admin\Page;
use LeadFlow\CRM\Admin\View;
use LeadFlow\CRM\Contracts\Module;
use LeadFlow\CRM\Plugin;
use LeadFlow\CRM\Rest\Controller;
use LeadFlow\CRM\Security\Capabilities;
use LeadFlow\CRM\Security\Guard;
use LeadFlow\CRM\Security\Input;
use LeadFlow\CRM\Security\Nonce;
use LeadFlow\CRM\Security\Permissions;

defined( 'ABSPATH' ) || exit;

/**
 * LeadFlow CRM → Access control (`leadflow_manage_users`):
 *
 * - Roles & permissions: grant or remove each CRM capability per role.
 * - Team: give users the CRM Manager or Sales Agent role.
 * - API: how external applications authenticate.
 *
 * Safety rules: administrators always keep every CRM permission; people
 * who are not administrators cannot change their own role, cannot grant
 * permissions they lack, cannot change their own CRM role and cannot give
 * a role with more permissions than they have. Resetting to the defaults
 * needs `manage_options`.
 */
final class AccessModule implements Module {

	/** Page slug. */
	public const PAGE_SLUG = 'leadflow-crm-access';

	/**
	 * Plugin.
	 *
	 * @var Plugin|null
	 */
	private ?Plugin $plugin = null;

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'access';
	}

	/**
	 * {@inheritDoc}
	 */
	public function boot( Plugin $plugin ): void {
		$this->plugin = $plugin;

		$plugin->get( Menu::class )->add(
			new Page(
				self::PAGE_SLUG,
				__( 'Access control', 'wp-leadflow-crm' ),
				__( 'Access control', 'wp-leadflow-crm' ),
				Permissions::MANAGE_USERS,
				array( $this, 'render' ),
				95
			)
		);

		add_action( 'admin_post_leadflow_crm_save_permissions', array( $this, 'handle_save_permissions' ) );
		add_action( 'admin_post_leadflow_crm_reset_permissions', array( $this, 'handle_reset_permissions' ) );
		add_action( 'admin_post_leadflow_crm_assign_crm_role', array( $this, 'handle_assign_role' ) );
	}

	/**
	 * Tabs.
	 *
	 * @return array<string, string>
	 */
	private static function tabs(): array {
		return array(
			'permissions' => __( 'Roles & permissions', 'wp-leadflow-crm' ),
			'team'        => __( 'Team', 'wp-leadflow-crm' ),
			'api'         => __( 'API access', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * Screen URL.
	 *
	 * @param string $tab Tab.
	 * @return string Unescaped URL.
	 */
	public static function url( string $tab = 'permissions' ): string {
		return Menu::url( self::PAGE_SLUG, array( 'tab' => $tab ) );
	}

	/**
	 * Page callback.
	 *
	 * @return void
	 */
	public function render(): void {
		Guard::authorize( Permissions::MANAGE_USERS );

		$tab  = Input::one_of( 'tab', array_keys( self::tabs() ), 'permissions' );
		$caps = $this->capabilities();
		$data = array(
			'tab'  => $tab,
			'tabs' => self::tabs(),
		);

		switch ( $tab ) {
			case 'team':
				$map  = $caps->map();
				$data = array_merge(
					$data,
					array(
						'users'      => $this->team(),
						'roles'      => $this->crm_roles(),
						'assignable' => array_filter( array_keys( $this->crm_roles() ), static fn( string $r ): bool => Permissions::can_assign_role( $r, $map ) ),
					)
				);
				break;

			case 'api':
				$data = array_merge(
					$data,
					array(
						'base'      => rest_url( Controller::REST_NAMESPACE ),
						'available' => wp_is_application_passwords_available(),
						'https'     => is_ssl() || str_starts_with( home_url(), 'https://' ),
						'profile'   => admin_url( 'profile.php#application-passwords-section' ),
					)
				);
				break;

			default:
				$data = array_merge(
					$data,
					array(
						'groups'    => $this->groups( $caps->defaults() ),
						'roles'     => Permissions::editable_roles(),
						'map'       => $caps->map(),
						'defaults'  => $caps->defaults(),
						'can_reset' => current_user_can( 'manage_options' ),
					)
				);
		}

		View::render( 'admin/access/page', $data );
	}

	/**
	 * Permission groups including capabilities not described anywhere
	 * (e.g. from add-ons) under "Other".
	 *
	 * @param array<string, string[]> $defaults Default map.
	 * @return array<string, array{label: string, description: string, caps: array<string, string>}>
	 */
	private function groups( array $defaults ): array {
		$groups = Permissions::groups();
		$known  = array();

		foreach ( $groups as $key => $group ) {
			$groups[ $key ]['caps'] = array_intersect_key( $group['caps'], $defaults );
			$known                 += $group['caps'];
		}

		$other = array_diff_key( $defaults, $known );

		if ( ! empty( $other ) ) {
			$groups['other'] = array(
				'label'       => __( 'Other', 'wp-leadflow-crm' ),
				'description' => __( 'Capabilities added by extensions.', 'wp-leadflow-crm' ),
				'caps'        => array_combine( array_keys( $other ), array_keys( $other ) ),
			);
		}

		return array_filter( $groups, static fn( array $g ): bool => ! empty( $g['caps'] ) );
	}

	/**
	 * Saves the permission matrix.
	 *
	 * @return void
	 */
	public function handle_save_permissions(): void {
		Guard::verify_form( 'save_permissions', Permissions::MANAGE_USERS );

		$caps     = $this->capabilities();
		$defaults = $caps->defaults();
		$current  = $caps->map();
		$roles    = Permissions::editable_roles();
		$posted   = isset( $_POST['caps'] ) && is_array( $_POST['caps'] ) ? wp_unslash( $_POST['caps'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Values are compared against allow-lists below.
		$wanted   = array();
		$skipped  = 0;

		foreach ( array_keys( $roles ) as $role ) {
			$submitted = array_map( 'strval', (array) ( $posted[ $role ] ?? array() ) );

			foreach ( array_keys( $defaults ) as $cap ) {
				$has  = in_array( $role, $current[ $cap ] ?? array(), true );
				$want = in_array( $cap, $submitted, true );

				if ( $has !== $want && '' !== Permissions::lock_reason( $role, $cap ) ) {
					++$skipped;
					$want = $has;
				}

				if ( $want ) {
					$wanted[ $role ][] = $cap;
				}
			}

			$wanted[ $role ] = $wanted[ $role ] ?? array();
		}

		Permissions::save( $defaults, $wanted );
		$caps->sync();

		/**
		 * Fires after CRM role permissions were changed.
		 *
		 * @param array<string, string[]> $wanted Role => capabilities.
		 */
		do_action( 'leadflow_crm_permissions_saved', $wanted );

		Notices::flash( 'success', __( 'Permissions saved.', 'wp-leadflow-crm' ) );

		if ( $skipped > 0 ) {
			/* translators: %d: Number of changes. */
			Notices::flash( 'warning', sprintf( _n( '%d change was not allowed and was ignored.', '%d changes were not allowed and were ignored.', $skipped, 'wp-leadflow-crm' ), $skipped ) );
		}

		wp_safe_redirect( self::url() );
		exit;
	}

	/**
	 * Restores the default permissions.
	 *
	 * @return void
	 */
	public function handle_reset_permissions(): void {
		Guard::verify_form( 'reset_permissions', Permissions::MANAGE_USERS );
		Guard::authorize( 'manage_options' );

		Permissions::reset();
		$this->capabilities()->sync();

		do_action( 'leadflow_crm_permissions_saved', array() );

		Notices::flash( 'success', __( 'Default permissions restored.', 'wp-leadflow-crm' ) );
		wp_safe_redirect( self::url() );
		exit;
	}

	/**
	 * Gives a user a CRM role (or removes it).
	 *
	 * @return void
	 */
	public function handle_assign_role(): void {
		Guard::verify_form( 'assign_crm_role', Permissions::MANAGE_USERS );

		$roles = $this->crm_roles();
		$role  = Input::key( 'role', 'post' );
		$ident = trim( Input::text( 'user', 'post' ) );
		$user  = ctype_digit( $ident ) ? get_user_by( 'id', (int) $ident ) : ( is_email( $ident ) ? get_user_by( 'email', $ident ) : get_user_by( 'login', $ident ) );
		$error = '';
		$map   = $this->capabilities()->map();

		if ( '' !== $role && ! isset( $roles[ $role ] ) ) {
			$error = __( 'Please choose a valid CRM role.', 'wp-leadflow-crm' );
		} elseif ( false === $user || ( is_multisite() && ! is_user_member_of_blog( $user->ID ) ) ) {
			$error = __( 'No user with this username or email address was found on this site.', 'wp-leadflow-crm' );
		} elseif ( get_current_user_id() === $user->ID ) {
			$error = __( 'You cannot change your own CRM role.', 'wp-leadflow-crm' );
		} elseif ( user_can( $user, 'manage_options' ) && ! current_user_can( 'manage_options' ) ) {
			$error = __( 'Only administrators can change the roles of administrators.', 'wp-leadflow-crm' );
		} elseif ( '' !== $role && ! Permissions::can_assign_role( $role, $map ) ) {
			$error = __( 'You cannot give a role that has permissions you do not have.', 'wp-leadflow-crm' );
		} else {
			foreach ( array_intersect( (array) $user->roles, array_keys( $roles ) ) as $current ) {
				if ( ! Permissions::can_assign_role( $current, $map ) ) {
					$error = __( 'You cannot change the role of someone with permissions you do not have.', 'wp-leadflow-crm' );
				}
			}
		}

		if ( '' !== $error ) {
			Notices::flash( 'error', $error );
			wp_safe_redirect( self::url( 'team' ) );
			exit;
		}

		foreach ( array_keys( $roles ) as $slug ) {
			if ( $slug !== $role ) {
				$user->remove_role( $slug );
			}
		}

		if ( '' !== $role ) {
			$user->add_role( $role );
		} elseif ( empty( $user->roles ) ) {
			$fallback = (string) get_option( 'default_role', 'subscriber' );
			$user->add_role( isset( $roles[ $fallback ] ) ? 'subscriber' : $fallback );
		}

		/**
		 * Fires after a user's CRM role changed.
		 *
		 * @param \WP_User $user User.
		 * @param string   $role New CRM role ('' = none).
		 */
		do_action( 'leadflow_crm_user_role_changed', $user, $role );

		Notices::flash(
			'success',
			'' === $role
				/* translators: %s: User name. */
				? sprintf( __( '%s no longer has a CRM role.', 'wp-leadflow-crm' ), $user->display_name )
				/* translators: 1: User name, 2: Role name. */
				: sprintf( __( '%1$s is now a %2$s.', 'wp-leadflow-crm' ), $user->display_name, $roles[ $role ] )
		);

		wp_safe_redirect( self::url( 'team' ) );
		exit;
	}

	/**
	 * CRM roles.
	 *
	 * @return array<string, string> Slug => translated name.
	 */
	private function crm_roles(): array {
		$roles = array();

		foreach ( Capabilities::custom_roles() as $slug => $name ) {
			$roles[ $slug ] = translate_user_role( $name );
		}

		return $roles;
	}

	/**
	 * Users with CRM access.
	 *
	 * @return \WP_User[]
	 */
	private function team(): array {
		$users = get_users(
			array(
				'capability' => Capabilities::ACCESS_CRM,
				'orderby'    => 'display_name',
				'order'      => 'ASC',
				'number'     => 500,
			)
		);

		return array_values( array_filter( $users, static fn( $u ): bool => $u instanceof \WP_User ) );
	}

	/**
	 * Capabilities service.
	 *
	 * @return Capabilities
	 */
	private function capabilities(): Capabilities {
		return ( $this->plugin ?? Plugin::instance() )->get( Capabilities::class );
	}
}
