<?php
/**
 * Tasks module.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Tasks;

use LeadFlow\CRM\Admin\Menu;
use LeadFlow\CRM\Admin\RecordPanels;
use LeadFlow\CRM\Admin\View;
use LeadFlow\CRM\Contracts\Module;
use LeadFlow\CRM\Contracts\ProvidesCapabilities;
use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\Task;
use LeadFlow\CRM\Modules\Dashboard\Sections;
use LeadFlow\CRM\Plugin;
use LeadFlow\CRM\Security\Nonce;
use LeadFlow\CRM\Support\Users;

defined( 'ABSPATH' ) || exit;

/**
 * Task management: screens, record tab, dashboard widget.
 */
final class TasksModule implements Module, ProvidesCapabilities {

	/**
	 * Admin controller.
	 *
	 * @var TasksAdmin|null
	 */
	private ?TasksAdmin $admin = null;

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'tasks';
	}

	/**
	 * {@inheritDoc}
	 */
	public function capabilities(): array {
		return $this->admin()->capability_map();
	}

	/**
	 * {@inheritDoc}
	 */
	public function boot( Plugin $plugin ): void {
		$admin = $this->admin();

		$plugin->get( Menu::class )->add( $admin->page() );
		$admin->register();

		add_action( 'admin_menu', array( $admin, 'add_menu_bubble' ), 99 );
		( new TaskActions( $admin ) )->register();

		add_action( 'leadflow_crm_record_panels', array( $this, 'add_panel' ), 30, 3 );
		add_action( 'leadflow_crm_dashboard_sections', array( $this, 'dashboard_section' ) );
	}

	/**
	 * Tasks tab on company, contact and lead screens.
	 *
	 * @param RecordPanels $panels Panel registry.
	 * @param string       $type   Record type.
	 * @param Model        $record Record.
	 * @return void
	 */
	public function add_panel( RecordPanels $panels, string $type, Model $record ): void {
		$admin = $this->admin();

		if ( ! in_array( $type, array( 'company', 'contact', 'lead' ), true ) || ! current_user_can( $admin->cap( 'view' ) ) ) {
			return;
		}

		$open_args = array(
			'where' => array(
				'status' => array(
					'op'    => 'NOT IN',
					'value' => Task::CLOSED_STATUSES,
				),
			),
		);
		$open      = $admin->tasks()->count_for_parent( $type, $record->id(), $open_args );

		$panels->add(
			'tasks',
			array(
				'title'  => __( 'Tasks', 'wp-leadflow-crm' ),
				'count'  => $open,
				'order'  => 30,
				'render' => function () use ( $admin, $type, $record, $open_args ): void {
					$tasks = $admin->tasks()->for_parent(
						$type,
						$record->id(),
						array_merge(
							$open_args,
							array(
								'orderby'    => 'due_at',
								'order'      => 'ASC',
								'nulls_last' => true,
								'per_page'   => 50,
							)
						)
					);
					$done  = $admin->tasks()->for_parent(
						$type,
						$record->id(),
						array(
							'where'    => array( 'status' => 'completed' ),
							'orderby'  => 'completed_at',
							'order'    => 'DESC',
							'per_page' => 5,
						)
					);

					View::render(
						'admin/partials/tasks-panel',
						array(
							'admin'      => $admin,
							'parent'     => $type,
							'parent_id'  => $record->id(),
							'tasks'      => array_merge( $tasks, $done ),
							'can_add'    => ! $record->is_trashed() && current_user_can( $admin->cap( 'edit' ) ),
							'can_assign' => current_user_can( $admin->cap( 'edit_others' ) ),
							'users'      => Users::crm_users(),
							'nonce'      => Nonce::create( 'task' ),
							'list_url'   => $admin->url( array( $type . '_id' => $record->id() ) ),
						)
					);
				},
			)
		);
	}

	/**
	 * "My tasks" dashboard widget.
	 *
	 * @param Sections $sections Dashboard sections.
	 * @return void
	 */
	public function dashboard_section( Sections $sections ): void {
		$admin = $this->admin();

		$sections->add(
			'tasks',
			array(
				'title'      => __( 'My tasks', 'wp-leadflow-crm' ),
				'icon'       => 'yes-alt',
				'order'      => 50,
				'capability' => $admin->cap( 'view' ),
				'render'     => function () use ( $admin ): void {
					$user = get_current_user_id();

					View::render(
						'admin/partials/tasks-widget',
						array(
							'admin'   => $admin,
							'tasks'   => $admin->tasks()->open_for_user( $user, 6 ),
							'overdue' => $admin->tasks()->overdue_count( $user ),
							'open'    => $admin->tasks()->count(
								array(
									'where' => array(
										'assigned_to' => $user,
										'status'      => array(
											'op'    => 'NOT IN',
											'value' => Task::CLOSED_STATUSES,
										),
									),
								)
							),
							'nonce'   => Nonce::create( 'task' ),
						)
					);
				},
			)
		);
	}

	/**
	 * Lazily built admin controller.
	 *
	 * @return TasksAdmin
	 */
	public function admin(): TasksAdmin {
		if ( null === $this->admin ) {
			$this->admin = new TasksAdmin( Plugin::instance() );
		}

		return $this->admin;
	}
}
