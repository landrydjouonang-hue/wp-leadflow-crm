<?php
/**
 * Tasks admin screens.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Tasks;

use LeadFlow\CRM\Admin\Crud\EntityAdmin;
use LeadFlow\CRM\Admin\Crud\EntityListTable;
use LeadFlow\CRM\Admin\Menu;
use LeadFlow\CRM\Admin\View;
use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\Task;
use LeadFlow\CRM\Data\Repositories\CompanyRepository;
use LeadFlow\CRM\Data\Repositories\ContactRepository;
use LeadFlow\CRM\Data\Repositories\LeadRepository;
use LeadFlow\CRM\Data\Repositories\TaskRepository;
use LeadFlow\CRM\Data\Repository;
use LeadFlow\CRM\Modules\Contacts\ContactsAdmin;
use LeadFlow\CRM\Modules\Leads\LeadsAdmin;
use LeadFlow\CRM\Security\Input;
use LeadFlow\CRM\Support\Format;
use LeadFlow\CRM\Support\Users;

defined( 'ABSPATH' ) || exit;

/**
 * List, add, edit and view tasks.
 *
 * A task "belongs" to its assignee and its creator: either may edit it
 * with `leadflow_edit_tasks`; everyone else needs `leadflow_edit_others_tasks`.
 */
final class TasksAdmin extends EntityAdmin {

	protected const ENTITY     = 'task';
	protected const PLURAL     = 'tasks';
	protected const PAGE_SLUG  = 'leadflow-crm-tasks';
	protected const MENU_ORDER = 50;

	/** Records loaded into pickers before search is needed. */
	private const OPTIONS_LIMIT = 200;

	/**
	 * {@inheritDoc}
	 */
	public function repository(): Repository {
		return $this->plugin->get( TaskRepository::class );
	}

	/**
	 * Typed repository.
	 *
	 * @return TaskRepository
	 */
	public function tasks(): TaskRepository {
		return $this->plugin->get( TaskRepository::class );
	}

	/**
	 * {@inheritDoc}
	 */
	public function labels(): array {
		return array(
			'singular'        => __( 'Task', 'wp-leadflow-crm' ),
			'plural'          => __( 'Tasks', 'wp-leadflow-crm' ),
			'add_new'         => __( 'Add task', 'wp-leadflow-crm' ),
			'search'          => __( 'Search tasks', 'wp-leadflow-crm' ),
			'not_found'       => __( 'No tasks found.', 'wp-leadflow-crm' ),
			'not_found_trash' => __( 'No tasks in the trash.', 'wp-leadflow-crm' ),
			'created'         => __( 'Task created.', 'wp-leadflow-crm' ),
			'updated'         => __( 'Task updated.', 'wp-leadflow-crm' ),
			'trashed'         => __( 'Task moved to the trash.', 'wp-leadflow-crm' ),
			'restored'        => __( 'Task restored.', 'wp-leadflow-crm' ),
			'deleted'         => __( 'Task permanently deleted.', 'wp-leadflow-crm' ),
			'delete_confirm'  => __( 'Permanently delete this task? This cannot be undone.', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function status_labels(): array {
		return array(
			'pending'     => __( 'To do', 'wp-leadflow-crm' ),
			'in_progress' => __( 'In progress', 'wp-leadflow-crm' ),
			'completed'   => __( 'Completed', 'wp-leadflow-crm' ),
			'cancelled'   => __( 'Cancelled', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * Priority labels.
	 *
	 * @return array<string, string>
	 */
	public static function priority_labels(): array {
		return array(
			'low'    => __( 'Low', 'wp-leadflow-crm' ),
			'normal' => __( 'Normal', 'wp-leadflow-crm' ),
			'high'   => __( 'High', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function title_of( Model $model ): string {
		return (string) $model->get( 'title', '' );
	}

	/**
	 * Assignee or creator counts as the owner.
	 *
	 * {@inheritDoc}
	 */
	public function map_meta_cap( array $caps, string $cap, int $user_id, array $args ): array {
		if ( $cap !== $this->meta_cap( 'edit' ) && $cap !== $this->meta_cap( 'delete' ) ) {
			return $caps;
		}

		$task = $this->repository()->find( (int) ( $args[0] ?? 0 ), true );

		if ( null === $task ) {
			return array( 'do_not_allow' );
		}

		if ( $cap === $this->meta_cap( 'delete' ) ) {
			return array( $this->cap( 'delete' ) );
		}

		$mine = $user_id > 0 && in_array( $user_id, array( (int) $task->get( 'assigned_to', 0 ), (int) $task->get( 'created_by', 0 ) ), true );

		return $mine ? array( $this->cap( 'edit' ) ) : array( $this->cap( 'edit_others' ) );
	}

	/**
	 * Adds a bubble counting the current user's overdue tasks to the menu
	 * item. Runs on `admin_menu` after the pages were registered.
	 *
	 * @return void
	 */
	public function add_menu_bubble(): void {
		global $submenu;

		$user = get_current_user_id();

		if ( $user <= 0 || empty( $submenu[ Menu::SLUG ] ) ) {
			return;
		}

		$overdue = $this->tasks()->overdue_count( $user );

		if ( 0 === $overdue ) {
			return;
		}

		foreach ( $submenu[ Menu::SLUG ] as $index => $item ) {
			if ( static::PAGE_SLUG === ( $item[2] ?? '' ) ) {
				// phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Standard way to add a menu count.
				$submenu[ Menu::SLUG ][ $index ][0] = sprintf(
					'%1$s <span class="awaiting-mod count-%2$d"><span class="pending-count" aria-hidden="true">%2$d</span></span><span class="screen-reader-text">%3$s</span>',
					esc_html( $this->labels()['plural'] ),
					$overdue,
					/* translators: %d: Number of overdue tasks. */
					esc_html( sprintf( _n( '%d overdue task', '%d overdue tasks', $overdue, 'wp-leadflow-crm' ), $overdue ) )
				);
			}
		}
	}

	/**
	 * {@inheritDoc}
	 */
	protected function form_sections( ?Model $model ): array {
		$lead = array(
			'name'        => 'lead_id',
			'label'       => __( 'Lead', 'wp-leadflow-crm' ),
			'type'        => 'record',
			'width'       => 'half',
			'options'     => $this->lead_options( null !== $model ? (int) $model->get( 'lead_id', 0 ) : Input::int( 'lead_id' ) ),
			'empty_label' => __( 'No lead', 'wp-leadflow-crm' ),
		);

		if ( current_user_can( 'leadflow_view_leads' ) ) {
			$lead['search'] = array(
				'endpoint' => 'lookup/leads',
				'label'    => __( 'Search leads…', 'wp-leadflow-crm' ),
			);
		}

		$company = array(
			'name'        => 'company_id',
			'label'       => __( 'Company', 'wp-leadflow-crm' ),
			'type'        => 'record',
			'width'       => 'half',
			'options'     => ( new ContactsAdmin( $this->plugin ) )->company_options( null !== $model ? (int) $model->get( 'company_id', 0 ) : Input::int( 'company_id' ) ),
			'empty_label' => __( 'No company', 'wp-leadflow-crm' ),
		);

		if ( current_user_can( 'leadflow_view_companies' ) ) {
			$company['search'] = array(
				'endpoint' => 'lookup/companies',
				'label'    => __( 'Search companies…', 'wp-leadflow-crm' ),
			);
		}

		$contact = array(
			'name'        => 'contact_id',
			'label'       => __( 'Contact', 'wp-leadflow-crm' ),
			'type'        => 'record',
			'width'       => 'half',
			'options'     => ( new LeadsAdmin( $this->plugin ) )->contact_options( null !== $model ? (int) $model->get( 'contact_id', 0 ) : Input::int( 'contact_id' ) ),
			'empty_label' => __( 'No contact', 'wp-leadflow-crm' ),
		);

		if ( current_user_can( 'leadflow_view_contacts' ) ) {
			$contact['search'] = array(
				'endpoint' => 'lookup/contacts',
				'label'    => __( 'Search contacts…', 'wp-leadflow-crm' ),
			);
		}

		return array(
			array(
				'title'  => __( 'Task', 'wp-leadflow-crm' ),
				'fields' => array(
					array(
						'name'        => 'title',
						'label'       => __( 'Task title', 'wp-leadflow-crm' ),
						'required'    => true,
						'maxlength'   => 255,
						'placeholder' => __( 'e.g. Send the revised proposal', 'wp-leadflow-crm' ),
					),
					array(
						'name'  => 'description',
						'label' => __( 'Description', 'wp-leadflow-crm' ),
						'type'  => 'textarea',
						'rows'  => 5,
					),
				),
			),
			array(
				'title'       => __( 'Related to', 'wp-leadflow-crm' ),
				'description' => __( 'Optional. Choosing a lead also links its contact and company.', 'wp-leadflow-crm' ),
				'fields'      => array( $lead, $company, $contact ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function sidebar_fields( ?Model $model ): array {
		$fields = array(
			array(
				'name'     => 'status',
				'label'    => __( 'Status', 'wp-leadflow-crm' ),
				'type'     => 'select',
				'required' => true,
				'options'  => $this->status_labels(),
			),
			array(
				'name'     => 'priority',
				'label'    => __( 'Priority', 'wp-leadflow-crm' ),
				'type'     => 'select',
				'required' => true,
				'options'  => self::priority_labels(),
			),
			array(
				'name'        => 'due_at',
				'label'       => __( 'Due date', 'wp-leadflow-crm' ),
				'type'        => 'datetime',
				'description' => sprintf(
					/* translators: %s: Timezone name. */
					__( 'Time zone: %s.', 'wp-leadflow-crm' ),
					wp_timezone_string()
				),
			),
		);

		if ( current_user_can( $this->cap( 'edit_others' ) ) ) {
			$options  = Users::crm_users();
			$assignee = null !== $model ? (int) $model->get( 'assigned_to', 0 ) : 0;

			if ( $assignee > 0 && ! isset( $options[ $assignee ] ) ) {
				$options[ $assignee ] = Format::user( $assignee );
			}

			$fields[] = array(
				'name'        => 'assigned_to',
				'label'       => __( 'Assigned to', 'wp-leadflow-crm' ),
				'type'        => 'user',
				'options'     => $options,
				'empty_label' => __( 'Unassigned', 'wp-leadflow-crm' ),
			);
		}

		return $fields;
	}

	/**
	 * {@inheritDoc}
	 */
	protected function default_values(): array {
		$values = array(
			'status'      => 'pending',
			'priority'    => 'normal',
			'assigned_to' => get_current_user_id(),
		);

		$repos = array(
			'lead_id'    => LeadRepository::class,
			'company_id' => CompanyRepository::class,
			'contact_id' => ContactRepository::class,
		);

		foreach ( $repos as $column => $class ) {
			$id = Input::int( $column );

			if ( $id > 0 && null !== $this->plugin->get( $class )->find( $id ) ) {
				$values[ $column ] = $id;
			}
		}

		return $values;
	}

	/**
	 * {@inheritDoc}
	 */
	protected function create_list_table(): EntityListTable {
		return new TasksListTable( $this, $this->repository() );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function render_view( Model $model ): void {
		View::render(
			'admin/tasks/view',
			array(
				'admin'    => $this,
				'task'     => $model,
				'related'  => self::related_links( array( $model ) )[ $model->id() ] ?? array(),
				'can_edit' => ! $model->is_trashed() && current_user_can( $this->meta_cap( 'edit' ), $model->id() ),
				'nonce'    => \LeadFlow\CRM\Security\Nonce::create( 'task' ),
			)
		);
	}

	/**
	 * Bulk "Mark as completed".
	 *
	 * {@inheritDoc}
	 */
	public function extra_bulk_actions(): array {
		return array( 'bulk_complete' => __( 'Mark as completed', 'wp-leadflow-crm' ) );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function handle_extra_bulk( string $action, array $ids ): string {
		if ( 'bulk_complete' !== $action ) {
			return '';
		}

		$done = 0;

		foreach ( $ids as $id ) {
			$task = $this->repository()->find( $id );

			if ( null !== $task && 'completed' !== $task->get( 'status' ) && current_user_can( $this->meta_cap( 'edit' ), $id ) ) {
				$this->repository()->update( $id, array( 'status' => 'completed' ) );
				++$done;
			}
		}

		/* translators: %d: Number of tasks. */
		return sprintf( _n( '%d task marked as completed.', '%d tasks marked as completed.', $done, 'wp-leadflow-crm' ), $done );
	}

	/**
	 * Leads for pickers: the most recent N plus the selected one.
	 *
	 * @param int $include Lead id that must be present.
	 * @return array<int, string>
	 */
	public function lead_options( int $include = 0 ): array {
		$leads   = $this->plugin->get( LeadRepository::class );
		$options = array();

		foreach ( $leads->query(
			array(
				'where'    => array( 'status' => 'open' ),
				'orderby'  => 'title',
				'order'    => 'ASC',
				'per_page' => self::OPTIONS_LIMIT,
			)
		) as $lead ) {
			$options[ $lead->id() ] = (string) $lead->get( 'title' );
		}

		if ( $include > 0 && ! isset( $options[ $include ] ) ) {
			$current = $leads->find( $include, true );

			if ( null !== $current ) {
				$options[ $include ] = (string) $current->get( 'title' );
			}
		}

		return $options;
	}

	/**
	 * Links to the lead, contact and company of many tasks (batched).
	 *
	 * @param Model[] $tasks Tasks (or any records with lead/contact/company ids).
	 * @return array<int, array<string, array{label: string, url: string}>> Task id => type => link.
	 */
	public static function related_links( array $tasks ): array {
		$plugin  = leadflow_crm();
		$sources = array(
			'lead'    => array( LeadRepository::class, 'leadflow-crm-leads', 'leadflow_view_leads' ),
			'contact' => array( ContactRepository::class, 'leadflow-crm-contacts', 'leadflow_view_contacts' ),
			'company' => array( CompanyRepository::class, 'leadflow-crm-companies', 'leadflow_view_companies' ),
		);
		$links   = array();

		foreach ( $sources as $type => list( $class, $slug, $cap ) ) {
			$records = $plugin->get( $class )->find_many( array_map( static fn( Model $t ): int => (int) $t->get( $type . '_id', 0 ), $tasks ) );

			foreach ( $tasks as $task ) {
				$record = $records[ (int) $task->get( $type . '_id', 0 ) ] ?? null;

				if ( null === $record ) {
					continue;
				}

				$links[ $task->id() ][ $type ] = array(
					'label' => match ( $type ) {
						'lead'    => (string) $record->get( 'title' ),
						'contact' => method_exists( $record, 'full_name' ) ? $record->full_name() : '',
						default   => (string) $record->get( 'name' ),
					},
					'url'   => current_user_can( $cap )
						? \LeadFlow\CRM\Admin\Menu::url(
							$slug,
							array(
								'action' => 'view',
								'id'     => $record->id(),
							)
						)
						: '',
				);
			}
		}

		return $links;
	}

	/**
	 * Whether a task is overdue (open and past due).
	 *
	 * @param Model $task Task.
	 * @return bool
	 */
	public static function is_overdue( Model $task ): bool {
		return $task instanceof Task && $task->is_overdue();
	}
}
