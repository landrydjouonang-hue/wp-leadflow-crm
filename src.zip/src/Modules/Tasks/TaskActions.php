<?php
/**
 * Task actions: complete/reopen (AJAX + fallback) and quick add.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Tasks;

use LeadFlow\CRM\Admin\Notices;
use LeadFlow\CRM\Data\RecordNotFoundException;
use LeadFlow\CRM\Data\ValidationException;
use LeadFlow\CRM\Security\Guard;
use LeadFlow\CRM\Security\Input;
use LeadFlow\CRM\Security\Nonce;
use LeadFlow\CRM\Support\Format;
use LeadFlow\CRM\Support\Users;

defined( 'ABSPATH' ) || exit;

/**
 * State changes for tasks outside the edit form.
 */
final class TaskActions {

	/** Record types a task can be quick-added to. */
	private const PARENTS = array(
		'company' => 'companies',
		'contact' => 'contacts',
		'lead'    => 'leads',
	);

	/**
	 * Constructor.
	 *
	 * @param TasksAdmin $admin Tasks admin controller.
	 */
	public function __construct( private TasksAdmin $admin ) {}

	/**
	 * Registers hooks.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'wp_ajax_leadflow_crm_toggle_task', array( $this, 'ajax_toggle' ) );
		add_action( 'admin_post_leadflow_crm_toggle_task', array( $this, 'handle_toggle' ) );
		add_action( 'admin_post_leadflow_crm_quick_task', array( $this, 'handle_quick_add' ) );
	}

	/**
	 * AJAX: marks a task completed (done=1) or reopens it (done=0).
	 *
	 * @return void
	 */
	public function ajax_toggle(): void {
		Guard::verify_ajax( 'task', $this->admin->cap( 'view' ) );

		$id   = Input::int( 'task_id', 'post' );
		$done = Input::bool( 'done', 'post' );

		if ( ! current_user_can( $this->admin->meta_cap( 'edit' ), $id ) ) {
			wp_send_json_error( array( 'message' => __( 'You are not allowed to change this task.', 'wp-leadflow-crm' ) ), 403 );
		}

		try {
			$task = $this->toggle( $id, $done );
		} catch ( RecordNotFoundException $e ) {
			wp_send_json_error( array( 'message' => __( 'This task no longer exists. Please reload the page.', 'wp-leadflow-crm' ) ), 404 );
		}

		wp_send_json_success(
			array(
				'id'            => $task->id(),
				'status'        => (string) $task->get( 'status' ),
				'status_label'  => $this->admin->status_labels()[ (string) $task->get( 'status' ) ] ?? '',
				'overdue'       => TasksAdmin::is_overdue( $task ),
				'overdue_count' => $this->admin->tasks()->overdue_count( get_current_user_id() ),
				'message'       => $done
					/* translators: %s: Task title. */
					? sprintf( __( 'Task “%s” completed.', 'wp-leadflow-crm' ), (string) $task->get( 'title' ) )
					/* translators: %s: Task title. */
					: sprintf( __( 'Task “%s” reopened.', 'wp-leadflow-crm' ), (string) $task->get( 'title' ) ),
			)
		);
	}

	/**
	 * Link fallback (row action / no JavaScript).
	 *
	 * @return void
	 */
	public function handle_toggle(): void {
		$id = Input::int( 'task_id' );

		if ( ! Nonce::verify( Input::text( Nonce::FIELD ), 'toggle_task_' . $id ) ) {
			wp_nonce_ays( '' );
		}

		Guard::authorize( $this->admin->meta_cap( 'edit' ), $id );

		try {
			$done = Input::bool( 'done', 'get' );
			$this->toggle( $id, $done );
			Notices::flash( 'success', $done ? __( 'Task completed.', 'wp-leadflow-crm' ) : __( 'Task reopened.', 'wp-leadflow-crm' ) );
		} catch ( RecordNotFoundException $e ) {
			Notices::flash( 'error', __( 'This task no longer exists.', 'wp-leadflow-crm' ) );
		}

		$referer = wp_get_referer();
		wp_safe_redirect( false !== $referer ? $referer : $this->admin->url() );
		exit;
	}

	/**
	 * Quick add from a company/contact/lead screen.
	 *
	 * @return void
	 */
	public function handle_quick_add(): void {
		$parent    = Input::one_of( 'parent', array_keys( self::PARENTS ), '', 'post' );
		$parent_id = Input::int( 'parent_id', 'post' );

		check_admin_referer( Nonce::action( 'quick_task_' . $parent . '_' . $parent_id ), Nonce::FIELD );
		Guard::authorize( $this->admin->cap( 'edit' ) );

		if ( '' === $parent ) {
			Guard::authorize( 'do_not_allow' );
		}

		Guard::authorize( 'leadflow_view_' . self::PARENTS[ $parent ] );

		$data = array(
			$parent . '_id' => $parent_id,
			'title'         => Input::text( 'title', 'post' ),
			'priority'      => Input::one_of( 'priority', array_keys( TasksAdmin::priority_labels() ), 'normal', 'post' ),
		);

		$due = Input::text( 'due_at', 'post' );

		if ( '' !== $due ) {
			$data['due_at'] = Format::to_utc( $due );
		}

		// Only users who may edit others' tasks can assign them to someone else.
		$assignee = Input::int( 'assigned_to', 'post' );

		if ( $assignee > 0 && current_user_can( $this->admin->cap( 'edit_others' ) ) && isset( Users::crm_users()[ $assignee ] ) ) {
			$data['assigned_to'] = $assignee;
		}

		try {
			$this->admin->tasks()->create( $data );
			Notices::flash( 'success', __( 'Task added.', 'wp-leadflow-crm' ) );
		} catch ( ValidationException $e ) {
			Notices::flash( 'error', implode( ' ', $e->errors() ) );
		}

		$referer = wp_get_referer();
		wp_safe_redirect( ( false !== $referer ? strtok( $referer, '#' ) : $this->admin->url() ) . '#lf-panel-tasks' );
		exit;
	}

	/**
	 * Applies the completion state.
	 *
	 * @param int  $id   Task id.
	 * @param bool $done Completed?
	 * @return \LeadFlow\CRM\Data\Model
	 * @throws RecordNotFoundException When the task is missing or trashed.
	 */
	private function toggle( int $id, bool $done ): \LeadFlow\CRM\Data\Model {
		$task = $this->admin->tasks()->find( $id );

		if ( null === $task ) {
			throw new RecordNotFoundException( 'task', $id );
		}

		$status = $done ? 'completed' : 'pending';

		return $status === $task->get( 'status' ) ? $task : $this->admin->tasks()->update( $id, array( 'status' => $status ) );
	}
}
