<?php
/**
 * Tasks list table.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Tasks;

use LeadFlow\CRM\Admin\Crud\EntityListTable;
use LeadFlow\CRM\Admin\UI;
use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\Task;
use LeadFlow\CRM\Data\Repositories\TaskRepository;
use LeadFlow\CRM\Security\Input;
use LeadFlow\CRM\Security\Nonce;
use LeadFlow\CRM\Support\Format;
use LeadFlow\CRM\Support\Users;

defined( 'ABSPATH' ) || exit;

/**
 * Tasks table with "Overdue" and "My tasks" views, completion checkboxes
 * (AJAX) and overdue highlighting.
 */
final class TasksListTable extends EntityListTable {

	/**
	 * Related record links of the current page.
	 *
	 * @var array<int, array<string, array{label: string, url: string}>>
	 */
	private array $related = array();

	/**
	 * Cached view counts.
	 *
	 * @var array<string, array{0: string, 1: int}>|null
	 */
	private ?array $extra = null;

	/**
	 * {@inheritDoc}
	 */
	public function get_columns(): array {
		return array(
			'cb'          => '<input type="checkbox" />',
			'done'        => '<span class="screen-reader-text">' . esc_html__( 'Completed', 'wp-leadflow-crm' ) . '</span><span class="dashicons dashicons-yes" aria-hidden="true"></span>',
			'title'       => __( 'Task', 'wp-leadflow-crm' ),
			'related'     => __( 'Related to', 'wp-leadflow-crm' ),
			'assigned_to' => __( 'Assigned to', 'wp-leadflow-crm' ),
			'priority'    => __( 'Priority', 'wp-leadflow-crm' ),
			'status'      => __( 'Status', 'wp-leadflow-crm' ),
			'due_at'      => __( 'Due', 'wp-leadflow-crm' ),
			'created_at'  => __( 'Created', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_sortable_columns(): array {
		return array(
			'title'      => array( 'title', false ),
			'due_at'     => array( 'due_at', false ),
			'created_at' => array( 'created_at', true ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_primary_column_name(): string {
		return 'title';
	}

	/**
	 * Soonest due first; undated tasks last.
	 *
	 * {@inheritDoc}
	 */
	protected function default_order(): array {
		return array( 'due_at', 'asc' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function extra_views(): array {
		if ( null === $this->extra ) {
			$user = get_current_user_id();

			$this->extra = array(
				'overdue' => array( __( 'Overdue', 'wp-leadflow-crm' ), $this->repository->count( TaskRepository::overdue_args() ) ),
				'mine'    => array(
					__( 'My open tasks', 'wp-leadflow-crm' ),
					$this->repository->count(
						array(
							'where' => array(
								'assigned_to' => $user,
								'status'      => array(
									'op'    => 'NOT IN',
									'value' => Task::CLOSED_STATUSES,
								),
							),
						)
					),
				),
			);
		}

		return $this->extra;
	}

	/**
	 * {@inheritDoc}
	 */
	protected function status_args( array $args, string $status ): array {
		$args['where'] = (array) ( $args['where'] ?? array() );

		if ( 'overdue' === $status ) {
			$args['where'] = array_merge( $args['where'], TaskRepository::overdue_args()['where'] );
			return $args;
		}

		if ( 'mine' === $status ) {
			$args['where']['assigned_to'] = get_current_user_id();
			$args['where']['status']      = array(
				'op'    => 'NOT IN',
				'value' => Task::CLOSED_STATUSES,
			);
			return $args;
		}

		return parent::status_args( $args, $status );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function filter_args(): array {
		$where = array();

		$assignee = Input::int( 'assignee' );
		if ( $assignee > 0 ) {
			$where['assigned_to'] = $assignee;
		}

		$priority = Input::one_of( 'priority', array_keys( TasksAdmin::priority_labels() ), '' );
		if ( '' !== $priority ) {
			$where['priority'] = $priority;
		}

		foreach ( array( 'lead_id', 'company_id', 'contact_id' ) as $column ) {
			$id = Input::int( $column );
			if ( $id > 0 ) {
				$where[ $column ] = $id;
			}
		}

		// Due window, in the site timezone.
		$due = Input::one_of( 'due', array( 'today', 'week', 'none' ), '' );

		if ( 'none' === $due ) {
			$where['due_at'] = null;
		} elseif ( '' !== $due ) {
			$end             = 'today' === $due ? 'tomorrow' : '+7 days';
			$where['due_at'] = array(
				'op'    => '<',
				'value' => Format::to_utc( ( new \DateTimeImmutable( $end, wp_timezone() ) )->setTime( 0, 0 )->format( 'Y-m-d H:i' ) ),
			);
		}

		return array(
			'where'      => $where,
			'nulls_last' => true,
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function render_filters(): void {
		$this->filter_select( 'assignee', __( 'Filter by assignee', 'wp-leadflow-crm' ), Users::crm_users(), __( 'All assignees', 'wp-leadflow-crm' ) );
		$this->filter_select( 'priority', __( 'Filter by priority', 'wp-leadflow-crm' ), TasksAdmin::priority_labels(), __( 'All priorities', 'wp-leadflow-crm' ) );
		$this->filter_select(
			'due',
			__( 'Filter by due date', 'wp-leadflow-crm' ),
			array(
				'today' => __( 'Due today (or earlier)', 'wp-leadflow-crm' ),
				'week'  => __( 'Due in the next 7 days', 'wp-leadflow-crm' ),
				'none'  => __( 'No due date', 'wp-leadflow-crm' ),
			),
			__( 'Any due date', 'wp-leadflow-crm' )
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function prefetch( array $items ): void {
		$this->related = TasksAdmin::related_links( $items );
	}

	/**
	 * Row with state classes (completed / overdue).
	 *
	 * @param Model $item Row.
	 * @return void
	 */
	public function single_row( $item ): void {
		$classes = array();

		if ( 'completed' === $item->get( 'status' ) ) {
			$classes[] = 'is-completed';
		} elseif ( TasksAdmin::is_overdue( $item ) ) {
			$classes[] = 'is-overdue';
		}

		printf( '<tr class="%1$s" data-task-row="%2$d">', esc_attr( implode( ' ', $classes ) ), (int) $item->id() );
		$this->single_row_columns( $item );
		echo '</tr>';
	}

	/**
	 * Completion checkbox (AJAX; the row action is the no-JS fallback).
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_done( Model $item ): string {
		return self::toggle( $item, $this->is_trash() );
	}

	/**
	 * Completion checkbox markup (shared with panels and the dashboard).
	 *
	 * @param Model $task     Task.
	 * @param bool  $disabled Force disabled.
	 * @return string
	 */
	public static function toggle( Model $task, bool $disabled = false ): string {
		$can = ! $disabled && ! $task->is_trashed() && current_user_can( 'leadflow_edit_task', $task->id() );

		return sprintf(
			'<input type="checkbox" class="lf-task-toggle hide-if-no-js" data-lf-task-toggle="%1$d" %2$s %3$s aria-label="%4$s" />',
			(int) $task->id(),
			checked( 'completed', $task->get( 'status' ), false ),
			disabled( $can, false, false ),
			esc_attr(
				sprintf(
					/* translators: %s: Task title. */
					__( 'Completed: %s', 'wp-leadflow-crm' ),
					(string) $task->get( 'title' )
				)
			)
		);
	}

	/**
	 * Title column.
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_title( Model $item ): string {
		return $this->primary_cell( $item, wp_trim_words( (string) $item->get( 'description', '' ), 12 ) );
	}

	/**
	 * Related records column.
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_related( Model $item ): string {
		$links = $this->related[ $item->id() ] ?? array();

		if ( empty( $links ) ) {
			return UI::text( '' );
		}

		$html = array();

		foreach ( $links as $link ) {
			$html[] = '' !== $link['url']
				? sprintf( '<a href="%1$s">%2$s</a>', esc_url( $link['url'] ), esc_html( $link['label'] ) )
				: esc_html( $link['label'] );
		}

		return implode( '<br />', $html );
	}

	/**
	 * Assignee column.
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_assigned_to( Model $item ): string {
		return UI::text( Format::user( $item->get( 'assigned_to' ) ) );
	}

	/**
	 * Priority column.
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_priority( Model $item ): string {
		$priority = (string) $item->get( 'priority', 'normal' );

		return UI::badge( 'priority-' . $priority, TasksAdmin::priority_labels()[ $priority ] ?? $priority );
	}

	/**
	 * Due column with overdue indicator.
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_due_at( Model $item ): string {
		return self::due_label( $item );
	}

	/**
	 * Due date text with an "Overdue" pill (shared).
	 *
	 * @param Model $task Task.
	 * @return string
	 */
	public static function due_label( Model $task ): string {
		$due = $task->get( 'due_at' );

		if ( null === $due ) {
			return UI::text( '' );
		}

		$html = sprintf(
			'<time datetime="%1$s">%2$s</time>',
			esc_attr( Format::iso( $due ) ),
			esc_html( Format::due( $due ) )
		);

		if ( TasksAdmin::is_overdue( $task ) ) {
			$html .= ' <span class="lf-pill lf-pill--overdue" data-lf-overdue>' . esc_html__( 'Overdue', 'wp-leadflow-crm' ) . '</span>';
		}

		return $html;
	}

	/**
	 * "Complete" / "Reopen" row action (works without JavaScript).
	 *
	 * {@inheritDoc}
	 */
	protected function extra_row_actions( Model $item, string $title ): array {
		if ( ! current_user_can( 'leadflow_edit_task', $item->id() ) ) {
			return array();
		}

		$done = 'completed' === $item->get( 'status' );
		$url  = Nonce::url(
			add_query_arg(
				array(
					'action'  => 'leadflow_crm_toggle_task',
					'task_id' => $item->id(),
					'done'    => $done ? 0 : 1,
				),
				admin_url( 'admin-post.php' )
			),
			'toggle_task_' . $item->id()
		);

		return array(
			'toggle' => $this->action_link( $url, $done ? __( 'Reopen', 'wp-leadflow-crm' ) : __( 'Complete', 'wp-leadflow-crm' ), $title ),
		);
	}
}
