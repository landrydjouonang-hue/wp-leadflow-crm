<?php
/**
 * System status report.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Settings;

use LeadFlow\CRM\Core\Installer;
use LeadFlow\CRM\Database\MigrationRepository;
use LeadFlow\CRM\Database\Migrator;
use LeadFlow\CRM\Database\Schema;
use LeadFlow\CRM\Database\Table;
use LeadFlow\CRM\Security\Capabilities;

defined( 'ABSPATH' ) || exit;

/**
 * Environment and installation health, for support and troubleshooting.
 */
final class SystemStatus {

	/**
	 * Constructor.
	 *
	 * @param Migrator $migrator Migrator.
	 */
	public function __construct( private Migrator $migrator ) {}

	/**
	 * Report rows.
	 *
	 * @return array<int, array{label: string, value: string, status: string}>
	 */
	public function rows(): array {
		global $wpdb;

		$installed = Installer::installed_version();
		$pending   = count( $this->migrator->pending() );
		$error     = $this->migrator->last_error();
		$tracking  = Table::exists( Table::name( MigrationRepository::TABLE ) );

		$rows = array(
			$this->row(
				__( 'Plugin version', 'wp-leadflow-crm' ),
				LEADFLOW_CRM_VERSION
			),
			$this->row(
				__( 'Installed version', 'wp-leadflow-crm' ),
				$installed ?? __( 'Not installed', 'wp-leadflow-crm' ),
				LEADFLOW_CRM_VERSION === $installed ? 'ok' : 'warning'
			),
			$this->row(
				__( 'Migrations table', 'wp-leadflow-crm' ),
				$tracking ? __( 'Present', 'wp-leadflow-crm' ) : __( 'Missing', 'wp-leadflow-crm' ),
				$tracking ? 'ok' : 'error'
			),
			$this->row(
				__( 'Pending migrations', 'wp-leadflow-crm' ),
				(string) $pending,
				0 === $pending ? 'ok' : 'warning'
			),
			$this->row(
				__( 'Last migration error', 'wp-leadflow-crm' ),
				null === $error ? __( 'None', 'wp-leadflow-crm' ) : $error['migration'] . ': ' . $error['message'],
				null === $error ? 'ok' : 'error'
			),
			$this->row(
				__( 'Database schema version', 'wp-leadflow-crm' ),
				$this->migrator->current_version() ?? __( 'None', 'wp-leadflow-crm' )
			),
			$this->row(
				__( 'CRM tables', 'wp-leadflow-crm' ),
				$this->tables_status(),
				'' === $this->missing_tables() ? 'ok' : 'error'
			),
			$this->row(
				__( 'Foreign keys', 'wp-leadflow-crm' ),
				Table::supports_foreign_keys( Table::name( Schema::CONTACTS ) )
					? __( 'Enforced by the database (InnoDB)', 'wp-leadflow-crm' )
					: __( 'Enforced by LeadFlow CRM (storage engine has no foreign keys)', 'wp-leadflow-crm' ),
				'ok'
			),
			$this->row(
				__( 'CRM roles', 'wp-leadflow-crm' ),
				$this->roles_status(),
				'' === $this->missing_roles() ? 'ok' : 'error'
			),
			$this->row(
				__( 'PHP version', 'wp-leadflow-crm' ),
				PHP_VERSION,
				version_compare( PHP_VERSION, LEADFLOW_CRM_MIN_PHP, '>=' ) ? 'ok' : 'error'
			),
			$this->row(
				__( 'WordPress version', 'wp-leadflow-crm' ),
				get_bloginfo( 'version' ),
				version_compare( get_bloginfo( 'version' ), LEADFLOW_CRM_MIN_WP, '>=' ) ? 'ok' : 'error'
			),
			$this->row(
				__( 'Database server', 'wp-leadflow-crm' ),
				(string) $wpdb->db_server_info()
			),
			$this->row(
				__( 'Database charset', 'wp-leadflow-crm' ),
				(string) $wpdb->charset,
				'utf8mb4' === $wpdb->charset ? 'ok' : 'warning'
			),
			$this->row(
				__( 'Multisite', 'wp-leadflow-crm' ),
				is_multisite() ? __( 'Yes', 'wp-leadflow-crm' ) : __( 'No', 'wp-leadflow-crm' )
			),
			$this->row(
				__( 'Debug mode', 'wp-leadflow-crm' ),
				defined( 'WP_DEBUG' ) && WP_DEBUG ? __( 'Enabled', 'wp-leadflow-crm' ) : __( 'Disabled', 'wp-leadflow-crm' )
			),
			$this->row(
				__( 'WP-Cron', 'wp-leadflow-crm' ),
				defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ? __( 'Disabled (server cron expected)', 'wp-leadflow-crm' ) : __( 'Enabled', 'wp-leadflow-crm' )
			),
			$this->row(
				__( 'PHP memory limit', 'wp-leadflow-crm' ),
				(string) ini_get( 'memory_limit' )
			),
			$this->row(
				__( 'Site language', 'wp-leadflow-crm' ),
				get_locale()
			),
		);

		/**
		 * Filters the system status rows.
		 *
		 * @param array<int, array{label: string, value: string, status: string}> $rows Rows.
		 */
		return (array) apply_filters( 'leadflow_crm_system_status', $rows );
	}

	/**
	 * Builds a row.
	 *
	 * @param string $label  Label.
	 * @param string $value  Value.
	 * @param string $status ok|warning|error|info.
	 * @return array{label: string, value: string, status: string}
	 */
	private function row( string $label, string $value, string $status = 'info' ): array {
		return array(
			'label'  => $label,
			'value'  => $value,
			'status' => $status,
		);
	}

	/**
	 * Comma-separated list of missing core CRM tables.
	 *
	 * @return string
	 */
	private function missing_tables(): string {
		$missing = array();

		foreach ( array( Schema::COMPANIES, Schema::CONTACTS, Schema::LEADS, Schema::ACTIVITIES, Schema::NOTES, Schema::TASKS, Schema::FOLLOW_UPS ) as $short ) {
			if ( ! Table::exists( Table::name( $short ) ) ) {
				$missing[] = $short;
			}
		}

		return implode( ', ', $missing );
	}

	/**
	 * Human-readable tables status.
	 *
	 * @return string
	 */
	private function tables_status(): string {
		$missing = $this->missing_tables();

		if ( '' !== $missing ) {
			/* translators: %s: Comma-separated table names. */
			return sprintf( __( 'Missing: %s', 'wp-leadflow-crm' ), $missing );
		}

		/* translators: %d: Number of tables. */
		return sprintf( __( '%d tables present', 'wp-leadflow-crm' ), count( Table::all_existing() ) );
	}

	/**
	 * Comma-separated list of missing custom roles.
	 *
	 * @return string
	 */
	private function missing_roles(): string {
		$missing = array();

		foreach ( Capabilities::custom_roles() as $slug => $name ) {
			if ( null === get_role( $slug ) ) {
				$missing[] = $name;
			}
		}

		return implode( ', ', $missing );
	}

	/**
	 * Human-readable roles status.
	 *
	 * @return string
	 */
	private function roles_status(): string {
		$missing = $this->missing_roles();

		if ( '' !== $missing ) {
			/* translators: %s: Comma-separated role names. */
			return sprintf( __( 'Missing: %s', 'wp-leadflow-crm' ), $missing );
		}

		return implode( ', ', Capabilities::custom_roles() );
	}
}
