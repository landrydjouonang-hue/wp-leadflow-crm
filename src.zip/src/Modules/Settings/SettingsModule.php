<?php
/**
 * Settings module.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Settings;

use LeadFlow\CRM\Admin\Menu;
use LeadFlow\CRM\Admin\Page;
use LeadFlow\CRM\Admin\View;
use LeadFlow\CRM\Contracts\Module;
use LeadFlow\CRM\Contracts\ProvidesRestControllers;
use LeadFlow\CRM\Database\Migrator;
use LeadFlow\CRM\Plugin;
use LeadFlow\CRM\Security\Capabilities;
use LeadFlow\CRM\Security\Guard;
use LeadFlow\CRM\Security\Input;
use LeadFlow\CRM\Settings\Registry;
use LeadFlow\CRM\Settings\Settings;
use LeadFlow\CRM\Support\Logger;

defined( 'ABSPATH' ) || exit;

/**
 * Settings screen, core settings fields and the system status report.
 */
final class SettingsModule implements Module, ProvidesRestControllers {

	/** Settings page slug. */
	public const PAGE_SLUG = 'leadflow-crm-settings';

	/**
	 * Plugin instance, set on boot.
	 *
	 * @var Plugin|null
	 */
	private ?Plugin $plugin = null;

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'settings';
	}

	/**
	 * {@inheritDoc}
	 */
	public function boot( Plugin $plugin ): void {
		$this->plugin = $plugin;

		$plugin->get( Menu::class )->add(
			new Page(
				self::PAGE_SLUG,
				__( 'CRM Settings', 'wp-leadflow-crm' ),
				__( 'Settings', 'wp-leadflow-crm' ),
				Capabilities::MANAGE_SETTINGS,
				array( $this, 'render' ),
				100
			)
		);

		$this->register_fields( $plugin->get( Registry::class ) );
	}

	/**
	 * {@inheritDoc}
	 */
	public function rest_controllers(): array {
		return array( new SystemStatusController( fn() => $this->status() ) );
	}

	/**
	 * Core tabs and fields.
	 *
	 * @param Registry $registry Settings registry.
	 * @return void
	 */
	private function register_fields( Registry $registry ): void {
		$registry->add_tab( 'general', __( 'General', 'wp-leadflow-crm' ), 10 );
		$registry->add_tab( 'advanced', __( 'Advanced', 'wp-leadflow-crm' ), 90 );
		$registry->add_tab( 'status', __( 'System status', 'wp-leadflow-crm' ), 100, array( $this, 'render_status' ) );

		$registry->add_field(
			'company_name',
			array(
				'tab'         => 'general',
				'label'       => __( 'Business name', 'wp-leadflow-crm' ),
				'type'        => 'text',
				'default'     => get_bloginfo( 'name' ),
				'description' => __( 'Used in CRM emails and exports.', 'wp-leadflow-crm' ),
			)
		);

		$registry->add_field(
			'default_currency',
			array(
				'tab'         => 'general',
				'label'       => __( 'Default currency', 'wp-leadflow-crm' ),
				'type'        => 'select',
				'default'     => 'USD',
				'options'     => self::currencies(),
				'description' => __( 'Currency used for new deal values.', 'wp-leadflow-crm' ),
			)
		);

		$registry->add_field(
			'items_per_page',
			array(
				'tab'         => 'general',
				'label'       => __( 'Records per page', 'wp-leadflow-crm' ),
				'type'        => 'number',
				'default'     => 20,
				'min'         => 5,
				'max'         => 100,
				'description' => __( 'Number of rows shown in CRM lists (5–100).', 'wp-leadflow-crm' ),
			)
		);

		$registry->add_field(
			'delete_data_on_uninstall',
			array(
				'tab'         => 'advanced',
				'label'       => __( 'Delete all CRM data when the plugin is deleted', 'wp-leadflow-crm' ),
				'type'        => 'checkbox',
				'default'     => false,
				'description' => __( 'Permanently removes all CRM records, settings and CRM roles when you delete the plugin from the Plugins screen. Deactivating never deletes data. This cannot be undone.', 'wp-leadflow-crm' ),
			)
		);
	}

	/**
	 * Supported currencies.
	 *
	 * @return array<string, string> ISO code => label.
	 */
	public static function currencies(): array {
		$currencies = array(
			'USD' => __( 'US Dollar (USD)', 'wp-leadflow-crm' ),
			'EUR' => __( 'Euro (EUR)', 'wp-leadflow-crm' ),
			'GBP' => __( 'British Pound (GBP)', 'wp-leadflow-crm' ),
			'CAD' => __( 'Canadian Dollar (CAD)', 'wp-leadflow-crm' ),
			'AUD' => __( 'Australian Dollar (AUD)', 'wp-leadflow-crm' ),
			'CHF' => __( 'Swiss Franc (CHF)', 'wp-leadflow-crm' ),
			'JPY' => __( 'Japanese Yen (JPY)', 'wp-leadflow-crm' ),
			'INR' => __( 'Indian Rupee (INR)', 'wp-leadflow-crm' ),
			'XAF' => __( 'Central African CFA Franc (XAF)', 'wp-leadflow-crm' ),
			'XOF' => __( 'West African CFA Franc (XOF)', 'wp-leadflow-crm' ),
			'NGN' => __( 'Nigerian Naira (NGN)', 'wp-leadflow-crm' ),
			'ZAR' => __( 'South African Rand (ZAR)', 'wp-leadflow-crm' ),
		);

		/**
		 * Filters the currencies offered in settings.
		 *
		 * @param array<string, string> $currencies ISO code => label.
		 */
		return (array) apply_filters( 'leadflow_crm_currencies', $currencies );
	}

	/**
	 * Renders the settings page.
	 *
	 * @return void
	 */
	public function render(): void {
		Guard::authorize( Capabilities::MANAGE_SETTINGS );

		$registry = $this->plugin->get( Registry::class );
		$tabs     = $registry->tabs();
		$current  = Input::one_of( 'tab', array_keys( $tabs ), (string) array_key_first( $tabs ) );

		View::render(
			'admin/settings',
			array(
				'tabs'     => $tabs,
				'current'  => $current,
				'registry' => $registry,
				'group'    => Settings::GROUP,
			)
		);
	}

	/**
	 * Renders the System status tab.
	 *
	 * @return void
	 */
	public function render_status(): void {
		View::render(
			'admin/system-status',
			array(
				'rows'        => $this->status(),
				'log_enabled' => Logger::enabled(),
				'log_size'    => Logger::size(),
				'log_lines'   => Logger::enabled() || Logger::size() > 0 ? Logger::tail( 100 ) : array(),
			)
		);
	}

	/**
	 * Builds the status report.
	 *
	 * @return array<int, array{label: string, value: string, status: string}>
	 */
	public function status(): array {
		return ( new SystemStatus( $this->plugin->get( Migrator::class ) ) )->rows();
	}
}
