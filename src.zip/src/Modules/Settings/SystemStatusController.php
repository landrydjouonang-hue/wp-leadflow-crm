<?php
/**
 * System status REST endpoint.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Settings;

use LeadFlow\CRM\Rest\Controller;
use LeadFlow\CRM\Security\Capabilities;

defined( 'ABSPATH' ) || exit;

/**
 * GET /wp-json/leadflow-crm/v1/system-status
 */
final class SystemStatusController extends Controller {

	/**
	 * Report provider.
	 *
	 * @var callable
	 */
	private $provider;

	/**
	 * Constructor.
	 *
	 * @param callable $provider Returns the status rows.
	 */
	public function __construct( callable $provider ) {
		$this->provider = $provider;
	}

	/**
	 * {@inheritDoc}
	 */
	public function register_routes(): void {
		register_rest_route(
			self::REST_NAMESPACE,
			'/system-status',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_status' ),
					'permission_callback' => $this->require_capability( Capabilities::MANAGE_SETTINGS ),
				),
			)
		);
	}

	/**
	 * Returns the report.
	 *
	 * @return \WP_REST_Response
	 */
	public function get_status(): \WP_REST_Response {
		return rest_ensure_response(
			array(
				'generated_at' => gmdate( 'c' ),
				'rows'         => ( $this->provider )(),
			)
		);
	}
}
