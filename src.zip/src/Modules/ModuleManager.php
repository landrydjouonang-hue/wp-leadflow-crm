<?php
/**
 * Module manager.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules;

use LeadFlow\CRM\Contracts\Migration;
use LeadFlow\CRM\Contracts\Module;
use LeadFlow\CRM\Contracts\ProvidesCapabilities;
use LeadFlow\CRM\Contracts\ProvidesMigrations;
use LeadFlow\CRM\Contracts\ProvidesRestControllers;
use LeadFlow\CRM\Modules\Access\AccessModule;
use LeadFlow\CRM\Modules\Activities\ActivitiesModule;
use LeadFlow\CRM\Modules\Api\ApiModule;
use LeadFlow\CRM\Modules\Companies\CompaniesModule;
use LeadFlow\CRM\Modules\Emails\EmailsModule;
use LeadFlow\CRM\Modules\FollowUps\FollowUpsModule;
use LeadFlow\CRM\Modules\ImportExport\ImportExportModule;
use LeadFlow\CRM\Modules\Templates\TemplatesModule;
use LeadFlow\CRM\Modules\Tasks\TasksModule;
use LeadFlow\CRM\Modules\Contacts\ContactsModule;
use LeadFlow\CRM\Modules\Dashboard\DashboardModule;
use LeadFlow\CRM\Modules\Leads\LeadsModule;
use LeadFlow\CRM\Modules\Maintenance\MaintenanceModule;
use LeadFlow\CRM\Modules\Settings\SettingsModule;
use LeadFlow\CRM\Plugin;
use LeadFlow\CRM\Rest\Controller;

defined( 'ABSPATH' ) || exit;

/**
 * Discovers modules and aggregates what they provide.
 */
final class ModuleManager {

	/**
	 * Loaded modules keyed by id.
	 *
	 * @var array<string, Module>|null
	 */
	private ?array $modules = null;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin instance.
	 */
	public function __construct( private Plugin $plugin ) {}

	/**
	 * Built-in module classes, in load order.
	 *
	 * New feature areas are added here (or through the filter below).
	 *
	 * @return string[]
	 */
	private function default_modules(): array {
		return array(
			DashboardModule::class,
			LeadsModule::class,
			CompaniesModule::class,
			ContactsModule::class,
			TasksModule::class,
			ActivitiesModule::class,
			FollowUpsModule::class,
			TemplatesModule::class,
			EmailsModule::class,
			ImportExportModule::class,
			ApiModule::class,
			AccessModule::class,
			MaintenanceModule::class,
			SettingsModule::class,
		);
	}

	/**
	 * Returns all modules keyed by id.
	 *
	 * @return array<string, Module>
	 */
	public function all(): array {
		if ( null !== $this->modules ) {
			return $this->modules;
		}

		/**
		 * Filters the modules LeadFlow CRM loads.
		 *
		 * @param array<int, string|Module> $modules Module class names or instances.
		 */
		$definitions = (array) apply_filters( 'leadflow_crm_modules', $this->default_modules() );

		$this->modules = array();

		foreach ( $definitions as $definition ) {
			$module = is_string( $definition ) && class_exists( $definition ) ? new $definition() : $definition;

			if ( ! $module instanceof Module ) {
				_doing_it_wrong(
					__METHOD__,
					esc_html__( 'LeadFlow CRM modules must implement LeadFlow\CRM\Contracts\Module.', 'wp-leadflow-crm' ),
					'0.1.0'
				);
				continue;
			}

			$this->modules[ $module->id() ] = $module;
		}

		return $this->modules;
	}

	/**
	 * Whether a module is loaded.
	 *
	 * @param string $id Module id.
	 * @return bool
	 */
	public function has( string $id ): bool {
		return isset( $this->all()[ $id ] );
	}

	/**
	 * Boots every module.
	 *
	 * @return void
	 */
	public function boot_all(): void {
		foreach ( $this->all() as $module ) {
			$module->boot( $this->plugin );
		}
	}

	/**
	 * Migrations from all modules.
	 *
	 * @return Migration[]
	 */
	public function migrations(): array {
		$migrations = array();

		foreach ( $this->all() as $module ) {
			if ( $module instanceof ProvidesMigrations ) {
				foreach ( $module->migrations() as $migration ) {
					if ( $migration instanceof Migration ) {
						$migrations[] = $migration;
					}
				}
			}
		}

		return $migrations;
	}

	/**
	 * Capability map from all modules.
	 *
	 * @return array<string, string[]> Capability => roles.
	 */
	public function capabilities(): array {
		$caps = array();

		foreach ( $this->all() as $module ) {
			if ( $module instanceof ProvidesCapabilities ) {
				foreach ( $module->capabilities() as $cap => $roles ) {
					$caps[ $cap ] = array_values( array_unique( array_merge( $caps[ $cap ] ?? array(), (array) $roles ) ) );
				}
			}
		}

		return $caps;
	}

	/**
	 * REST controllers from all modules.
	 *
	 * @return Controller[]
	 */
	public function rest_controllers(): array {
		$controllers = array();

		foreach ( $this->all() as $module ) {
			if ( $module instanceof ProvidesRestControllers ) {
				foreach ( $module->rest_controllers() as $controller ) {
					if ( $controller instanceof Controller ) {
						$controllers[] = $controller;
					}
				}
			}
		}

		return $controllers;
	}
}
