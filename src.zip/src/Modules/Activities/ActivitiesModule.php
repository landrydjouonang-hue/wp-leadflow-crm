<?php
/**
 * Activities module: timelines and activity logging.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Activities;

use LeadFlow\CRM\Admin\Menu;
use LeadFlow\CRM\Admin\Notices;
use LeadFlow\CRM\Admin\RecordPanels;
use LeadFlow\CRM\Admin\View;
use LeadFlow\CRM\Contracts\Module;
use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\Activity;
use LeadFlow\CRM\Data\Repositories\ActivityRepository;
use LeadFlow\CRM\Data\Repositories\CompanyRepository;
use LeadFlow\CRM\Data\Repositories\ContactRepository;
use LeadFlow\CRM\Data\Repositories\LeadRepository;
use LeadFlow\CRM\Data\Repositories\StageRepository;
use LeadFlow\CRM\Data\ValidationException;
use LeadFlow\CRM\Modules\Dashboard\Sections;
use LeadFlow\CRM\Plugin;
use LeadFlow\CRM\Security\Capabilities;
use LeadFlow\CRM\Security\Guard;
use LeadFlow\CRM\Security\Input;
use LeadFlow\CRM\Security\Nonce;
use LeadFlow\CRM\Support\Format;

defined( 'ABSPATH' ) || exit;

/**
 * Activity timeline on company, contact and lead screens.
 *
 * - View: the parent's view capability (`leadflow_view_{plural}`).
 * - Log an activity: the parent's edit meta capability
 *   (`leadflow_edit_{type}` with the record id).
 * - AJAX: `leadflow_crm_log_activity`, `leadflow_crm_timeline`; the log
 *   form also works without JavaScript (admin-post).
 */
final class ActivitiesModule implements Module {

	/** Parent type => plural. */
	public const PARENTS = array(
		'company' => 'companies',
		'contact' => 'contacts',
		'lead'    => 'leads',
	);

	/** Entries per timeline page. */
	public const PER_PAGE = 20;

	/**
	 * Plugin.
	 *
	 * @var Plugin|null
	 */
	private ?Plugin $plugin = null;

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'activities';
	}

	/**
	 * {@inheritDoc}
	 */
	public function boot( Plugin $plugin ): void {
		$this->plugin = $plugin;

		( new ActivityLogger( $plugin->get( ActivityRepository::class ), $plugin->get( StageRepository::class ) ) )->register();

		add_action( 'leadflow_crm_record_panels', array( $this, 'add_panel' ), 10, 3 );
		add_action( 'wp_ajax_leadflow_crm_log_activity', array( $this, 'ajax_log' ) );
		add_action( 'wp_ajax_leadflow_crm_timeline', array( $this, 'ajax_timeline' ) );
		add_action( 'admin_post_leadflow_crm_log_activity', array( $this, 'handle_log' ) );
		add_action( 'leadflow_crm_dashboard_sections', array( $this, 'dashboard_section' ) );
	}

	/**
	 * Activity types users can log by hand.
	 *
	 * @return array<string, string>
	 */
	public static function manual_types(): array {
		return array(
			'call'    => __( 'Call', 'wp-leadflow-crm' ),
			'email'   => __( 'Email', 'wp-leadflow-crm' ),
			'meeting' => __( 'Meeting', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * Dashicon per activity type.
	 *
	 * @param string $type Type.
	 * @return string
	 */
	public static function icon( string $type ): string {
		$icons = array(
			'note'          => 'edit-page',
			'call'          => 'phone',
			'email'         => 'email',
			'meeting'       => 'groups',
			'task'          => 'yes-alt',
			'follow_up'     => 'calendar-alt',
			'status_change' => 'randomize',
			'created'       => 'plus-alt',
			'updated'       => 'update',
			'system'        => 'admin-generic',
		);

		return $icons[ $type ] ?? 'marker';
	}

	/**
	 * Adds the Activity tab.
	 *
	 * @param RecordPanels $panels Panel registry.
	 * @param string       $type   Record type.
	 * @param Model        $record Record.
	 * @return void
	 */
	public function add_panel( RecordPanels $panels, string $type, Model $record ): void {
		if ( ! isset( self::PARENTS[ $type ] ) ) {
			return;
		}

		$panels->add(
			'activity',
			array(
				'title'  => __( 'Activity', 'wp-leadflow-crm' ),
				'count'  => $this->activities()->count_for_parent( $type, $record->id() ),
				'order'  => 10,
				'render' => fn() => $this->render_timeline( $type, $record ),
			)
		);
	}

	/**
	 * Timeline with the "Log activity" form.
	 *
	 * @param string $type   Record type.
	 * @param Model  $record Record.
	 * @return void
	 */
	public function render_timeline( string $type, Model $record ): void {
		$pages = max( 1, Input::int( 'timeline_page', 'get', 1 ) );
		$items = $this->activities()->timeline( $type, $record->id(), self::PER_PAGE * $pages );
		$total = $this->activities()->count_for_parent( $type, $record->id() );

		View::render(
			'admin/partials/timeline',
			array(
				'parent'    => $type,
				'parent_id' => $record->id(),
				'items'     => $items,
				'origins'   => $this->origins( $items, $type ),
				'has_more'  => $total > count( $items ),
				'next_page' => $pages + 1,
				'can_log'   => ! $record->is_trashed() && current_user_can( 'leadflow_edit_' . $type, $record->id() ),
				'types'     => self::manual_types(),
				'nonce'     => Nonce::create( 'activity' ),
			)
		);
	}

	/**
	 * Renders timeline items to a string.
	 *
	 * @param Activity[] $items   Activities.
	 * @param string     $parent  Parent type being viewed.
	 * @return string
	 */
	private function render_items( array $items, string $parent ): string {
		$origins = $this->origins( $items, $parent );

		ob_start();

		foreach ( $items as $item ) {
			View::render(
				'admin/partials/activity-item',
				array(
					'activity' => $item,
					'origin'   => $origins[ $item->id() ] ?? null,
				)
			);
		}

		return (string) ob_get_clean();
	}

	/**
	 * For entries shown on a company/contact that belong to a more specific
	 * record, the label and URL of that record ("on Website redesign").
	 *
	 * @param Activity[] $items  Activities.
	 * @param string     $parent Parent type being viewed (or '' for the dashboard).
	 * @return array<int, array{label: string, url: string}>
	 */
	public function origins( array $items, string $parent ): array {
		$plugin   = $this->plugin ?? Plugin::instance();
		$wanted   = array(
			'lead'    => array(),
			'contact' => array(),
			'company' => array(),
		);
		$specific = array();

		foreach ( $items as $item ) {
			foreach ( array( 'lead', 'contact', 'company' ) as $type ) {
				$id = (int) $item->get( $type . '_id', 0 );

				if ( $id > 0 ) {
					// The most specific parent other than the one being viewed.
					if ( $type !== $parent ) {
						$wanted[ $type ][]         = $id;
						$specific[ $item->id() ] = array( $type, $id );
					}
					break;
				}
			}
		}

		$records = array(
			'lead'    => $plugin->get( LeadRepository::class )->find_many( $wanted['lead'] ),
			'contact' => $plugin->get( ContactRepository::class )->find_many( $wanted['contact'] ),
			'company' => $plugin->get( CompanyRepository::class )->find_many( $wanted['company'] ),
		);
		$slugs   = array(
			'lead'    => 'leadflow-crm-leads',
			'contact' => 'leadflow-crm-contacts',
			'company' => 'leadflow-crm-companies',
		);
		$origins = array();

		foreach ( $specific as $activity_id => list( $type, $id ) ) {
			$record = $records[ $type ][ $id ] ?? null;

			if ( null === $record ) {
				continue;
			}

			$origins[ $activity_id ] = array(
				'label' => match ( $type ) {
					'lead'    => (string) $record->get( 'title' ),
					'contact' => method_exists( $record, 'full_name' ) ? $record->full_name() : '',
					default   => (string) $record->get( 'name' ),
				},
				'url'   => current_user_can( 'leadflow_view_' . self::PARENTS[ $type ] )
					? Menu::url(
						$slugs[ $type ],
						array(
							'action' => 'view',
							'id'     => $id,
						)
					)
					: '',
			);
		}

		return $origins;
	}

	/**
	 * Validates a posted "log activity" request and creates the entry.
	 *
	 * @return Activity
	 * @throws ValidationException When the data is invalid.
	 */
	private function create_from_request(): Activity {
		$parent    = Input::one_of( 'parent', array_keys( self::PARENTS ), '', 'post' );
		$parent_id = Input::int( 'parent_id', 'post' );
		$type      = Input::one_of( 'type', array_keys( self::manual_types() ), '', 'post' );
		$when      = Input::text( 'occurred_at', 'post' );

		if ( '' === $type ) {
			throw new ValidationException( array( 'type' => __( 'Please choose what kind of activity this was.', 'wp-leadflow-crm' ) ) );
		}

		$description = Input::textarea( 'description', 'post' );

		if ( '' === trim( $description ) ) {
			throw new ValidationException( array( 'description' => __( 'Please describe the activity.', 'wp-leadflow-crm' ) ) );
		}

		$occurred = '' !== $when ? Format::to_utc( $when ) : '';

		if ( '' !== $occurred && $occurred > gmdate( 'Y-m-d H:i:s', time() + 5 * MINUTE_IN_SECONDS ) ) {
			throw new ValidationException( array( 'occurred_at' => __( 'An activity cannot be in the future. Schedule a follow-up instead.', 'wp-leadflow-crm' ) ) );
		}

		/** @var Activity $activity */
		$activity = $this->activities()->create(
			array(
				$parent . '_id' => $parent_id,
				'type'          => $type,
				'subject'       => self::manual_types()[ $type ],
				'description'   => $description,
				'occurred_at'   => $occurred,
			)
		);

		return $activity;
	}

	/**
	 * Checks the parent record permission for logging.
	 *
	 * @return void
	 */
	private function authorize_log(): void {
		$parent    = Input::one_of( 'parent', array_keys( self::PARENTS ), '', 'post' );
		$parent_id = Input::int( 'parent_id', 'post' );

		if ( '' === $parent || ! current_user_can( 'leadflow_edit_' . $parent, $parent_id ) ) {
			if ( wp_doing_ajax() ) {
				wp_send_json_error( array( 'message' => __( 'You are not allowed to log activities on this record.', 'wp-leadflow-crm' ) ), 403 );
			}

			Guard::authorize( 'do_not_allow' );
		}
	}

	/**
	 * AJAX: logs an activity and returns its timeline HTML.
	 *
	 * @return void
	 */
	public function ajax_log(): void {
		Guard::verify_ajax( 'activity', Capabilities::ACCESS_CRM );
		$this->authorize_log();

		try {
			$activity = $this->create_from_request();
		} catch ( ValidationException $e ) {
			wp_send_json_error( array( 'message' => implode( ' ', $e->errors() ) ), 400 );
		}

		wp_send_json_success(
			array(
				'html'    => $this->render_items( array( $activity ), Input::key( 'parent', 'post' ) ),
				'message' => __( 'Activity logged.', 'wp-leadflow-crm' ),
			)
		);
	}

	/**
	 * Form POST fallback for logging an activity.
	 *
	 * @return void
	 */
	public function handle_log(): void {
		check_admin_referer( Nonce::action( 'activity' ), Nonce::FIELD );
		$this->authorize_log();

		try {
			$this->create_from_request();
			Notices::flash( 'success', __( 'Activity logged.', 'wp-leadflow-crm' ) );
		} catch ( ValidationException $e ) {
			Notices::flash( 'error', implode( ' ', $e->errors() ) );
		}

		$referer = wp_get_referer();
		wp_safe_redirect( ( false !== $referer ? strtok( $referer, '#' ) : admin_url() ) . '#lf-panel-activity' );
		exit;
	}

	/**
	 * AJAX: next page of a timeline.
	 *
	 * @return void
	 */
	public function ajax_timeline(): void {
		Guard::verify_ajax( 'activity', Capabilities::ACCESS_CRM );

		$parent    = Input::one_of( 'parent', array_keys( self::PARENTS ), '', 'post' );
		$parent_id = Input::int( 'parent_id', 'post' );
		$page      = max( 1, Input::int( 'page', 'post', 1 ) );

		if ( '' === $parent || ! current_user_can( 'leadflow_view_' . self::PARENTS[ $parent ] ) ) {
			wp_send_json_error( array( 'message' => __( 'You are not allowed to view this timeline.', 'wp-leadflow-crm' ) ), 403 );
		}

		$items = $this->activities()->timeline( $parent, $parent_id, self::PER_PAGE, $page );
		$total = $this->activities()->count_for_parent( $parent, $parent_id );

		wp_send_json_success(
			array(
				'html'     => $this->render_items( $items, $parent ),
				'has_more' => $total > $page * self::PER_PAGE,
				'page'     => $page,
			)
		);
	}

	/**
	 * Replaces the Activities dashboard placeholder with a recent feed.
	 *
	 * @param Sections $sections Dashboard sections.
	 * @return void
	 */
	public function dashboard_section( Sections $sections ): void {
		$sections->add(
			'activities',
			array(
				'title'  => __( 'Recent activity', 'wp-leadflow-crm' ),
				'icon'   => 'backup',
				'order'  => 70,
				'wide'   => true,
				'render' => function (): void {
					$items = $this->activities()->query(
						array(
							'orderby'  => 'occurred_at',
							'order'    => 'DESC',
							'per_page' => 8,
						)
					);

					$origins = $this->origins( $items, '' );

					echo '<ol class="lf-timeline lf-timeline--compact">';
					foreach ( $items as $item ) {
						View::render(
							'admin/partials/activity-item',
							array(
								'activity' => $item,
								'origin'   => $origins[ $item->id() ] ?? null,
							)
						);
					}
					echo '</ol>';

					if ( empty( $items ) ) {
						echo '<p class="lf-empty-text">' . esc_html__( 'Activity on your leads, companies and contacts will appear here.', 'wp-leadflow-crm' ) . '</p>';
					}
				},
			)
		);
	}

	/**
	 * Activity repository.
	 *
	 * @return ActivityRepository
	 */
	private function activities(): ActivityRepository {
		return ( $this->plugin ?? Plugin::instance() )->get( ActivityRepository::class );
	}
}
