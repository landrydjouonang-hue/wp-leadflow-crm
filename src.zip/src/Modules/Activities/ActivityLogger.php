<?php
/**
 * Automatic activity logging.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Activities;

use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\Contact;
use LeadFlow\CRM\Data\Repositories\ActivityRepository;
use LeadFlow\CRM\Data\Repositories\StageRepository;
use LeadFlow\CRM\Support\Format;

defined( 'ABSPATH' ) || exit;

/**
 * Writes timeline entries when CRM records change.
 *
 * Listens to the repository hooks (`leadflow_crm_{entity}_{event}`).
 * Logging never interrupts the action that triggered it. Disable it with:
 *
 *     add_filter( 'leadflow_crm_auto_log_activities', '__return_false' );
 */
final class ActivityLogger {

	/** Record types with their own timeline. */
	private const RECORDS = array( 'company', 'contact', 'lead' );

	/** Columns ignored when describing an update. */
	private const IGNORED = array( 'updated_at', 'updated_by', 'position', 'probability', 'status', 'closed_at' );

	/**
	 * Constructor.
	 *
	 * @param ActivityRepository $activities Activities.
	 * @param StageRepository    $stages     Stages.
	 */
	public function __construct(
		private ActivityRepository $activities,
		private StageRepository $stages
	) {}

	/**
	 * Registers the listeners.
	 *
	 * @return void
	 */
	public function register(): void {
		foreach ( self::RECORDS as $entity ) {
			add_action( "leadflow_crm_{$entity}_created", fn( Model $m ) => $this->record_created( $entity, $m ) );
			add_action( "leadflow_crm_{$entity}_trashed", fn( int $id ) => $this->log( 'system', array( $entity . '_id' => $id ), __( 'Moved to the trash', 'wp-leadflow-crm' ) ) );
			add_action( "leadflow_crm_{$entity}_restored", fn( int $id ) => $this->log( 'system', array( $entity . '_id' => $id ), __( 'Restored from the trash', 'wp-leadflow-crm' ) ) );
		}

		add_action( 'leadflow_crm_lead_updated', array( $this, 'lead_updated' ), 10, 2 );
		add_action( 'leadflow_crm_company_updated', fn( Model $m, Model $p ) => $this->record_updated( 'company', $m, $p ), 10, 2 );
		add_action( 'leadflow_crm_contact_updated', fn( Model $m, Model $p ) => $this->record_updated( 'contact', $m, $p ), 10, 2 );
		add_action( 'leadflow_crm_note_created', array( $this, 'note_created' ) );
		add_action( 'leadflow_crm_task_created', array( $this, 'task_created' ) );
		add_action( 'leadflow_crm_task_updated', array( $this, 'task_updated' ), 10, 2 );
		add_action( 'leadflow_crm_follow_up_created', array( $this, 'follow_up_created' ) );
		add_action( 'leadflow_crm_follow_up_updated', array( $this, 'follow_up_updated' ), 10, 2 );
		add_action( 'leadflow_crm_email_created', array( $this, 'email_created' ) );
	}

	/**
	 * Email sent from the CRM (failed attempts stay in the email log only).
	 *
	 * @param Model $email Email.
	 * @return void
	 */
	public function email_created( Model $email ): void {
		if ( 'sent' !== $email->get( 'status' ) ) {
			return;
		}

		$this->log(
			'email',
			self::parents_of( $email ),
			/* translators: %s: Email subject. */
			sprintf( __( 'Email sent: %s', 'wp-leadflow-crm' ), (string) $email->get( 'subject' ) ),
			/* translators: %s: Recipient address. */
			sprintf( __( 'To: %s', 'wp-leadflow-crm' ), (string) $email->get( 'to_email' ) ),
			array( 'email_id' => $email->id() )
		);
	}

	/**
	 * Company, contact or lead created.
	 *
	 * @param string $entity Entity.
	 * @param Model  $model  Record.
	 * @return void
	 */
	private function record_created( string $entity, Model $model ): void {
		$labels = array(
			'company' => __( 'Company created', 'wp-leadflow-crm' ),
			'contact' => __( 'Contact created', 'wp-leadflow-crm' ),
			'lead'    => __( 'Lead created', 'wp-leadflow-crm' ),
		);

		$this->log( 'created', array( $entity . '_id' => $model->id() ), $labels[ $entity ], $this->title( $entity, $model ) );
	}

	/**
	 * Lead changed: stage changes get their own entry; other important
	 * changes (assignee, value, close date, name) are summarized.
	 *
	 * @param Model $lead     Updated lead.
	 * @param Model $previous Lead before the update.
	 * @return void
	 */
	public function lead_updated( Model $lead, Model $previous ): void {
		$parents = array( 'lead_id' => $lead->id() );

		if ( $lead->get( 'stage' ) !== $previous->get( 'stage' ) ) {
			$from = $this->stages->find_by_slug( (string) $previous->get( 'stage' ) );
			$to   = $this->stages->find_by_slug( (string) $lead->get( 'stage' ) );
			$meta = array(
				'from' => (string) $previous->get( 'stage' ),
				'to'   => (string) $lead->get( 'stage' ),
			);

			if ( 'won' === $lead->get( 'status' ) && 'won' !== $previous->get( 'status' ) ) {
				$subject = __( 'Lead won', 'wp-leadflow-crm' );
			} elseif ( 'lost' === $lead->get( 'status' ) && 'lost' !== $previous->get( 'status' ) ) {
				$subject = __( 'Lead lost', 'wp-leadflow-crm' );
			} else {
				$subject = sprintf(
					/* translators: 1: Previous stage, 2: New stage. */
					__( 'Stage changed from %1$s to %2$s', 'wp-leadflow-crm' ),
					null !== $from ? $from->name() : $meta['from'],
					null !== $to ? $to->name() : $meta['to']
				);
			}

			$this->log( 'status_change', $parents, $subject, (string) $lead->get( 'lost_reason', '' ), $meta );
		}

		$changes = array();

		if ( $lead->get( 'owner_id' ) !== $previous->get( 'owner_id' ) ) {
			$owner     = Format::user( $lead->get( 'owner_id' ) );
			$changes[] = '' !== $owner
				/* translators: %s: User name. */
				? sprintf( __( 'Assigned to %s', 'wp-leadflow-crm' ), $owner )
				: __( 'Unassigned', 'wp-leadflow-crm' );
		}

		if ( (float) $lead->get( 'amount' ) !== (float) $previous->get( 'amount' ) || $lead->get( 'currency' ) !== $previous->get( 'currency' ) ) {
			$changes[] = sprintf(
				/* translators: 1: Old value, 2: New value. */
				__( 'Value changed from %1$s to %2$s', 'wp-leadflow-crm' ),
				Format::money( (float) $previous->get( 'amount' ), (string) $previous->get( 'currency' ) ),
				Format::money( (float) $lead->get( 'amount' ), (string) $lead->get( 'currency' ) )
			);
		}

		if ( $lead->get( 'expected_close_date' ) !== $previous->get( 'expected_close_date' ) ) {
			$date      = $lead->get( 'expected_close_date' );
			$changes[] = null === $date
				? __( 'Expected close date removed', 'wp-leadflow-crm' )
				/* translators: %s: Date. */
				: sprintf( __( 'Expected close date set to %s', 'wp-leadflow-crm' ), (string) wp_date( (string) get_option( 'date_format' ), (int) strtotime( $date . ' 12:00:00 UTC' ) ) );
		}

		if ( $lead->get( 'title' ) !== $previous->get( 'title' ) ) {
			/* translators: %s: New name. */
			$changes[] = sprintf( __( 'Renamed to “%s”', 'wp-leadflow-crm' ), (string) $lead->get( 'title' ) );
		}

		if ( ! empty( $changes ) ) {
			$this->log( 'updated', $parents, __( 'Lead updated', 'wp-leadflow-crm' ), implode( "\n", $changes ) );
		}
	}

	/**
	 * Company or contact details changed.
	 *
	 * @param string $entity   Entity.
	 * @param Model  $model    Updated record.
	 * @param Model  $previous Record before the update.
	 * @return void
	 */
	private function record_updated( string $entity, Model $model, Model $previous ): void {
		$changed = array();

		foreach ( $model->to_array() as $column => $value ) {
			if ( ! in_array( $column, self::IGNORED, true ) && $value !== $previous->get( $column ) ) {
				$changed[] = ucfirst( str_replace( array( '_id', '_' ), array( '', ' ' ), (string) $column ) );
			}
		}

		if ( empty( $changed ) ) {
			return;
		}

		$this->log(
			'updated',
			array( $entity . '_id' => $model->id() ),
			__( 'Details updated', 'wp-leadflow-crm' ),
			/* translators: %s: Comma-separated field names. */
			sprintf( __( 'Changed: %s', 'wp-leadflow-crm' ), implode( ', ', $changed ) ),
			array( 'fields' => $changed )
		);
	}

	/**
	 * Note added.
	 *
	 * @param Model $note Note.
	 * @return void
	 */
	public function note_created( Model $note ): void {
		$this->log(
			'note',
			self::parents_of( $note ),
			__( 'Note added', 'wp-leadflow-crm' ),
			Format::excerpt( (string) $note->get( 'content', '' ), 40 ),
			array( 'note_id' => $note->id() )
		);
	}

	/**
	 * Task added.
	 *
	 * @param Model $task Task.
	 * @return void
	 */
	public function task_created( Model $task ): void {
		$due = Format::due( $task->get( 'due_at' ) );

		$this->log(
			'task',
			self::parents_of( $task ),
			/* translators: %s: Task title. */
			sprintf( __( 'Task added: %s', 'wp-leadflow-crm' ), (string) $task->get( 'title' ) ),
			/* translators: %s: Due date. */
			'' !== $due ? sprintf( __( 'Due %s', 'wp-leadflow-crm' ), $due ) : '',
			array( 'task_id' => $task->id() )
		);
	}

	/**
	 * Task completed or reopened.
	 *
	 * @param Model $task     Updated task.
	 * @param Model $previous Task before the update.
	 * @return void
	 */
	public function task_updated( Model $task, Model $previous ): void {
		if ( $task->get( 'status' ) === $previous->get( 'status' ) ) {
			return;
		}

		$title = (string) $task->get( 'title' );

		if ( 'completed' === $task->get( 'status' ) ) {
			/* translators: %s: Task title. */
			$subject = sprintf( __( 'Task completed: %s', 'wp-leadflow-crm' ), $title );
		} elseif ( 'completed' === $previous->get( 'status' ) ) {
			/* translators: %s: Task title. */
			$subject = sprintf( __( 'Task reopened: %s', 'wp-leadflow-crm' ), $title );
		} elseif ( 'cancelled' === $task->get( 'status' ) ) {
			/* translators: %s: Task title. */
			$subject = sprintf( __( 'Task cancelled: %s', 'wp-leadflow-crm' ), $title );
		} else {
			return;
		}

		$this->log( 'task', self::parents_of( $task ), $subject, '', array( 'task_id' => $task->id() ) );
	}

	/**
	 * Follow-up scheduled.
	 *
	 * @param Model $follow_up Follow-up.
	 * @return void
	 */
	public function follow_up_created( Model $follow_up ): void {
		$this->log(
			'follow_up',
			self::parents_of( $follow_up ),
			/* translators: %s: Follow-up subject. */
			sprintf( __( 'Follow-up scheduled: %s', 'wp-leadflow-crm' ), (string) $follow_up->get( 'subject' ) ),
			Format::due( $follow_up->get( 'scheduled_at' ) ),
			array( 'follow_up_id' => $follow_up->id() )
		);
	}

	/**
	 * Follow-up completed or cancelled.
	 *
	 * @param Model $follow_up Updated follow-up.
	 * @param Model $previous  Follow-up before the update.
	 * @return void
	 */
	public function follow_up_updated( Model $follow_up, Model $previous ): void {
		if ( $follow_up->get( 'status' ) === $previous->get( 'status' ) ) {
			return;
		}

		$subject = (string) $follow_up->get( 'subject' );

		switch ( $follow_up->get( 'status' ) ) {
			case 'completed':
				/* translators: %s: Follow-up subject. */
				$text = sprintf( __( 'Follow-up completed: %s', 'wp-leadflow-crm' ), $subject );
				break;
			case 'cancelled':
				/* translators: %s: Follow-up subject. */
				$text = sprintf( __( 'Follow-up cancelled: %s', 'wp-leadflow-crm' ), $subject );
				break;
			default:
				return;
		}

		$this->log( 'follow_up', self::parents_of( $follow_up ), $text, (string) $follow_up->get( 'outcome', '' ), array( 'follow_up_id' => $follow_up->id() ) );
	}

	/**
	 * Writes an activity (never throws).
	 *
	 * @param string               $type        Type.
	 * @param array<string, mixed> $parents     Parent columns.
	 * @param string               $subject     Subject.
	 * @param string               $description Description.
	 * @param array<string, mixed> $meta        Meta.
	 * @return void
	 */
	private function log( string $type, array $parents, string $subject, string $description = '', array $meta = array() ): void {
		/**
		 * Filters whether CRM changes are logged to the activity timeline.
		 *
		 * @param bool   $enabled Whether to log.
		 * @param string $type    Activity type.
		 */
		if ( ! apply_filters( 'leadflow_crm_auto_log_activities', true, $type ) ) {
			return;
		}

		$parents = array_filter( $parents );

		if ( empty( $parents ) ) {
			return;
		}

		try {
			$this->activities->log( $type, $parents, $subject, $description, array_merge( $meta, array( 'auto' => true ) ) );
		} catch ( \Throwable $e ) {
			// The timeline is secondary: never break the action being logged.
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				error_log( 'LeadFlow CRM: could not log activity: ' . $e->getMessage() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			}
		}
	}

	/**
	 * Parent columns of a related record.
	 *
	 * @param Model $model Note, task, follow-up or email.
	 * @return array<string, int>
	 */
	private static function parents_of( Model $model ): array {
		$parents = array();

		foreach ( array( 'company_id', 'contact_id', 'lead_id' ) as $column ) {
			if ( null !== $model->get( $column ) ) {
				$parents[ $column ] = (int) $model->get( $column );
			}
		}

		return $parents;
	}

	/**
	 * Display title of a record.
	 *
	 * @param string $entity Entity.
	 * @param Model  $model  Record.
	 * @return string
	 */
	private function title( string $entity, Model $model ): string {
		return match ( $entity ) {
			'company' => (string) $model->get( 'name', '' ),
			'contact' => $model instanceof Contact ? $model->full_name() : '',
			default   => (string) $model->get( 'title', '' ),
		};
	}
}
