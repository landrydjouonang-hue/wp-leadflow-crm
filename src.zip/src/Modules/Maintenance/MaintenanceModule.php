<?php
/**
 * Data retention, debug log and export tools.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Maintenance;

use LeadFlow\CRM\Admin\Menu;
use LeadFlow\CRM\Admin\Notices;
use LeadFlow\CRM\Admin\View;
use LeadFlow\CRM\Contracts\Module;
use LeadFlow\CRM\Data\Retention;
use LeadFlow\CRM\Modules\Settings\SettingsModule;
use LeadFlow\CRM\Plugin;
use LeadFlow\CRM\Security\Capabilities;
use LeadFlow\CRM\Security\Guard;
use LeadFlow\CRM\Security\Input;
use LeadFlow\CRM\Settings\Registry;
use LeadFlow\CRM\Settings\Settings;
use LeadFlow\CRM\Support\Logger;

defined( 'ABSPATH' ) || exit;

/**
 * Housekeeping around the CRM data:
 *
 * - *Settings → Data*: retention policies, "Run clean-up now", and the
 *   daily cron that applies them.
 * - *Settings → Advanced*: debug logging, with a viewer, a download and a
 *   "Clear log" button on *System status*.
 *
 * Everything here needs `leadflow_manage_settings`.
 */
final class MaintenanceModule implements Module {

	/**
	 * Plugin.
	 *
	 * @var Plugin|null
	 */
	private ?Plugin $plugin = null;

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'maintenance';
	}

	/**
	 * {@inheritDoc}
	 */
	public function boot( Plugin $plugin ): void {
		$this->plugin = $plugin;

		$this->register_settings( $plugin->get( Registry::class ) );

		add_action( Retention::CRON_HOOK, array( $this, 'run_cron' ) );
		add_action( 'admin_post_leadflow_crm_run_retention', array( $this, 'handle_run_retention' ) );
		add_action( 'admin_post_leadflow_crm_clear_log', array( $this, 'handle_clear_log' ) );
		add_action( 'admin_post_leadflow_crm_download_log', array( $this, 'handle_download_log' ) );
		add_action( 'admin_post_leadflow_crm_download_status', array( $this, 'handle_download_status' ) );
		add_filter( 'leadflow_crm_system_status', array( $this, 'status_rows' ) );

		if ( false === wp_next_scheduled( Retention::CRON_HOOK ) ) {
			wp_schedule_event( time() + 2 * HOUR_IN_SECONDS, 'daily', Retention::CRON_HOOK );
		}
	}

	/**
	 * Settings fields.
	 *
	 * @param Registry $registry Registry.
	 * @return void
	 */
	private function register_settings( Registry $registry ): void {
		$registry->add_tab( 'data', __( 'Data', 'wp-leadflow-crm' ), 80, array( $this, 'render_data_tab' ) );

		foreach ( Retention::policies() as $key => $policy ) {
			$registry->add_field(
				$key,
				array(
					'tab'         => 'data',
					'label'       => $policy['label'],
					'type'        => 'number',
					'default'     => 0,
					'min'         => 0,
					'max'         => $policy['max'],
					'description' => $policy['description'],
				)
			);
		}

		$registry->add_field(
			'debug_logging',
			array(
				'tab'         => 'advanced',
				'label'       => __( 'Write a debug log', 'wp-leadflow-crm' ),
				'type'        => 'checkbox',
				'default'     => false,
				'description' => __( 'Records what the plugin does (imports, emails, clean-ups, errors) in a private log file you can read under System status. Useful when troubleshooting; turn it off afterwards.', 'wp-leadflow-crm' ),
			)
		);
	}

	/**
	 * Renders *Settings → Data*.
	 *
	 * @return void
	 */
	public function render_data_tab(): void {
		$plugin = $this->plugin ?? Plugin::instance();

		View::render(
			'admin/settings-data',
			array(
				'registry'  => $plugin->get( Registry::class ),
				'group'     => Settings::GROUP,
				'policies'  => Retention::policies(),
				'active'    => ( new Retention( $plugin ) )->active(),
				'last_run'  => Retention::last_run(),
				'next_run'  => wp_next_scheduled( Retention::CRON_HOOK ),
				'export_url' => Menu::url( 'leadflow-crm-import-export', array( 'tab' => 'export' ) ),
			)
		);
	}

	/**
	 * Daily clean-up.
	 *
	 * @return void
	 */
	public function run_cron(): void {
		$retention = new Retention( $this->plugin ?? Plugin::instance() );

		if ( ! $retention->active() ) {
			return;
		}

		$result = $retention->run();

		// More to do than one batch: finish tomorrow, or sooner.
		if ( ! empty( $result['more'] ) ) {
			wp_schedule_single_event( time() + 5 * MINUTE_IN_SECONDS, Retention::CRON_HOOK );
		}
	}

	/**
	 * "Run clean-up now".
	 *
	 * @return void
	 */
	public function handle_run_retention(): void {
		Guard::verify_form( 'run_retention', Capabilities::MANAGE_SETTINGS );

		$retention = new Retention( $this->plugin ?? Plugin::instance() );

		if ( ! $retention->active() ) {
			Notices::flash( 'warning', __( 'No retention rule is active, so nothing was deleted.', 'wp-leadflow-crm' ) );
		} else {
			$result = $retention->run();

			Notices::flash(
				'success',
				sprintf(
					/* translators: 1: Activities, 2: Emails, 3: Records. */
					__( 'Clean-up finished: %1$s activities, %2$s emails and %3$s trashed records deleted.', 'wp-leadflow-crm' ),
					number_format_i18n( $result['activities'] ),
					number_format_i18n( $result['emails'] ),
					number_format_i18n( $result['trashed'] )
				)
			);

			if ( ! empty( $result['more'] ) ) {
				Notices::flash( 'info', __( 'There is more to delete; the rest is handled automatically in the next runs.', 'wp-leadflow-crm' ) );
			}
		}

		wp_safe_redirect( Menu::url( SettingsModule::PAGE_SLUG, array( 'tab' => 'data' ) ) );
		exit;
	}

	/**
	 * Empties the debug log.
	 *
	 * @return void
	 */
	public function handle_clear_log(): void {
		Guard::verify_form( 'clear_log', Capabilities::MANAGE_SETTINGS );

		Logger::clear();
		Notices::flash( 'success', __( 'Debug log cleared.', 'wp-leadflow-crm' ) );

		wp_safe_redirect( Menu::url( SettingsModule::PAGE_SLUG, array( 'tab' => 'status' ) ) );
		exit;
	}

	/**
	 * Downloads the debug log.
	 *
	 * @return void
	 */
	public function handle_download_log(): void {
		Guard::verify_form( 'download_log', Capabilities::MANAGE_SETTINGS );

		$file = Logger::file();

		if ( ! is_readable( $file ) ) {
			Notices::flash( 'warning', __( 'There is no log file yet.', 'wp-leadflow-crm' ) );
			wp_safe_redirect( Menu::url( SettingsModule::PAGE_SLUG, array( 'tab' => 'status' ) ) );
			exit;
		}

		nocache_headers();
		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="leadflow-crm-log-' . gmdate( 'Y-m-d-His' ) . '.txt"' );
		header( 'X-Content-Type-Options: nosniff' );

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile, WordPress.Security.EscapeOutput.OutputNotEscaped -- Plain text download of our own log.
		readfile( $file );
		exit;
	}

	/**
	 * Downloads the system status report as text.
	 *
	 * @return void
	 */
	public function handle_download_status(): void {
		Guard::verify_form( 'download_status', Capabilities::MANAGE_SETTINGS );

		$plugin   = $this->plugin ?? Plugin::instance();
		$settings = $plugin->modules()->all()['settings'] ?? null;
		$rows     = $settings instanceof SettingsModule ? $settings->status() : array();
		$lines    = array( '### WP LeadFlow CRM — System status ###', 'Generated: ' . gmdate( 'c' ), '' );

		foreach ( $rows as $row ) {
			$lines[] = sprintf( '%s: %s [%s]', $row['label'], $row['value'], $row['status'] );
		}

		nocache_headers();
		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="leadflow-crm-status-' . gmdate( 'Y-m-d-His' ) . '.txt"' );
		header( 'X-Content-Type-Options: nosniff' );

		echo esc_html( implode( PHP_EOL, $lines ) );
		exit;
	}

	/**
	 * Adds retention, cron and log rows to the system status report.
	 *
	 * @param array<int, array{label: string, value: string, status: string}> $rows Rows.
	 * @return array<int, array{label: string, value: string, status: string}>
	 */
	public function status_rows( array $rows ): array {
		$plugin    = $this->plugin ?? Plugin::instance();
		$retention = new Retention( $plugin );
		$next      = wp_next_scheduled( Retention::CRON_HOOK );
		$last      = Retention::last_run();
		$policies  = array();

		foreach ( Retention::policies() as $key => $policy ) {
			$value = (int) $plugin->get( Settings::class )->get( $key, 0 );

			if ( $value > 0 ) {
				$policies[] = $key . '=' . $value;
			}
		}

		$rows[] = array(
			'label'  => __( 'Data retention', 'wp-leadflow-crm' ),
			'value'  => empty( $policies ) ? __( 'Keep everything', 'wp-leadflow-crm' ) : implode( ', ', $policies ),
			'status' => 'info',
		);

		$rows[] = array(
			'label'  => __( 'Next clean-up', 'wp-leadflow-crm' ),
			'value'  => false === $next ? __( 'Not scheduled', 'wp-leadflow-crm' ) : gmdate( 'Y-m-d H:i', (int) $next ) . ' UTC',
			'status' => false === $next && $retention->active() ? 'warning' : 'info',
		);

		$rows[] = array(
			'label'  => __( 'Last clean-up', 'wp-leadflow-crm' ),
			'value'  => null === $last ? __( 'Never', 'wp-leadflow-crm' ) : gmdate( 'Y-m-d H:i', (int) $last['time'] ) . ' UTC (' . implode( ', ', array_map( static fn( $k, $v ): string => "$k: $v", array_keys( $last['counts'] ), $last['counts'] ) ) . ')',
			'status' => 'info',
		);

		$rows[] = array(
			'label'  => __( 'Debug logging', 'wp-leadflow-crm' ),
			'value'  => Logger::enabled()
				? sprintf(
					/* translators: %s: File size. */
					__( 'On (%s)', 'wp-leadflow-crm' ),
					size_format( Logger::size() )
				)
				: __( 'Off', 'wp-leadflow-crm' ),
			'status' => 'info',
		);

		return $rows;
	}
}
