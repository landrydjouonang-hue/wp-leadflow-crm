<?php
/**
 * Companies admin screens.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Companies;

use LeadFlow\CRM\Admin\Crud\EntityAdmin;
use LeadFlow\CRM\Admin\Crud\EntityListTable;
use LeadFlow\CRM\Admin\Notes\NoteActions;
use LeadFlow\CRM\Admin\View;
use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\Company;
use LeadFlow\CRM\Data\Relations;
use LeadFlow\CRM\Data\Repositories\CompanyRepository;
use LeadFlow\CRM\Data\Repositories\NoteRepository;
use LeadFlow\CRM\Data\Repository;
use LeadFlow\CRM\Modules\Contacts\ContactsAdmin;
use LeadFlow\CRM\Support\Format;
use LeadFlow\CRM\Support\Users;

defined( 'ABSPATH' ) || exit;

/**
 * List, add, edit and view companies.
 */
final class CompaniesAdmin extends EntityAdmin {

	protected const ENTITY     = 'company';
	protected const PLURAL     = 'companies';
	protected const PAGE_SLUG  = 'leadflow-crm-companies';
	protected const MENU_ORDER = 30;

	/**
	 * {@inheritDoc}
	 */
	public function repository(): Repository {
		return $this->plugin->get( CompanyRepository::class );
	}

	/**
	 * {@inheritDoc}
	 */
	public function labels(): array {
		return array(
			'singular'        => __( 'Company', 'wp-leadflow-crm' ),
			'plural'          => __( 'Companies', 'wp-leadflow-crm' ),
			'add_new'         => __( 'Add company', 'wp-leadflow-crm' ),
			'search'          => __( 'Search companies', 'wp-leadflow-crm' ),
			'not_found'       => __( 'No companies found.', 'wp-leadflow-crm' ),
			'not_found_trash' => __( 'No companies in the trash.', 'wp-leadflow-crm' ),
			'created'         => __( 'Company created.', 'wp-leadflow-crm' ),
			'updated'         => __( 'Company updated.', 'wp-leadflow-crm' ),
			'trashed'         => __( 'Company moved to the trash.', 'wp-leadflow-crm' ),
			'restored'        => __( 'Company restored.', 'wp-leadflow-crm' ),
			'deleted'         => __( 'Company permanently deleted.', 'wp-leadflow-crm' ),
			'delete_confirm'  => __( 'Permanently delete this company? Its contacts and leads are kept but unlinked; notes that belong only to this company are deleted. This cannot be undone.', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function status_labels(): array {
		return array(
			'prospect' => __( 'Prospect', 'wp-leadflow-crm' ),
			'customer' => __( 'Customer', 'wp-leadflow-crm' ),
			'partner'  => __( 'Partner', 'wp-leadflow-crm' ),
			'inactive' => __( 'Inactive', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function title_of( Model $model ): string {
		return $model instanceof Company ? $model->name() : (string) $model->get( 'name', '' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function form_sections( ?Model $model ): array {
		$sections = array(
			array(
				'title'  => __( 'Company details', 'wp-leadflow-crm' ),
				'fields' => array(
					array(
						'name'         => 'name',
						'label'        => __( 'Company name', 'wp-leadflow-crm' ),
						'required'     => true,
						'maxlength'    => 191,
						'autocomplete' => 'organization',
					),
					array(
						'name'        => 'industry',
						'label'       => __( 'Industry', 'wp-leadflow-crm' ),
						'width'       => 'half',
						'maxlength'   => 100,
						'placeholder' => __( 'e.g. Software, Retail', 'wp-leadflow-crm' ),
					),
					array(
						'name'        => 'website',
						'label'       => __( 'Website', 'wp-leadflow-crm' ),
						'type'        => 'url',
						'width'       => 'half',
						'maxlength'   => 255,
						'placeholder' => 'https://',
					),
				),
			),
			array(
				'title'  => __( 'Contact information', 'wp-leadflow-crm' ),
				'fields' => array(
					array(
						'name'         => 'email',
						'label'        => __( 'Email', 'wp-leadflow-crm' ),
						'type'         => 'email',
						'width'        => 'half',
						'maxlength'    => 100,
						'autocomplete' => 'email',
					),
					array(
						'name'         => 'phone',
						'label'        => __( 'Phone', 'wp-leadflow-crm' ),
						'type'         => 'tel',
						'width'        => 'half',
						'maxlength'    => 50,
						'autocomplete' => 'tel',
					),
				),
			),
			array(
				'title'  => __( 'Address', 'wp-leadflow-crm' ),
				'fields' => array(
					array(
						'name'         => 'address_line_1',
						'label'        => __( 'Street address', 'wp-leadflow-crm' ),
						'maxlength'    => 255,
						'autocomplete' => 'address-line1',
					),
					array(
						'name'         => 'address_line_2',
						'label'        => __( 'Apartment, suite, building (optional)', 'wp-leadflow-crm' ),
						'maxlength'    => 255,
						'autocomplete' => 'address-line2',
					),
					array(
						'name'         => 'city',
						'label'        => __( 'City', 'wp-leadflow-crm' ),
						'width'        => 'half',
						'maxlength'    => 100,
						'autocomplete' => 'address-level2',
					),
					array(
						'name'         => 'state',
						'label'        => __( 'State / region', 'wp-leadflow-crm' ),
						'width'        => 'half',
						'maxlength'    => 100,
						'autocomplete' => 'address-level1',
					),
					array(
						'name'         => 'postal_code',
						'label'        => __( 'Postal code', 'wp-leadflow-crm' ),
						'width'        => 'half',
						'maxlength'    => 20,
						'autocomplete' => 'postal-code',
					),
					array(
						'name'        => 'country',
						'label'       => __( 'Country', 'wp-leadflow-crm' ),
						'type'        => 'country',
						'width'       => 'half',
						'empty_label' => __( 'Select a country', 'wp-leadflow-crm' ),
					),
				),
			),
			array(
				'title'  => __( 'About', 'wp-leadflow-crm' ),
				'fields' => array(
					array(
						'name'  => 'description',
						'label' => __( 'Description', 'wp-leadflow-crm' ),
						'type'  => 'textarea',
						'rows'  => 4,
					),
				),
			),
		);

		if ( null === $model && current_user_can( \LeadFlow\CRM\Security\Permissions::MANAGE_NOTES ) ) {
			$sections[] = self::initial_note_section();
		}

		return $sections;
	}

	/**
	 * {@inheritDoc}
	 */
	protected function sidebar_fields( ?Model $model ): array {
		$fields = array(
			array(
				'name'     => 'status',
				'label'    => __( 'Status', 'wp-leadflow-crm' ),
				'type'     => 'select',
				'required' => true,
				'options'  => $this->status_labels(),
			),
		);

		// Only users who can edit others' companies may assign an owner.
		if ( current_user_can( $this->cap( 'edit_others' ) ) ) {
			$fields[] = self::owner_field( $model );
		}

		return $fields;
	}

	/**
	 * {@inheritDoc}
	 */
	protected function default_values(): array {
		return array(
			'status'   => 'prospect',
			'owner_id' => get_current_user_id(),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function after_save( Model $model, bool $created, array $extra ): void {
		self::save_initial_note( $this->plugin->get( NoteRepository::class ), 'company_id', $model->id(), $extra );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function create_list_table(): EntityListTable {
		return new CompaniesListTable( $this, $this->repository() );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function render_view( Model $model ): void {
		$relations = $this->plugin->get( Relations::class );
		$contacts  = new ContactsAdmin( $this->plugin );

		View::render(
			'admin/companies/view',
			array(
				'admin'         => $this,
				'company'       => $model,
				'contacts'      => $relations->contacts_of_company( $model->id(), array( 'per_page' => 50 ) ),
				'summary'       => $relations->summary( 'company', $model->id() ),
				'contacts_url'  => $contacts->url( array( 'company_id' => $model->id() ) ),
				'contact_admin' => $contacts,
				'can_add'       => ! $model->is_trashed() && current_user_can( $contacts->cap( 'edit' ) ),
				'note_actions'  => $this->plugin->get( NoteActions::class ),
			)
		);
	}

	/**
	 * Owner picker (shared with contacts).
	 *
	 * @param Model|null  $model Record.
	 * @param string|null $label Field label (default "Owner").
	 * @return array<string, mixed>
	 */
	public static function owner_field( ?Model $model, ?string $label = null ): array {
		$options = Users::crm_users();
		$owner   = null !== $model ? (int) $model->get( 'owner_id', 0 ) : 0;

		// Keep the current owner selectable even if they lost CRM access.
		if ( $owner > 0 && ! isset( $options[ $owner ] ) ) {
			$options[ $owner ] = Format::user( $owner );
		}

		return array(
			'name'        => 'owner_id',
			'label'       => $label ?? __( 'Owner', 'wp-leadflow-crm' ),
			'type'        => 'user',
			'options'     => $options,
			'empty_label' => __( 'No owner', 'wp-leadflow-crm' ),
			'description' => __( 'The team member responsible for this record.', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * "Notes" section shown when creating a record (shared with contacts).
	 *
	 * @return array<string, mixed>
	 */
	public static function initial_note_section(): array {
		return array(
			'title'  => __( 'Notes', 'wp-leadflow-crm' ),
			'fields' => array(
				array(
					'name'        => 'initial_note',
					'label'       => __( 'First note', 'wp-leadflow-crm' ),
					'type'        => 'textarea',
					'rows'        => 3,
					'persist'     => false,
					'description' => __( 'Optional. Saved to the notes timeline, where you can add more notes later.', 'wp-leadflow-crm' ),
				),
			),
		);
	}

	/**
	 * Stores the optional first note after creating a record.
	 *
	 * @param NoteRepository       $notes  Notes.
	 * @param string               $column company_id|contact_id.
	 * @param int                  $id     Record id.
	 * @param array<string, mixed> $extra  Non-persisted form values.
	 * @return void
	 */
	public static function save_initial_note( NoteRepository $notes, string $column, int $id, array $extra ): void {
		$content = trim( (string) ( $extra['initial_note'] ?? '' ) );

		if ( '' !== $content && current_user_can( \LeadFlow\CRM\Security\Permissions::MANAGE_NOTES ) ) {
			$notes->create(
				array(
					$column   => $id,
					'content' => $content,
				)
			);
		}
	}
}
