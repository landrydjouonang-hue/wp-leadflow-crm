<?php
/**
 * Company lookup REST endpoint.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Companies;

use LeadFlow\CRM\Data\Models\Company;
use LeadFlow\CRM\Data\Repositories\CompanyRepository;
use LeadFlow\CRM\Rest\Controller;

defined( 'ABSPATH' ) || exit;

/**
 * GET /wp-json/leadflow-crm/v1/lookup/companies?search=acme&per_page=20
 *
 * Lightweight id/name search used by company pickers.
 */
final class CompanyLookupController extends Controller {

	/**
	 * Constructor.
	 *
	 * @param CompanyRepository $companies Companies.
	 */
	public function __construct( private CompanyRepository $companies ) {}

	/**
	 * {@inheritDoc}
	 */
	public function register_routes(): void {
		register_rest_route(
			self::REST_NAMESPACE,
			'/lookup/companies',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'search' ),
					'permission_callback' => $this->require_capability( 'leadflow_view_companies' ),
					'args'                => array(
						'search'   => array(
							'type'              => 'string',
							'default'           => '',
							'sanitize_callback' => 'sanitize_text_field',
						),
						'per_page' => array(
							'type'    => 'integer',
							'default' => 20,
							'minimum' => 1,
							'maximum' => 50,
						),
					),
				),
			)
		);
	}

	/**
	 * Returns matching companies.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public function search( \WP_REST_Request $request ): \WP_REST_Response {
		$companies = $this->companies->query(
			array(
				'search'   => (string) $request->get_param( 'search' ),
				'orderby'  => 'name',
				'order'    => 'ASC',
				'per_page' => (int) $request->get_param( 'per_page' ),
			)
		);

		return rest_ensure_response(
			array_map(
				static fn( Company $company ): array => array(
					'id'   => $company->id(),
					'name' => $company->name(),
				),
				$companies
			)
		);
	}
}
