<?php
/**
 * Companies list table.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Companies;

use LeadFlow\CRM\Admin\Crud\EntityListTable;
use LeadFlow\CRM\Admin\UI;
use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Repositories\ContactRepository;
use LeadFlow\CRM\Security\Input;
use LeadFlow\CRM\Support\Countries;
use LeadFlow\CRM\Support\Users;

defined( 'ABSPATH' ) || exit;

/**
 * Companies table.
 */
final class CompaniesListTable extends EntityListTable {

	/**
	 * Contacts per company for the current page.
	 *
	 * @var array<string, int>
	 */
	private array $contact_counts = array();

	/**
	 * {@inheritDoc}
	 */
	public function get_columns(): array {
		return array(
			'cb'         => '<input type="checkbox" />',
			'name'       => __( 'Company', 'wp-leadflow-crm' ),
			'industry'   => __( 'Industry', 'wp-leadflow-crm' ),
			'contact'    => __( 'Contact details', 'wp-leadflow-crm' ),
			'country'    => __( 'Country', 'wp-leadflow-crm' ),
			'contacts'   => __( 'Contacts', 'wp-leadflow-crm' ),
			'status'     => __( 'Status', 'wp-leadflow-crm' ),
			'owner_id'   => __( 'Owner', 'wp-leadflow-crm' ),
			'created_at' => __( 'Created', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_sortable_columns(): array {
		return array(
			'name'       => array( 'name', false ),
			'industry'   => array( 'industry', false ),
			'country'    => array( 'country', false ),
			'status'     => array( 'status', false ),
			'created_at' => array( 'created_at', true ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_primary_column_name(): string {
		return 'name';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function filter_args(): array {
		$where = array();
		$owner = Input::int( 'owner' );

		if ( $owner > 0 ) {
			$where['owner_id'] = $owner;
		}

		$country = strtoupper( Input::key( 'country' ) );

		if ( 1 === preg_match( '/^[A-Z]{2}$/', $country ) ) {
			$where['country'] = $country;
		}

		return array( 'where' => $where );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function render_filters(): void {
		$this->filter_select( 'owner', __( 'Filter by owner', 'wp-leadflow-crm' ), Users::crm_users(), __( 'All owners', 'wp-leadflow-crm' ) );

		$countries = array();

		foreach ( $this->repository->distinct_values( 'country' ) as $code ) {
			$countries[ $code ] = Countries::name( $code );
		}

		asort( $countries );

		if ( ! empty( $countries ) ) {
			$this->filter_select( 'country', __( 'Filter by country', 'wp-leadflow-crm' ), $countries, __( 'All countries', 'wp-leadflow-crm' ) );
		}
	}

	/**
	 * {@inheritDoc}
	 */
	protected function prefetch( array $items ): void {
		$ids = array_map( static fn( Model $m ): int => $m->id(), $items );

		$this->contact_counts = empty( $ids )
			? array()
			: leadflow_crm()->get( ContactRepository::class )->count_by( 'company_id', array( 'company_id' => $ids ) );
	}

	/**
	 * Name column.
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_name( Model $item ): string {
		$website = (string) $item->get( 'website', '' );
		$host    = '' !== $website ? (string) wp_parse_url( $website, PHP_URL_HOST ) : '';

		return $this->primary_cell( $item, (string) preg_replace( '/^www\./', '', $host ), UI::avatar( $this->admin->title_of( $item ), 'sm' ) );
	}

	/**
	 * Email + phone column.
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_contact( Model $item ): string {
		$email = (string) $item->get( 'email', '' );
		$phone = (string) $item->get( 'phone', '' );

		if ( '' === $email && '' === $phone ) {
			return UI::text( '' );
		}

		return implode( '<br />', array_filter( array( '' !== $email ? UI::email( $email ) : '', '' !== $phone ? UI::phone( $phone ) : '' ) ) );
	}

	/**
	 * Country column.
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_country( Model $item ): string {
		return UI::text( Countries::name( (string) $item->get( 'country', '' ) ) );
	}

	/**
	 * Contacts count column (links to the filtered contacts list).
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_contacts( Model $item ): string {
		$count = (int) ( $this->contact_counts[ (string) $item->id() ] ?? 0 );

		if ( 0 === $count ) {
			return '<span class="lf-muted">0</span>';
		}

		return sprintf(
			'<a href="%1$s">%2$s</a>',
			esc_url( \LeadFlow\CRM\Admin\Menu::url( 'leadflow-crm-contacts', array( 'company_id' => $item->id() ) ) ),
			esc_html( number_format_i18n( $count ) )
		);
	}
}
