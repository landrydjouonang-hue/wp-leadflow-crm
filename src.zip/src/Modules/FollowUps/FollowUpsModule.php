<?php
/**
 * Follow-ups module.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\FollowUps;

use LeadFlow\CRM\Admin\Menu;
use LeadFlow\CRM\Admin\Notices;
use LeadFlow\CRM\Admin\RecordPanels;
use LeadFlow\CRM\Admin\View;
use LeadFlow\CRM\Contracts\Module;
use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\FollowUp;
use LeadFlow\CRM\Data\Repositories\FollowUpRepository;
use LeadFlow\CRM\Data\ValidationException;
use LeadFlow\CRM\Modules\Dashboard\Sections;
use LeadFlow\CRM\Modules\Tasks\TasksAdmin;
use LeadFlow\CRM\Plugin;
use LeadFlow\CRM\Security\Capabilities;
use LeadFlow\CRM\Security\Guard;
use LeadFlow\CRM\Security\Input;
use LeadFlow\CRM\Security\Nonce;
use LeadFlow\CRM\Support\Format;
use LeadFlow\CRM\Support\Users;

defined( 'ABSPATH' ) || exit;

/**
 * Scheduled follow-ups (call, email, meeting) on companies, contacts and leads.
 *
 * Permissions follow the record the follow-up belongs to (its most
 * specific parent): whoever may edit that record may schedule, complete
 * and cancel its follow-ups.
 */
final class FollowUpsModule implements Module {

	/** Parent type => plural. */
	private const PARENTS = array(
		'company' => 'companies',
		'contact' => 'contacts',
		'lead'    => 'leads',
	);

	/**
	 * Plugin.
	 *
	 * @var Plugin|null
	 */
	private ?Plugin $plugin = null;

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'follow-ups';
	}

	/**
	 * {@inheritDoc}
	 */
	public function boot( Plugin $plugin ): void {
		$this->plugin = $plugin;

		add_action( 'leadflow_crm_record_panels', array( $this, 'add_panel' ), 40, 3 );
		add_action( 'admin_post_leadflow_crm_schedule_follow_up', array( $this, 'handle_schedule' ) );
		add_action( 'admin_post_leadflow_crm_complete_follow_up', array( $this, 'handle_complete' ) );
		add_action( 'admin_post_leadflow_crm_cancel_follow_up', array( $this, 'handle_cancel' ) );
		add_action( 'wp_ajax_leadflow_crm_complete_follow_up', array( $this, 'ajax_complete' ) );
		add_action( 'leadflow_crm_dashboard_sections', array( $this, 'dashboard_section' ) );
	}

	/**
	 * Type labels.
	 *
	 * @return array<string, string>
	 */
	public static function type_labels(): array {
		return array(
			'call'    => __( 'Call', 'wp-leadflow-crm' ),
			'email'   => __( 'Email', 'wp-leadflow-crm' ),
			'meeting' => __( 'Meeting', 'wp-leadflow-crm' ),
			'other'   => __( 'Other', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * Most specific parent of a follow-up (lead, then contact, then company).
	 *
	 * @param Model $follow_up Follow-up.
	 * @return array{0: string|null, 1: int}
	 */
	public static function owning_parent( Model $follow_up ): array {
		foreach ( array( 'lead', 'contact', 'company' ) as $type ) {
			$id = $follow_up->get( $type . '_id' );

			if ( null !== $id ) {
				return array( $type, (int) $id );
			}
		}

		return array( null, 0 );
	}

	/**
	 * Whether the current user may complete/cancel a follow-up.
	 *
	 * @param Model $follow_up Follow-up.
	 * @return bool
	 */
	public static function can_manage( Model $follow_up ): bool {
		list( $type, $id ) = self::owning_parent( $follow_up );

		return null !== $type && current_user_can( 'leadflow_edit_' . $type, $id );
	}

	/**
	 * Follow-ups tab.
	 *
	 * @param RecordPanels $panels Panel registry.
	 * @param string       $type   Record type.
	 * @param Model        $record Record.
	 * @return void
	 */
	public function add_panel( RecordPanels $panels, string $type, Model $record ): void {
		if ( ! isset( self::PARENTS[ $type ] ) ) {
			return;
		}

		$repo      = $this->repo();
		$scheduled = $repo->count_for_parent( $type, $record->id(), array( 'where' => array( 'status' => 'scheduled' ) ) );

		$panels->add(
			'follow-ups',
			array(
				'title'  => __( 'Follow-ups', 'wp-leadflow-crm' ),
				'count'  => $scheduled,
				'order'  => 40,
				'render' => function () use ( $repo, $type, $record ): void {
					View::render(
						'admin/partials/follow-ups-panel',
						array(
							'parent'     => $type,
							'parent_id'  => $record->id(),
							'scheduled'  => $repo->for_parent(
								$type,
								$record->id(),
								array(
									'where'    => array( 'status' => 'scheduled' ),
									'orderby'  => 'scheduled_at',
									'order'    => 'ASC',
									'per_page' => 50,
								)
							),
							'history'    => $repo->for_parent(
								$type,
								$record->id(),
								array(
									'where'    => array(
										'status' => array(
											'op'    => 'IN',
											'value' => array( 'completed', 'cancelled', 'missed' ),
										),
									),
									'orderby'  => 'updated_at',
									'order'    => 'DESC',
									'per_page' => 5,
								)
							),
							'can_add'    => ! $record->is_trashed() && current_user_can( 'leadflow_edit_' . $type, $record->id() ),
							'can_assign' => current_user_can( 'leadflow_edit_others_' . self::PARENTS[ $type ] ),
							'users'      => Users::crm_users(),
						)
					);
				},
			)
		);
	}

	/**
	 * Schedules a follow-up (form POST).
	 *
	 * @return void
	 */
	public function handle_schedule(): void {
		$parent    = Input::one_of( 'parent', array_keys( self::PARENTS ), '', 'post' );
		$parent_id = Input::int( 'parent_id', 'post' );

		check_admin_referer( Nonce::action( 'schedule_follow_up_' . $parent . '_' . $parent_id ), Nonce::FIELD );
		Guard::authorize( '' === $parent ? 'do_not_allow' : 'leadflow_edit_' . $parent, $parent_id );

		$when = Input::text( 'scheduled_at', 'post' );
		$data = array(
			$parent . '_id' => $parent_id,
			'type'          => Input::one_of( 'type', array_keys( self::type_labels() ), 'call', 'post' ),
			'subject'       => Input::text( 'subject', 'post' ),
			'notes'         => Input::textarea( 'notes', 'post' ),
			'scheduled_at'  => '' !== $when ? Format::to_utc( $when ) : '',
		);

		$assignee = Input::int( 'assigned_to', 'post' );

		if ( $assignee > 0 && current_user_can( 'leadflow_edit_others_' . self::PARENTS[ $parent ] ) && isset( Users::crm_users()[ $assignee ] ) ) {
			$data['assigned_to'] = $assignee;
		}

		try {
			$this->repo()->create( $data );
			Notices::flash( 'success', __( 'Follow-up scheduled.', 'wp-leadflow-crm' ) );
		} catch ( ValidationException $e ) {
			Notices::flash( 'error', implode( ' ', $e->errors() ) );
		}

		$this->back();
	}

	/**
	 * AJAX: completes a follow-up with an optional outcome.
	 *
	 * @return void
	 */
	public function ajax_complete(): void {
		Guard::verify_ajax( 'follow_up', Capabilities::ACCESS_CRM );

		$follow_up = $this->repo()->find( Input::int( 'follow_up_id', 'post' ) );

		if ( ! $follow_up instanceof FollowUp ) {
			wp_send_json_error( array( 'message' => __( 'This follow-up no longer exists. Please reload the page.', 'wp-leadflow-crm' ) ), 404 );
		}

		if ( ! self::can_manage( $follow_up ) ) {
			wp_send_json_error( array( 'message' => __( 'You are not allowed to change this follow-up.', 'wp-leadflow-crm' ) ), 403 );
		}

		try {
			$updated = $this->complete( $follow_up );
		} catch ( ValidationException $e ) {
			wp_send_json_error( array( 'message' => implode( ' ', $e->errors() ) ), 400 );
		}

		ob_start();
		View::render(
			'admin/partials/follow-up-item',
			array(
				'follow_up' => $updated,
			)
		);

		wp_send_json_success(
			array(
				'html'    => (string) ob_get_clean(),
				'message' => __( 'Follow-up completed.', 'wp-leadflow-crm' ),
			)
		);
	}

	/**
	 * Completes a follow-up (form POST fallback).
	 *
	 * @return void
	 */
	public function handle_complete(): void {
		check_admin_referer( Nonce::action( 'follow_up' ), Nonce::FIELD );

		$follow_up = $this->managed_or_die();

		try {
			$this->complete( $follow_up );
			Notices::flash( 'success', __( 'Follow-up completed.', 'wp-leadflow-crm' ) );
		} catch ( ValidationException $e ) {
			Notices::flash( 'error', implode( ' ', $e->errors() ) );
		}

		$this->back();
	}

	/**
	 * Cancels a follow-up (form POST).
	 *
	 * @return void
	 */
	public function handle_cancel(): void {
		check_admin_referer( Nonce::action( 'follow_up' ), Nonce::FIELD );

		$follow_up = $this->managed_or_die();

		$this->repo()->update( $follow_up->id(), array( 'status' => 'cancelled' ) );
		Notices::flash( 'success', __( 'Follow-up cancelled.', 'wp-leadflow-crm' ) );

		$this->back();
	}

	/**
	 * "Follow-ups" dashboard widget: overdue and next 7 days for the user.
	 *
	 * @param Sections $sections Dashboard sections.
	 * @return void
	 */
	public function dashboard_section( Sections $sections ): void {
		$sections->add(
			'follow-ups',
			array(
				'title'  => __( 'My follow-ups', 'wp-leadflow-crm' ),
				'icon'   => 'calendar-alt',
				'order'  => 60,
				'render' => function (): void {
					$items = $this->repo()->due_for_user( get_current_user_id(), 7, 8 );

					View::render(
						'admin/partials/follow-ups-widget',
						array(
							'items' => $items,
							'links' => TasksAdmin::related_links( $items ),
						)
					);
				},
			)
		);
	}

	/**
	 * Marks a follow-up completed with the posted outcome.
	 *
	 * @param FollowUp $follow_up Follow-up.
	 * @return FollowUp
	 */
	private function complete( FollowUp $follow_up ): FollowUp {
		/** @var FollowUp $updated */
		$updated = $this->repo()->update(
			$follow_up->id(),
			array(
				'status'  => 'completed',
				'outcome' => Input::text( 'outcome', 'post' ),
			)
		);

		return $updated;
	}

	/**
	 * Loads the posted follow-up and checks permissions.
	 *
	 * @return FollowUp
	 */
	private function managed_or_die(): FollowUp {
		$follow_up = $this->repo()->find( Input::int( 'follow_up_id', 'post' ) );

		if ( ! $follow_up instanceof FollowUp ) {
			wp_die( esc_html__( 'This follow-up no longer exists.', 'wp-leadflow-crm' ), '', array( 'response' => 404, 'back_link' => true ) );
		}

		if ( ! self::can_manage( $follow_up ) ) {
			Guard::authorize( 'do_not_allow' );
		}

		return $follow_up;
	}

	/**
	 * Back to the record, at the Follow-ups tab.
	 *
	 * @return void
	 */
	private function back(): void {
		$referer = wp_get_referer();

		wp_safe_redirect( ( false !== $referer ? strtok( $referer, '#' ) : Menu::url() ) . '#lf-panel-follow-ups' );
		exit;
	}

	/**
	 * Repository.
	 *
	 * @return FollowUpRepository
	 */
	private function repo(): FollowUpRepository {
		return ( $this->plugin ?? Plugin::instance() )->get( FollowUpRepository::class );
	}
}
