<?php
/**
 * Email screens and actions.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Emails;

use LeadFlow\CRM\Admin\Menu;
use LeadFlow\CRM\Admin\Notices;
use LeadFlow\CRM\Admin\Page;
use LeadFlow\CRM\Admin\View;
use LeadFlow\CRM\Data\Models\Email;
use LeadFlow\CRM\Data\Models\EmailTemplate;
use LeadFlow\CRM\Data\Repositories\EmailRepository;
use LeadFlow\CRM\Data\Repositories\EmailTemplateRepository;
use LeadFlow\CRM\Data\ValidationException;
use LeadFlow\CRM\Email\EmailSender;
use LeadFlow\CRM\Email\TemplateRenderer;
use LeadFlow\CRM\Modules\Settings\SettingsModule;
use LeadFlow\CRM\Plugin;
use LeadFlow\CRM\Security\Capabilities;
use LeadFlow\CRM\Security\Guard;
use LeadFlow\CRM\Security\Input;
use LeadFlow\CRM\Security\Nonce;
use LeadFlow\CRM\Settings\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Screens: admin.php?page=leadflow-crm-emails
 *   (list) | &action=view&id=N | &action=compose&record=lead&record_id=N[&template=N][&resend=N]
 *
 * Actions (nonce → capability → service → flash → redirect):
 *   admin-post leadflow_crm_send_email, leadflow_crm_send_test_email
 *   admin-ajax leadflow_crm_preview_email
 */
final class EmailsPage {

	/** Page slug. */
	public const PAGE_SLUG = 'leadflow-crm-emails';

	/** Screen-options user meta key. */
	public const PER_PAGE_OPTION = 'leadflow_crm_emails_per_page';

	/**
	 * List table, built on load-{page}.
	 *
	 * @var EmailsListTable|null
	 */
	private ?EmailsListTable $table = null;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( private Plugin $plugin ) {}

	/**
	 * Registers the action handlers.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'admin_post_leadflow_crm_send_email', array( $this, 'handle_send' ) );
		add_action( 'admin_post_leadflow_crm_send_test_email', array( $this, 'handle_test' ) );
		add_action( 'wp_ajax_leadflow_crm_preview_email', array( $this, 'ajax_preview' ) );
		add_filter( 'set_screen_option_' . self::PER_PAGE_OPTION, array( $this, 'save_per_page' ), 10, 3 );
	}

	/**
	 * Menu page.
	 *
	 * @return Page
	 */
	public function page(): Page {
		return new Page(
			self::PAGE_SLUG,
			__( 'Emails', 'wp-leadflow-crm' ),
			__( 'Emails', 'wp-leadflow-crm' ),
			EmailsModule::VIEW_CAP,
			array( $this, 'render' ),
			55,
			array( $this, 'load' )
		);
	}

	/**
	 * Compose screen URL.
	 *
	 * @param string               $type  Record type.
	 * @param int                  $id    Record id.
	 * @param array<string, mixed> $extra Extra query args.
	 * @return string Unescaped URL.
	 */
	public static function compose_url( string $type, int $id, array $extra = array() ): string {
		return Menu::url(
			self::PAGE_SLUG,
			array_merge(
				array(
					'action'    => 'compose',
					'record'    => $type,
					'record_id' => $id,
				),
				$extra
			)
		);
	}

	/**
	 * Email screen URL.
	 *
	 * @param int $id Email id.
	 * @return string Unescaped URL.
	 */
	public static function view_url( int $id ): string {
		return Menu::url(
			self::PAGE_SLUG,
			array(
				'action' => 'view',
				'id'     => $id,
			)
		);
	}

	/**
	 * Validates the Screen Options value.
	 *
	 * @param mixed  $keep   Previous filter value.
	 * @param string $option Option.
	 * @param mixed  $value  Value.
	 * @return int
	 */
	public function save_per_page( mixed $keep, string $option, mixed $value ): int {
		return max( 1, min( 200, (int) $value ) );
	}

	/**
	 * Current screen.
	 *
	 * @return string list|view|compose
	 */
	private function screen(): string {
		return Input::one_of( 'action', array( 'view', 'compose' ), 'list' );
	}

	/**
	 * `load-{page}`: Screen Options and the list table.
	 *
	 * @return void
	 */
	public function load(): void {
		if ( 'list' !== $this->screen() ) {
			return;
		}

		add_screen_option(
			'per_page',
			array(
				'default' => max( 5, (int) $this->plugin->get( Settings::class )->get( 'items_per_page', 20 ) ),
				'option'  => self::PER_PAGE_OPTION,
			)
		);

		$this->table = new EmailsListTable( $this->plugin );
	}

	/**
	 * Page callback.
	 *
	 * @return void
	 */
	public function render(): void {
		Guard::authorize( EmailsModule::VIEW_CAP );

		switch ( $this->screen() ) {
			case 'compose':
				$this->render_compose();
				return;

			case 'view':
				$this->render_view();
				return;

			default:
				$table = $this->table ?? new EmailsListTable( $this->plugin );
				$table->prepare_items();

				View::render(
					'admin/emails/list',
					array(
						'table'  => $table,
						'others' => current_user_can( EmailsModule::VIEW_OTHERS_CAP ),
					)
				);
		}
	}

	/**
	 * One email.
	 *
	 * @return void
	 */
	private function render_view(): void {
		$email = $this->emails()->find( Input::int( 'id' ) );

		if ( ! $email instanceof Email ) {
			wp_die( esc_html__( 'This email does not exist.', 'wp-leadflow-crm' ), esc_html__( 'Not found', 'wp-leadflow-crm' ), array( 'response' => 404, 'back_link' => true ) );
		}

		Guard::authorize( EmailsModule::VIEW_ONE_CAP, $email->id() );

		list( $type, $record_id ) = EmailSender::owning_record( $email );
		$record                   = null !== $type ? $this->sender()->record( $type, $record_id ) : null;

		View::render(
			'admin/emails/view',
			array(
				'email'      => $email,
				'type'       => $type,
				'record'     => $record,
				'record_url' => null !== $type && current_user_can( 'leadflow_view_' . EmailsModule::PARENTS[ $type ] ) ? EmailSender::record_url( $type, $record_id ) : '',
				'resend_url' => null !== $record && EmailsModule::can_send_to( (string) $type, $record_id ) ? self::compose_url( (string) $type, $record_id, array( 'resend' => $email->id() ) ) : '',
			)
		);
	}

	/**
	 * Compose screen.
	 *
	 * @return void
	 */
	private function render_compose(): void {
		$type = Input::one_of( 'record', array_keys( EmailsModule::PARENTS ), '' );
		$id   = Input::int( 'record_id' );

		Guard::authorize( '' === $type ? 'do_not_allow' : EmailsModule::SEND_CAP );

		$record = $this->sender()->record( $type, $id );

		if ( null === $record ) {
			wp_die( esc_html__( 'This record does not exist or is in the trash.', 'wp-leadflow-crm' ), esc_html__( 'Not found', 'wp-leadflow-crm' ), array( 'response' => 404, 'back_link' => true ) );
		}

		Guard::authorize( 'leadflow_edit_' . $type, $id );

		$recipients = $this->sender()->recipients( $type, $record );
		$templates  = $this->templates();
		$values     = array(
			'to'          => (string) ( array_key_first( $recipients ) ?? '' ),
			'cc'          => '',
			'bcc'         => '',
			'subject'     => '',
			'body'        => '',
			'template_id' => '',
			'copy_me'     => $this->sender()->copy_by_default(),
		);

		// Start from a template (also the no-JavaScript template picker).
		$template_id = Input::int( 'template' );

		if ( isset( $templates[ $template_id ] ) ) {
			$values['template_id'] = (string) $template_id;
			$values['subject']     = $templates[ $template_id ]->subject();
			$values['body']        = $templates[ $template_id ]->body();
		}

		// "Send again": same recipient and content as an earlier email of this record.
		$resend = $this->emails()->find( Input::int( 'resend' ) );

		if ( $resend instanceof Email && current_user_can( EmailsModule::VIEW_ONE_CAP, $resend->id() ) && (int) $resend->get( $type . '_id' ) === $id ) {
			$values = array_merge(
				$values,
				array(
					'to'          => $resend->to_email(),
					'cc'          => implode( ', ', $resend->cc() ),
					'bcc'         => implode( ', ', array_diff( $resend->bcc(), array( (string) wp_get_current_user()->user_email ) ) ),
					'subject'     => $resend->subject(),
					'body'        => $resend->body(),
					'template_id' => (string) ( $resend->get( 'template_id' ) ?? '' ),
				)
			);
		}

		$errors = array();
		$old    = get_transient( $this->old_input_key( $type, $id ) );

		if ( is_array( $old ) ) {
			delete_transient( $this->old_input_key( $type, $id ) );
			$values = array_merge( $values, (array) ( $old['values'] ?? array() ) );
			$errors = (array) ( $old['errors'] ?? array() );
		}

		View::render(
			'admin/emails/compose',
			array(
				'type'          => $type,
				'record'        => $record,
				'label'         => EmailSender::label( $record ),
				'record_url'    => EmailSender::record_url( $type, $id ),
				'recipients'    => $recipients,
				'templates'     => $templates,
				'values'        => $values,
				'errors'        => $errors,
				'remaining'     => $this->sender()->remaining( get_current_user_id() ),
				'limit'         => $this->sender()->hourly_limit(),
				'has_signature' => $this->sender()->has_signature(),
				'can_settings'  => current_user_can( Capabilities::MANAGE_SETTINGS ),
				'placeholders'  => TemplateRenderer::placeholders(),
			)
		);
	}

	/**
	 * Sends an email (form POST).
	 *
	 * @return void
	 */
	public function handle_send(): void {
		$type = Input::one_of( 'record', array_keys( EmailsModule::PARENTS ), '', 'post' );
		$id   = Input::int( 'record_id', 'post' );

		check_admin_referer( Nonce::action( 'send_email_' . $type . '_' . $id ), Nonce::FIELD );

		if ( ! EmailsModule::can_send_to( $type, $id ) ) {
			Guard::authorize( 'do_not_allow' );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified above; sanitized with wp_kses_post.
		$body  = isset( $_POST['body'] ) ? wp_kses_post( wp_unslash( (string) $_POST['body'] ) ) : '';
		$input = array(
			'to'          => trim( Input::text( 'to', 'post' ) ),
			'cc'          => Input::text( 'cc', 'post' ),
			'bcc'         => Input::text( 'bcc', 'post' ),
			'subject'     => Input::text( 'subject', 'post' ),
			'body'        => $body,
			'template_id' => Input::int( 'template_id', 'post' ),
			'copy_me'     => Input::bool( 'copy_me', 'post' ),
		);

		try {
			$email = $this->sender()->send( $type, $id, $input );
		} catch ( ValidationException $e ) {
			if ( isset( $e->errors()['record'] ) ) {
				Notices::flash( 'error', $e->errors()['record'] );
				wp_safe_redirect( Menu::url() );
				exit;
			}

			set_transient(
				$this->old_input_key( $type, $id ),
				array(
					'values' => array_merge( $input, array( 'template_id' => (string) $input['template_id'] ) ),
					'errors' => $e->errors(),
				),
				10 * MINUTE_IN_SECONDS
			);

			wp_safe_redirect( self::compose_url( $type, $id ) );
			exit;
		}

		if ( $email->is_sent() ) {
			/* translators: %s: Recipient address. */
			Notices::flash( 'success', sprintf( __( 'Email sent to %s.', 'wp-leadflow-crm' ), $email->to_email() ) );
		} else {
			Notices::flash(
				'error',
				sprintf(
					/* translators: %s: Error message from the mail server. */
					__( 'The email could not be sent: %s It was saved in the Emails tab, where you can try again.', 'wp-leadflow-crm' ),
					rtrim( (string) $email->get( 'error', '' ), '.' ) . '.'
				)
			);
		}

		wp_safe_redirect( EmailSender::record_url( $type, $id ) . '#lf-panel-emails' );
		exit;
	}

	/**
	 * Sends a test email (Settings → Email).
	 *
	 * @return void
	 */
	public function handle_test(): void {
		Guard::verify_form( 'send_test_email', Capabilities::MANAGE_SETTINGS );

		$to = Input::email( 'to', 'post' );

		if ( ! is_email( $to ) ) {
			Notices::flash( 'error', __( 'Please enter a valid email address for the test email.', 'wp-leadflow-crm' ) );
		} else {
			$result = $this->sender()->send_test( $to );

			if ( $result['sent'] ) {
				/* translators: %s: Email address. */
				Notices::flash( 'success', sprintf( __( 'Test email sent to %s. Check the inbox (and the spam folder).', 'wp-leadflow-crm' ), $to ) );
			} else {
				/* translators: %s: Error message. */
				Notices::flash( 'error', sprintf( __( 'The test email could not be sent: %s', 'wp-leadflow-crm' ), $result['error'] ) );
			}
		}

		wp_safe_redirect( Menu::url( SettingsModule::PAGE_SLUG, array( 'tab' => 'email' ) ) );
		exit;
	}

	/**
	 * AJAX: renders the compose form exactly as it will be sent.
	 *
	 * POST: subject, body, record ("lead:12", "contact:5", "company:3").
	 *
	 * @return void
	 */
	public function ajax_preview(): void {
		Guard::verify_ajax( 'email', EmailsModule::SEND_CAP );

		$record = Input::text( 'record', 'post' );

		if ( 1 !== preg_match( '/^(lead|contact|company):(\d+)$/', $record, $m ) || ! current_user_can( 'leadflow_view_' . EmailsModule::PARENTS[ $m[1] ] ) ) {
			wp_send_json_error( array( 'message' => __( 'You are not allowed to preview emails for this record.', 'wp-leadflow-crm' ) ), 403 );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified above.
		$subject = isset( $_POST['subject'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['subject'] ) ) : '';
		$body    = isset( $_POST['body'] ) ? wp_kses_post( wp_unslash( (string) $_POST['body'] ) ) : '';
		// phpcs:enable

		$rendered = $this->sender()->render( $m[1], (int) $m[2], $subject, $body );

		if ( null === $rendered ) {
			wp_send_json_error( array( 'message' => __( 'This record no longer exists.', 'wp-leadflow-crm' ) ), 404 );
		}

		wp_send_json_success(
			array_merge(
				$rendered,
				array( 'unknown' => TemplateRenderer::unknown_placeholders( $subject . ' ' . $body ) )
			)
		);
	}

	/**
	 * Active templates keyed by id.
	 *
	 * @return array<int, EmailTemplate>
	 */
	private function templates(): array {
		$templates = array();

		if ( ! current_user_can( 'leadflow_view_email_templates' ) ) {
			return $templates;
		}

		foreach ( $this->plugin->get( EmailTemplateRepository::class )->query(
			array(
				'where'    => array( 'status' => 'active' ),
				'orderby'  => 'name',
				'order'    => 'ASC',
				'per_page' => EmailTemplateRepository::MAX_PER_PAGE,
			)
		) as $template ) {
			if ( $template instanceof EmailTemplate ) {
				$templates[ $template->id() ] = $template;
			}
		}

		return $templates;
	}

	/**
	 * Transient key for a failed compose submission.
	 *
	 * @param string $type Record type.
	 * @param int    $id   Record id.
	 * @return string
	 */
	private function old_input_key( string $type, int $id ): string {
		return 'leadflow_crm_email_' . get_current_user_id() . '_' . $type . '_' . $id;
	}

	/**
	 * Email sender.
	 *
	 * @return EmailSender
	 */
	private function sender(): EmailSender {
		return $this->plugin->get( EmailSender::class );
	}

	/**
	 * Email repository.
	 *
	 * @return EmailRepository
	 */
	private function emails(): EmailRepository {
		return $this->plugin->get( EmailRepository::class );
	}
}
