<?php
// Silence is golden.
