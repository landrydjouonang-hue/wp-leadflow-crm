<?php
/**
 * Email log table.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Emails;

use LeadFlow\CRM\Admin\UI;
use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\Email;
use LeadFlow\CRM\Data\Repositories\CompanyRepository;
use LeadFlow\CRM\Data\Repositories\ContactRepository;
use LeadFlow\CRM\Data\Repositories\EmailRepository;
use LeadFlow\CRM\Data\Repositories\LeadRepository;
use LeadFlow\CRM\Email\EmailSender;
use LeadFlow\CRM\Plugin;
use LeadFlow\CRM\Security\Input;
use LeadFlow\CRM\Settings\Settings;
use LeadFlow\CRM\Support\Format;
use LeadFlow\CRM\Support\Users;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( '\WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * Sent and failed emails. Users without `leadflow_view_others_emails` only
 * see the emails they sent. Read-only: emails are history.
 */
final class EmailsListTable extends \WP_List_Table {

	/**
	 * Related records of the current page: type => id => label.
	 *
	 * @var array<string, array<int, string>>
	 */
	private array $records = array();

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( private Plugin $plugin ) {
		parent::__construct(
			array(
				'singular' => 'email',
				'plural'   => 'emails',
				'ajax'     => false,
				'screen'   => get_current_screen(),
			)
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_columns(): array {
		return array(
			'subject'    => __( 'Subject', 'wp-leadflow-crm' ),
			'to_email'   => __( 'Recipient', 'wp-leadflow-crm' ),
			'record'     => __( 'Related to', 'wp-leadflow-crm' ),
			'status'     => __( 'Status', 'wp-leadflow-crm' ),
			'sent_by'    => __( 'Sent by', 'wp-leadflow-crm' ),
			'created_at' => __( 'Date', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_sortable_columns(): array {
		return array(
			'subject'    => array( 'subject', false ),
			'to_email'   => array( 'to_email', false ),
			'status'     => array( 'status', false ),
			'created_at' => array( 'created_at', true ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_primary_column_name(): string {
		return 'subject';
	}

	/**
	 * Current status view.
	 *
	 * @return string all|sent|failed
	 */
	public function current_status(): string {
		return Input::one_of( 'status', array( 'all', 'sent', 'failed' ), 'all' );
	}

	/**
	 * Base filters: own emails only for users who cannot see everyone's.
	 *
	 * @return array<string, mixed>
	 */
	private function scope(): array {
		if ( ! current_user_can( EmailsModule::VIEW_OTHERS_CAP ) ) {
			return array( 'sent_by' => get_current_user_id() );
		}

		$sender = Input::int( 'sent_by' );

		return $sender > 0 ? array( 'sent_by' => $sender ) : array();
	}

	/**
	 * {@inheritDoc}
	 */
	public function prepare_items(): void {
		$per_page = $this->get_items_per_page( EmailsPage::PER_PAGE_OPTION, max( 5, (int) $this->plugin->get( Settings::class )->get( 'items_per_page', 20 ) ) );
		$orderby  = Input::one_of( 'orderby', array( 'subject', 'to_email', 'status', 'created_at' ), 'created_at' );
		$order    = Input::one_of( 'order', array( 'asc', 'desc' ), 'desc' );
		$where    = $this->scope();

		if ( 'all' !== $this->current_status() ) {
			$where['status'] = $this->current_status();
		}

		$result = $this->repo()->paginate(
			array(
				'where'    => $where,
				'search'   => Input::text( 's' ),
				'orderby'  => $orderby,
				'order'    => $order,
				'per_page' => $per_page,
				'page'     => $this->get_pagenum(),
			)
		);

		$this->items = $result['items'];
		$this->prefetch( $this->items );

		$this->set_pagination_args(
			array(
				'total_items' => $result['total'],
				'per_page'    => $per_page,
				'total_pages' => $result['pages'],
			)
		);
	}

	/**
	 * Loads related record names for the page (no N+1).
	 *
	 * @param Model[] $items Emails.
	 * @return void
	 */
	private function prefetch( array $items ): void {
		$ids = array(
			'lead'    => array(),
			'contact' => array(),
			'company' => array(),
		);

		foreach ( $items as $item ) {
			list( $type, $id ) = EmailSender::owning_record( $item );

			if ( null !== $type ) {
				$ids[ $type ][] = $id;
			}
		}

		$repos = array(
			'lead'    => LeadRepository::class,
			'contact' => ContactRepository::class,
			'company' => CompanyRepository::class,
		);

		foreach ( $repos as $type => $class ) {
			$this->records[ $type ] = array();

			if ( empty( $ids[ $type ] ) ) {
				continue;
			}

			foreach ( $this->plugin->get( $class )->query(
				array(
					'where'    => array( 'id' => array_values( array_unique( $ids[ $type ] ) ) ),
					'trashed'  => 'with',
					'per_page' => 500,
				)
			) as $record ) {
				$this->records[ $type ][ $record->id() ] = EmailSender::label( $record );
			}
		}
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_views(): array {
		$scope   = $this->scope();
		$counts  = $this->repo()->count_by( 'status', $scope );
		$current = $this->current_status();
		$labels  = array(
			'all'    => array( __( 'All', 'wp-leadflow-crm' ), array_sum( $counts ) ),
			'sent'   => array( __( 'Sent', 'wp-leadflow-crm' ), (int) ( $counts['sent'] ?? 0 ) ),
			'failed' => array( __( 'Failed', 'wp-leadflow-crm' ), (int) ( $counts['failed'] ?? 0 ) ),
		);
		$views   = array();

		foreach ( $labels as $status => list( $label, $count ) ) {
			if ( 'failed' === $status && 0 === $count && 'failed' !== $current ) {
				continue;
			}

			$views[ $status ] = sprintf(
				'<a href="%1$s"%2$s>%3$s <span class="count">(%4$s)</span></a>',
				esc_url( add_query_arg( array_filter( array( 'status' => 'all' === $status ? '' : $status, 'sent_by' => $scope['sent_by'] ?? 0 ) ), \LeadFlow\CRM\Admin\Menu::url( EmailsPage::PAGE_SLUG ) ) ),
				$status === $current ? ' class="current" aria-current="page"' : '',
				esc_html( $label ),
				esc_html( number_format_i18n( $count ) )
			);
		}

		return $views;
	}

	/**
	 * Sender filter (managers).
	 *
	 * @param string $which top|bottom.
	 * @return void
	 */
	protected function extra_tablenav( $which ): void {
		if ( 'top' !== $which || ! current_user_can( EmailsModule::VIEW_OTHERS_CAP ) ) {
			return;
		}

		$current = Input::int( 'sent_by' );

		echo '<div class="alignleft actions lf-filters">';
		printf( '<label class="screen-reader-text" for="lf-filter-sent-by">%s</label>', esc_html__( 'Filter by sender', 'wp-leadflow-crm' ) );
		echo '<select id="lf-filter-sent-by" name="sent_by"><option value="">' . esc_html__( 'All senders', 'wp-leadflow-crm' ) . '</option>';

		foreach ( Users::crm_users() as $user_id => $name ) {
			printf( '<option value="%1$d"%2$s>%3$s</option>', (int) $user_id, selected( $current, (int) $user_id, false ), esc_html( $name ) );
		}

		echo '</select>';
		submit_button( __( 'Filter', 'wp-leadflow-crm' ), '', 'filter_action', false, array( 'id' => 'lf-filter-submit' ) );
		echo '</div>';
	}

	/**
	 * Subject with a link to the email.
	 *
	 * @param Email $item Row.
	 * @return string
	 */
	protected function column_subject( $item ): string {
		$url = EmailsPage::view_url( $item->id() );

		return sprintf(
			'<strong><a class="row-title" href="%1$s">%2$s</a></strong><span class="lf-cell-subtitle">%3$s</span>%4$s',
			esc_url( $url ),
			esc_html( '' !== $item->subject() ? $item->subject() : __( '(no subject)', 'wp-leadflow-crm' ) ),
			esc_html( Format::excerpt( $item->body(), 14 ) ),
			$this->row_actions(
				array(
					'view' => sprintf(
						'<a href="%1$s">%2$s<span class="screen-reader-text"> “%3$s”</span></a>',
						esc_url( $url ),
						esc_html__( 'View', 'wp-leadflow-crm' ),
						esc_html( $item->subject() )
					),
				)
			)
		);
	}

	/**
	 * Recipient.
	 *
	 * @param Email $item Row.
	 * @return string
	 */
	protected function column_to_email( $item ): string {
		$name = (string) $item->get( 'to_name', '' );

		return esc_html( '' !== $name ? $name : $item->to_email() ) . ( '' !== $name ? '<span class="lf-cell-subtitle">' . esc_html( $item->to_email() ) . '</span>' : '' );
	}

	/**
	 * Related record.
	 *
	 * @param Email $item Row.
	 * @return string
	 */
	protected function column_record( $item ): string {
		list( $type, $id ) = EmailSender::owning_record( $item );

		if ( null === $type || ! isset( $this->records[ $type ][ $id ] ) ) {
			return UI::text( '' );
		}

		$labels = array(
			'lead'    => __( 'Lead', 'wp-leadflow-crm' ),
			'contact' => __( 'Contact', 'wp-leadflow-crm' ),
			'company' => __( 'Company', 'wp-leadflow-crm' ),
		);
		$name   = $this->records[ $type ][ $id ];

		$link = current_user_can( 'leadflow_view_' . EmailsModule::PARENTS[ $type ] )
			? sprintf( '<a href="%1$s">%2$s</a>', esc_url( EmailSender::record_url( $type, $id ) ), esc_html( $name ) )
			: esc_html( $name );

		return $link . '<span class="lf-cell-subtitle">' . esc_html( $labels[ $type ] ) . '</span>';
	}

	/**
	 * Status.
	 *
	 * @param Email $item Row.
	 * @return string
	 */
	protected function column_status( $item ): string {
		return $item->is_sent()
			? UI::badge( 'sent', __( 'Sent', 'wp-leadflow-crm' ) )
			: UI::badge( 'failed', __( 'Failed', 'wp-leadflow-crm' ) );
	}

	/**
	 * Sender.
	 *
	 * @param Email $item Row.
	 * @return string
	 */
	protected function column_sent_by( $item ): string {
		return UI::text( Format::user( $item->get( 'sent_by' ) ) );
	}

	/**
	 * Date.
	 *
	 * @param Email $item Row.
	 * @return string
	 */
	protected function column_created_at( $item ): string {
		return sprintf(
			'<time datetime="%1$s" title="%2$s">%3$s</time>',
			esc_attr( Format::iso( $item->get( 'created_at' ) ) ),
			esc_attr( Format::datetime( $item->get( 'created_at' ) ) ),
			esc_html( Format::due( $item->get( 'created_at' ) ) )
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function column_default( $item, $column_name ): string {
		return UI::text( (string) $item->get( $column_name, '' ) );
	}

	/**
	 * {@inheritDoc}
	 */
	public function no_items(): void {
		if ( current_user_can( EmailsModule::VIEW_OTHERS_CAP ) ) {
			esc_html_e( 'No emails found. Send one from a lead, contact or company.', 'wp-leadflow-crm' );
			return;
		}

		esc_html_e( 'You have not sent any emails yet. Send one from a lead, contact or company.', 'wp-leadflow-crm' );
	}

	/**
	 * Repository.
	 *
	 * @return EmailRepository
	 */
	private function repo(): EmailRepository {
		return $this->plugin->get( EmailRepository::class );
	}
}
