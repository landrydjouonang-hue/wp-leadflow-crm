<?php
/**
 * Emails module.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Emails;

use LeadFlow\CRM\Admin\Menu;
use LeadFlow\CRM\Admin\RecordPanels;
use LeadFlow\CRM\Admin\View;
use LeadFlow\CRM\Contracts\Module;
use LeadFlow\CRM\Contracts\ProvidesCapabilities;
use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Repositories\EmailRepository;
use LeadFlow\CRM\Email\EmailSender;
use LeadFlow\CRM\Email\Mailer;
use LeadFlow\CRM\Plugin;
use LeadFlow\CRM\Security\Capabilities;
use LeadFlow\CRM\Settings\Registry;
use LeadFlow\CRM\Settings\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Sending emails to leads, contacts and companies.
 *
 * Permissions:
 * - Send: `leadflow_send_emails` AND the edit capability of the record
 *   (`leadflow_edit_{lead|contact|company}` with its id).
 * - Email log: `leadflow_view_emails` shows your own emails;
 *   `leadflow_view_others_emails` shows everyone's.
 * - Read one email (`leadflow_view_email`, meta): you sent it, you can see
 *   everyone's emails, or you can see the record it was sent from.
 * - Email settings and the test email: `leadflow_manage_settings`.
 */
final class EmailsModule implements Module, ProvidesCapabilities {

	/** Send emails to records you can edit. */
	public const SEND_CAP = 'leadflow_send_emails';

	/** See your own emails in the email log. */
	public const VIEW_CAP = 'leadflow_view_emails';

	/** See everyone's emails in the email log. */
	public const VIEW_OTHERS_CAP = 'leadflow_view_others_emails';

	/** Meta capability: read one email (takes the email id). */
	public const VIEW_ONE_CAP = 'leadflow_view_email';

	/** Record type => plural. */
	public const PARENTS = array(
		'company' => 'companies',
		'contact' => 'contacts',
		'lead'    => 'leads',
	);

	/**
	 * Plugin.
	 *
	 * @var Plugin|null
	 */
	private ?Plugin $plugin = null;

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'emails';
	}

	/**
	 * {@inheritDoc}
	 */
	public function capabilities(): array {
		$all      = array( 'administrator', Capabilities::ROLE_MANAGER, Capabilities::ROLE_AGENT );
		$managers = array( 'administrator', Capabilities::ROLE_MANAGER );

		return array(
			self::SEND_CAP        => $all,
			self::VIEW_CAP        => $all,
			self::VIEW_OTHERS_CAP => $managers,
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function boot( Plugin $plugin ): void {
		$this->plugin = $plugin;

		$page = new EmailsPage( $plugin );

		$plugin->get( Menu::class )->add( $page->page() );
		$page->register();

		$this->register_settings( $plugin->get( Registry::class ) );

		add_filter( 'map_meta_cap', array( $this, 'map_meta_cap' ), 10, 4 );
		add_filter( 'leadflow_crm_record_actions', array( $this, 'record_action' ), 10, 3 );
		add_action( 'leadflow_crm_record_panels', array( $this, 'add_panel' ), 35, 3 );
	}

	/**
	 * Whether the current user may email a record.
	 *
	 * @param string $type Record type.
	 * @param int    $id   Record id.
	 * @return bool
	 */
	public static function can_send_to( string $type, int $id ): bool {
		return isset( self::PARENTS[ $type ] )
			&& current_user_can( self::SEND_CAP )
			&& current_user_can( 'leadflow_edit_' . $type, $id );
	}

	/**
	 * Maps `leadflow_view_email` to primitive capabilities.
	 *
	 * @param string[] $caps    Required caps.
	 * @param string   $cap     Requested cap.
	 * @param int      $user_id User.
	 * @param mixed[]  $args    Email id.
	 * @return string[]
	 */
	public function map_meta_cap( array $caps, string $cap, int $user_id, array $args ): array {
		if ( self::VIEW_ONE_CAP !== $cap ) {
			return $caps;
		}

		$email = $this->emails()->find( (int) ( $args[0] ?? 0 ) );

		if ( null === $email ) {
			return array( 'do_not_allow' );
		}

		if ( $user_id > 0 && (int) $email->get( 'sent_by' ) === $user_id ) {
			return array( self::VIEW_CAP );
		}

		if ( user_can( $user_id, self::VIEW_OTHERS_CAP ) ) {
			return array( self::VIEW_OTHERS_CAP );
		}

		list( $type ) = EmailSender::owning_record( $email );

		return null !== $type ? array( self::VIEW_CAP, 'leadflow_view_' . self::PARENTS[ $type ] ) : array( 'do_not_allow' );
	}

	/**
	 * "Send email" button on lead, contact and company screens.
	 *
	 * @param array<int, array<string, mixed>> $actions Buttons.
	 * @param string                           $entity  Entity key.
	 * @param Model                            $model   Record.
	 * @return array<int, array<string, mixed>>
	 */
	public function record_action( array $actions, string $entity, Model $model ): array {
		if ( ! isset( self::PARENTS[ $entity ] ) || $model->is_trashed() || ! self::can_send_to( $entity, $model->id() ) ) {
			return $actions;
		}

		$actions[] = array(
			'label' => __( 'Send email', 'wp-leadflow-crm' ),
			'url'   => EmailsPage::compose_url( $entity, $model->id() ),
		);

		return $actions;
	}

	/**
	 * Emails tab on record screens.
	 *
	 * @param RecordPanels $panels Panel registry.
	 * @param string       $type   Record type.
	 * @param Model        $record Record.
	 * @return void
	 */
	public function add_panel( RecordPanels $panels, string $type, Model $record ): void {
		if ( ! isset( self::PARENTS[ $type ] ) || ! current_user_can( self::VIEW_CAP ) ) {
			return;
		}

		$repo = $this->emails();

		$panels->add(
			'emails',
			array(
				'title'  => __( 'Emails', 'wp-leadflow-crm' ),
				'count'  => $repo->count_for_parent( $type, $record->id() ),
				'order'  => 35,
				'render' => function () use ( $repo, $type, $record ): void {
					View::render(
						'admin/partials/emails-panel',
						array(
							'type'        => $type,
							'record'      => $record,
							'emails'      => $repo->for_parent(
								$type,
								$record->id(),
								array(
									'orderby'  => 'created_at',
									'order'    => 'DESC',
									'per_page' => 25,
								)
							),
							'total'       => $repo->count_for_parent( $type, $record->id() ),
							'can_send'    => ! $record->is_trashed() && self::can_send_to( $type, $record->id() ),
							'compose_url' => EmailsPage::compose_url( $type, $record->id() ),
						)
					);
				},
			)
		);
	}

	/**
	 * Settings → Email.
	 *
	 * @param Registry $registry Settings registry.
	 * @return void
	 */
	private function register_settings( Registry $registry ): void {
		$registry->add_tab( 'email', __( 'Email', 'wp-leadflow-crm' ), 30, array( $this, 'render_settings' ) );

		$registry->add_field(
			'email_from_name',
			array(
				'tab'         => 'email',
				'label'       => __( 'From name', 'wp-leadflow-crm' ),
				'type'        => 'text',
				'default'     => '',
				'description' => __( 'Name recipients see. Leave empty to use your business name.', 'wp-leadflow-crm' ),
			)
		);

		$registry->add_field(
			'email_from_email',
			array(
				'tab'         => 'email',
				'label'       => __( 'From email', 'wp-leadflow-crm' ),
				'type'        => 'email',
				'default'     => '',
				'description' => __( 'Leave empty to use your site’s default sender. Use an address on your own domain so emails are not marked as spam.', 'wp-leadflow-crm' ),
			)
		);

		$registry->add_field(
			'email_reply_to',
			array(
				'tab'         => 'email',
				'label'       => __( 'Replies go to', 'wp-leadflow-crm' ),
				'type'        => 'select',
				'default'     => 'sender',
				'options'     => array(
					'sender' => __( 'The team member who sent the email', 'wp-leadflow-crm' ),
					'from'   => __( 'The From email', 'wp-leadflow-crm' ),
				),
			)
		);

		$registry->add_field(
			'email_signature',
			array(
				'tab'         => 'email',
				'label'       => __( 'Signature', 'wp-leadflow-crm' ),
				'type'        => 'textarea',
				'default'     => '',
				'description' => __( 'Added below every email. Basic HTML and placeholders such as {{sender_name}} and {{business_name}} are allowed.', 'wp-leadflow-crm' ),
				'sanitize'    => static fn( mixed $raw ): string => is_scalar( $raw ) ? wp_kses_post( trim( (string) $raw ) ) : '',
			)
		);

		$registry->add_field(
			'email_bcc_sender',
			array(
				'tab'         => 'email',
				'label'       => __( 'Select “Send me a copy” by default', 'wp-leadflow-crm' ),
				'type'        => 'checkbox',
				'default'     => false,
			)
		);

		$registry->add_field(
			'email_hourly_limit',
			array(
				'tab'         => 'email',
				'label'       => __( 'Emails per user per hour', 'wp-leadflow-crm' ),
				'type'        => 'number',
				'default'     => 50,
				'min'         => 0,
				'max'         => 1000,
				'description' => __( 'Protects your sending reputation if an account is misused. 0 means no limit.', 'wp-leadflow-crm' ),
			)
		);
	}

	/**
	 * Renders the Email settings tab (settings form + test email).
	 *
	 * @param Registry|null $registry Registry (resolved when omitted).
	 * @return void
	 */
	public function render_settings( ?Registry $registry = null ): void {
		$plugin = $this->plugin ?? Plugin::instance();
		$mailer = $plugin->get( Mailer::class );

		View::render(
			'admin/emails/settings',
			array(
				'registry'   => $registry ?? $plugin->get( Registry::class ),
				'group'      => Settings::GROUP,
				'from_name'  => $mailer->from_name(),
				'from_email' => '' !== $mailer->from_email() ? $mailer->from_email() : self::default_from_email(),
				'test_to'    => (string) wp_get_current_user()->user_email,
			)
		);
	}

	/**
	 * The address WordPress uses when no From email is set.
	 *
	 * @return string
	 */
	public static function default_from_email(): string {
		$host = strtolower( (string) wp_parse_url( network_home_url(), PHP_URL_HOST ) );

		if ( str_starts_with( $host, 'www.' ) ) {
			$host = substr( $host, 4 );
		}

		return (string) apply_filters( 'wp_mail_from', 'wordpress@' . $host );
	}

	/**
	 * Email repository.
	 *
	 * @return EmailRepository
	 */
	private function emails(): EmailRepository {
		return ( $this->plugin ?? Plugin::instance() )->get( EmailRepository::class );
	}
}
