<?php
/**
 * Contact lookup REST endpoint.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Contacts;

use LeadFlow\CRM\Data\Models\Contact;
use LeadFlow\CRM\Data\Repositories\ContactRepository;
use LeadFlow\CRM\Rest\Controller;

defined( 'ABSPATH' ) || exit;

/**
 * GET /wp-json/leadflow-crm/v1/lookup/contacts?search=jane&per_page=20
 *
 * Id/name search used by contact pickers.
 */
final class ContactLookupController extends Controller {

	/**
	 * Constructor.
	 *
	 * @param ContactRepository $contacts Contacts.
	 */
	public function __construct( private ContactRepository $contacts ) {}

	/**
	 * {@inheritDoc}
	 */
	public function register_routes(): void {
		register_rest_route(
			self::REST_NAMESPACE,
			'/lookup/contacts',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'search' ),
					'permission_callback' => $this->require_capability( 'leadflow_view_contacts' ),
					'args'                => array(
						'search'   => array(
							'type'              => 'string',
							'default'           => '',
							'sanitize_callback' => 'sanitize_text_field',
						),
						'per_page' => array(
							'type'    => 'integer',
							'default' => 20,
							'minimum' => 1,
							'maximum' => 50,
						),
					),
				),
			)
		);
	}

	/**
	 * Returns matching contacts.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public function search( \WP_REST_Request $request ): \WP_REST_Response {
		$contacts = $this->contacts->query(
			array(
				'search'   => (string) $request->get_param( 'search' ),
				'orderby'  => 'last_name',
				'order'    => 'ASC',
				'per_page' => (int) $request->get_param( 'per_page' ),
			)
		);

		return rest_ensure_response(
			array_map(
				static fn( Contact $contact ): array => array(
					'id'         => $contact->id(),
					'name'       => $contact->full_name(),
					'company_id' => $contact->company_id(),
				),
				$contacts
			)
		);
	}
}
