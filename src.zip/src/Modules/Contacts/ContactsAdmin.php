<?php
/**
 * Contacts admin screens.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Contacts;

use LeadFlow\CRM\Admin\Crud\EntityAdmin;
use LeadFlow\CRM\Admin\Crud\EntityListTable;
use LeadFlow\CRM\Admin\Notes\NoteActions;
use LeadFlow\CRM\Admin\View;
use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\Contact;
use LeadFlow\CRM\Data\Relations;
use LeadFlow\CRM\Data\Repositories\CompanyRepository;
use LeadFlow\CRM\Data\Repositories\ContactRepository;
use LeadFlow\CRM\Data\Repositories\NoteRepository;
use LeadFlow\CRM\Data\Repository;
use LeadFlow\CRM\Modules\Companies\CompaniesAdmin;
use LeadFlow\CRM\Security\Input;

defined( 'ABSPATH' ) || exit;

/**
 * List, add, edit and view contacts.
 */
final class ContactsAdmin extends EntityAdmin {

	protected const ENTITY     = 'contact';
	protected const PLURAL     = 'contacts';
	protected const PAGE_SLUG  = 'leadflow-crm-contacts';
	protected const MENU_ORDER = 40;

	/** Companies loaded into pickers before search is needed. */
	public const COMPANY_OPTIONS_LIMIT = 200;

	/**
	 * {@inheritDoc}
	 */
	public function repository(): Repository {
		return $this->plugin->get( ContactRepository::class );
	}

	/**
	 * {@inheritDoc}
	 */
	public function labels(): array {
		return array(
			'singular'        => __( 'Contact', 'wp-leadflow-crm' ),
			'plural'          => __( 'Contacts', 'wp-leadflow-crm' ),
			'add_new'         => __( 'Add contact', 'wp-leadflow-crm' ),
			'search'          => __( 'Search contacts', 'wp-leadflow-crm' ),
			'not_found'       => __( 'No contacts found.', 'wp-leadflow-crm' ),
			'not_found_trash' => __( 'No contacts in the trash.', 'wp-leadflow-crm' ),
			'created'         => __( 'Contact created.', 'wp-leadflow-crm' ),
			'updated'         => __( 'Contact updated.', 'wp-leadflow-crm' ),
			'trashed'         => __( 'Contact moved to the trash.', 'wp-leadflow-crm' ),
			'restored'        => __( 'Contact restored.', 'wp-leadflow-crm' ),
			'deleted'         => __( 'Contact permanently deleted.', 'wp-leadflow-crm' ),
			'delete_confirm'  => __( 'Permanently delete this contact? Their leads are kept but unlinked; notes that belong only to this contact are deleted. This cannot be undone.', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function status_labels(): array {
		return array(
			'active'   => __( 'Active', 'wp-leadflow-crm' ),
			'inactive' => __( 'Inactive', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function title_of( Model $model ): string {
		if ( $model instanceof Contact ) {
			$name = $model->full_name();

			return '' !== $name ? $name : __( '(no name)', 'wp-leadflow-crm' );
		}

		return '';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function form_sections( ?Model $model ): array {
		$company = array(
			'name'        => 'company_id',
			'label'       => __( 'Company', 'wp-leadflow-crm' ),
			'type'        => 'record',
			'width'       => 'half',
			'options'     => $this->company_options( null !== $model ? (int) $model->get( 'company_id', 0 ) : Input::int( 'company_id' ) ),
			'empty_label' => __( 'No company', 'wp-leadflow-crm' ),
		);

		if ( current_user_can( 'leadflow_view_companies' ) ) {
			$company['search'] = array(
				'endpoint' => 'lookup/companies',
				'label'    => __( 'Search companies…', 'wp-leadflow-crm' ),
			);
		}

		$sections = array(
			array(
				'title'       => __( 'Personal details', 'wp-leadflow-crm' ),
				'description' => __( 'A first name, last name or email address is required.', 'wp-leadflow-crm' ),
				'fields'      => array(
					array(
						'name'         => 'first_name',
						'label'        => __( 'First name', 'wp-leadflow-crm' ),
						'width'        => 'half',
						'maxlength'    => 100,
						'autocomplete' => 'given-name',
					),
					array(
						'name'         => 'last_name',
						'label'        => __( 'Last name', 'wp-leadflow-crm' ),
						'width'        => 'half',
						'maxlength'    => 100,
						'autocomplete' => 'family-name',
					),
					array(
						'name'         => 'job_title',
						'label'        => __( 'Job title', 'wp-leadflow-crm' ),
						'width'        => 'half',
						'maxlength'    => 150,
						'autocomplete' => 'organization-title',
					),
					$company,
				),
			),
			array(
				'title'  => __( 'Contact information', 'wp-leadflow-crm' ),
				'fields' => array(
					array(
						'name'         => 'email',
						'label'        => __( 'Email', 'wp-leadflow-crm' ),
						'type'         => 'email',
						'maxlength'    => 100,
						'autocomplete' => 'email',
					),
					array(
						'name'         => 'phone',
						'label'        => __( 'Phone', 'wp-leadflow-crm' ),
						'type'         => 'tel',
						'width'        => 'half',
						'maxlength'    => 50,
						'autocomplete' => 'tel',
					),
					array(
						'name'      => 'mobile',
						'label'     => __( 'Mobile', 'wp-leadflow-crm' ),
						'type'      => 'tel',
						'width'     => 'half',
						'maxlength' => 50,
					),
					array(
						'name'        => 'country',
						'label'       => __( 'Country', 'wp-leadflow-crm' ),
						'type'        => 'country',
						'width'       => 'half',
						'empty_label' => __( 'Select a country', 'wp-leadflow-crm' ),
					),
				),
			),
		);

		if ( null === $model && current_user_can( \LeadFlow\CRM\Security\Permissions::MANAGE_NOTES ) ) {
			$sections[] = CompaniesAdmin::initial_note_section();
		}

		return $sections;
	}

	/**
	 * {@inheritDoc}
	 */
	protected function sidebar_fields( ?Model $model ): array {
		$fields = array(
			array(
				'name'     => 'status',
				'label'    => __( 'Status', 'wp-leadflow-crm' ),
				'type'     => 'select',
				'required' => true,
				'options'  => $this->status_labels(),
			),
			array(
				'name'        => 'source',
				'label'       => __( 'Source', 'wp-leadflow-crm' ),
				'maxlength'   => 50,
				'description' => __( 'Where this contact came from, e.g. referral, website, event.', 'wp-leadflow-crm' ),
			),
		);

		if ( current_user_can( $this->cap( 'edit_others' ) ) ) {
			$fields[] = CompaniesAdmin::owner_field( $model );
		}

		return $fields;
	}

	/**
	 * {@inheritDoc}
	 */
	protected function default_values(): array {
		$values = array(
			'status'   => 'active',
			'owner_id' => get_current_user_id(),
		);

		// "Add contact" from a company screen pre-selects the company.
		$company = Input::int( 'company_id' );

		if ( $company > 0 && null !== $this->plugin->get( CompanyRepository::class )->find( $company ) ) {
			$values['company_id'] = $company;
		}

		return $values;
	}

	/**
	 * {@inheritDoc}
	 */
	protected function after_save( Model $model, bool $created, array $extra ): void {
		CompaniesAdmin::save_initial_note( $this->plugin->get( NoteRepository::class ), 'contact_id', $model->id(), $extra );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function create_list_table(): EntityListTable {
		return new ContactsListTable( $this, $this->repository() );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function render_view( Model $model ): void {
		$relations = $this->plugin->get( Relations::class );

		View::render(
			'admin/contacts/view',
			array(
				'admin'         => $this,
				'contact'       => $model,
				'company'       => $model instanceof Contact ? $relations->company_of_contact( $model ) : null,
				'company_admin' => new CompaniesAdmin( $this->plugin ),
				'summary'       => $relations->summary( 'contact', $model->id() ),
				'note_actions'  => $this->plugin->get( NoteActions::class ),
			)
		);
	}

	/**
	 * Companies for pickers and filters: the first N by name, plus the
	 * currently selected one.
	 *
	 * @param int $include Company id that must be present.
	 * @return array<int, string> Id => name.
	 */
	public function company_options( int $include = 0 ): array {
		$companies = $this->plugin->get( CompanyRepository::class );
		$options   = array();

		foreach ( $companies->query(
			array(
				'orderby'  => 'name',
				'order'    => 'ASC',
				'per_page' => self::COMPANY_OPTIONS_LIMIT,
			)
		) as $company ) {
			$options[ $company->id() ] = (string) $company->get( 'name' );
		}

		if ( $include > 0 && ! isset( $options[ $include ] ) ) {
			$current = $companies->find( $include, true );

			if ( null !== $current ) {
				$options[ $include ] = (string) $current->get( 'name' );
			}
		}

		return $options;
	}
}
