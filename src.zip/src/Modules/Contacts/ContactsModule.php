<?php
/**
 * Contacts module.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Contacts;

use LeadFlow\CRM\Admin\Menu;
use LeadFlow\CRM\Admin\View;
use LeadFlow\CRM\Contracts\Module;
use LeadFlow\CRM\Contracts\ProvidesCapabilities;
use LeadFlow\CRM\Contracts\ProvidesRestControllers;
use LeadFlow\CRM\Data\Repositories\ContactRepository;
use LeadFlow\CRM\Modules\Dashboard\Sections;
use LeadFlow\CRM\Plugin;

defined( 'ABSPATH' ) || exit;

/**
 * Contact management.
 */
final class ContactsModule implements Module, ProvidesCapabilities, ProvidesRestControllers {

	/**
	 * Admin controller.
	 *
	 * @var ContactsAdmin|null
	 */
	private ?ContactsAdmin $admin = null;

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'contacts';
	}

	/**
	 * {@inheritDoc}
	 */
	public function capabilities(): array {
		return $this->admin()->capability_map();
	}

	/**
	 * {@inheritDoc}
	 */
	public function rest_controllers(): array {
		return array( new ContactLookupController( Plugin::instance()->get( ContactRepository::class ) ) );
	}

	/**
	 * {@inheritDoc}
	 */
	public function boot( Plugin $plugin ): void {
		$admin = $this->admin();

		$plugin->get( Menu::class )->add( $admin->page() );
		$admin->register();

		add_action( 'leadflow_crm_dashboard_sections', array( $this, 'dashboard_section' ) );
	}

	/**
	 * Replaces the dashboard placeholder with a live summary.
	 *
	 * @param Sections $sections Dashboard sections.
	 * @return void
	 */
	public function dashboard_section( Sections $sections ): void {
		$sections->add(
			'contacts',
			array(
				'title'      => __( 'Contacts', 'wp-leadflow-crm' ),
				'icon'       => 'businessperson',
				'order'      => 40,
				'capability' => $this->admin()->cap( 'view' ),
				'render'     => array( $this, 'render_dashboard_section' ),
			)
		);
	}

	/**
	 * Dashboard widget.
	 *
	 * @return void
	 */
	public function render_dashboard_section(): void {
		$admin      = $this->admin();
		$repository = $admin->repository();

		View::render(
			'admin/partials/entity-widget',
			array(
				'admin'    => $admin,
				'counts'   => $repository->count_by( 'status' ),
				'statuses' => $admin->status_labels(),
				'recent'   => $repository->query( array( 'per_page' => 5 ) ),
				'can_add'  => current_user_can( $admin->cap( 'edit' ) ),
			)
		);
	}

	/**
	 * Lazily built admin controller.
	 *
	 * @return ContactsAdmin
	 */
	private function admin(): ContactsAdmin {
		if ( null === $this->admin ) {
			$this->admin = new ContactsAdmin( Plugin::instance() );
		}

		return $this->admin;
	}
}
