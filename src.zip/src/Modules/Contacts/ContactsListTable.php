<?php
/**
 * Contacts list table.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Contacts;

use LeadFlow\CRM\Admin\Crud\EntityListTable;
use LeadFlow\CRM\Admin\Menu;
use LeadFlow\CRM\Admin\UI;
use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\Company;
use LeadFlow\CRM\Data\Relations;
use LeadFlow\CRM\Security\Input;
use LeadFlow\CRM\Support\Countries;
use LeadFlow\CRM\Support\Users;

defined( 'ABSPATH' ) || exit;

/**
 * Contacts table.
 */
final class ContactsListTable extends EntityListTable {

	/**
	 * Companies of the current page.
	 *
	 * @var array<int, Company>
	 */
	private array $companies = array();

	/**
	 * {@inheritDoc}
	 */
	public function get_columns(): array {
		return array(
			'cb'         => '<input type="checkbox" />',
			'name'       => __( 'Name', 'wp-leadflow-crm' ),
			'company_id' => __( 'Company', 'wp-leadflow-crm' ),
			'email'      => __( 'Email', 'wp-leadflow-crm' ),
			'phone'      => __( 'Phone', 'wp-leadflow-crm' ),
			'country'    => __( 'Country', 'wp-leadflow-crm' ),
			'status'     => __( 'Status', 'wp-leadflow-crm' ),
			'owner_id'   => __( 'Owner', 'wp-leadflow-crm' ),
			'created_at' => __( 'Created', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_sortable_columns(): array {
		return array(
			'name'       => array( 'last_name', false ),
			'email'      => array( 'email', false ),
			'country'    => array( 'country', false ),
			'status'     => array( 'status', false ),
			'created_at' => array( 'created_at', true ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_primary_column_name(): string {
		return 'name';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function filter_args(): array {
		$where = array();

		foreach ( array( 'owner' => 'owner_id', 'company_id' => 'company_id' ) as $param => $column ) {
			$value = Input::int( $param );

			if ( $value > 0 ) {
				$where[ $column ] = $value;
			}
		}

		return array( 'where' => $where );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function render_filters(): void {
		$admin = $this->admin;

		if ( $admin instanceof ContactsAdmin && current_user_can( 'leadflow_view_companies' ) ) {
			$this->filter_select( 'company_id', __( 'Filter by company', 'wp-leadflow-crm' ), $admin->company_options( Input::int( 'company_id' ) ), __( 'All companies', 'wp-leadflow-crm' ) );
		}

		$this->filter_select( 'owner', __( 'Filter by owner', 'wp-leadflow-crm' ), Users::crm_users(), __( 'All owners', 'wp-leadflow-crm' ) );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function prefetch( array $items ): void {
		$this->companies = leadflow_crm()->get( Relations::class )->companies_for( $items );
	}

	/**
	 * Name column.
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_name( Model $item ): string {
		return $this->primary_cell( $item, (string) $item->get( 'job_title', '' ), UI::avatar( $this->admin->title_of( $item ), 'sm' ) );
	}

	/**
	 * Company column.
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_company_id( Model $item ): string {
		$company = $this->companies[ (int) $item->get( 'company_id', 0 ) ] ?? null;

		if ( null === $company ) {
			return UI::text( '' );
		}

		if ( ! current_user_can( 'leadflow_view_companies' ) ) {
			return esc_html( $company->name() );
		}

		return sprintf(
			'<a href="%1$s">%2$s</a>',
			esc_url(
				Menu::url(
					'leadflow-crm-companies',
					array(
						'action' => 'view',
						'id'     => $company->id(),
					)
				)
			),
			esc_html( $company->name() )
		);
	}

	/**
	 * Email column.
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_email( Model $item ): string {
		return UI::email( (string) $item->get( 'email', '' ) );
	}

	/**
	 * Phone column (falls back to mobile).
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_phone( Model $item ): string {
		$phone = (string) $item->get( 'phone', '' );

		return UI::phone( '' !== $phone ? $phone : (string) $item->get( 'mobile', '' ) );
	}

	/**
	 * Country column.
	 *
	 * @param Model $item Row.
	 * @return string
	 */
	protected function column_country( Model $item ): string {
		return UI::text( Countries::name( (string) $item->get( 'country', '' ) ) );
	}
}
