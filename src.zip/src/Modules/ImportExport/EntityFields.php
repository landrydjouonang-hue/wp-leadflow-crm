<?php
/**
 * Import/export field definitions.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\ImportExport;

use LeadFlow\CRM\Data\Repositories\CompanyRepository;
use LeadFlow\CRM\Data\Repositories\ContactRepository;
use LeadFlow\CRM\Data\Repositories\LeadRepository;

defined( 'ABSPATH' ) || exit;

/**
 * What can be imported for each entity and how CSV values are converted.
 *
 * Field types:
 *   text          trimmed as is (validated by the repository)
 *   money         "1,234.50", "$1 234,50" → 1234.50
 *   date          per the chosen date format → Y-m-d
 *   country       ISO code or country name → ISO code
 *   status        status key or label
 *   stage         pipeline stage name or slug
 *   owner         user email, login or display name (CRM users only)
 *   company_name  existing company by name (optionally created)
 *   contact_email existing contact by email
 *   full_name     split into first/last name
 */
final class EntityFields {

	/** Supported entities. */
	public const ENTITIES = array( 'leads', 'contacts', 'companies' );

	/**
	 * Entity definition.
	 *
	 * @param string $entity leads|contacts|companies.
	 * @return array{label: string, singular: string, repository: string, fields: array<string, array{label: string, type: string, required: bool, aliases: string[]}>}
	 */
	public static function get( string $entity ): array {
		$all = self::all();

		if ( ! isset( $all[ $entity ] ) ) {
			throw new \InvalidArgumentException( 'Unknown entity.' );
		}

		return $all[ $entity ];
	}

	/**
	 * Entity labels.
	 *
	 * @return array<string, string>
	 */
	public static function labels(): array {
		return array_map( static fn( array $d ): string => $d['label'], self::all() );
	}

	/**
	 * All definitions.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	private static function all(): array {
		$f = static fn( string $label, string $type = 'text', array $aliases = array(), bool $required = false ): array => array(
			'label'    => $label,
			'type'     => $type,
			'required' => $required,
			'aliases'  => $aliases,
		);

		$address = array(
			'address_line_1' => $f( __( 'Street address', 'wp-leadflow-crm' ), 'text', array( 'address', 'street', 'address 1', 'address line 1', 'street address' ) ),
			'address_line_2' => $f( __( 'Address line 2', 'wp-leadflow-crm' ), 'text', array( 'address 2', 'address line 2', 'suite', 'apartment' ) ),
			'city'           => $f( __( 'City', 'wp-leadflow-crm' ), 'text', array( 'city', 'town', 'locality' ) ),
			'state'          => $f( __( 'State / region', 'wp-leadflow-crm' ), 'text', array( 'state', 'region', 'province', 'county' ) ),
			'postal_code'    => $f( __( 'Postal code', 'wp-leadflow-crm' ), 'text', array( 'postal code', 'postcode', 'zip', 'zip code', 'zipcode' ) ),
		);

		$definitions = array(
			'leads'     => array(
				'label'      => __( 'Leads', 'wp-leadflow-crm' ),
				'singular'   => __( 'lead', 'wp-leadflow-crm' ),
				'repository' => LeadRepository::class,
				'fields'     => array(
					'title'               => $f( __( 'Lead name', 'wp-leadflow-crm' ), 'text', array( 'lead', 'lead name', 'deal', 'deal name', 'opportunity', 'title', 'name' ), true ),
					'company'             => $f( __( 'Company (name)', 'wp-leadflow-crm' ), 'company_name', array( 'company', 'company name', 'organization', 'organisation', 'account' ) ),
					'contact_email'       => $f( __( 'Contact (email)', 'wp-leadflow-crm' ), 'contact_email', array( 'contact email', 'contact' ) ),
					'email'               => $f( __( 'Email', 'wp-leadflow-crm' ), 'text', array( 'email', 'e-mail', 'email address' ) ),
					'phone'               => $f( __( 'Phone', 'wp-leadflow-crm' ), 'text', array( 'phone', 'telephone', 'tel', 'phone number' ) ),
					'amount'              => $f( __( 'Value', 'wp-leadflow-crm' ), 'money', array( 'value', 'amount', 'deal value', 'price', 'revenue', 'deal amount' ) ),
					'currency'            => $f( __( 'Currency', 'wp-leadflow-crm' ), 'text', array( 'currency', 'currency code' ) ),
					'stage'               => $f( __( 'Sales stage', 'wp-leadflow-crm' ), 'stage', array( 'stage', 'sales stage', 'pipeline stage', 'deal stage' ) ),
					'source'              => $f( __( 'Source', 'wp-leadflow-crm' ), 'text', array( 'source', 'lead source', 'channel' ) ),
					'probability'         => $f( __( 'Win probability (%)', 'wp-leadflow-crm' ), 'text', array( 'probability', 'win probability', 'chance' ) ),
					'expected_close_date' => $f( __( 'Expected close date', 'wp-leadflow-crm' ), 'date', array( 'close date', 'expected close', 'expected close date', 'closing date' ) ),
					'description'         => $f( __( 'Description', 'wp-leadflow-crm' ), 'text', array( 'description', 'notes', 'details' ) ),
					'owner'               => $f( __( 'Assigned to (user email or login)', 'wp-leadflow-crm' ), 'owner', array( 'owner', 'assigned to', 'assignee', 'owner email', 'sales rep' ) ),
				),
			),
			'contacts'  => array(
				'label'      => __( 'Contacts', 'wp-leadflow-crm' ),
				'singular'   => __( 'contact', 'wp-leadflow-crm' ),
				'repository' => ContactRepository::class,
				'fields'     => array(
					'first_name' => $f( __( 'First name', 'wp-leadflow-crm' ), 'text', array( 'first name', 'firstname', 'given name', 'forename' ) ),
					'last_name'  => $f( __( 'Last name', 'wp-leadflow-crm' ), 'text', array( 'last name', 'lastname', 'surname', 'family name' ) ),
					'full_name'  => $f( __( 'Full name (split into first/last)', 'wp-leadflow-crm' ), 'full_name', array( 'full name', 'name', 'contact name' ) ),
					'email'      => $f( __( 'Email', 'wp-leadflow-crm' ), 'text', array( 'email', 'e-mail', 'email address' ) ),
					'phone'      => $f( __( 'Phone', 'wp-leadflow-crm' ), 'text', array( 'phone', 'telephone', 'tel', 'phone number', 'work phone' ) ),
					'mobile'     => $f( __( 'Mobile', 'wp-leadflow-crm' ), 'text', array( 'mobile', 'cell', 'mobile phone', 'cell phone' ) ),
					'job_title'  => $f( __( 'Job title', 'wp-leadflow-crm' ), 'text', array( 'job title', 'title', 'position', 'role' ) ),
					'company'    => $f( __( 'Company (name)', 'wp-leadflow-crm' ), 'company_name', array( 'company', 'company name', 'organization', 'organisation', 'account' ) ),
					'country'    => $f( __( 'Country', 'wp-leadflow-crm' ), 'country', array( 'country', 'country code' ) ),
					'status'     => $f( __( 'Status', 'wp-leadflow-crm' ), 'status', array( 'status' ) ),
					'source'     => $f( __( 'Source', 'wp-leadflow-crm' ), 'text', array( 'source', 'lead source' ) ),
					'owner'      => $f( __( 'Owner (user email or login)', 'wp-leadflow-crm' ), 'owner', array( 'owner', 'assigned to', 'owner email' ) ),
				),
			),
			'companies' => array(
				'label'      => __( 'Companies', 'wp-leadflow-crm' ),
				'singular'   => __( 'company', 'wp-leadflow-crm' ),
				'repository' => CompanyRepository::class,
				'fields'     => array_merge(
					array(
						'name'     => $f( __( 'Company name', 'wp-leadflow-crm' ), 'text', array( 'company', 'company name', 'name', 'organization', 'organisation', 'account', 'account name' ), true ),
						'industry' => $f( __( 'Industry', 'wp-leadflow-crm' ), 'text', array( 'industry', 'sector' ) ),
						'website'  => $f( __( 'Website', 'wp-leadflow-crm' ), 'text', array( 'website', 'url', 'web', 'site', 'domain' ) ),
						'email'    => $f( __( 'Email', 'wp-leadflow-crm' ), 'text', array( 'email', 'e-mail', 'email address' ) ),
						'phone'    => $f( __( 'Phone', 'wp-leadflow-crm' ), 'text', array( 'phone', 'telephone', 'tel', 'phone number' ) ),
					),
					$address,
					array(
						'country'     => $f( __( 'Country', 'wp-leadflow-crm' ), 'country', array( 'country', 'country code' ) ),
						'status'      => $f( __( 'Status', 'wp-leadflow-crm' ), 'status', array( 'status', 'type' ) ),
						'description' => $f( __( 'Description', 'wp-leadflow-crm' ), 'text', array( 'description', 'notes', 'about' ) ),
						'owner'       => $f( __( 'Owner (user email or login)', 'wp-leadflow-crm' ), 'owner', array( 'owner', 'assigned to', 'owner email' ) ),
					)
				),
			),
		);

		/**
		 * Filters importable fields.
		 *
		 * @param array $definitions Entity => definition.
		 */
		return (array) apply_filters( 'leadflow_crm_import_fields', $definitions );
	}

	/**
	 * Suggests a field for each CSV header (exact alias match first).
	 *
	 * @param string   $entity  Entity.
	 * @param string[] $headers CSV headers.
	 * @return array<int, string> Column index => field key ('' = skip).
	 */
	public static function guess_mapping( string $entity, array $headers ): array {
		$fields  = self::get( $entity )['fields'];
		$mapping = array();
		$used    = array();

		foreach ( $headers as $index => $header ) {
			$normalized       = self::normalize( (string) $header );
			$mapping[ $index ] = '';

			foreach ( $fields as $key => $field ) {
				$candidates = array_merge( array( $key, $field['label'] ), $field['aliases'] );

				foreach ( $candidates as $candidate ) {
					if ( self::normalize( $candidate ) === $normalized && ! isset( $used[ $key ] ) ) {
						$mapping[ $index ] = $key;
						$used[ $key ]      = true;
						break 2;
					}
				}
			}
		}

		return $mapping;
	}

	/**
	 * Normalizes a header for matching ("E-mail Address" → "emailaddress").
	 *
	 * @param string $text Header.
	 * @return string
	 */
	public static function normalize( string $text ): string {
		return (string) preg_replace( '/[^a-z0-9]/', '', strtolower( remove_accents( $text ) ) );
	}
}
