<?php
/**
 * CSV reader.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\ImportExport;

defined( 'ABSPATH' ) || exit;

/**
 * Reads uploaded CSV files robustly:
 * - UTF-8 with or without BOM; other encodings converted from Windows-1252;
 * - delimiter detected (comma, semicolon, tab, pipe);
 * - \r\n, \n and \r line endings; quoted fields with embedded newlines;
 * - blank rows skipped; rows padded/trimmed to the header width.
 */
final class CsvReader {

	/**
	 * Normalized content stream.
	 *
	 * @var resource
	 */
	private $stream;

	/**
	 * Delimiter.
	 *
	 * @var string
	 */
	private string $delimiter;

	/**
	 * Header row.
	 *
	 * @var string[]
	 */
	private array $headers = array();

	/**
	 * Constructor.
	 *
	 * @param string $path File path.
	 * @throws \RuntimeException When the file cannot be read.
	 */
	public function __construct( string $path ) {
		$content = is_readable( $path ) ? file_get_contents( $path ) : false; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local upload.

		if ( false === $content ) {
			throw new \RuntimeException( 'The file could not be read.' );
		}

		if ( str_starts_with( $content, "\xEF\xBB\xBF" ) ) {
			$content = substr( $content, 3 );
		}

		if ( ! mb_check_encoding( $content, 'UTF-8' ) ) {
			$content = mb_convert_encoding( $content, 'UTF-8', 'Windows-1252' );
		}

		$content = str_replace( array( "\r\n", "\r" ), "\n", $content );

		$first_line      = strtok( $content, "\n" );
		$this->delimiter = self::detect_delimiter( false === $first_line ? '' : $first_line );

		$this->stream = fopen( 'php://temp', 'r+' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- In-memory stream.
		fwrite( $this->stream, $content ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
		rewind( $this->stream );

		$headers       = fgetcsv( $this->stream, 0, $this->delimiter, '"', '' );
		$this->headers = is_array( $headers ) ? array_map( static fn( $h ): string => trim( (string) $h ), $headers ) : array();
	}

	/**
	 * Picks the delimiter that splits the header line the most.
	 *
	 * @param string $line First line.
	 * @return string
	 */
	public static function detect_delimiter( string $line ): string {
		$best  = ',';
		$count = 0;

		foreach ( array( ',', ';', "\t", '|' ) as $candidate ) {
			$found = substr_count( $line, $candidate );

			if ( $found > $count ) {
				$best  = $candidate;
				$count = $found;
			}
		}

		return $best;
	}

	/**
	 * Header row.
	 *
	 * @return string[]
	 */
	public function headers(): array {
		return $this->headers;
	}

	/**
	 * Delimiter in use.
	 *
	 * @return string
	 */
	public function delimiter(): string {
		return $this->delimiter;
	}

	/**
	 * Data rows (1-based row numbers, header excluded).
	 *
	 * @param int      $offset Rows to skip.
	 * @param int|null $limit  Max rows.
	 * @return \Generator<int, string[]>
	 */
	public function rows( int $offset = 0, ?int $limit = null ): \Generator {
		rewind( $this->stream );
		fgetcsv( $this->stream, 0, $this->delimiter, '"', '' );

		$width  = count( $this->headers );
		$number = 0;
		$given  = 0;

		while ( false !== ( $row = fgetcsv( $this->stream, 0, $this->delimiter, '"', '' ) ) ) {
			if ( array( null ) === $row || '' === trim( implode( '', array_map( 'strval', $row ) ) ) ) {
				continue;
			}

			++$number;

			if ( $number <= $offset ) {
				continue;
			}

			if ( null !== $limit && $given >= $limit ) {
				return;
			}

			$row = array_map( static fn( $v ): string => trim( (string) $v ), $row );
			$row = array_slice( array_pad( $row, $width, '' ), 0, $width );

			++$given;

			yield $number => $row;
		}
	}

	/**
	 * Number of data rows.
	 *
	 * @return int
	 */
	public function count(): int {
		$count = 0;

		foreach ( $this->rows() as $row ) {
			++$count;
		}

		return $count;
	}
}
