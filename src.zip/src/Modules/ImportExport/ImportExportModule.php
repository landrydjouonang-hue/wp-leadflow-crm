<?php
/**
 * Import / export module.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\ImportExport;

use LeadFlow\CRM\Admin\Menu;
use LeadFlow\CRM\Contracts\Module;
use LeadFlow\CRM\Contracts\ProvidesCapabilities;
use LeadFlow\CRM\Plugin;
use LeadFlow\CRM\Security\Capabilities;

defined( 'ABSPATH' ) || exit;

/**
 * CSV import (leads, contacts, companies) and export.
 */
final class ImportExportModule implements Module, ProvidesCapabilities {

	/** Run imports. */
	public const IMPORT_CAP = 'leadflow_import_data';

	/** Download exports. */
	public const EXPORT_CAP = 'leadflow_export_data';

	/** Meta capability: import OR export (menu access). */
	public const PAGE_CAP = 'leadflow_use_import_export';

	/** Daily clean-up of abandoned uploads. */
	public const CLEANUP_HOOK = 'leadflow_crm_cleanup_imports';

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'import-export';
	}

	/**
	 * {@inheritDoc}
	 */
	public function capabilities(): array {
		$managers = array( 'administrator', Capabilities::ROLE_MANAGER );

		return array(
			self::IMPORT_CAP => $managers,
			self::EXPORT_CAP => $managers,
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function boot( Plugin $plugin ): void {
		$page = new ImportExportPage( $plugin );

		$plugin->get( Menu::class )->add( $page->page() );
		$page->register();

		add_filter( 'map_meta_cap', array( $this, 'map_meta_cap' ), 10, 2 );
		add_action( self::CLEANUP_HOOK, array( self::class, 'cleanup' ) );

		if ( false === wp_next_scheduled( self::CLEANUP_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CLEANUP_HOOK );
		}
	}

	/**
	 * The menu is visible to users who can import or export.
	 *
	 * @param string[] $caps Required caps.
	 * @param string   $cap  Requested cap.
	 * @return string[]
	 */
	public function map_meta_cap( array $caps, string $cap ): array {
		if ( self::PAGE_CAP !== $cap ) {
			return $caps;
		}

		return current_user_can( self::IMPORT_CAP ) || current_user_can( self::EXPORT_CAP ) ? array( 'exist' ) : array( 'do_not_allow' );
	}

	/**
	 * Protected upload folder for import files.
	 *
	 * @return string
	 */
	public static function upload_dir(): string {
		return trailingslashit( wp_upload_dir( null, false )['basedir'] ) . 'leadflow-crm/imports';
	}

	/**
	 * Creates the folder with deny-all protection.
	 *
	 * @return string Path, '' on failure.
	 */
	public static function ensure_upload_dir(): string {
		$dir = self::upload_dir();

		if ( ! wp_mkdir_p( $dir ) ) {
			return '';
		}

		$files = array(
			'.htaccess'  => "# LeadFlow CRM: import files are private.\n<IfModule mod_authz_core.c>\n\tRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n\tDeny from all\n</IfModule>\n",
			'index.php'  => "<?php\n// Silence is golden.\n",
			'web.config' => "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<configuration><system.webServer><authorization><deny users=\"*\" /></authorization></system.webServer></configuration>\n",
		);

		foreach ( $files as $name => $content ) {
			if ( ! file_exists( $dir . '/' . $name ) ) {
				file_put_contents( $dir . '/' . $name, $content ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Protection files.
			}
		}

		return $dir;
	}

	/**
	 * Deletes import files older than a day.
	 *
	 * @return void
	 */
	public static function cleanup(): void {
		foreach ( (array) glob( self::upload_dir() . '/*.csv' ) as $file ) {
			if ( is_string( $file ) && filemtime( $file ) < time() - DAY_IN_SECONDS ) {
				wp_delete_file( $file );
			}
		}
	}
}
