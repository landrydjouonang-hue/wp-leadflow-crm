<?php
/**
 * CSV import engine.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\ImportExport;

use LeadFlow\CRM\Data\DataException;
use LeadFlow\CRM\Data\Repositories\CompanyRepository;
use LeadFlow\CRM\Data\Repositories\ContactRepository;
use LeadFlow\CRM\Data\Repositories\StageRepository;
use LeadFlow\CRM\Data\Repository;
use LeadFlow\CRM\Data\ValidationException;
use LeadFlow\CRM\Modules\Companies\CompaniesAdmin;
use LeadFlow\CRM\Modules\Contacts\ContactsAdmin;
use LeadFlow\CRM\Plugin;
use LeadFlow\CRM\Support\Countries;
use LeadFlow\CRM\Support\Users;

defined( 'ABSPATH' ) || exit;

/**
 * Converts, validates, de-duplicates and imports CSV rows.
 *
 * Every row goes through the same analysis for the preview and for the
 * actual import, so the preview is an exact forecast. Each row is
 * validated by the entity repository (the same rules as the forms).
 *
 * Duplicate keys:
 *   companies  name, email or website domain
 *   contacts   email; without email: first + last name at the same company
 *   leads      lead name + company (or lead name + email)
 * Duplicates are skipped, updated or created anyway (user's choice), and
 * duplicates inside the file are detected too.
 */
final class Importer {

	/** Maximum rows per file. */
	public const MAX_ROWS = 5000;

	/** Rows per AJAX batch. */
	public const BATCH = 100;

	/** Duplicate handling modes. */
	public const MODES = array( 'skip', 'update', 'create' );

	/** Accepted date formats. */
	public const DATE_FORMATS = array( 'Y-m-d', 'd/m/Y', 'm/d/Y' );

	/** Errors kept for the report. */
	private const MAX_ERRORS = 1000;

	/**
	 * Duplicate index: key => record id.
	 *
	 * @var array<string, int>|null
	 */
	private ?array $index = null;

	/**
	 * Keys seen earlier in this file (preview): key => row number.
	 *
	 * @var array<string, int>
	 */
	private array $seen = array();

	/**
	 * Companies by lower-case name.
	 *
	 * @var array<string, int>|null
	 */
	private ?array $companies = null;

	/**
	 * Contacts by lower-case email.
	 *
	 * @var array<string, int>|null
	 */
	private ?array $contacts = null;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 * @param string $entity leads|contacts|companies.
	 */
	public function __construct( private Plugin $plugin, private string $entity ) {}

	/**
	 * Entity repository.
	 *
	 * @return Repository
	 */
	public function repository(): Repository {
		return $this->plugin->get( EntityFields::get( $this->entity )['repository'] );
	}

	// ---------------------------------------------------------------------
	// Preview and run.
	// ---------------------------------------------------------------------

	/**
	 * Analyses every row and stores the forecast in the session.
	 *
	 * @param ImportSession $session Session.
	 * @return void
	 */
	public function preview( ImportSession $session ): void {
		$reader  = new CsvReader( (string) $session->data['path'] );
		$counts  = array_fill_keys( array( 'create', 'update', 'skip', 'error', 'warning' ), 0 );
		$rows    = array();
		$errors  = array();
		$headers = $reader->headers();

		$this->seen = array();

		foreach ( $reader->rows( 0, self::MAX_ROWS ) as $number => $row ) {
			$result = $this->analyse( $session->data, $row, $number );

			++$counts[ $result['action'] ];

			if ( ! empty( $result['warnings'] ) ) {
				++$counts['warning'];
			}

			if ( count( $rows ) < 25 ) {
				$rows[] = array(
					'row'      => $number,
					'action'   => $result['action'],
					'values'   => $this->display_values( $session->data['mapping'], $headers, $row ),
					'messages' => array_merge( $result['errors'], $result['warnings'] ),
				);
			}

			if ( 'error' === $result['action'] && count( $errors ) < 200 ) {
				$errors[] = array(
					'row'      => $number,
					'messages' => $result['errors'],
				);
			}
		}

		$session->data['preview'] = array(
			'counts' => $counts,
			'rows'   => $rows,
			'errors' => $errors,
		);
		$session->data['step']    = 'preview';
		$session->save();
	}

	/**
	 * Imports the next batch of rows.
	 *
	 * @param ImportSession $session Session.
	 * @param int           $limit   Rows to process (0 = all remaining).
	 * @return bool Whether the import is finished.
	 */
	public function run( ImportSession $session, int $limit = self::BATCH ): bool {
		$data    = &$session->data;
		$offset  = (int) ( $data['offset'] ?? 0 );
		$results = $data['results'] ?? array(
			'created' => 0,
			'updated' => 0,
			'skipped' => 0,
			'failed'  => 0,
			'errors'  => array(),
		);

		$reader = new CsvReader( (string) $data['path'] );
		$max    = min( (int) $data['total'], self::MAX_ROWS );
		$limit  = $limit > 0 ? min( $limit, $max - $offset ) : $max - $offset;

		if ( $limit > 0 ) {
			foreach ( $reader->rows( $offset, $limit ) as $number => $row ) {
				$this->import_row( $data, $row, $number, $results );
				$offset = $number;
			}
		}

		$data['offset']  = $offset;
		$data['results'] = $results;
		$done            = $offset >= $max;

		if ( $done ) {
			$data['step'] = 'done';
			$session->delete_file();
			$data['path'] = '';
		} else {
			$data['step'] = 'running';
		}

		$session->save();

		return $done;
	}

	/**
	 * Imports one row, updating the counters.
	 *
	 * @param array<string, mixed> $data    Session data.
	 * @param string[]             $row     CSV values.
	 * @param int                  $number  Row number.
	 * @param array<string, mixed> $results Counters (by reference).
	 * @return void
	 */
	private function import_row( array $data, array $row, int $number, array &$results ): void {
		// Every row is re-checked against the live database.
		$this->seen = array();
		$result     = $this->analyse( $data, $row, $number );

		if ( 'skip' === $result['action'] ) {
			++$results['skipped'];
			return;
		}

		if ( 'error' === $result['action'] ) {
			$this->fail( $results, $number, $result['errors'], $row );
			return;
		}

		try {
			$values = $result['data'];

			if ( null !== $result['create_company'] ) {
				$company               = $this->plugin->get( CompanyRepository::class )->create( array( 'name' => $result['create_company'] ) );
				$values['company_id'] = $company->id();
				$this->companies[ mb_strtolower( $result['create_company'] ) ] = $company->id();
			}

			if ( 'update' === $result['action'] ) {
				$saved = $this->repository()->update( (int) $result['existing'], $values );
				++$results['updated'];
			} else {
				$saved = $this->repository()->create( $values );
				++$results['created'];
			}

			// Later rows of the file must see this record as a duplicate.
			$this->index();
			foreach ( $this->keys( $saved->to_array() ) as $key ) {
				$this->index[ $key ] = $this->index[ $key ] ?? $saved->id();
			}
		} catch ( ValidationException $e ) {
			$this->fail( $results, $number, array_values( $e->errors() ), $row );
		} catch ( DataException $e ) {
			$this->fail( $results, $number, array( __( 'Database error while saving this row.', 'wp-leadflow-crm' ) ), $row );
		}
	}

	/**
	 * Records a failed row.
	 *
	 * @param array<string, mixed> $results  Counters (by reference).
	 * @param int                  $number   Row number.
	 * @param string[]             $messages Messages.
	 * @param string[]             $row      Original values.
	 * @return void
	 */
	private function fail( array &$results, int $number, array $messages, array $row ): void {
		++$results['failed'];

		if ( count( $results['errors'] ) < self::MAX_ERRORS ) {
			$results['errors'][] = array(
				'row'      => $number,
				'messages' => $messages,
				'values'   => $row,
			);
		}
	}

	// ---------------------------------------------------------------------
	// Row analysis.
	// ---------------------------------------------------------------------

	/**
	 * Converts, validates and classifies a row.
	 *
	 * @param array<string, mixed> $session Session data (mapping, options).
	 * @param string[]             $row     CSV values.
	 * @param int                  $number  Row number.
	 * @return array{action: string, data: array<string, mixed>, existing: int|null, errors: string[], warnings: string[], create_company: string|null}
	 */
	public function analyse( array $session, array $row, int $number ): array {
		$definition = EntityFields::get( $this->entity );
		$fields     = $definition['fields'];
		$options    = (array) ( $session['options'] ?? array() );
		$data       = array();
		$errors     = array();
		$warnings   = array();
		$create     = null;
		$full_name  = '';

		// Stores a converted value, or an error when conversion failed.
		$assign = static function ( ?string $value, string $target, string $message ) use ( &$data, &$errors ): void {
			if ( null === $value ) {
				$errors[] = $message;
			} else {
				$data[ $target ] = $value;
			}
		};

		foreach ( (array) $session['mapping'] as $index => $key ) {
			if ( '' === $key || ! isset( $fields[ $key ] ) ) {
				continue;
			}

			$raw   = trim( (string) ( $row[ $index ] ?? '' ) );
			$label = $fields[ $key ]['label'];

			// Undo the exporter's formula-injection escaping ("'=..." → "=..."),
			// so exported files re-import unchanged. Values are stored as text.
			if ( 1 === preg_match( "/^'[=+\\-@]/", $raw ) ) {
				$raw = substr( $raw, 1 );
			}

			if ( '' === $raw ) {
				continue;
			}

			switch ( $fields[ $key ]['type'] ) {
				case 'money':
					/* translators: 1: Field, 2: Value. */
					$assign( self::parse_money( $raw ), $key, sprintf( __( '%1$s: “%2$s” is not a number.', 'wp-leadflow-crm' ), $label, $raw ) );
					break;

				case 'date':
					/* translators: 1: Field, 2: Value. */
					$assign( self::parse_date( $raw, (string) ( $options['date_format'] ?? 'Y-m-d' ) ), $key, sprintf( __( '%1$s: “%2$s” is not a valid date.', 'wp-leadflow-crm' ), $label, $raw ) );
					break;

				case 'country':
					/* translators: 1: Field, 2: Value. */
					$assign( self::parse_country( $raw ), $key, sprintf( __( '%1$s: unknown country “%2$s”.', 'wp-leadflow-crm' ), $label, $raw ) );
					break;

				case 'status':
					/* translators: 1: Field, 2: Value. */
					$assign( $this->parse_status( $raw ), 'status', sprintf( __( '%1$s: unknown status “%2$s”.', 'wp-leadflow-crm' ), $label, $raw ) );
					break;

				case 'stage':
					/* translators: 1: Field, 2: Value. */
					$assign( $this->parse_stage( $raw ), 'stage', sprintf( __( '%1$s: unknown pipeline stage “%2$s”.', 'wp-leadflow-crm' ), $label, $raw ) );
					break;

				case 'owner':
					if ( ! current_user_can( 'leadflow_edit_others_' . $this->entity ) ) {
						$warnings[] = __( 'Owner ignored: records you import are assigned to you.', 'wp-leadflow-crm' );
						break;
					}
					$owner = self::parse_owner( $raw );
					/* translators: %s: Value. */
					$assign( null === $owner ? null : (string) $owner, 'owner_id', sprintf( __( 'Owner: “%s” is not a team member with CRM access.', 'wp-leadflow-crm' ), $raw ) );
					break;

				case 'company_name':
					$id = $this->company_id( $raw );
					if ( null !== $id ) {
						$data['company_id'] = $id;
					} elseif ( ! empty( $options['create_companies'] ) ) {
						$create     = $raw;
						$warnings[] = sprintf( /* translators: %s: Company name. */ __( 'Company “%s” will be created.', 'wp-leadflow-crm' ), $raw );
					} else {
						$warnings[] = sprintf( /* translators: %s: Company name. */ __( 'Company “%s” not found: imported without a company.', 'wp-leadflow-crm' ), $raw );
					}
					break;

				case 'contact_email':
					$id = $this->contact_id( $raw );
					if ( null !== $id ) {
						$data['contact_id'] = $id;
					} else {
						$warnings[] = sprintf( /* translators: %s: Email. */ __( 'Contact “%s” not found: imported without a contact.', 'wp-leadflow-crm' ), $raw );
						if ( ! isset( $data['email'] ) && is_email( $raw ) ) {
							$data['email'] = $raw;
						}
					}
					break;

				case 'full_name':
					$full_name = $raw;
					break;

				default:
					$data[ $key ] = $raw;
			}
		}

		if ( '' !== $full_name ) {
			$parts = preg_split( '/\s+/', $full_name, 2 ) ?: array( $full_name );
			$data['first_name'] = $data['first_name'] ?? $parts[0];
			$data['last_name']  = $data['last_name'] ?? ( $parts[1] ?? '' );
		}

		// Duplicates.
		$existing = null;
		$action   = 'create';
		$mode     = in_array( $options['mode'] ?? 'skip', self::MODES, true ) ? $options['mode'] : 'skip';
		$keys     = $this->keys( $data );

		foreach ( $keys as $key ) {
			if ( isset( $this->index()[ $key ] ) ) {
				$existing = $this->index()[ $key ];
				break;
			}
		}

		$in_file = null;

		foreach ( $keys as $key ) {
			if ( isset( $this->seen[ $key ] ) ) {
				$in_file = $this->seen[ $key ];
				break;
			}
		}

		foreach ( $keys as $key ) {
			$this->seen[ $key ] = $this->seen[ $key ] ?? $number;
		}

		if ( null !== $existing && 'create' !== $mode ) {
			if ( 'skip' === $mode ) {
				$action     = 'skip';
				$warnings[] = __( 'Already in the CRM: skipped.', 'wp-leadflow-crm' );
			} else {
				$action = 'update';

				if ( ! current_user_can( 'leadflow_edit_' . $this->singular_key(), $existing ) ) {
					$errors[] = __( 'Already in the CRM, and you are not allowed to update that record.', 'wp-leadflow-crm' );
				}
			}
		} elseif ( null !== $in_file && 'create' !== $mode ) {
			$action     = 'skip' === $mode ? 'skip' : 'update';
			/* translators: %d: Row number. */
			$warnings[] = sprintf( __( 'Duplicate of row %d in this file.', 'wp-leadflow-crm' ), $in_file );
		}

		// Repository validation (same rules as the forms).
		if ( 'skip' !== $action && empty( $errors ) ) {
			$model = 'update' === $action && null !== $existing ? $this->repository()->find( $existing ) : null;

			foreach ( $this->repository()->check( $data, $model ) as $field => $message ) {
				$errors[] = $this->field_label( (string) $field ) . ': ' . $message;
			}
		}

		return array(
			'action'         => empty( $errors ) ? $action : ( 'skip' === $action ? 'skip' : 'error' ),
			'data'           => $data,
			'existing'       => 'update' === $action ? $existing : null,
			'errors'         => $errors,
			'warnings'       => array_values( array_unique( $warnings ) ),
			'create_company' => $create,
		);
	}

	/**
	 * Duplicate keys of a row.
	 *
	 * @param array<string, mixed> $data Converted data.
	 * @return string[]
	 */
	private function keys( array $data ): array {
		$lower = static fn( $value ): string => mb_strtolower( trim( (string) $value ) );
		$keys  = array();

		switch ( $this->entity ) {
			case 'companies':
				if ( '' !== $lower( $data['name'] ?? '' ) ) {
					$keys[] = 'name:' . $lower( $data['name'] );
				}
				if ( '' !== $lower( $data['email'] ?? '' ) ) {
					$keys[] = 'email:' . $lower( $data['email'] );
				}
				$host = self::host( (string) ( $data['website'] ?? '' ) );
				if ( '' !== $host ) {
					$keys[] = 'host:' . $host;
				}
				break;

			case 'contacts':
				if ( '' !== $lower( $data['email'] ?? '' ) ) {
					$keys[] = 'email:' . $lower( $data['email'] );
				} elseif ( '' !== $lower( ( $data['first_name'] ?? '' ) . ( $data['last_name'] ?? '' ) ) ) {
					$keys[] = 'name:' . $lower( ( $data['first_name'] ?? '' ) . ' ' . ( $data['last_name'] ?? '' ) ) . '|' . (int) ( $data['company_id'] ?? 0 );
				}
				break;

			case 'leads':
				$title = $lower( $data['title'] ?? '' );
				if ( '' !== $title ) {
					if ( ! empty( $data['company_id'] ) ) {
						$keys[] = 'title:' . $title . '|c' . (int) $data['company_id'];
					}
					if ( '' !== $lower( $data['email'] ?? '' ) ) {
						$keys[] = 'title:' . $title . '|e' . $lower( $data['email'] );
					}
				}
				break;
		}

		return $keys;
	}

	/**
	 * Duplicate index of existing records (built once per request).
	 *
	 * @return array<string, int>
	 */
	private function index(): array {
		if ( null !== $this->index ) {
			return $this->index;
		}

		$index   = array();
		$columns = array(
			'companies' => array( 'name', 'email', 'website' ),
			'contacts'  => array( 'first_name', 'last_name', 'email', 'company_id' ),
			'leads'     => array( 'title', 'company_id', 'email' ),
		);

		foreach ( $this->repository()->pluck( $columns[ $this->entity ] ) as $record ) {
			foreach ( $this->keys( $record ) as $key ) {
				$index[ $key ] = $index[ $key ] ?? (int) $record['id'];
			}
		}

		$this->index = $index;

		return $index;
	}

	// ---------------------------------------------------------------------
	// Value parsing.
	// ---------------------------------------------------------------------

	/**
	 * "1,234.50" / "1.234,50" / "$1 234" → "1234.50".
	 *
	 * @param string $raw Raw value.
	 * @return string|null
	 */
	public static function parse_money( string $raw ): ?string {
		$value = (string) preg_replace( '/[^\d,.\-]/', '', $raw );

		if ( '' === $value ) {
			return null;
		}

		$comma = strrpos( $value, ',' );
		$dot   = strrpos( $value, '.' );

		if ( false !== $comma && false !== $dot ) {
			$value = $comma > $dot
				? str_replace( ',', '.', str_replace( '.', '', $value ) )
				: str_replace( ',', '', $value );
		} elseif ( false !== $comma ) {
			$value = 1 === preg_match( '/^-?\d+,\d{1,2}$/', $value ) ? str_replace( ',', '.', $value ) : str_replace( ',', '', $value );
		} elseif ( false !== $dot && 1 === preg_match( '/^-?\d{1,3}(\.\d{3})+$/', $value ) ) {
			$value = str_replace( '.', '', $value ); // "1.234.567" thousands separators.
		}

		return is_numeric( $value ) ? number_format( (float) $value, 2, '.', '' ) : null;
	}

	/**
	 * Parses a date in the chosen format (ISO Y-m-d always accepted).
	 *
	 * @param string $raw    Raw value.
	 * @param string $format Expected format.
	 * @return string|null Y-m-d.
	 */
	public static function parse_date( string $raw, string $format ): ?string {
		foreach ( array_unique( array( $format, 'Y-m-d' ) ) as $candidate ) {
			$date   = \DateTimeImmutable::createFromFormat( '!' . $candidate, $raw );
			$errors = \DateTimeImmutable::getLastErrors();

			if ( false !== $date && ( false === $errors || ( 0 === $errors['warning_count'] && 0 === $errors['error_count'] ) ) ) {
				return $date->format( 'Y-m-d' );
			}
		}

		return null;
	}

	/**
	 * ISO code or country name → ISO code.
	 *
	 * @param string $raw Raw value.
	 * @return string|null
	 */
	public static function parse_country( string $raw ): ?string {
		$countries = Countries::all();
		$upper     = strtoupper( $raw );

		if ( isset( $countries[ $upper ] ) ) {
			return $upper;
		}

		$aliases = array(
			'usa'                      => 'US',
			'united states of america' => 'US',
			'uk'                       => 'GB',
			'great britain'            => 'GB',
			'england'                  => 'GB',
		);
		$needle  = EntityFields::normalize( $raw );

		foreach ( $aliases as $alias => $code ) {
			if ( EntityFields::normalize( $alias ) === $needle ) {
				return $code;
			}
		}

		foreach ( $countries as $code => $name ) {
			if ( EntityFields::normalize( $name ) === $needle ) {
				return $code;
			}
		}

		return null;
	}

	/**
	 * Status key or label → key.
	 *
	 * @param string $raw Raw value.
	 * @return string|null
	 */
	private function parse_status( string $raw ): ?string {
		$labels = 'companies' === $this->entity
			? ( new CompaniesAdmin( $this->plugin ) )->status_labels()
			: ( new ContactsAdmin( $this->plugin ) )->status_labels();

		foreach ( $labels as $key => $label ) {
			if ( EntityFields::normalize( $key ) === EntityFields::normalize( $raw ) || EntityFields::normalize( $label ) === EntityFields::normalize( $raw ) ) {
				return $key;
			}
		}

		return null;
	}

	/**
	 * Stage name or slug → slug.
	 *
	 * @param string $raw Raw value.
	 * @return string|null
	 */
	private function parse_stage( string $raw ): ?string {
		foreach ( $this->plugin->get( StageRepository::class )->all() as $stage ) {
			if ( $stage->slug() === sanitize_title( $raw ) || EntityFields::normalize( $stage->name() ) === EntityFields::normalize( $raw ) ) {
				return $stage->slug();
			}
		}

		return null;
	}

	/**
	 * Email, login or display name of a CRM user → id.
	 *
	 * @param string $raw Raw value.
	 * @return int|null
	 */
	public static function parse_owner( string $raw ): ?int {
		$crm  = Users::crm_users();
		$user = is_email( $raw ) ? get_user_by( 'email', $raw ) : get_user_by( 'login', $raw );

		if ( false !== $user && isset( $crm[ (int) $user->ID ] ) ) {
			return (int) $user->ID;
		}

		foreach ( $crm as $id => $name ) {
			if ( mb_strtolower( $name ) === mb_strtolower( $raw ) ) {
				return (int) $id;
			}
		}

		return null;
	}

	/**
	 * Existing company id by name (case-insensitive).
	 *
	 * @param string $name Name.
	 * @return int|null
	 */
	private function company_id( string $name ): ?int {
		if ( null === $this->companies ) {
			$this->companies = array();

			foreach ( $this->plugin->get( CompanyRepository::class )->pluck( array( 'name' ) ) as $row ) {
				$this->companies[ mb_strtolower( (string) $row['name'] ) ] = $this->companies[ mb_strtolower( (string) $row['name'] ) ] ?? (int) $row['id'];
			}
		}

		return $this->companies[ mb_strtolower( $name ) ] ?? null;
	}

	/**
	 * Existing contact id by email (case-insensitive).
	 *
	 * @param string $email Email.
	 * @return int|null
	 */
	private function contact_id( string $email ): ?int {
		if ( null === $this->contacts ) {
			$this->contacts = array();

			foreach ( $this->plugin->get( ContactRepository::class )->pluck( array( 'email' ) ) as $row ) {
				if ( '' !== (string) $row['email'] ) {
					$this->contacts[ mb_strtolower( (string) $row['email'] ) ] = $this->contacts[ mb_strtolower( (string) $row['email'] ) ] ?? (int) $row['id'];
				}
			}
		}

		return $this->contacts[ mb_strtolower( trim( $email ) ) ] ?? null;
	}

	/**
	 * Host without "www." of a URL-ish value.
	 *
	 * @param string $website Website.
	 * @return string
	 */
	private static function host( string $website ): string {
		if ( '' === trim( $website ) ) {
			return '';
		}

		$host = wp_parse_url( str_contains( $website, '://' ) ? $website : 'http://' . $website, PHP_URL_HOST );

		return is_string( $host ) ? (string) preg_replace( '/^www\./', '', strtolower( $host ) ) : '';
	}

	/**
	 * Singular entity key (lead, contact, company).
	 *
	 * @return string
	 */
	private function singular_key(): string {
		return array(
			'leads'     => 'lead',
			'contacts'  => 'contact',
			'companies' => 'company',
		)[ $this->entity ];
	}

	/**
	 * Human label of a repository field.
	 *
	 * @param string $field Field.
	 * @return string
	 */
	private function field_label( string $field ): string {
		$fields = EntityFields::get( $this->entity )['fields'];
		$map    = array(
			'company_id' => 'company',
			'contact_id' => 'contact_email',
			'owner_id'   => 'owner',
		);

		return $fields[ $map[ $field ] ?? $field ]['label'] ?? ucfirst( str_replace( '_', ' ', $field ) );
	}

	/**
	 * Mapped values of a row for display in the preview.
	 *
	 * @param array<int, string> $mapping Column => field.
	 * @param string[]           $headers Headers.
	 * @param string[]           $row     Values.
	 * @return array<string, string> Field label => value.
	 */
	private function display_values( array $mapping, array $headers, array $row ): array {
		$fields = EntityFields::get( $this->entity )['fields'];
		$values = array();

		foreach ( $mapping as $index => $key ) {
			if ( '' !== $key && isset( $fields[ $key ] ) ) {
				$values[ $fields[ $key ]['label'] ] = (string) ( $row[ $index ] ?? '' );
			}
		}

		return $values;
	}
}
