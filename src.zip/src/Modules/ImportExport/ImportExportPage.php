<?php
/**
 * Import / Export screen.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\ImportExport;

use LeadFlow\CRM\Admin\Menu;
use LeadFlow\CRM\Admin\Notices;
use LeadFlow\CRM\Admin\Page;
use LeadFlow\CRM\Admin\View;
use LeadFlow\CRM\Database\Schema;
use LeadFlow\CRM\Database\Table;
use LeadFlow\CRM\Plugin;
use LeadFlow\CRM\Security\Capabilities;
use LeadFlow\CRM\Security\Guard;
use LeadFlow\CRM\Security\Input;
use LeadFlow\CRM\Security\Nonce;
use LeadFlow\CRM\Settings\Settings;
use LeadFlow\CRM\Support\Logger;

defined( 'ABSPATH' ) || exit;

/**
 * Import wizard (upload → map → preview → import → summary) and export.
 *
 * Every action: nonce → `leadflow_import_data` / `leadflow_export_data` →
 * the entity capability (`leadflow_edit_{entity}` to import,
 * `leadflow_view_{entity}` to export).
 */
final class ImportExportPage {

	/** Page slug. */
	public const PAGE_SLUG = 'leadflow-crm-import-export';

	/** Maximum upload size in bytes. */
	public const MAX_BYTES = 10 * MB_IN_BYTES;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( private Plugin $plugin ) {}

	/**
	 * Registers the handlers.
	 *
	 * @return void
	 */
	public function register(): void {
		add_action( 'admin_post_leadflow_crm_import_upload', array( $this, 'handle_upload' ) );
		add_action( 'admin_post_leadflow_crm_import_map', array( $this, 'handle_map' ) );
		add_action( 'admin_post_leadflow_crm_import_run', array( $this, 'handle_run' ) );
		add_action( 'admin_post_leadflow_crm_import_cancel', array( $this, 'handle_cancel' ) );
		add_action( 'admin_post_leadflow_crm_import_errors', array( $this, 'handle_error_report' ) );
		add_action( 'admin_post_leadflow_crm_export', array( $this, 'handle_export' ) );
		add_action( 'admin_post_leadflow_crm_export_all', array( $this, 'handle_export_all' ) );
		add_action( 'wp_ajax_leadflow_crm_import_batch', array( $this, 'ajax_batch' ) );
	}

	/**
	 * Page definition.
	 *
	 * @return Page
	 */
	public function page(): Page {
		return new Page(
			self::PAGE_SLUG,
			__( 'Import & export', 'wp-leadflow-crm' ),
			__( 'Import / Export', 'wp-leadflow-crm' ),
			ImportExportModule::PAGE_CAP,
			array( $this, 'render' ),
			80
		);
	}

	/**
	 * Screen URL.
	 *
	 * @param array<string, mixed> $args Query args.
	 * @return string
	 */
	public static function url( array $args = array() ): string {
		return Menu::url( self::PAGE_SLUG, $args );
	}

	/**
	 * Entities the user may import.
	 *
	 * @return array<string, string>
	 */
	private function importable(): array {
		return array_filter(
			EntityFields::labels(),
			static fn( string $label, string $entity ): bool => current_user_can( 'leadflow_edit_' . $entity ),
			ARRAY_FILTER_USE_BOTH
		);
	}

	/**
	 * Entities the user may export.
	 *
	 * @return array<string, string>
	 */
	private function exportable(): array {
		return array_filter(
			EntityFields::labels(),
			static fn( string $label, string $entity ): bool => current_user_can( 'leadflow_view_' . $entity ),
			ARRAY_FILTER_USE_BOTH
		);
	}

	// ---------------------------------------------------------------------
	// Screen.
	// ---------------------------------------------------------------------

	/**
	 * Renders the screen.
	 *
	 * @return void
	 */
	public function render(): void {
		Guard::authorize( ImportExportModule::PAGE_CAP );

		$can_import = current_user_can( ImportExportModule::IMPORT_CAP );
		$can_export = current_user_can( ImportExportModule::EXPORT_CAP );
		$tab        = Input::one_of( 'tab', array( 'import', 'export' ), $can_import ? 'import' : 'export' );

		if ( ( 'import' === $tab && ! $can_import ) || ( 'export' === $tab && ! $can_export ) ) {
			$tab = $can_import ? 'import' : 'export';
		}

		$session = null;

		if ( 'import' === $tab ) {
			$token   = Input::text( 'import' );
			$session = '' !== $token ? ImportSession::load( $token ) : null;

			if ( '' !== $token && null === $session ) {
				echo '<div class="notice notice-warning"><p>' . esc_html__( 'This import has expired or does not exist. Please start again.', 'wp-leadflow-crm' ) . '</p></div>';
			}
		}

		View::render(
			'admin/import-export/page',
			array(
				'tab'        => $tab,
				'can_import' => $can_import,
				'can_export' => $can_export,
				'session'    => $session,
				'importable' => $this->importable(),
				'exportable' => $this->exportable(),
				'fields'     => null !== $session ? EntityFields::get( (string) $session->data['entity'] )['fields'] : array(),
				'max_mb'     => (int) floor( min( self::MAX_BYTES, wp_max_upload_size() ) / MB_IN_BYTES ),
			)
		);
	}

	// ---------------------------------------------------------------------
	// Import steps.
	// ---------------------------------------------------------------------

	/**
	 * Step 1: validates and stores the uploaded file.
	 *
	 * @return void
	 */
	public function handle_upload(): void {
		check_admin_referer( Nonce::action( 'import_upload' ), Nonce::FIELD );
		Guard::authorize( ImportExportModule::IMPORT_CAP );

		$entity = Input::one_of( 'entity', EntityFields::ENTITIES, '', 'post' );

		if ( '' === $entity ) {
			$this->fail_upload( __( 'Please choose what you want to import.', 'wp-leadflow-crm' ) );
		}

		Guard::authorize( 'leadflow_edit_' . $entity );

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- Validated below; file array handled by wp_handle_upload().
		$file = isset( $_FILES['csv_file'] ) && is_array( $_FILES['csv_file'] ) ? $_FILES['csv_file'] : null;

		if ( null === $file || UPLOAD_ERR_NO_FILE === (int) $file['error'] ) {
			$this->fail_upload( __( 'Please choose a CSV file.', 'wp-leadflow-crm' ) );
		}

		if ( UPLOAD_ERR_OK !== (int) $file['error'] ) {
			$this->fail_upload( __( 'The file could not be uploaded. It may be larger than the server allows.', 'wp-leadflow-crm' ) );
		}

		if ( (int) $file['size'] > self::MAX_BYTES ) {
			/* translators: %d: Megabytes. */
			$this->fail_upload( sprintf( __( 'The file is too large. The maximum is %d MB.', 'wp-leadflow-crm' ), (int) ( self::MAX_BYTES / MB_IN_BYTES ) ) );
		}

		$extension = strtolower( pathinfo( (string) $file['name'], PATHINFO_EXTENSION ) );

		if ( ! in_array( $extension, array( 'csv', 'txt' ), true ) ) {
			$this->fail_upload( __( 'Please upload a .csv file.', 'wp-leadflow-crm' ) );
		}

		$stored = $this->store_upload( $file );

		if ( is_string( $stored ) && str_starts_with( $stored, 'error:' ) ) {
			$this->fail_upload( substr( $stored, 6 ) );
		}

		try {
			$reader  = new CsvReader( $stored );
			$headers = $reader->headers();
			$total   = $reader->count();
		} catch ( \RuntimeException $e ) {
			wp_delete_file( $stored );
			$this->fail_upload( __( 'The file could not be read.', 'wp-leadflow-crm' ) );
		}

		if ( count( array_filter( $headers ) ) < 1 || 0 === $total ) {
			wp_delete_file( $stored );
			$this->fail_upload( __( 'The file is empty or has no header row. The first row must contain the column names.', 'wp-leadflow-crm' ) );
		}

		if ( $total > Importer::MAX_ROWS ) {
			wp_delete_file( $stored );
			/* translators: 1: Rows in the file, 2: Maximum rows. */
			$this->fail_upload( sprintf( __( 'The file has %1$s rows; the maximum is %2$s per import. Please split it into smaller files.', 'wp-leadflow-crm' ), number_format_i18n( $total ), number_format_i18n( Importer::MAX_ROWS ) ) );
		}

		$session = ImportSession::create(
			array(
				'entity'   => $entity,
				'path'     => $stored,
				'filename' => sanitize_file_name( (string) $file['name'] ),
				'headers'  => $headers,
				'total'    => $total,
				'options'  => array(
					'mode'             => Input::one_of( 'mode', Importer::MODES, 'skip', 'post' ),
					'date_format'      => Input::one_of( 'date_format', Importer::DATE_FORMATS, 'Y-m-d', 'post' ),
					'create_companies' => Input::bool( 'create_companies', 'post' ),
				),
				'mapping'  => EntityFields::guess_mapping( $entity, $headers ),
				'step'     => 'map',
			)
		);

		wp_safe_redirect( self::url( array( 'tab' => 'import', 'import' => $session->token() ) ) );
		exit;
	}

	/**
	 * Step 2: saves the column mapping and builds the preview.
	 *
	 * @return void
	 */
	public function handle_map(): void {
		$session = $this->session_or_die( 'post' );
		$entity  = (string) $session->data['entity'];
		$fields  = EntityFields::get( $entity )['fields'];

		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified in session_or_die(); values allow-listed below.
		$posted  = isset( $_POST['mapping'] ) && is_array( $_POST['mapping'] ) ? wp_unslash( $_POST['mapping'] ) : array();
		$mapping = array();
		$used    = array();
		$errors  = array();

		foreach ( array_keys( (array) $session->data['headers'] ) as $index ) {
			$key = sanitize_key( (string) ( $posted[ $index ] ?? '' ) );
			$key = isset( $fields[ $key ] ) ? $key : '';

			if ( '' !== $key && isset( $used[ $key ] ) ) {
				/* translators: %s: Field label. */
				$errors[] = sprintf( __( '“%s” is mapped to more than one column.', 'wp-leadflow-crm' ), $fields[ $key ]['label'] );
			}

			$used[ $key ]      = true;
			$mapping[ $index ] = $key;
		}

		foreach ( $fields as $key => $field ) {
			if ( $field['required'] && ! isset( $used[ $key ] ) ) {
				/* translators: %s: Field label. */
				$errors[] = sprintf( __( 'Please map a column to “%s” (required).', 'wp-leadflow-crm' ), $field['label'] );
			}
		}

		if ( 'contacts' === $entity && empty( array_intersect_key( $used, array_flip( array( 'first_name', 'last_name', 'full_name', 'email' ) ) ) ) ) {
			$errors[] = __( 'Please map at least a name or an email column for contacts.', 'wp-leadflow-crm' );
		}

		$session->data['mapping'] = $mapping;
		$session->save();

		if ( ! empty( $errors ) ) {
			Notices::flash( 'error', implode( ' ', array_unique( $errors ) ) );
			$this->to_session( $session );
		}

		( new Importer( $this->plugin, $entity ) )->preview( $session );

		$this->to_session( $session );
	}

	/**
	 * Step 4 without JavaScript: imports all rows in one request.
	 *
	 * @return void
	 */
	public function handle_run(): void {
		$session = $this->session_or_die( 'post' );

		if ( in_array( $session->data['step'] ?? '', array( 'preview', 'running' ), true ) ) {
			if ( function_exists( 'set_time_limit' ) ) {
				@set_time_limit( 300 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- May be disabled on the host.
			}

			( new Importer( $this->plugin, (string) $session->data['entity'] ) )->run( $session, 0 );
		}

		$this->to_session( $session );
	}

	/**
	 * AJAX: imports the next batch and reports progress.
	 *
	 * @return void
	 */
	public function ajax_batch(): void {
		Guard::verify_ajax( 'import', ImportExportModule::IMPORT_CAP );

		$session = ImportSession::load( Input::text( 'import', 'post' ) );

		if ( null === $session || ! in_array( $session->data['step'] ?? '', array( 'preview', 'running' ), true ) ) {
			wp_send_json_error( array( 'message' => __( 'This import has expired or is already finished. Please reload the page.', 'wp-leadflow-crm' ) ), 404 );
		}

		if ( ! current_user_can( 'leadflow_edit_' . $session->data['entity'] ) ) {
			wp_send_json_error( array( 'message' => __( 'You are not allowed to import these records.', 'wp-leadflow-crm' ) ), 403 );
		}

		$done    = ( new Importer( $this->plugin, (string) $session->data['entity'] ) )->run( $session, Importer::BATCH );
		$results = $session->data['results'];

		wp_send_json_success(
			array(
				'done'      => $done,
				'processed' => (int) $session->data['offset'],
				'total'     => min( (int) $session->data['total'], Importer::MAX_ROWS ),
				'created'   => (int) $results['created'],
				'updated'   => (int) $results['updated'],
				'skipped'   => (int) $results['skipped'],
				'failed'    => (int) $results['failed'],
				'redirect'  => $done ? self::url( array( 'tab' => 'import', 'import' => $session->token() ) ) : '',
			)
		);
	}

	/**
	 * Cancels an import and deletes its file.
	 *
	 * @return void
	 */
	public function handle_cancel(): void {
		$session = $this->session_or_die( 'post' );
		$session->destroy();

		Notices::flash( 'info', __( 'Import cancelled. The uploaded file was deleted.', 'wp-leadflow-crm' ) );
		wp_safe_redirect( self::url( array( 'tab' => 'import' ) ) );
		exit;
	}

	/**
	 * Downloads the rows that failed, with the reasons, as CSV.
	 *
	 * @return void
	 */
	public function handle_error_report(): void {
		$session = $this->session_or_die( 'get' );
		$errors  = (array) ( $session->data['results']['errors'] ?? array() );

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="leadflow-import-errors-' . gmdate( 'Y-m-d-His' ) . '.csv"' );
		header( 'X-Content-Type-Options: nosniff' );

		$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- Streaming download.
		fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
		fputcsv( $out, array_merge( array( __( 'Row', 'wp-leadflow-crm' ), __( 'Errors', 'wp-leadflow-crm' ) ), array_map( array( Exporter::class, 'cell' ), (array) $session->data['headers'] ) ), ',', '"', '' );

		foreach ( $errors as $error ) {
			fputcsv(
				$out,
				array_merge(
					array( (string) $error['row'], Exporter::cell( implode( ' ', (array) $error['messages'] ) ) ),
					array_map( static fn( $v ): string => Exporter::cell( (string) $v ), (array) $error['values'] )
				),
				',',
				'"',
				''
			);
		}

		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		exit;
	}

	// ---------------------------------------------------------------------
	// Export.
	// ---------------------------------------------------------------------

	/**
	 * Streams a CSV export.
	 *
	 * @return void
	 */
	public function handle_export(): void {
		check_admin_referer( Nonce::action( 'export' ), Nonce::FIELD );
		Guard::authorize( ImportExportModule::EXPORT_CAP );

		$entity = Input::one_of( 'entity', EntityFields::ENTITIES, '', 'post' );

		if ( '' === $entity ) {
			Guard::authorize( 'do_not_allow' );
		}

		Guard::authorize( 'leadflow_view_' . $entity );

		$where  = array();
		$status = Input::key( 'status', 'post' );

		if ( '' !== $status && in_array( $status, $this->statuses( $entity ), true ) ) {
			$where['status'] = $status;
		}

		if ( 'mine' === Input::key( 'owner', 'post' ) ) {
			$where['owner_id'] = get_current_user_id();
		}

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="leadflow-' . $entity . '-' . gmdate( 'Y-m-d' ) . '.csv"' );
		header( 'X-Content-Type-Options: nosniff' );

		$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- Streaming download.
		( new Exporter( $this->plugin ) )->write( $out, $entity, $where );
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose

		/**
		 * Fires after a CSV export (for audit logging).
		 *
		 * @param string               $entity Entity.
		 * @param array<string, mixed> $where  Filters.
		 */
		do_action( 'leadflow_crm_exported', $entity, $where );
		exit;
	}

	/**
	 * Streams a complete backup of the CRM data as JSON.
	 *
	 * One line per record (JSON Lines inside a JSON envelope) so even large
	 * installations export without loading everything into memory. Includes
	 * trashed records and every related table.
	 *
	 * @return void
	 */
	public function handle_export_all(): void {
		check_admin_referer( Nonce::action( 'export_all' ), Nonce::FIELD );
		Guard::authorize( ImportExportModule::EXPORT_CAP );
		Guard::authorize( Capabilities::MANAGE_SETTINGS );

		global $wpdb;

		$tables = array(
			'companies'       => Schema::COMPANIES,
			'contacts'        => Schema::CONTACTS,
			'leads'           => Schema::LEADS,
			'pipeline_stages' => Schema::PIPELINE_STAGES,
			'activities'      => Schema::ACTIVITIES,
			'notes'           => Schema::NOTES,
			'tasks'           => Schema::TASKS,
			'follow_ups'      => Schema::FOLLOW_UPS,
			'email_templates' => Schema::EMAIL_TEMPLATES,
			'emails'          => Schema::EMAILS,
		);

		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="leadflow-crm-backup-' . gmdate( 'Y-m-d-His' ) . '.json"' );
		header( 'X-Content-Type-Options: nosniff' );

		echo '{"format":"leadflow-crm-backup","version":1,"plugin_version":' . wp_json_encode( LEADFLOW_CRM_VERSION )
			. ',"site":' . wp_json_encode( home_url( '/' ) )
			. ',"generated_at":' . wp_json_encode( gmdate( 'c' ) )
			. ',"settings":' . wp_json_encode( $this->plugin->get( Settings::class )->all() )
			. ',"records":{';

		$first_table = true;
		$counts      = array();

		foreach ( $tables as $key => $table ) {
			$name = Table::name( $table );

			if ( ! Table::exists( $name ) ) {
				continue;
			}

			echo $first_table ? '' : ',';
			echo wp_json_encode( $key ), ':[';

			$first_table = false;
			$offset      = 0;
			$written     = 0;

			do {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Streaming export of our own tables.
				$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i ORDER BY id ASC LIMIT %d OFFSET %d', $name, 500, $offset ), ARRAY_A );

				foreach ( (array) $rows as $row ) {
					echo $written > 0 ? ',' : '', wp_json_encode( $row );
					++$written;
				}

				$offset += 500;

				if ( function_exists( 'flush' ) ) {
					flush();
				}
			} while ( count( (array) $rows ) === 500 );

			$counts[ $key ] = $written;
			echo ']';
		}

		echo '},"counts":', wp_json_encode( $counts ), '}';

		Logger::info( 'Complete backup exported', $counts );

		/**
		 * Fires after a complete JSON backup was downloaded.
		 *
		 * @param array<string, int> $counts Records per table.
		 */
		do_action( 'leadflow_crm_exported_all', $counts );
		exit;
	}

	/**
	 * Status keys of an entity.
	 *
	 * @param string $entity Entity.
	 * @return string[]
	 */
	public function statuses( string $entity ): array {
		return array(
			'leads'     => array( 'open', 'won', 'lost' ),
			'contacts'  => array( 'active', 'inactive' ),
			'companies' => array( 'prospect', 'customer', 'partner', 'inactive' ),
		)[ $entity ] ?? array();
	}

	// ---------------------------------------------------------------------
	// Helpers.
	// ---------------------------------------------------------------------

	/**
	 * Moves the upload into the protected import folder.
	 *
	 * @param array<string, mixed> $file $_FILES entry.
	 * @return string Path, or "error:message".
	 */
	private function store_upload( array $file ): string {
		require_once ABSPATH . 'wp-admin/includes/file.php';

		$dir = ImportExportModule::ensure_upload_dir();

		if ( '' === $dir ) {
			return 'error:' . __( 'The import folder could not be created. Please check that wp-content/uploads is writable.', 'wp-leadflow-crm' );
		}

		$name   = wp_generate_password( 24, false, false ) . '.csv';
		$filter = static function ( array $uploads ) use ( $dir ): array {
			$uploads['path']   = $dir;
			$uploads['subdir'] = '';
			$uploads['error']  = false;

			return $uploads;
		};

		add_filter( 'upload_dir', $filter );

		$result = wp_handle_upload(
			$file,
			array(
				'test_form'                => false,
				'mimes'                    => array(
					'csv' => 'text/csv',
					'txt' => 'text/plain',
				),
				'unique_filename_callback' => static fn(): string => $name,
			)
		);

		remove_filter( 'upload_dir', $filter );

		if ( isset( $result['error'] ) ) {
			return 'error:' . (string) $result['error'];
		}

		return (string) $result['file'];
	}

	/**
	 * Loads the session from the request, verifying nonce and capabilities.
	 *
	 * @param string $source get|post.
	 * @return ImportSession
	 */
	private function session_or_die( string $source ): ImportSession {
		$token = Input::text( 'import', $source );

		if ( ! Nonce::verify( Input::text( Nonce::FIELD, $source ), 'import_' . $token ) ) {
			wp_nonce_ays( '' );
		}

		Guard::authorize( ImportExportModule::IMPORT_CAP );

		$session = ImportSession::load( $token );

		if ( null === $session ) {
			Notices::flash( 'warning', __( 'This import has expired or does not exist. Please start again.', 'wp-leadflow-crm' ) );
			wp_safe_redirect( self::url( array( 'tab' => 'import' ) ) );
			exit;
		}

		Guard::authorize( 'leadflow_edit_' . $session->data['entity'] );

		return $session;
	}

	/**
	 * Redirects to the session's current step.
	 *
	 * @param ImportSession $session Session.
	 * @return void
	 */
	private function to_session( ImportSession $session ): void {
		wp_safe_redirect( self::url( array( 'tab' => 'import', 'import' => $session->token() ) ) );
		exit;
	}

	/**
	 * Back to the upload form with an error.
	 *
	 * @param string $message Message.
	 * @return void
	 */
	private function fail_upload( string $message ): void {
		Notices::flash( 'error', $message );
		wp_safe_redirect( self::url( array( 'tab' => 'import' ) ) );
		exit;
	}
}
