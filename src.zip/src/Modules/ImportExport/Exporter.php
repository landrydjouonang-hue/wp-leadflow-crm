<?php
/**
 * CSV export.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\ImportExport;

use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\Contact;
use LeadFlow\CRM\Data\Relations;
use LeadFlow\CRM\Data\Repositories\StageRepository;
use LeadFlow\CRM\Data\Repository;
use LeadFlow\CRM\Plugin;
use LeadFlow\CRM\Support\Countries;

defined( 'ABSPATH' ) || exit;

/**
 * Streams leads, contacts or companies as CSV (UTF-8 with BOM for Excel).
 *
 * Column names match the importer's aliases, so an export can be
 * re-imported without manual mapping. Cells that a spreadsheet could
 * execute as a formula are neutralized.
 */
final class Exporter {

	/** Rows fetched per query. */
	private const PAGE = 500;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( private Plugin $plugin ) {}

	/**
	 * Column definitions: header => value callback.
	 *
	 * @param string $entity Entity.
	 * @return array<string, callable(Model, array<string, mixed>): string>
	 */
	public function columns( string $entity ): array {
		$date  = static fn( ?string $utc ): string => null === $utc || '' === $utc ? '' : get_date_from_gmt( $utc, 'Y-m-d H:i:s' );
		$owner = static function ( Model $m ): string {
			$user = get_userdata( (int) $m->get( 'owner_id', 0 ) );
			return false === $user ? '' : (string) $user->user_email;
		};
		$get   = static fn( string $column ): callable => static fn( Model $m ): string => (string) $m->get( $column, '' );

		switch ( $entity ) {
			case 'companies':
				return array(
					'ID'                              => static fn( Model $m ): string => (string) $m->id(),
					__( 'Company name', 'wp-leadflow-crm' ) => $get( 'name' ),
					__( 'Industry', 'wp-leadflow-crm' )     => $get( 'industry' ),
					__( 'Website', 'wp-leadflow-crm' )      => $get( 'website' ),
					__( 'Email', 'wp-leadflow-crm' )        => $get( 'email' ),
					__( 'Phone', 'wp-leadflow-crm' )        => $get( 'phone' ),
					__( 'Street address', 'wp-leadflow-crm' ) => $get( 'address_line_1' ),
					__( 'Address line 2', 'wp-leadflow-crm' ) => $get( 'address_line_2' ),
					__( 'City', 'wp-leadflow-crm' )         => $get( 'city' ),
					__( 'State', 'wp-leadflow-crm' )        => $get( 'state' ),
					__( 'Postal code', 'wp-leadflow-crm' )  => $get( 'postal_code' ),
					__( 'Country', 'wp-leadflow-crm' )      => static fn( Model $m ): string => Countries::name( (string) $m->get( 'country', '' ) ),
					__( 'Status', 'wp-leadflow-crm' )       => $get( 'status' ),
					__( 'Description', 'wp-leadflow-crm' )  => $get( 'description' ),
					__( 'Owner', 'wp-leadflow-crm' )        => $owner,
					__( 'Created', 'wp-leadflow-crm' )      => static fn( Model $m ): string => $date( $m->get( 'created_at' ) ),
				);

			case 'contacts':
				return array(
					'ID'                                  => static fn( Model $m ): string => (string) $m->id(),
					__( 'First name', 'wp-leadflow-crm' ) => $get( 'first_name' ),
					__( 'Last name', 'wp-leadflow-crm' )  => $get( 'last_name' ),
					__( 'Email', 'wp-leadflow-crm' )      => $get( 'email' ),
					__( 'Phone', 'wp-leadflow-crm' )      => $get( 'phone' ),
					__( 'Mobile', 'wp-leadflow-crm' )     => $get( 'mobile' ),
					__( 'Job title', 'wp-leadflow-crm' )  => $get( 'job_title' ),
					__( 'Company', 'wp-leadflow-crm' )    => static fn( Model $m, array $x ): string => isset( $x['companies'][ (int) $m->get( 'company_id', 0 ) ] ) ? $x['companies'][ (int) $m->get( 'company_id' ) ]->name() : '',
					__( 'Country', 'wp-leadflow-crm' )    => static fn( Model $m ): string => Countries::name( (string) $m->get( 'country', '' ) ),
					__( 'Status', 'wp-leadflow-crm' )     => $get( 'status' ),
					__( 'Source', 'wp-leadflow-crm' )     => $get( 'source' ),
					__( 'Owner', 'wp-leadflow-crm' )      => $owner,
					__( 'Created', 'wp-leadflow-crm' )    => static fn( Model $m ): string => $date( $m->get( 'created_at' ) ),
				);

			default:
				$stages = $this->plugin->get( StageRepository::class );

				return array(
					'ID'                                      => static fn( Model $m ): string => (string) $m->id(),
					__( 'Lead name', 'wp-leadflow-crm' )      => $get( 'title' ),
					__( 'Company', 'wp-leadflow-crm' )        => static fn( Model $m, array $x ): string => isset( $x['companies'][ (int) $m->get( 'company_id', 0 ) ] ) ? $x['companies'][ (int) $m->get( 'company_id' ) ]->name() : '',
					__( 'Contact email', 'wp-leadflow-crm' )  => static function ( Model $m, array $x ): string {
						$contact = $x['contacts'][ (int) $m->get( 'contact_id', 0 ) ] ?? null;
						return $contact instanceof Contact ? (string) $contact->get( 'email', '' ) : '';
					},
					__( 'Email', 'wp-leadflow-crm' )          => $get( 'email' ),
					__( 'Phone', 'wp-leadflow-crm' )          => $get( 'phone' ),
					__( 'Value', 'wp-leadflow-crm' )          => static fn( Model $m ): string => number_format( (float) $m->get( 'amount', 0 ), 2, '.', '' ),
					__( 'Currency', 'wp-leadflow-crm' )       => $get( 'currency' ),
					__( 'Stage', 'wp-leadflow-crm' )          => static function ( Model $m ) use ( $stages ): string {
						$stage = $stages->find_by_slug( (string) $m->get( 'stage' ) );
						return null !== $stage ? $stage->name() : (string) $m->get( 'stage' );
					},
					__( 'Status', 'wp-leadflow-crm' )         => $get( 'status' ),
					__( 'Source', 'wp-leadflow-crm' )         => $get( 'source' ),
					__( 'Win probability', 'wp-leadflow-crm' ) => static fn( Model $m ): string => null === $m->get( 'probability' ) ? '' : (string) $m->get( 'probability' ),
					__( 'Expected close date', 'wp-leadflow-crm' ) => $get( 'expected_close_date' ),
					__( 'Description', 'wp-leadflow-crm' )    => $get( 'description' ),
					__( 'Assigned to', 'wp-leadflow-crm' )    => $owner,
					__( 'Created', 'wp-leadflow-crm' )        => static fn( Model $m ): string => $date( $m->get( 'created_at' ) ),
					__( 'Closed', 'wp-leadflow-crm' )         => static fn( Model $m ): string => $date( $m->get( 'closed_at' ) ),
				);
		}
	}

	/**
	 * Writes the CSV to a stream.
	 *
	 * @param resource             $out    Output stream.
	 * @param string               $entity Entity.
	 * @param array<string, mixed> $where  Filters (validated by the caller).
	 * @return int Rows written.
	 */
	public function write( $out, string $entity, array $where ): int {
		/** @var Repository $repository */
		$repository = $this->plugin->get( EntityFields::get( $entity )['repository'] );
		$relations  = $this->plugin->get( Relations::class );
		$columns    = $this->columns( $entity );
		$page       = 1;
		$written    = 0;

		fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite -- Stream output.
		fputcsv( $out, array_keys( $columns ), ',', '"', '' );

		do {
			$items = $repository->query(
				array(
					'where'    => $where,
					'orderby'  => 'id',
					'order'    => 'ASC',
					'per_page' => self::PAGE,
					'page'     => $page,
				)
			);

			$extra = array(
				'companies' => 'companies' === $entity ? array() : $relations->companies_for( $items ),
				'contacts'  => 'leads' === $entity ? $relations->contacts_for( $items ) : array(),
			);

			foreach ( $items as $item ) {
				$row = array();

				foreach ( $columns as $callback ) {
					$row[] = self::cell( (string) $callback( $item, $extra ) );
				}

				fputcsv( $out, $row, ',', '"', '' );
				++$written;
			}

			++$page;
		} while ( count( $items ) === self::PAGE );

		return $written;
	}

	/**
	 * Neutralizes values a spreadsheet would run as a formula
	 * (CSV/formula injection), leaving plain numbers untouched.
	 *
	 * @param string $value Value.
	 * @return string
	 */
	public static function cell( string $value ): string {
		if ( '' !== $value && in_array( $value[0], array( '=', '+', '-', '@', "\t", "\r" ), true ) && ! is_numeric( $value ) ) {
			return "'" . $value;
		}

		return $value;
	}
}
