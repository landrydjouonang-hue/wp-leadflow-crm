<?php
/**
 * Import wizard state.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\ImportExport;

defined( 'ABSPATH' ) || exit;

/**
 * An import in progress, stored per user for 24 hours.
 *
 * The token in the URL is random and only valid for the user who
 * uploaded the file; the file path is never taken from the request.
 */
final class ImportSession {

	/** Lifetime. */
	public const TTL = DAY_IN_SECONDS;

	/**
	 * Constructor.
	 *
	 * @param string               $token Token.
	 * @param array<string, mixed> $data  State.
	 */
	private function __construct( private string $token, public array $data ) {}

	/**
	 * Starts a session.
	 *
	 * @param array<string, mixed> $data Initial state.
	 * @return self
	 */
	public static function create( array $data ): self {
		$session = new self( wp_generate_password( 20, false, false ), array_merge( $data, array( 'user_id' => get_current_user_id() ) ) );
		$session->save();

		return $session;
	}

	/**
	 * Loads the current user's session.
	 *
	 * @param string $token Token from the request.
	 * @return self|null
	 */
	public static function load( string $token ): ?self {
		if ( 1 !== preg_match( '/^[A-Za-z0-9]{20}$/', $token ) ) {
			return null;
		}

		$data = get_transient( self::key( $token ) );

		if ( ! is_array( $data ) || (int) ( $data['user_id'] ?? 0 ) !== get_current_user_id() ) {
			return null;
		}

		return new self( $token, $data );
	}

	/**
	 * Token.
	 *
	 * @return string
	 */
	public function token(): string {
		return $this->token;
	}

	/**
	 * Persists the state.
	 *
	 * @return void
	 */
	public function save(): void {
		set_transient( self::key( $this->token ), $this->data, self::TTL );
	}

	/**
	 * Deletes the state and the uploaded file.
	 *
	 * @return void
	 */
	public function destroy(): void {
		$this->delete_file();
		delete_transient( self::key( $this->token ) );
	}

	/**
	 * Deletes the uploaded file (results are kept).
	 *
	 * @return void
	 */
	public function delete_file(): void {
		$path = (string) ( $this->data['path'] ?? '' );

		if ( '' !== $path && is_file( $path ) && str_starts_with( wp_normalize_path( $path ), wp_normalize_path( ImportExportModule::upload_dir() ) ) ) {
			wp_delete_file( $path );
		}
	}

	/**
	 * Transient key.
	 *
	 * @param string $token Token.
	 * @return string
	 */
	private static function key( string $token ): string {
		return 'leadflow_crm_import_' . $token;
	}
}
