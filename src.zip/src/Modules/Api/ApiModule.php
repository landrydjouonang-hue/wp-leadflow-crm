<?php
/**
 * REST API module.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Modules\Api;

use LeadFlow\CRM\Contracts\Module;
use LeadFlow\CRM\Contracts\ProvidesRestControllers;
use LeadFlow\CRM\Data\Repositories\ActivityRepository;
use LeadFlow\CRM\Data\Repositories\CompanyRepository;
use LeadFlow\CRM\Data\Repositories\ContactRepository;
use LeadFlow\CRM\Data\Repositories\LeadRepository;
use LeadFlow\CRM\Data\Repositories\TaskRepository;
use LeadFlow\CRM\Plugin;
use LeadFlow\CRM\Rest\Endpoints\ActivitiesController;
use LeadFlow\CRM\Rest\Endpoints\CompaniesController;
use LeadFlow\CRM\Rest\Endpoints\ContactsController;
use LeadFlow\CRM\Rest\Endpoints\LeadsController;
use LeadFlow\CRM\Rest\Endpoints\TasksController;

defined( 'ABSPATH' ) || exit;

/**
 * CRUD endpoints under /wp-json/leadflow-crm/v1 (see docs/API.md).
 *
 * Authentication is WordPress's own: the logged-in cookie with a
 * `wp_rest` nonce (admin screens) or Application Passwords (external
 * applications, HTTPS). Every endpoint then checks CRM permissions.
 */
final class ApiModule implements Module, ProvidesRestControllers {

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'api';
	}

	/**
	 * {@inheritDoc}
	 */
	public function boot( Plugin $plugin ): void {}

	/**
	 * {@inheritDoc}
	 */
	public function rest_controllers(): array {
		$plugin = Plugin::instance();

		return array(
			new LeadsController( $plugin->get( LeadRepository::class ), 'leads' ),
			new CompaniesController( $plugin->get( CompanyRepository::class ), 'companies' ),
			new ContactsController( $plugin->get( ContactRepository::class ), 'contacts' ),
			new TasksController( $plugin->get( TaskRepository::class ), 'tasks' ),
			new ActivitiesController( $plugin->get( ActivityRepository::class ), 'activities' ),
		);
	}
}
