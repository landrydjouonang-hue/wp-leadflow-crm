<?php
/**
 * Installs or upgrades the plugin on the current site.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Core;

use LeadFlow\CRM\Database\Migrator;
use LeadFlow\CRM\Security\Capabilities;
use LeadFlow\CRM\Settings\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Idempotent install routine shared by activation, upgrades and new
 * multisite sites.
 */
final class Installer {

	/** Option holding the installed plugin version. */
	public const VERSION_OPTION = 'leadflow_crm_version';

	/** Option holding the first install timestamp. */
	public const INSTALLED_AT_OPTION = 'leadflow_crm_installed_at';

	/**
	 * Constructor.
	 *
	 * @param Migrator     $migrator     Migrator.
	 * @param Capabilities $capabilities Capabilities.
	 * @param Settings     $settings     Settings.
	 */
	public function __construct(
		private Migrator $migrator,
		private Capabilities $capabilities,
		private Settings $settings
	) {}

	/**
	 * Runs migrations, syncs roles and records the version.
	 *
	 * Safe to run any number of times.
	 *
	 * @return bool False when a migration failed (version is not bumped).
	 */
	public function install(): bool {
		$migrated = $this->migrator->migrate();

		$this->capabilities->sync();
		$this->settings->ensure_option();

		add_option( self::INSTALLED_AT_OPTION, time(), '', false );

		if ( ! $migrated ) {
			return false;
		}

		update_option( self::VERSION_OPTION, LEADFLOW_CRM_VERSION, true );

		/**
		 * Fires after LeadFlow CRM was installed or upgraded on a site.
		 */
		do_action( 'leadflow_crm_installed' );

		return true;
	}

	/**
	 * Installed version, or null on a fresh site.
	 *
	 * @return string|null
	 */
	public static function installed_version(): ?string {
		$version = get_option( self::VERSION_OPTION );

		return is_string( $version ) && '' !== $version ? $version : null;
	}
}
