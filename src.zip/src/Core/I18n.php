<?php
/**
 * Internationalization.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Core;

use LeadFlow\CRM\Contracts\Hookable;

defined( 'ABSPATH' ) || exit;

/**
 * Loads the plugin text domain.
 *
 * Translations in wp-content/languages/plugins/ take precedence; the
 * bundled /languages directory is the fallback.
 */
final class I18n implements Hookable {

	/** Text domain. */
	public const DOMAIN = 'wp-leadflow-crm';

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		// Priority 0, registered before Plugin::boot_modules() so it runs first.
		add_action( 'init', array( $this, 'load_textdomain' ), 0 );
	}

	/**
	 * Loads translations.
	 *
	 * @return void
	 */
	public function load_textdomain(): void {
		load_plugin_textdomain( self::DOMAIN, false, dirname( LEADFLOW_CRM_BASENAME ) . '/languages' );
	}
}
