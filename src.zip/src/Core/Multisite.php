<?php
/**
 * Multisite integration.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Core;

use LeadFlow\CRM\Contracts\Hookable;
use LeadFlow\CRM\Database\Table;

defined( 'ABSPATH' ) || exit;

/**
 * Installs on new sites of a network activation and drops tables when a
 * site is deleted.
 */
final class Multisite implements Hookable {

	/**
	 * Constructor.
	 *
	 * @param Installer $installer Installer.
	 */
	public function __construct( private Installer $installer ) {}

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_action( 'wp_initialize_site', array( $this, 'install_new_site' ), 200 );
		add_filter( 'wpmu_drop_tables', array( $this, 'drop_site_tables' ), 10, 2 );
	}

	/**
	 * Installs on a newly created site when network-activated.
	 *
	 * @param \WP_Site $site New site.
	 * @return void
	 */
	public function install_new_site( \WP_Site $site ): void {
		if ( ! function_exists( 'is_plugin_active_for_network' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		if ( ! is_plugin_active_for_network( LEADFLOW_CRM_BASENAME ) ) {
			return;
		}

		switch_to_blog( (int) $site->blog_id );
		$this->installer->install();
		restore_current_blog();
	}

	/**
	 * Drops plugin tables when a site is deleted.
	 *
	 * Core drops the listed tables one by one in list order, which foreign
	 * keys between CRM tables would block, so they are dropped here with
	 * foreign key checks disabled. The core list is returned unchanged.
	 *
	 * @param string[] $tables  Tables core will drop.
	 * @param int      $site_id Site id.
	 * @return string[]
	 */
	public function drop_site_tables( array $tables, int $site_id ): array {
		switch_to_blog( $site_id );
		Table::drop_all();
		restore_current_blog();

		return $tables;
	}
}
