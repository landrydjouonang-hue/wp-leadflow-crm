<?php
/**
 * Deactivation handler.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Runs on deactivation. Data, roles and settings are kept so that
 * reactivating restores the CRM exactly as it was.
 */
final class Deactivator {

	/**
	 * Deactivation callback.
	 *
	 * @param bool $network_wide Whether deactivated for the whole network.
	 * @return void
	 */
	public static function deactivate( bool $network_wide = false ): void {
		if ( is_multisite() && $network_wide ) {
			foreach ( get_sites(
				array(
					'fields' => 'ids',
					'number' => 0,
				)
			) as $site_id ) {
				switch_to_blog( (int) $site_id );
				self::deactivate_site();
				restore_current_blog();
			}

			return;
		}

		self::deactivate_site();
	}

	/**
	 * Cleans up the current site.
	 *
	 * @return void
	 */
	private static function deactivate_site(): void {
		Cron::clear_all();

		delete_transient( Activator::NOTICE_TRANSIENT );
		delete_option( 'leadflow_crm_upgrade_lock' );

		/**
		 * Fires after LeadFlow CRM was deactivated on a site.
		 */
		do_action( 'leadflow_crm_deactivated' );
	}
}
