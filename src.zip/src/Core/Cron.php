<?php
/**
 * Scheduled event helpers.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Every scheduled hook the plugin owns must start with HOOK_PREFIX so it
 * can be cleaned up without loading modules.
 */
final class Cron {

	/** Required prefix for plugin cron hooks. */
	public const HOOK_PREFIX = 'leadflow_crm_';

	/**
	 * Unschedules every plugin event on the current site.
	 *
	 * @return string[] Cleared hook names.
	 */
	public static function clear_all(): array {
		$cron    = _get_cron_array();
		$cleared = array();

		if ( ! is_array( $cron ) ) {
			return $cleared;
		}

		foreach ( $cron as $hooks ) {
			foreach ( array_keys( (array) $hooks ) as $hook ) {
				$hook = (string) $hook;

				if ( str_starts_with( $hook, self::HOOK_PREFIX ) && ! in_array( $hook, $cleared, true ) ) {
					wp_unschedule_hook( $hook );
					$cleared[] = $hook;
				}
			}
		}

		return $cleared;
	}
}
