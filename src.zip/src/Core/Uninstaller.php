<?php
/**
 * Uninstall handler.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Core;

use LeadFlow\CRM\Database\Table;
use LeadFlow\CRM\Security\Capabilities;
use LeadFlow\CRM\Settings\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Removes plugin data when the plugin is deleted.
 *
 * CRM data is business-critical, so it is only removed when the
 * "Delete all data on uninstall" setting is enabled or the
 * LEADFLOW_CRM_REMOVE_ALL_DATA constant is true. Scheduled events are
 * always cleared.
 *
 * Runs without modules loaded, so cleanup is prefix-based:
 * tables `{prefix}leadflow_*`, options `leadflow_crm_*`, user meta
 * `leadflow_crm_*`, capabilities `leadflow_*`.
 */
final class Uninstaller {

	/**
	 * Uninstalls on every site.
	 *
	 * @return void
	 */
	public static function uninstall(): void {
		$remove_data = false;

		if ( is_multisite() ) {
			foreach ( get_sites(
				array(
					'fields' => 'ids',
					'number' => 0,
				)
			) as $site_id ) {
				switch_to_blog( (int) $site_id );
				$remove_data = self::uninstall_site() || $remove_data;
				restore_current_blog();
			}
		} else {
			$remove_data = self::uninstall_site();
		}

		if ( $remove_data ) {
			self::delete_user_meta();
		}
	}

	/**
	 * Whether data should be removed on the current site.
	 *
	 * @return bool
	 */
	public static function should_remove_data(): bool {
		if ( defined( 'LEADFLOW_CRM_REMOVE_ALL_DATA' ) && true === LEADFLOW_CRM_REMOVE_ALL_DATA ) {
			return true;
		}

		$settings = get_option( Settings::OPTION, array() );

		return is_array( $settings ) && ! empty( $settings['delete_data_on_uninstall'] );
	}

	/**
	 * Uninstalls on the current site.
	 *
	 * @return bool Whether data was removed.
	 */
	private static function uninstall_site(): bool {
		Cron::clear_all();

		if ( ! self::should_remove_data() ) {
			return false;
		}

		self::drop_tables();
		Capabilities::remove_all();
		self::delete_options();
		self::delete_uploads();

		return true;
	}

	/**
	 * Deletes wp-content/uploads/leadflow-crm (import files) of the site.
	 *
	 * @return void
	 */
	private static function delete_uploads(): void {
		$base = wp_upload_dir( null, false )['basedir'] ?? '';
		$dir  = '' !== $base ? trailingslashit( $base ) . 'leadflow-crm' : '';

		if ( '' === $dir || ! is_dir( $dir ) ) {
			return;
		}

		$items = new \RecursiveIteratorIterator(
			new \RecursiveDirectoryIterator( $dir, \FilesystemIterator::SKIP_DOTS ),
			\RecursiveIteratorIterator::CHILD_FIRST
		);

		foreach ( $items as $item ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_rmdir -- Uninstall cleanup.
			$item->isDir() ? rmdir( $item->getPathname() ) : wp_delete_file( $item->getPathname() );
		}

		rmdir( $dir ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_rmdir
	}

	/**
	 * Drops every `{prefix}leadflow_*` table.
	 *
	 * @return void
	 */
	private static function drop_tables(): void {
		// Foreign key checks are disabled during the drop, so order is irrelevant.
		Table::drop_all();
	}

	/**
	 * Deletes `leadflow_crm_*` options and transients.
	 *
	 * @return void
	 */
	private static function delete_options(): void {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Prefix lookup, no API equivalent.
		$names = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s",
				$wpdb->esc_like( 'leadflow_crm_' ) . '%',
				$wpdb->esc_like( '_transient_leadflow_crm_' ) . '%',
				$wpdb->esc_like( '_transient_timeout_leadflow_crm_' ) . '%'
			)
		);

		foreach ( (array) $names as $name ) {
			delete_option( (string) $name );
		}

		wp_cache_delete( 'alloptions', 'options' );
	}

	/**
	 * Deletes `leadflow_crm_*` user meta (network-wide table).
	 *
	 * @return void
	 */
	private static function delete_user_meta(): void {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Prefix lookup, no API equivalent.
		$keys = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT meta_key FROM {$wpdb->usermeta} WHERE meta_key LIKE %s",
				$wpdb->esc_like( 'leadflow_crm_' ) . '%'
			)
		);

		foreach ( (array) $keys as $key ) {
			delete_metadata( 'user', 0, (string) $key, '', true );
		}
	}
}
