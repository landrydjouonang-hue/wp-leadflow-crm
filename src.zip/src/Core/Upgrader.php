<?php
/**
 * Version management.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Core;

use LeadFlow\CRM\Contracts\Hookable;
use LeadFlow\CRM\Security\Capabilities;

defined( 'ABSPATH' ) || exit;

/**
 * Runs the installer when the code version differs from the stored one.
 *
 * Activation hooks do not fire on plugin updates, so this catches updates
 * delivered by the updater, FTP or version control.
 */
final class Upgrader implements Hookable {

	/** Lock option name. */
	private const LOCK_OPTION = 'leadflow_crm_upgrade_lock';

	/** Transient set after a failed upgrade to avoid retrying on every request. */
	private const BACKOFF_TRANSIENT = 'leadflow_crm_upgrade_backoff';

	/** Seconds after which a lock is considered stale. */
	private const LOCK_TIMEOUT = 300;

	/**
	 * Constructor.
	 *
	 * @param Installer    $installer    Installer.
	 * @param Capabilities $capabilities Capabilities.
	 */
	public function __construct(
		private Installer $installer,
		private Capabilities $capabilities
	) {}

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_action( 'init', array( $this, 'maybe_upgrade' ), 5 );
	}

	/**
	 * Whether an upgrade is needed.
	 *
	 * @return bool
	 */
	public function needs_upgrade(): bool {
		return LEADFLOW_CRM_VERSION !== Installer::installed_version() || $this->capabilities->needs_sync();
	}

	/**
	 * Upgrades if needed. Protected by a lock against concurrent requests.
	 *
	 * @return void
	 */
	public function maybe_upgrade(): void {
		if ( ! $this->needs_upgrade() || false !== get_transient( self::BACKOFF_TRANSIENT ) ) {
			return;
		}

		if ( ! $this->acquire_lock() ) {
			return;
		}

		$previous = Installer::installed_version();

		try {
			if ( ! $this->installer->install() ) {
				set_transient( self::BACKOFF_TRANSIENT, 1, 15 * MINUTE_IN_SECONDS );
				return;
			}
		} finally {
			delete_option( self::LOCK_OPTION );
		}

		if ( null !== $previous && $previous !== LEADFLOW_CRM_VERSION ) {
			/**
			 * Fires after the plugin was updated to a new version.
			 *
			 * @param string $previous Previous version.
			 * @param string $current  Current version.
			 */
			\LeadFlow\CRM\Support\Logger::info(
				'Plugin updated',
				array(
					'from' => $previous,
					'to'   => LEADFLOW_CRM_VERSION,
				)
			);

			do_action( 'leadflow_crm_updated', $previous, LEADFLOW_CRM_VERSION );
		}
	}

	/**
	 * Acquires the lock atomically (add_option fails if the row exists).
	 *
	 * @return bool
	 */
	private function acquire_lock(): bool {
		if ( add_option( self::LOCK_OPTION, time(), '', false ) ) {
			return true;
		}

		$since = (int) get_option( self::LOCK_OPTION, 0 );

		if ( $since > 0 && ( time() - $since ) < self::LOCK_TIMEOUT ) {
			return false;
		}

		// Stale lock left by a crashed request: take it over.
		update_option( self::LOCK_OPTION, time(), false );

		return true;
	}
}
