<?php
/**
 * Activation handler.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Core;

use LeadFlow\CRM\Plugin;

defined( 'ABSPATH' ) || exit;

/**
 * Runs on plugin activation (single site or network-wide).
 */
final class Activator {

	/** Transient that triggers the one-time "activated" notice. */
	public const NOTICE_TRANSIENT = 'leadflow_crm_activated';

	/**
	 * Activation callback.
	 *
	 * @param bool $network_wide Whether activated for the whole network.
	 * @return void
	 */
	public static function activate( bool $network_wide = false ): void {
		if ( is_multisite() && $network_wide ) {
			foreach ( get_sites(
				array(
					'fields' => 'ids',
					'number' => 0,
				)
			) as $site_id ) {
				switch_to_blog( (int) $site_id );
				self::activate_site();
				restore_current_blog();
			}

			return;
		}

		self::activate_site();
	}

	/**
	 * Installs on the current site.
	 *
	 * @return void
	 */
	private static function activate_site(): void {
		Plugin::instance()->get( Installer::class )->install();

		set_transient( self::NOTICE_TRANSIENT, 1, MINUTE_IN_SECONDS );

		/**
		 * Fires after LeadFlow CRM was activated on a site.
		 */
		do_action( 'leadflow_crm_activated' );
	}
}
