<?php
/**
 * Request authorization helpers.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Security;

defined( 'ABSPATH' ) || exit;

/**
 * Enforces capabilities and nonces on admin requests.
 */
final class Guard {

	/**
	 * Stops the request unless the current user has the capability.
	 *
	 * @param string $capability Capability.
	 * @param mixed  ...$args    Optional object id(s) for meta capabilities.
	 * @return void
	 */
	public static function authorize( string $capability, mixed ...$args ): void {
		if ( ! current_user_can( $capability, ...$args ) ) {
			wp_die(
				esc_html__( 'Sorry, you are not allowed to access this page.', 'wp-leadflow-crm' ),
				esc_html__( 'Access denied', 'wp-leadflow-crm' ),
				array(
					'response'  => 403,
					'back_link' => true,
				)
			);
		}
	}

	/**
	 * Verifies a form submission: nonce first, then capability.
	 *
	 * @param string $action     Unprefixed nonce action.
	 * @param string $capability Capability.
	 * @return void
	 */
	public static function verify_form( string $action, string $capability ): void {
		check_admin_referer( Nonce::action( $action ), Nonce::FIELD );
		self::authorize( $capability );
	}

	/**
	 * Verifies an admin-ajax request: nonce first, then capability.
	 *
	 * Sends a JSON error and exits on failure.
	 *
	 * @param string $action     Unprefixed nonce action.
	 * @param string $capability Capability.
	 * @return void
	 */
	public static function verify_ajax( string $action, string $capability ): void {
		if ( false === check_ajax_referer( Nonce::action( $action ), Nonce::FIELD, false ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Your session has expired. Please reload the page and try again.', 'wp-leadflow-crm' ) ),
				403
			);
		}

		if ( ! current_user_can( $capability ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You are not allowed to perform this action.', 'wp-leadflow-crm' ) ),
				403
			);
		}
	}
}
