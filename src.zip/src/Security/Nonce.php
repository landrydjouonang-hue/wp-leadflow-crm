<?php
/**
 * Nonce helpers.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Security;

defined( 'ABSPATH' ) || exit;

/**
 * Namespaces nonce actions so they never collide with other plugins.
 */
final class Nonce {

	/** Request field carrying the nonce. */
	public const FIELD = '_leadflow_nonce';

	/**
	 * Prefixed nonce action.
	 *
	 * @param string $action Unprefixed action, e.g. "save_lead".
	 * @return string
	 */
	public static function action( string $action ): string {
		return 'leadflow_crm_' . $action;
	}

	/**
	 * Creates a nonce value.
	 *
	 * @param string $action Unprefixed action.
	 * @return string
	 */
	public static function create( string $action ): string {
		return wp_create_nonce( self::action( $action ) );
	}

	/**
	 * Verifies a nonce value.
	 *
	 * @param string $nonce  Nonce value.
	 * @param string $action Unprefixed action.
	 * @return bool
	 */
	public static function verify( string $nonce, string $action ): bool {
		return false !== wp_verify_nonce( $nonce, self::action( $action ) );
	}

	/**
	 * Outputs the hidden nonce field.
	 *
	 * @param string $action Unprefixed action.
	 * @return void
	 */
	public static function field( string $action ): void {
		wp_nonce_field( self::action( $action ), self::FIELD );
	}

	/**
	 * Adds a nonce to a URL.
	 *
	 * @param string $url    URL.
	 * @param string $action Unprefixed action.
	 * @return string Unescaped URL.
	 */
	public static function url( string $url, string $action ): string {
		return add_query_arg( self::FIELD, self::create( $action ), $url );
	}
}
