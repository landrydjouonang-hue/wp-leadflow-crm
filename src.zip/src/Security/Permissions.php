<?php
/**
 * Permission catalog and role overrides.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Security;

defined( 'ABSPATH' ) || exit;

/**
 * Describes every CRM capability (grouped as the permissions people
 * manage: View CRM, Manage leads, Manage companies, …) and stores the
 * per-role changes made on the Access control screen.
 *
 * Defaults come from the modules (`Capabilities::map()`); overrides are
 * applied on top of them, so plugin updates can add new capabilities
 * without undoing a site's choices. Administrators always keep every CRM
 * capability, so nobody can lock the site out of its own CRM.
 */
final class Permissions {

	/** Option holding role => capability => granted overrides. */
	public const OPTION = 'leadflow_crm_role_caps';

	/** Manage CRM users, roles and permissions. */
	public const MANAGE_USERS = 'leadflow_manage_users';

	/** Add notes and manage your own notes. */
	public const MANAGE_NOTES = 'leadflow_manage_notes';

	/** Pin and delete anyone's notes. */
	public const MANAGE_OTHERS_NOTES = 'leadflow_manage_others_notes';

	/** Edit and delete any manually logged activity. */
	public const MANAGE_ACTIVITIES = 'leadflow_manage_activities';

	/**
	 * Capability groups shown on the Access control screen.
	 *
	 * @return array<string, array{label: string, description: string, caps: array<string, string>}>
	 */
	public static function groups(): array {
		$entity = static fn( string $plural, string $view, string $edit, string $others, string $delete ): array => array(
			'leadflow_view_' . $plural        => $view,
			'leadflow_edit_' . $plural        => $edit,
			'leadflow_edit_others_' . $plural => $others,
			'leadflow_delete_' . $plural      => $delete,
		);

		$groups = array(
			'crm'        => array(
				'label'       => __( 'View CRM', 'wp-leadflow-crm' ),
				'description' => __( 'Open the CRM and its dashboard.', 'wp-leadflow-crm' ),
				'caps'        => array( Capabilities::ACCESS_CRM => __( 'Access the CRM', 'wp-leadflow-crm' ) ),
			),
			'leads'      => array(
				'label'       => __( 'Manage leads', 'wp-leadflow-crm' ),
				'description' => __( 'Leads and the sales pipeline.', 'wp-leadflow-crm' ),
				'caps'        => $entity( 'leads', __( 'View leads', 'wp-leadflow-crm' ), __( 'Create leads and edit their own', 'wp-leadflow-crm' ), __( 'Edit and assign everyone’s leads', 'wp-leadflow-crm' ), __( 'Trash, restore and delete leads', 'wp-leadflow-crm' ) )
					+ array( 'leadflow_manage_pipeline' => __( 'Configure pipeline stages', 'wp-leadflow-crm' ) ),
			),
			'companies'  => array(
				'label'       => __( 'Manage companies', 'wp-leadflow-crm' ),
				'description' => __( 'Organizations and their details.', 'wp-leadflow-crm' ),
				'caps'        => $entity( 'companies', __( 'View companies', 'wp-leadflow-crm' ), __( 'Create companies and edit their own', 'wp-leadflow-crm' ), __( 'Edit and assign everyone’s companies', 'wp-leadflow-crm' ), __( 'Trash, restore and delete companies', 'wp-leadflow-crm' ) ),
			),
			'contacts'   => array(
				'label'       => __( 'Manage contacts', 'wp-leadflow-crm' ),
				'description' => __( 'People and their details.', 'wp-leadflow-crm' ),
				'caps'        => $entity( 'contacts', __( 'View contacts', 'wp-leadflow-crm' ), __( 'Create contacts and edit their own', 'wp-leadflow-crm' ), __( 'Edit and assign everyone’s contacts', 'wp-leadflow-crm' ), __( 'Trash, restore and delete contacts', 'wp-leadflow-crm' ) ),
			),
			'tasks'      => array(
				'label'       => __( 'Manage tasks', 'wp-leadflow-crm' ),
				'description' => __( 'To-dos; a task belongs to its assignee and its creator.', 'wp-leadflow-crm' ),
				'caps'        => $entity( 'tasks', __( 'View tasks', 'wp-leadflow-crm' ), __( 'Create tasks and edit their own', 'wp-leadflow-crm' ), __( 'Edit and assign everyone’s tasks', 'wp-leadflow-crm' ), __( 'Trash, restore and delete tasks', 'wp-leadflow-crm' ) ),
			),
			'notes'      => array(
				'label'       => __( 'Manage notes', 'wp-leadflow-crm' ),
				'description' => __( 'Notes on records the user can edit.', 'wp-leadflow-crm' ),
				'caps'        => array(
					self::MANAGE_NOTES        => __( 'Add notes and manage their own', 'wp-leadflow-crm' ),
					self::MANAGE_OTHERS_NOTES => __( 'Pin and delete everyone’s notes', 'wp-leadflow-crm' ),
				),
			),
			'activities' => array(
				'label'       => __( 'Manage activities', 'wp-leadflow-crm' ),
				'description' => __( 'Logging calls, emails and meetings follows the record’s edit permission.', 'wp-leadflow-crm' ),
				'caps'        => array( self::MANAGE_ACTIVITIES => __( 'Edit and delete everyone’s logged activities (API)', 'wp-leadflow-crm' ) ),
			),
			'email'      => array(
				'label'       => __( 'Email', 'wp-leadflow-crm' ),
				'description' => __( 'Sending emails and email templates.', 'wp-leadflow-crm' ),
				'caps'        => array(
					'leadflow_send_emails'        => __( 'Send emails to records they can edit', 'wp-leadflow-crm' ),
					'leadflow_view_emails'        => __( 'See their own sent emails', 'wp-leadflow-crm' ),
					'leadflow_view_others_emails' => __( 'See everyone’s sent emails', 'wp-leadflow-crm' ),
				) + $entity( 'email_templates', __( 'View email templates', 'wp-leadflow-crm' ), __( 'Create and edit email templates', 'wp-leadflow-crm' ), __( 'Edit all email templates', 'wp-leadflow-crm' ), __( 'Delete email templates', 'wp-leadflow-crm' ) ),
			),
			'data'       => array(
				'label'       => __( 'Import and export', 'wp-leadflow-crm' ),
				'description' => __( 'CSV files. Importing also needs permission to create the records.', 'wp-leadflow-crm' ),
				'caps'        => array(
					'leadflow_import_data' => __( 'Import data', 'wp-leadflow-crm' ),
					'leadflow_export_data' => __( 'Export data', 'wp-leadflow-crm' ),
				),
			),
			'admin'      => array(
				'label'       => __( 'Administration', 'wp-leadflow-crm' ),
				'description' => __( 'Sensitive: grant only to trusted people.', 'wp-leadflow-crm' ),
				'caps'        => array(
					Capabilities::MANAGE_SETTINGS => __( 'Manage settings', 'wp-leadflow-crm' ),
					self::MANAGE_USERS            => __( 'Manage users, roles and permissions', 'wp-leadflow-crm' ),
				),
			),
		);

		/**
		 * Filters the permission groups shown on the Access control screen.
		 *
		 * @param array $groups Groups.
		 */
		return (array) apply_filters( 'leadflow_crm_permission_groups', $groups );
	}

	/**
	 * Stored overrides.
	 *
	 * @return array<string, array<string, bool>> Role => capability => granted.
	 */
	public static function overrides(): array {
		$stored = get_option( self::OPTION, array() );
		$clean  = array();

		foreach ( is_array( $stored ) ? $stored : array() as $role => $caps ) {
			if ( ! is_string( $role ) || 'administrator' === $role || ! is_array( $caps ) ) {
				continue;
			}

			foreach ( $caps as $cap => $granted ) {
				if ( is_string( $cap ) && str_starts_with( $cap, Capabilities::PREFIX ) ) {
					$clean[ $role ][ $cap ] = (bool) $granted;
				}
			}
		}

		return $clean;
	}

	/**
	 * Applies overrides to a capability map; administrators get everything.
	 *
	 * @param array<string, string[]> $map Capability => roles.
	 * @return array<string, string[]>
	 */
	public static function apply( array $map ): array {
		foreach ( self::overrides() as $role => $caps ) {
			foreach ( $caps as $cap => $granted ) {
				if ( ! isset( $map[ $cap ] ) ) {
					continue;
				}

				$roles = array_values( array_diff( $map[ $cap ], array( $role ) ) );

				if ( $granted ) {
					$roles[] = $role;
				}

				$map[ $cap ] = $roles;
			}
		}

		foreach ( $map as $cap => $roles ) {
			$map[ $cap ] = array_values( array_unique( array_merge( array( 'administrator' ), $roles ) ) );
		}

		return $map;
	}

	/**
	 * Roles shown as editable columns (every role except administrator).
	 *
	 * @return array<string, string> Slug => translated name.
	 */
	public static function editable_roles(): array {
		$roles = array();

		// CRM roles first.
		foreach ( Capabilities::custom_roles() as $slug => $name ) {
			if ( null !== get_role( $slug ) ) {
				$roles[ $slug ] = translate_user_role( $name );
			}
		}

		foreach ( wp_roles()->get_names() as $slug => $name ) {
			if ( 'administrator' !== $slug && ! isset( $roles[ $slug ] ) ) {
				$roles[ $slug ] = translate_user_role( $name );
			}
		}

		return $roles;
	}

	/**
	 * Why the current user may not change a capability for a role ('' = allowed).
	 *
	 * Rules: administrators are locked; non-administrators cannot change
	 * roles they have, nor grant or revoke capabilities they lack.
	 *
	 * @param string $role Role slug.
	 * @param string $cap  Capability.
	 * @return string Reason.
	 */
	public static function lock_reason( string $role, string $cap ): string {
		if ( 'administrator' === $role ) {
			return __( 'Administrators always have every CRM permission.', 'wp-leadflow-crm' );
		}

		if ( current_user_can( 'manage_options' ) ) {
			return '';
		}

		if ( in_array( $role, (array) wp_get_current_user()->roles, true ) ) {
			return __( 'You cannot change the permissions of your own role.', 'wp-leadflow-crm' );
		}

		if ( ! current_user_can( $cap ) ) {
			return __( 'You can only grant or remove permissions you have yourself.', 'wp-leadflow-crm' );
		}

		return '';
	}

	/**
	 * Whether the current user may give a role to someone: they must hold
	 * every CRM capability of that role (no privilege escalation).
	 *
	 * @param string                  $role Role slug.
	 * @param array<string, string[]> $map  Current capability map.
	 * @return bool
	 */
	public static function can_assign_role( string $role, array $map ): bool {
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}

		foreach ( $map as $cap => $roles ) {
			if ( in_array( $role, $roles, true ) && ! current_user_can( $cap ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Saves overrides so that the effective map equals `$wanted` for the
	 * given roles (only differences from the defaults are stored).
	 *
	 * @param array<string, string[]> $defaults Default map (no overrides).
	 * @param array<string, string[]> $wanted   Role => wanted capabilities.
	 * @return void
	 */
	public static function save( array $defaults, array $wanted ): void {
		$overrides = self::overrides();

		foreach ( $wanted as $role => $caps ) {
			unset( $overrides[ $role ] );

			foreach ( array_keys( $defaults ) as $cap ) {
				$default = in_array( $role, $defaults[ $cap ], true );
				$granted = in_array( $cap, $caps, true );

				if ( $default !== $granted ) {
					$overrides[ $role ][ $cap ] = $granted;
				}
			}
		}

		update_option( self::OPTION, array_filter( $overrides ), false );
	}

	/**
	 * Removes every override (back to the defaults).
	 *
	 * @return void
	 */
	public static function reset(): void {
		delete_option( self::OPTION );
	}
}
