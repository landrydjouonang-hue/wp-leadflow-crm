<?php
/**
 * Sanitized request input.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Security;

defined( 'ABSPATH' ) || exit;

/**
 * Typed, sanitized accessors for $_GET / $_POST.
 *
 * Callers are responsible for nonce verification before trusting
 * state-changing input (see Guard).
 */
final class Input {

	/**
	 * Raw, unslashed value.
	 *
	 * @param string $key    Field name.
	 * @param string $source "get" or "post".
	 * @return mixed|null
	 */
	private static function raw( string $key, string $source ): mixed {
		// phpcs:disable WordPress.Security.NonceVerification -- Verification is the caller's responsibility.
		$data = 'post' === $source ? $_POST : $_GET;
		// phpcs:enable

		if ( ! isset( $data[ $key ] ) ) {
			return null;
		}

		return wp_unslash( $data[ $key ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized by the typed accessors.
	}

	/**
	 * Single-line text.
	 *
	 * @param string $key     Field name.
	 * @param string $source  "get" or "post".
	 * @param string $default Default value.
	 * @return string
	 */
	public static function text( string $key, string $source = 'get', string $default = '' ): string {
		$value = self::raw( $key, $source );

		return is_scalar( $value ) ? sanitize_text_field( (string) $value ) : $default;
	}

	/**
	 * Multi-line text.
	 *
	 * @param string $key    Field name.
	 * @param string $source "get" or "post".
	 * @return string
	 */
	public static function textarea( string $key, string $source = 'post' ): string {
		$value = self::raw( $key, $source );

		return is_scalar( $value ) ? sanitize_textarea_field( (string) $value ) : '';
	}

	/**
	 * Slug-like key (lowercase alphanumerics, dashes, underscores).
	 *
	 * @param string $key     Field name.
	 * @param string $source  "get" or "post".
	 * @param string $default Default value.
	 * @return string
	 */
	public static function key( string $key, string $source = 'get', string $default = '' ): string {
		$value = self::raw( $key, $source );

		return is_scalar( $value ) ? sanitize_key( (string) $value ) : $default;
	}

	/**
	 * Integer.
	 *
	 * @param string $key     Field name.
	 * @param string $source  "get" or "post".
	 * @param int    $default Default value.
	 * @return int
	 */
	public static function int( string $key, string $source = 'get', int $default = 0 ): int {
		$value = self::raw( $key, $source );

		return is_numeric( $value ) ? (int) $value : $default;
	}

	/**
	 * Email address ('' when invalid).
	 *
	 * @param string $key    Field name.
	 * @param string $source "get" or "post".
	 * @return string
	 */
	public static function email( string $key, string $source = 'post' ): string {
		$value = self::raw( $key, $source );

		return is_scalar( $value ) ? sanitize_email( (string) $value ) : '';
	}

	/**
	 * Boolean (checkbox semantics).
	 *
	 * @param string $key    Field name.
	 * @param string $source "get" or "post".
	 * @return bool
	 */
	public static function bool( string $key, string $source = 'post' ): bool {
		return (bool) rest_sanitize_boolean( self::raw( $key, $source ) ?? false );
	}

	/**
	 * Value restricted to an allow-list.
	 *
	 * @param string   $key     Field name.
	 * @param string[] $allowed Allowed values.
	 * @param string   $default Default when not allowed.
	 * @param string   $source  "get" or "post".
	 * @return string
	 */
	public static function one_of( string $key, array $allowed, string $default, string $source = 'get' ): string {
		$value = self::text( $key, $source, $default );

		return in_array( $value, $allowed, true ) ? $value : $default;
	}
}
