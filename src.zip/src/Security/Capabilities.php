<?php
/**
 * Capability and role framework.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Security;

use LeadFlow\CRM\Modules\ModuleManager;

defined( 'ABSPATH' ) || exit;

/**
 * Defines CRM roles and keeps role capabilities in sync with modules.
 */
final class Capabilities {

	/** Access the CRM admin area. */
	public const ACCESS_CRM = 'leadflow_access_crm';

	/** Manage plugin settings and see system status. */
	public const MANAGE_SETTINGS = 'leadflow_manage_settings';

	/** CRM Manager role slug. */
	public const ROLE_MANAGER = 'leadflow_manager';

	/** Sales Agent role slug. */
	public const ROLE_AGENT = 'leadflow_sales_agent';

	/** Option storing the hash of the last synced capability map. */
	public const HASH_OPTION = 'leadflow_crm_caps_hash';

	/** Option storing the caps this plugin granted, per role. */
	public const GRANTED_OPTION = 'leadflow_crm_granted_caps';

	/** Prefix shared by every capability this plugin owns. */
	public const PREFIX = 'leadflow_';

	/**
	 * Constructor.
	 *
	 * @param ModuleManager $modules Module manager.
	 */
	public function __construct( private ModuleManager $modules ) {}

	/**
	 * Roles created by the plugin.
	 *
	 * Names are stored untranslated, as WordPress core does for its roles.
	 *
	 * @return array<string, string> Role slug => display name.
	 */
	public static function custom_roles(): array {
		return array(
			self::ROLE_MANAGER => 'CRM Manager',
			self::ROLE_AGENT   => 'Sales Agent',
		);
	}

	/**
	 * Core capabilities.
	 *
	 * @return array<string, string[]> Capability => roles.
	 */
	private function core_map(): array {
		$all      = array( 'administrator', self::ROLE_MANAGER, self::ROLE_AGENT );
		$managers = array( 'administrator', self::ROLE_MANAGER );

		return array(
			self::ACCESS_CRM                        => $all,
			self::MANAGE_SETTINGS                   => $managers,
			Permissions::MANAGE_USERS               => array( 'administrator' ),
			Permissions::MANAGE_NOTES               => $all,
			Permissions::MANAGE_OTHERS_NOTES        => $managers,
			Permissions::MANAGE_ACTIVITIES          => $managers,
		);
	}

	/**
	 * Default capability map: core plus modules, before the role
	 * overrides made on the Access control screen.
	 *
	 * @return array<string, string[]> Capability => roles.
	 */
	public function defaults(): array {
		$map = $this->core_map();

		foreach ( $this->modules->capabilities() as $cap => $roles ) {
			$map[ $cap ] = array_values( array_unique( array_merge( $map[ $cap ] ?? array(), $roles ) ) );
		}

		/**
		 * Filters the capability => roles map before it is applied.
		 *
		 * @param array<string, string[]> $map Capability map.
		 */
		$map = (array) apply_filters( 'leadflow_crm_capability_map', $map );

		ksort( $map );

		return $map;
	}

	/**
	 * Effective capability map: defaults with role overrides applied
	 * (administrators always hold every capability).
	 *
	 * @return array<string, string[]> Capability => roles.
	 */
	public function map(): array {
		return Permissions::apply( $this->defaults() );
	}

	/**
	 * Map inverted to role => capabilities.
	 *
	 * @return array<string, string[]>
	 */
	public function by_role(): array {
		$roles = array();

		foreach ( $this->map() as $cap => $cap_roles ) {
			foreach ( (array) $cap_roles as $role ) {
				$roles[ $role ][] = $cap;
			}
		}

		return $roles;
	}

	/**
	 * Whether roles need to be re-synced.
	 *
	 * @return bool
	 */
	public function needs_sync(): bool {
		return get_option( self::HASH_OPTION ) !== $this->hash();
	}

	/**
	 * Creates roles and grants/revokes capabilities to match the map.
	 *
	 * Only capabilities this plugin granted itself are ever revoked, so
	 * manual grants made with a role editor are respected.
	 *
	 * @return void
	 */
	public function sync(): void {
		foreach ( self::custom_roles() as $slug => $name ) {
			if ( null === get_role( $slug ) ) {
				add_role( $slug, $name, array( 'read' => true ) );
			}
		}

		$wanted  = $this->by_role();
		$granted = get_option( self::GRANTED_OPTION, array() );
		$granted = is_array( $granted ) ? $granted : array();

		foreach ( $granted as $role_slug => $caps ) {
			$role = get_role( (string) $role_slug );

			if ( null === $role ) {
				continue;
			}

			foreach ( array_diff( (array) $caps, $wanted[ $role_slug ] ?? array() ) as $cap ) {
				$role->remove_cap( $cap );
			}
		}

		$applied = array();

		foreach ( $wanted as $role_slug => $caps ) {
			$role = get_role( $role_slug );

			if ( null === $role ) {
				continue;
			}

			foreach ( $caps as $cap ) {
				$role->add_cap( $cap );
			}

			$applied[ $role_slug ] = $caps;
		}

		update_option( self::GRANTED_OPTION, $applied, false );
		update_option( self::HASH_OPTION, $this->hash(), true );
	}

	/**
	 * Removes all plugin capabilities from every role and deletes the
	 * custom roles. Users left without a role get the site default role.
	 *
	 * Works without modules loaded (used by the uninstaller).
	 *
	 * @return void
	 */
	public static function remove_all(): void {
		$wp_roles = wp_roles();

		foreach ( $wp_roles->role_objects as $role ) {
			foreach ( array_keys( (array) $role->capabilities ) as $cap ) {
				if ( str_starts_with( (string) $cap, self::PREFIX ) ) {
					$role->remove_cap( $cap );
				}
			}
		}

		$fallback = (string) get_option( 'default_role', 'subscriber' );

		if ( isset( self::custom_roles()[ $fallback ] ) ) {
			$fallback = 'subscriber';
		}

		foreach ( array_keys( self::custom_roles() ) as $slug ) {
			$users = get_users(
				array(
					'role'   => $slug,
					'fields' => 'ID',
				)
			);

			foreach ( $users as $user_id ) {
				$user = new \WP_User( (int) $user_id );
				$user->remove_role( $slug );

				if ( empty( $user->roles ) ) {
					$user->add_role( $fallback );
				}
			}

			remove_role( $slug );
		}

		delete_option( self::HASH_OPTION );
		delete_option( self::GRANTED_OPTION );
		delete_option( Permissions::OPTION );
	}

	/**
	 * Hash of the current map.
	 *
	 * @return string
	 */
	private function hash(): string {
		return md5( (string) wp_json_encode( array( self::custom_roles(), $this->map() ) ) );
	}
}
