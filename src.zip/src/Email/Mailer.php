<?php
/**
 * Email transport.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Email;

use LeadFlow\CRM\Admin\View;
use LeadFlow\CRM\Settings\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Sends HTML emails through wp_mail(), so any SMTP or transactional-email
 * plugin configured on the site is used automatically.
 *
 * - Every address is validated and every display name stripped of line
 *   breaks and delimiters (no header injection).
 * - The message is wrapped in a simple responsive layout and gets a plain
 *   text alternative.
 * - The transport error (wp_mail_failed) is captured and returned.
 */
final class Mailer {

	/**
	 * Error captured from wp_mail_failed during the current send.
	 *
	 * @var string
	 */
	private string $error = '';

	/**
	 * Plain-text alternative for the current send.
	 *
	 * @var string
	 */
	private string $alt_body = '';

	/**
	 * Constructor.
	 *
	 * @param Settings $settings Settings.
	 */
	public function __construct( private Settings $settings ) {}

	/**
	 * Sender name from the settings (business name when empty).
	 *
	 * @return string
	 */
	public function from_name(): string {
		$name = trim( (string) $this->settings->get( 'email_from_name', '' ) );

		if ( '' === $name ) {
			$name = trim( (string) $this->settings->get( 'company_name', '' ) );
		}

		return self::clean_name( '' !== $name ? $name : (string) get_bloginfo( 'name' ) );
	}

	/**
	 * Sender address from the settings ('' = WordPress default).
	 *
	 * @return string
	 */
	public function from_email(): string {
		$email = sanitize_email( (string) $this->settings->get( 'email_from_email', '' ) );

		return is_email( $email ) ? $email : '';
	}

	/**
	 * Sends a message.
	 *
	 * @param array<string, mixed> $message {
	 *     @type string   $to       Recipient address. Required.
	 *     @type string   $to_name  Recipient name.
	 *     @type string[] $cc       Cc addresses.
	 *     @type string[] $bcc      Bcc addresses.
	 *     @type string   $reply_to Reply-To address.
	 *     @type string   $subject  Subject (plain text). Required.
	 *     @type string   $html     Message content (sanitized HTML). Required.
	 * }
	 * @return array{sent: bool, error: string}
	 */
	public function send( array $message ): array {
		$to = sanitize_email( (string) ( $message['to'] ?? '' ) );

		if ( ! is_email( $to ) ) {
			return array(
				'sent'  => false,
				'error' => __( 'The recipient address is not valid.', 'wp-leadflow-crm' ),
			);
		}

		$subject = self::clean_header( (string) ( $message['subject'] ?? '' ) );
		$content = (string) ( $message['html'] ?? '' );
		$headers = array( 'Content-Type: text/html; charset=UTF-8' );

		if ( '' !== $this->from_email() ) {
			$headers[] = 'From: ' . self::address( $this->from_email(), $this->from_name() );
		}

		$reply_to = sanitize_email( (string) ( $message['reply_to'] ?? '' ) );

		if ( is_email( $reply_to ) ) {
			$headers[] = 'Reply-To: ' . $reply_to;
		}

		foreach ( array( 'cc' => 'Cc', 'bcc' => 'Bcc' ) as $key => $label ) {
			foreach ( (array) ( $message[ $key ] ?? array() ) as $address ) {
				$address = sanitize_email( (string) $address );

				if ( is_email( $address ) ) {
					$headers[] = $label . ': ' . $address;
				}
			}
		}

		/**
		 * Filters the headers of a CRM email.
		 *
		 * @param string[]             $headers Headers.
		 * @param array<string, mixed> $message Message.
		 */
		$headers = (array) apply_filters( 'leadflow_crm_email_headers', $headers, $message );

		$html = $this->document( $subject, $content );

		/**
		 * Filters the full HTML document of a CRM email.
		 *
		 * @param string               $html    HTML document.
		 * @param array<string, mixed> $message Message.
		 */
		$html = (string) apply_filters( 'leadflow_crm_email_html', $html, $message );

		$this->error    = '';
		$this->alt_body = self::plain_text( $content );

		add_action( 'wp_mail_failed', array( $this, 'capture_error' ) );
		add_action( 'phpmailer_init', array( $this, 'add_alt_body' ) );

		if ( '' === $this->from_email() ) {
			add_filter( 'wp_mail_from_name', array( $this, 'from_name' ) );
		}

		try {
			$sent = (bool) wp_mail( self::address( $to, (string) ( $message['to_name'] ?? '' ) ), $subject, $html, $headers );
		} catch ( \Throwable $e ) {
			$sent        = false;
			$this->error = $e->getMessage();
		} finally {
			remove_action( 'wp_mail_failed', array( $this, 'capture_error' ) );
			remove_action( 'phpmailer_init', array( $this, 'add_alt_body' ) );
			remove_filter( 'wp_mail_from_name', array( $this, 'from_name' ) );
		}

		if ( $sent ) {
			return array(
				'sent'  => true,
				'error' => '',
			);
		}

		return array(
			'sent'  => false,
			'error' => '' !== $this->error
				? $this->error
				: __( 'Your site could not send the email. Check the email configuration of your site (for example with an SMTP plugin).', 'wp-leadflow-crm' ),
		);
	}

	/**
	 * `wp_mail_failed` listener.
	 *
	 * @param \WP_Error $error Error.
	 * @return void
	 */
	public function capture_error( \WP_Error $error ): void {
		$this->error = wp_strip_all_tags( $error->get_error_message() );
	}

	/**
	 * `phpmailer_init` listener: plain-text alternative body.
	 *
	 * @param object $phpmailer PHPMailer instance.
	 * @return void
	 */
	public function add_alt_body( object $phpmailer ): void {
		if ( property_exists( $phpmailer, 'AltBody' ) ) {
			$phpmailer->AltBody = $this->alt_body; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- PHPMailer API.
		}
	}

	/**
	 * Wraps content in the email layout.
	 *
	 * @param string $subject Subject.
	 * @param string $content Sanitized HTML content.
	 * @return string
	 */
	public function document( string $subject, string $content ): string {
		ob_start();
		View::render(
			'emails/layout',
			array(
				'subject'  => $subject,
				'content'  => $content,
				'business' => $this->from_name(),
				'site_url' => home_url( '/' ),
			)
		);

		return (string) ob_get_clean();
	}

	/**
	 * Plain-text version of HTML content.
	 *
	 * @param string $html HTML.
	 * @return string
	 */
	public static function plain_text( string $html ): string {
		// Keep link targets and line structure.
		$text = (string) preg_replace( '#<a\s[^>]*href=(["\'])(https?://[^"\']+)\1[^>]*>(.*?)</a>#is', '$3 ($2)', $html );
		$text = (string) preg_replace( '#<br\s*/?>#i', "\n", $text );
		$text = (string) preg_replace( '#</(p|div|h[1-6]|ul|ol|table|tr)>#i', "\n\n", $text );
		$text = (string) preg_replace( '#<li[^>]*>#i', '- ', $text );
		$text = html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES, 'UTF-8' );
		$text = (string) preg_replace( "/[ \t]+/", ' ', $text );
		$text = (string) preg_replace( "/ *\n */", "\n", $text );

		return trim( (string) preg_replace( "/\n{3,}/", "\n\n", $text ) );
	}

	/**
	 * "Name <email>" with a safe display name.
	 *
	 * @param string $email Address.
	 * @param string $name  Display name.
	 * @return string
	 */
	public static function address( string $email, string $name ): string {
		$name = self::clean_name( $name );

		return '' !== $name ? sprintf( '%1$s <%2$s>', $name, $email ) : $email;
	}

	/**
	 * Display name without characters that could break an address header.
	 *
	 * @param string $name Name.
	 * @return string
	 */
	public static function clean_name( string $name ): string {
		return trim( (string) preg_replace( '/[\r\n\t<>"\\\\,;:]+/', ' ', wp_strip_all_tags( $name ) ) );
	}

	/**
	 * Single-line header value.
	 *
	 * @param string $value Value.
	 * @return string
	 */
	public static function clean_header( string $value ): string {
		return trim( (string) preg_replace( '/[\r\n]+/', ' ', $value ) );
	}
}
