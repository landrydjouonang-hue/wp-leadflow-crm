<?php
/**
 * Sends emails to CRM records.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Email;

use LeadFlow\CRM\Admin\Menu;
use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\Company;
use LeadFlow\CRM\Data\Models\Contact;
use LeadFlow\CRM\Data\Models\Email;
use LeadFlow\CRM\Data\Models\EmailTemplate;
use LeadFlow\CRM\Data\Models\Lead;
use LeadFlow\CRM\Data\Repositories\CompanyRepository;
use LeadFlow\CRM\Data\Repositories\ContactRepository;
use LeadFlow\CRM\Data\Repositories\EmailRepository;
use LeadFlow\CRM\Data\Repositories\EmailTemplateRepository;
use LeadFlow\CRM\Data\Repositories\LeadRepository;
use LeadFlow\CRM\Data\ValidationException;
use LeadFlow\CRM\Plugin;
use LeadFlow\CRM\Settings\Settings;
use LeadFlow\CRM\Support\Logger;

defined( 'ABSPATH' ) || exit;

/**
 * Composes, sends and logs an email to a lead, contact or company.
 *
 * Callers are responsible for authorization (the admin screens require
 * `leadflow_send_emails` and the edit capability of the record).
 *
 * Every attempt is stored in the emails table (status sent|failed); a
 * successful email also appears on the record's activity timeline.
 */
final class EmailSender {

	/** Record type => repository and admin page slug. */
	public const TYPES = array(
		'lead'    => array( LeadRepository::class, 'leadflow-crm-leads', 'leads' ),
		'contact' => array( ContactRepository::class, 'leadflow-crm-contacts', 'contacts' ),
		'company' => array( CompanyRepository::class, 'leadflow-crm-companies', 'companies' ),
	);

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( private Plugin $plugin ) {}

	// ------------------------------------------------------------------
	// Records.
	// ------------------------------------------------------------------

	/**
	 * Loads a record that can receive emails (not trashed).
	 *
	 * @param string $type lead|contact|company.
	 * @param int    $id   Record id.
	 * @return Model|null
	 */
	public function record( string $type, int $id ): ?Model {
		if ( ! isset( self::TYPES[ $type ] ) ) {
			return null;
		}

		return $this->plugin->get( self::TYPES[ $type ][0] )->find( $id );
	}

	/**
	 * Display name of a record.
	 *
	 * @param Model $record Record.
	 * @return string
	 */
	public static function label( Model $record ): string {
		return match ( true ) {
			$record instanceof Lead    => $record->title(),
			$record instanceof Contact => $record->full_name(),
			$record instanceof Company => $record->name(),
			default                    => '',
		};
	}

	/**
	 * URL of a record screen.
	 *
	 * @param string $type Record type.
	 * @param int    $id   Record id.
	 * @return string Unescaped URL.
	 */
	public static function record_url( string $type, int $id ): string {
		return isset( self::TYPES[ $type ] )
			? Menu::url(
				self::TYPES[ $type ][1],
				array(
					'action' => 'view',
					'id'     => $id,
				)
			)
			: Menu::url();
	}

	/**
	 * Most specific record an email belongs to.
	 *
	 * @param Model $email Email.
	 * @return array{0: string|null, 1: int}
	 */
	public static function owning_record( Model $email ): array {
		foreach ( array( 'lead', 'contact', 'company' ) as $type ) {
			$id = $email->get( $type . '_id' );

			if ( null !== $id ) {
				return array( $type, (int) $id );
			}
		}

		return array( null, 0 );
	}

	/**
	 * Suggested recipients, the primary one first.
	 *
	 * @param string $type   Record type.
	 * @param Model  $record Record.
	 * @return array<string, string> Email => name.
	 */
	public function recipients( string $type, Model $record ): array {
		$list = array();
		$add  = static function ( mixed $email, string $name ) use ( &$list ): void {
			$email = sanitize_email( (string) $email );

			if ( is_email( $email ) && ! isset( $list[ strtolower( $email ) ] ) ) {
				$list[ strtolower( $email ) ] = array( $email, $name );
			}
		};

		$contacts  = $this->plugin->get( ContactRepository::class );
		$companies = $this->plugin->get( CompanyRepository::class );

		switch ( $type ) {
			case 'lead':
				$contact = $record->get( 'contact_id' ) ? $contacts->find( (int) $record->get( 'contact_id' ) ) : null;
				$company = $record->get( 'company_id' ) ? $companies->find( (int) $record->get( 'company_id' ) ) : null;
				$add( $record->get( 'email' ), $contact instanceof Contact ? $contact->full_name() : '' );
				if ( $contact instanceof Contact ) {
					$add( $contact->get( 'email' ), $contact->full_name() );
				}
				if ( $company instanceof Company ) {
					$add( $company->get( 'email' ), $company->name() );
				}
				break;

			case 'contact':
				$add( $record->get( 'email' ), $record instanceof Contact ? $record->full_name() : '' );
				$company = $record->get( 'company_id' ) ? $companies->find( (int) $record->get( 'company_id' ) ) : null;
				if ( $company instanceof Company ) {
					$add( $company->get( 'email' ), $company->name() );
				}
				break;

			case 'company':
				$add( $record->get( 'email' ), $record instanceof Company ? $record->name() : '' );
				foreach ( $contacts->query(
					array(
						'where'    => array( 'company_id' => $record->id() ),
						'orderby'  => 'first_name',
						'order'    => 'ASC',
						'per_page' => 50,
					)
				) as $contact ) {
					$add( $contact->get( 'email' ), $contact instanceof Contact ? $contact->full_name() : '' );
				}
				break;
		}

		$recipients = array();

		foreach ( $list as list( $email, $name ) ) {
			$recipients[ $email ] = $name;
		}

		/**
		 * Filters the recipients suggested when emailing a record.
		 *
		 * @param array<string, string> $recipients Email => name.
		 * @param string                $type       Record type.
		 * @param Model                 $record     Record.
		 */
		return (array) apply_filters( 'leadflow_crm_email_recipients', $recipients, $type, $record );
	}

	// ------------------------------------------------------------------
	// Limits and settings.
	// ------------------------------------------------------------------

	/**
	 * Emails one user may send per hour (0 = unlimited).
	 *
	 * @return int
	 */
	public function hourly_limit(): int {
		/**
		 * Filters the number of emails a user may send per hour (0 = unlimited).
		 *
		 * @param int $limit Limit from the settings.
		 */
		return max( 0, (int) apply_filters( 'leadflow_crm_email_hourly_limit', (int) $this->settings()->get( 'email_hourly_limit', 50 ) ) );
	}

	/**
	 * Emails the user can still send this hour (null = unlimited).
	 *
	 * @param int $user_id User.
	 * @return int|null
	 */
	public function remaining( int $user_id ): ?int {
		$limit = $this->hourly_limit();

		if ( 0 === $limit ) {
			return null;
		}

		$used = $this->emails()->count_sent_by_since( $user_id, gmdate( 'Y-m-d H:i:s', time() - HOUR_IN_SECONDS ) );

		return max( 0, $limit - $used );
	}

	/**
	 * Whether "Send me a copy" is pre-selected.
	 *
	 * @return bool
	 */
	public function copy_by_default(): bool {
		return (bool) $this->settings()->get( 'email_bcc_sender', false );
	}

	/**
	 * Whether a signature is configured.
	 *
	 * @return bool
	 */
	public function has_signature(): bool {
		return '' !== trim( (string) $this->settings()->get( 'email_signature', '' ) );
	}

	// ------------------------------------------------------------------
	// Composing.
	// ------------------------------------------------------------------

	/**
	 * Renders subject and body for a record exactly as they will be sent
	 * (placeholders replaced, paragraphs added to plain text, signature).
	 *
	 * @param string $type    Record type.
	 * @param int    $id      Record id.
	 * @param string $subject Subject template.
	 * @param string $body    Body template (HTML or plain text).
	 * @return array{subject: string, body: string}|null Null when the record does not exist.
	 */
	public function render( string $type, int $id, string $subject, string $body ): ?array {
		$values = $this->renderer()->values_for( $type, $id );

		if ( null === $values ) {
			return null;
		}

		$rendered  = $this->renderer()->render( $subject, self::paragraphs( $body ), $values );
		$signature = trim( (string) $this->settings()->get( 'email_signature', '' ) );

		if ( '' !== $signature ) {
			$rendered['body'] .= "\n" . '<div class="leadflow-signature" style="margin-top:24px;">' . $this->renderer()->render( '', self::paragraphs( $signature ), $values )['body'] . '</div>';
		}

		return $rendered;
	}

	/**
	 * Adds paragraphs to plain-text input; HTML is kept as written.
	 *
	 * @param string $text Text or HTML.
	 * @return string
	 */
	public static function paragraphs( string $text ): string {
		$text = trim( $text );

		if ( '' === $text || 1 === preg_match( '#<(p|br|div|ul|ol|table|h[1-6]|blockquote)[\s/>]#i', $text ) ) {
			return $text;
		}

		return wpautop( $text );
	}

	/**
	 * Validates, sends and logs an email to a record.
	 *
	 * @param string               $type  Record type.
	 * @param int                  $id    Record id.
	 * @param array<string, mixed> $input {
	 *     @type string $to          Recipient. Required.
	 *     @type string $cc          Comma-separated addresses.
	 *     @type string $bcc         Comma-separated addresses.
	 *     @type string $subject     Subject (may contain placeholders). Required.
	 *     @type string $body        Message (may contain placeholders). Required.
	 *     @type int    $template_id Template used, if any.
	 *     @type bool   $copy_me     Bcc the sender.
	 * }
	 * @return Email Stored email; check is_sent() for the outcome.
	 * @throws ValidationException When the input is invalid or the hourly limit is reached.
	 */
	public function send( string $type, int $id, array $input ): Email {
		$record = $this->record( $type, $id );

		if ( null === $record ) {
			throw new ValidationException( array( 'record' => __( 'This record no longer exists or is in the trash.', 'wp-leadflow-crm' ) ) );
		}

		$errors  = array();
		$to      = trim( (string) ( $input['to'] ?? '' ) );
		$subject = trim( (string) ( $input['subject'] ?? '' ) );
		$body    = trim( (string) ( $input['body'] ?? '' ) );

		if ( '' === $to ) {
			$errors['to'] = __( 'Please enter the recipient’s email address.', 'wp-leadflow-crm' );
		} elseif ( ! is_email( $to ) || sanitize_email( $to ) !== $to ) {
			$errors['to'] = __( 'Please enter a valid email address.', 'wp-leadflow-crm' );
		}

		$copies = array();

		foreach ( array( 'cc', 'bcc' ) as $field ) {
			$list = EmailRepository::parse_addresses( (string) ( $input[ $field ] ?? '' ) );

			if ( null === $list ) {
				$errors[ $field ] = __( 'Please enter valid email addresses separated by commas.', 'wp-leadflow-crm' );
			} elseif ( count( $list ) > EmailRepository::MAX_COPIES ) {
				/* translators: %d: Maximum number of addresses. */
				$errors[ $field ] = sprintf( __( 'Please enter at most %d addresses.', 'wp-leadflow-crm' ), EmailRepository::MAX_COPIES );
			} else {
				$copies[ $field ] = $list;
			}
		}

		if ( '' === $subject ) {
			$errors['subject'] = __( 'Please enter a subject.', 'wp-leadflow-crm' );
		}

		if ( '' === trim( wp_strip_all_tags( $body ) ) ) {
			$errors['body'] = __( 'Please write a message.', 'wp-leadflow-crm' );
		}

		foreach ( array( 'subject' => $subject, 'body' => $body ) as $field => $text ) {
			$unknown = TemplateRenderer::unknown_placeholders( $text );

			if ( ! empty( $unknown ) && ! isset( $errors[ $field ] ) ) {
				$errors[ $field ] = sprintf(
					/* translators: %s: Comma-separated placeholders. */
					_n( 'Unknown placeholder: %s', 'Unknown placeholders: %s', count( $unknown ), 'wp-leadflow-crm' ),
					implode( ', ', array_map( static fn( string $p ): string => '{{' . $p . '}}', $unknown ) )
				);
			}
		}

		$user      = wp_get_current_user();
		$remaining = $this->remaining( (int) $user->ID );

		if ( null !== $remaining && $remaining <= 0 ) {
			$errors['limit'] = sprintf(
				/* translators: %d: Emails per hour. */
				__( 'You have reached the limit of %d emails per hour. Please try again later.', 'wp-leadflow-crm' ),
				$this->hourly_limit()
			);
		}

		if ( ! empty( $errors ) ) {
			throw new ValidationException( $errors );
		}

		$rendered   = (array) $this->render( $type, $id, $subject, $body );
		$recipients = $this->recipients( $type, $record );
		$to_name    = '';

		foreach ( $recipients as $email => $name ) {
			if ( 0 === strcasecmp( $email, $to ) ) {
				$to_name = (string) $name;
				break;
			}
		}

		$bcc = $copies['bcc'];

		if ( ! empty( $input['copy_me'] ) && is_email( $user->user_email ) && ! in_array( strtolower( $user->user_email ), array_map( 'strtolower', $bcc ), true ) ) {
			$bcc[] = $user->user_email;
		}

		$template_id = (int) ( $input['template_id'] ?? 0 );
		$template    = $template_id > 0 ? $this->plugin->get( EmailTemplateRepository::class )->find( $template_id, true ) : null;
		$reply_to    = 'sender' === $this->settings()->get( 'email_reply_to', 'sender' ) && is_email( $user->user_email ) ? $user->user_email : '';

		$message = array(
			'to'       => $to,
			'to_name'  => $to_name,
			'cc'       => $copies['cc'],
			'bcc'      => $bcc,
			'reply_to' => $reply_to,
			'subject'  => $rendered['subject'],
			'html'     => $rendered['body'],
		);

		/**
		 * Filters an email before it is sent to a CRM record.
		 *
		 * @param array<string, mixed> $message Message (see Mailer::send()).
		 * @param string               $type    Record type.
		 * @param Model                $record  Record.
		 */
		$message = (array) apply_filters( 'leadflow_crm_email_message', $message, $type, $record );

		$mailer = $this->mailer();
		$result = $mailer->send( $message );

		/** @var Email $email */
		$email = $this->emails()->create(
			array(
				$type . '_id' => $id,
				'template_id' => $template instanceof EmailTemplate ? $template->id() : null,
				'to_email'    => (string) $message['to'],
				'to_name'     => Mailer::clean_name( (string) $message['to_name'] ),
				'cc'          => implode( ', ', (array) $message['cc'] ),
				'bcc'         => implode( ', ', (array) $message['bcc'] ),
				'from_name'   => $mailer->from_name(),
				'from_email'  => $mailer->from_email(),
				'reply_to'    => (string) $message['reply_to'],
				'subject'     => Mailer::clean_header( (string) $message['subject'] ),
				'body'        => (string) $message['html'],
				'status'      => $result['sent'] ? 'sent' : 'failed',
				'error'       => $result['sent'] ? null : $result['error'],
				'sent_at'     => $result['sent'] ? current_time( 'mysql', true ) : null,
				'meta'        => array(
					'template' => $template instanceof EmailTemplate ? $template->name() : '',
					'copy_me'  => ! empty( $input['copy_me'] ),
				),
			)
		);

		if ( $email->is_sent() ) {
			/**
			 * Fires after a CRM email was handed to the mail server.
			 *
			 * @param Email $email Stored email.
			 */
			do_action( 'leadflow_crm_email_sent', $email );
		} else {
			Logger::warning(
				'Email could not be sent',
				array(
					'to'     => $email->to_email(),
					'record' => $type . ':' . $id,
					'error'  => (string) $email->get( 'error', '' ),
				)
			);

			/**
			 * Fires after a CRM email could not be sent.
			 *
			 * @param Email $email Stored email (see its `error`).
			 */
			do_action( 'leadflow_crm_email_failed', $email );
		}

		return $email;
	}

	/**
	 * Sends a test email to an address (Settings → Email).
	 *
	 * @param string $to Address.
	 * @return array{sent: bool, error: string}
	 */
	public function send_test( string $to ): array {
		$user = wp_get_current_user();

		$content = '<p>' . esc_html__( 'This is a test email from LeadFlow CRM.', 'wp-leadflow-crm' ) . '</p>'
			. '<p>' . esc_html__( 'If you are reading this, your site can send CRM emails.', 'wp-leadflow-crm' ) . '</p>';

		if ( $this->has_signature() ) {
			$values   = $this->renderer()->sample_values();
			$content .= '<div style="margin-top:24px;">' . $this->renderer()->render( '', self::paragraphs( (string) $this->settings()->get( 'email_signature', '' ) ), $values )['body'] . '</div>';
		}

		return $this->mailer()->send(
			array(
				'to'       => $to,
				'reply_to' => 'sender' === $this->settings()->get( 'email_reply_to', 'sender' ) ? $user->user_email : '',
				/* translators: %s: Business name. */
				'subject'  => sprintf( __( 'Test email from %s', 'wp-leadflow-crm' ), $this->mailer()->from_name() ),
				'html'     => $content,
			)
		);
	}

	// ------------------------------------------------------------------
	// Services.
	// ------------------------------------------------------------------

	/**
	 * Mailer.
	 *
	 * @return Mailer
	 */
	public function mailer(): Mailer {
		return $this->plugin->get( Mailer::class );
	}

	/**
	 * Email repository.
	 *
	 * @return EmailRepository
	 */
	public function emails(): EmailRepository {
		return $this->plugin->get( EmailRepository::class );
	}

	/**
	 * Placeholder renderer.
	 *
	 * @return TemplateRenderer
	 */
	private function renderer(): TemplateRenderer {
		return $this->plugin->get( TemplateRenderer::class );
	}

	/**
	 * Settings.
	 *
	 * @return Settings
	 */
	private function settings(): Settings {
		return $this->plugin->get( Settings::class );
	}
}
