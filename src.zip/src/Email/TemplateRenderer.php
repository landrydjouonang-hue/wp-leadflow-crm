<?php
/**
 * Email template placeholders.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Email;

use LeadFlow\CRM\Data\Models\Company;
use LeadFlow\CRM\Data\Models\Contact;
use LeadFlow\CRM\Data\Models\Lead;
use LeadFlow\CRM\Data\Repositories\CompanyRepository;
use LeadFlow\CRM\Data\Repositories\ContactRepository;
use LeadFlow\CRM\Data\Repositories\LeadRepository;
use LeadFlow\CRM\Data\Repositories\StageRepository;
use LeadFlow\CRM\Plugin;
use LeadFlow\CRM\Settings\Settings;
use LeadFlow\CRM\Support\Format;

defined( 'ABSPATH' ) || exit;

/**
 * Replaces {{placeholders}} in template subjects and bodies.
 *
 * Syntax: `{{first_name}}`, spaces allowed (`{{ first_name }}`), optional
 * fallback when the value is empty: `{{first_name|there}}`.
 *
 * Values are resolved from a lead, contact and/or company (a lead brings
 * its contact and company; a contact brings its company). In HTML bodies
 * every value is escaped.
 */
final class TemplateRenderer {

	/** Placeholder pattern: key and optional |fallback. */
	private const PATTERN = '/\{\{\s*([a-z0-9_]+)\s*(?:\|\s*([^}]*?)\s*)?\}\}/i';

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin Plugin.
	 */
	public function __construct( private Plugin $plugin ) {}

	/**
	 * Available placeholders.
	 *
	 * @return array<string, array{label: string, group: string, sample: string}>
	 */
	public static function placeholders(): array {
		$contact = __( 'Contact', 'wp-leadflow-crm' );
		$company = __( 'Company', 'wp-leadflow-crm' );
		$lead    = __( 'Lead', 'wp-leadflow-crm' );
		$general = __( 'General', 'wp-leadflow-crm' );

		$placeholders = array(
			'first_name'      => array( __( 'First name', 'wp-leadflow-crm' ), $contact, 'Jane' ),
			'last_name'       => array( __( 'Last name', 'wp-leadflow-crm' ), $contact, 'Doe' ),
			'full_name'       => array( __( 'Full name', 'wp-leadflow-crm' ), $contact, 'Jane Doe' ),
			'email'           => array( __( 'Email', 'wp-leadflow-crm' ), $contact, 'jane@example.com' ),
			'phone'           => array( __( 'Phone', 'wp-leadflow-crm' ), $contact, '+1 555 0100' ),
			'job_title'       => array( __( 'Job title', 'wp-leadflow-crm' ), $contact, 'Head of Marketing' ),
			'company'         => array( __( 'Company name', 'wp-leadflow-crm' ), $company, 'Acme Corp' ),
			'company_website' => array( __( 'Company website', 'wp-leadflow-crm' ), $company, 'https://acme.example' ),
			'company_phone'   => array( __( 'Company phone', 'wp-leadflow-crm' ), $company, '+1 555 0199' ),
			'lead_title'      => array( __( 'Lead name', 'wp-leadflow-crm' ), $lead, 'Website redesign' ),
			'lead_stage'      => array( __( 'Sales stage', 'wp-leadflow-crm' ), $lead, 'Proposal' ),
			'lead_value'      => array( __( 'Lead value', 'wp-leadflow-crm' ), $lead, '$12,000' ),
			'lead_close_date' => array( __( 'Expected close date', 'wp-leadflow-crm' ), $lead, 'December 15, 2026' ),
			'owner_name'      => array( __( 'Record owner', 'wp-leadflow-crm' ), $general, 'Alex Smith' ),
			'owner_email'     => array( __( 'Record owner email', 'wp-leadflow-crm' ), $general, 'alex@example.com' ),
			'sender_name'     => array( __( 'Your name', 'wp-leadflow-crm' ), $general, 'Alex Smith' ),
			'business_name'   => array( __( 'Business name', 'wp-leadflow-crm' ), $general, 'Your Business' ),
			'site_url'        => array( __( 'Site URL', 'wp-leadflow-crm' ), $general, home_url( '/' ) ),
			'today'           => array( __( 'Today’s date', 'wp-leadflow-crm' ), $general, wp_date( (string) get_option( 'date_format' ) ) ),
		);

		$list = array();

		foreach ( $placeholders as $key => list( $label, $group, $sample ) ) {
			$list[ $key ] = array(
				'label'  => $label,
				'group'  => $group,
				'sample' => $sample,
			);
		}

		/**
		 * Filters the available email placeholders.
		 *
		 * Add `key => array( label, group, sample )` and fill the value with
		 * `leadflow_crm_email_placeholder_values`.
		 *
		 * @param array $list Placeholders.
		 */
		return (array) apply_filters( 'leadflow_crm_email_placeholders', $list );
	}

	/**
	 * Placeholders used in a text that do not exist.
	 *
	 * @param string $text Template text.
	 * @return string[]
	 */
	public static function unknown_placeholders( string $text ): array {
		preg_match_all( self::PATTERN, $text, $matches );

		$known = self::placeholders();

		return array_values( array_unique( array_filter( array_map( 'strtolower', $matches[1] ), static fn( string $key ): bool => ! isset( $known[ $key ] ) ) ) );
	}

	/**
	 * Replaces placeholders.
	 *
	 * @param string                $text   Template text.
	 * @param array<string, string> $values Placeholder values (plain text).
	 * @param bool                  $html   Escape values for HTML.
	 * @return string
	 */
	public static function replace( string $text, array $values, bool $html ): string {
		return (string) preg_replace_callback(
			self::PATTERN,
			static function ( array $m ) use ( $values, $html ): string {
				$key   = strtolower( $m[1] );
				$value = trim( (string) ( $values[ $key ] ?? '' ) );

				if ( '' === $value && isset( $m[2] ) ) {
					$value = trim( $m[2] );
				}

				return $html ? esc_html( $value ) : $value;
			},
			$text
		);
	}

	/**
	 * Renders a subject and body.
	 *
	 * @param string                $subject Subject template.
	 * @param string                $body    Body template (HTML).
	 * @param array<string, string> $values  Placeholder values.
	 * @return array{subject: string, body: string}
	 */
	public function render( string $subject, string $body, array $values ): array {
		return array(
			'subject' => wp_strip_all_tags( self::replace( $subject, $values, false ) ),
			'body'    => wp_kses_post( self::replace( $body, $values, true ) ),
		);
	}

	/**
	 * Sample values (preview without a record).
	 *
	 * @return array<string, string>
	 */
	public function sample_values(): array {
		$values = array_map( static fn( array $p ): string => $p['sample'], self::placeholders() );

		return array_merge( $values, $this->general_values() );
	}

	/**
	 * Values for a CRM record.
	 *
	 * @param string $type lead|contact|company.
	 * @param int    $id   Record id.
	 * @return array<string, string>|null Null when the record does not exist.
	 */
	public function values_for( string $type, int $id ): ?array {
		$lead    = null;
		$contact = null;
		$company = null;

		switch ( $type ) {
			case 'lead':
				$lead = $this->plugin->get( LeadRepository::class )->find( $id );
				if ( ! $lead instanceof Lead ) {
					return null;
				}
				$contact = $lead->get( 'contact_id' ) ? $this->plugin->get( ContactRepository::class )->find( (int) $lead->get( 'contact_id' ), true ) : null;
				$company = $lead->get( 'company_id' ) ? $this->plugin->get( CompanyRepository::class )->find( (int) $lead->get( 'company_id' ), true ) : null;
				break;

			case 'contact':
				$contact = $this->plugin->get( ContactRepository::class )->find( $id );
				if ( ! $contact instanceof Contact ) {
					return null;
				}
				$company = $contact->company_id() ? $this->plugin->get( CompanyRepository::class )->find( (int) $contact->company_id(), true ) : null;
				break;

			case 'company':
				$company = $this->plugin->get( CompanyRepository::class )->find( $id );
				if ( ! $company instanceof Company ) {
					return null;
				}
				break;

			default:
				return null;
		}

		return $this->values( $lead, $contact instanceof Contact ? $contact : null, $company instanceof Company ? $company : null );
	}

	/**
	 * Builds values from records (contact first, then lead, then company).
	 *
	 * @param Lead|null    $lead    Lead.
	 * @param Contact|null $contact Contact.
	 * @param Company|null $company Company.
	 * @return array<string, string>
	 */
	public function values( ?Lead $lead, ?Contact $contact, ?Company $company ): array {
		$pick = static function ( array $candidates ): string {
			foreach ( $candidates as $candidate ) {
				if ( '' !== (string) $candidate ) {
					return (string) $candidate;
				}
			}
			return '';
		};

		$owner_id = (int) ( $lead?->get( 'owner_id' ) ?? $contact?->get( 'owner_id' ) ?? $company?->get( 'owner_id' ) ?? 0 );
		$owner    = $owner_id > 0 ? get_userdata( $owner_id ) : false;
		$stage    = null !== $lead ? $this->plugin->get( StageRepository::class )->find_by_slug( (string) $lead->get( 'stage' ) ) : null;
		$close    = $lead?->get( 'expected_close_date' );

		$values = array(
			'first_name'      => (string) $contact?->get( 'first_name', '' ),
			'last_name'       => (string) $contact?->get( 'last_name', '' ),
			'full_name'       => null !== $contact ? $contact->full_name() : '',
			'email'           => $pick( array( $contact?->get( 'email' ), $lead?->get( 'email' ), $company?->get( 'email' ) ) ),
			'phone'           => $pick( array( $contact?->get( 'phone' ), $contact?->get( 'mobile' ), $lead?->get( 'phone' ), $company?->get( 'phone' ) ) ),
			'job_title'       => (string) $contact?->get( 'job_title', '' ),
			'company'         => (string) $company?->get( 'name', '' ),
			'company_website' => (string) $company?->get( 'website', '' ),
			'company_phone'   => (string) $company?->get( 'phone', '' ),
			'lead_title'      => (string) $lead?->get( 'title', '' ),
			'lead_stage'      => null !== $stage ? $stage->name() : '',
			'lead_value'      => null !== $lead ? Format::money( $lead->amount(), (string) $lead->get( 'currency', '' ) ) : '',
			'lead_close_date' => null !== $close ? (string) wp_date( (string) get_option( 'date_format' ), (int) strtotime( $close . ' 12:00:00 UTC' ) ) : '',
			'owner_name'      => false !== $owner ? (string) $owner->display_name : '',
			'owner_email'     => false !== $owner ? (string) $owner->user_email : '',
		);

		$values = array_merge( $values, $this->general_values() );

		/**
		 * Filters placeholder values before rendering.
		 *
		 * @param array<string, string> $values  Values.
		 * @param Lead|null             $lead    Lead.
		 * @param Contact|null          $contact Contact.
		 * @param Company|null          $company Company.
		 */
		return (array) apply_filters( 'leadflow_crm_email_placeholder_values', $values, $lead, $contact, $company );
	}

	/**
	 * Values that do not depend on a record.
	 *
	 * @return array<string, string>
	 */
	private function general_values(): array {
		$user = wp_get_current_user();

		return array(
			'sender_name'   => $user->exists() ? (string) $user->display_name : '',
			'business_name' => (string) $this->plugin->get( Settings::class )->get( 'company_name', get_bloginfo( 'name' ) ),
			'site_url'      => home_url( '/' ),
			'today'         => (string) wp_date( (string) get_option( 'date_format' ) ),
		);
	}
}
