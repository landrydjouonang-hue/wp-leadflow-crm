<?php
/**
 * Contract for modules exposing REST endpoints.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Contracts;

use LeadFlow\CRM\Rest\Controller;

defined( 'ABSPATH' ) || exit;

/**
 * Module that registers REST controllers.
 */
interface ProvidesRestControllers {

	/**
	 * REST controllers owned by the module.
	 *
	 * @return Controller[]
	 */
	public function rest_controllers(): array;
}
