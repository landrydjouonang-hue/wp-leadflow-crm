<?php
/**
 * Migration contract.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Contracts;

defined( 'ABSPATH' ) || exit;

/**
 * A single, ordered, reversible schema change.
 */
interface Migration {

	/**
	 * Unique, sortable id, e.g. "2026_09_18_000001_create_leads_table".
	 *
	 * @return string
	 */
	public function id(): string;

	/**
	 * Applies the change. Throw on failure.
	 *
	 * @return void
	 */
	public function up(): void;

	/**
	 * Reverts the change.
	 *
	 * @return void
	 */
	public function down(): void;
}
