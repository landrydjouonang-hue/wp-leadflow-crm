<?php
/**
 * Contract for modules that own database tables.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Contracts;

defined( 'ABSPATH' ) || exit;

/**
 * Module that ships database migrations.
 */
interface ProvidesMigrations {

	/**
	 * Migrations owned by the module.
	 *
	 * @return Migration[]
	 */
	public function migrations(): array;
}
