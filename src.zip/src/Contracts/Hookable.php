<?php
/**
 * Hookable contract.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Contracts;

defined( 'ABSPATH' ) || exit;

/**
 * A service that attaches itself to WordPress hooks.
 */
interface Hookable {

	/**
	 * Registers actions and filters. Must not perform work itself.
	 *
	 * @return void
	 */
	public function register(): void;
}
