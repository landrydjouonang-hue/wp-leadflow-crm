<?php
/**
 * Contract for modules that define capabilities.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Contracts;

defined( 'ABSPATH' ) || exit;

/**
 * Module that grants its own capabilities to roles.
 */
interface ProvidesCapabilities {

	/**
	 * Capability map.
	 *
	 * @return array<string, string[]> Capability => role slugs that receive it.
	 */
	public function capabilities(): array;
}
