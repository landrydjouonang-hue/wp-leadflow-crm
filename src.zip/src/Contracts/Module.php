<?php
/**
 * Module contract.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Contracts;

use LeadFlow\CRM\Plugin;

defined( 'ABSPATH' ) || exit;

/**
 * A self-contained feature area (Dashboard, Leads, Contacts, ...).
 *
 * Modules may additionally implement ProvidesMigrations,
 * ProvidesCapabilities and ProvidesRestControllers.
 */
interface Module {

	/**
	 * Unique module id, e.g. "leads".
	 *
	 * @return string
	 */
	public function id(): string;

	/**
	 * Wires the module into the plugin: menu pages, settings, hooks.
	 *
	 * Called once on `init` (priority 0), so translations are safe to use.
	 * Not called during activation.
	 *
	 * @param Plugin $plugin Plugin instance.
	 * @return void
	 */
	public function boot( Plugin $plugin ): void;
}
