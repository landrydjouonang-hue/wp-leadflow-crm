<?php
/**
 * Minimal service container.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM;

defined( 'ABSPATH' ) || exit;

/**
 * Lazily builds and caches shared services.
 */
final class Container {

	/**
	 * Service factories keyed by id.
	 *
	 * @var array<string, callable>
	 */
	private array $factories = array();

	/**
	 * Resolved service instances keyed by id.
	 *
	 * @var array<string, mixed>
	 */
	private array $instances = array();

	/**
	 * Registers a shared service factory.
	 *
	 * @param string   $id      Service id (usually the class name).
	 * @param callable $factory Receives the container, returns the service.
	 * @return void
	 */
	public function set( string $id, callable $factory ): void {
		$this->factories[ $id ] = $factory;
		unset( $this->instances[ $id ] );
	}

	/**
	 * Whether a service is registered.
	 *
	 * @param string $id Service id.
	 * @return bool
	 */
	public function has( string $id ): bool {
		return isset( $this->factories[ $id ] ) || isset( $this->instances[ $id ] );
	}

	/**
	 * Resolves a service.
	 *
	 * @param string $id Service id.
	 * @return mixed
	 * @throws \InvalidArgumentException When the service is unknown.
	 */
	public function get( string $id ): mixed {
		if ( array_key_exists( $id, $this->instances ) ) {
			return $this->instances[ $id ];
		}

		if ( ! isset( $this->factories[ $id ] ) ) {
			throw new \InvalidArgumentException(
				sprintf( 'LeadFlow CRM: unknown service "%s".', esc_html( $id ) )
			);
		}

		$this->instances[ $id ] = ( $this->factories[ $id ] )( $this );

		return $this->instances[ $id ];
	}
}
