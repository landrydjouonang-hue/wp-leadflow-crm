<?php
/**
 * REST route registration.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Rest;

use LeadFlow\CRM\Contracts\Hookable;
use LeadFlow\CRM\Modules\ModuleManager;

defined( 'ABSPATH' ) || exit;

/**
 * Registers every module's REST controllers on `rest_api_init`.
 */
final class RestServer implements Hookable {

	/**
	 * Constructor.
	 *
	 * @param ModuleManager $modules Module manager.
	 */
	public function __construct( private ModuleManager $modules ) {}

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Registers routes.
	 *
	 * @return void
	 */
	public function register_routes(): void {
		foreach ( $this->modules->rest_controllers() as $controller ) {
			$controller->register_routes();
		}
	}
}
