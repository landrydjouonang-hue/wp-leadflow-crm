<?php
/**
 * Leads REST endpoints.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Rest\Endpoints;

use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Rest\RecordController;

defined( 'ABSPATH' ) || exit;

/**
 * /leadflow-crm/v1/leads[/{id}]
 *
 * `status` follows the stage (set `stage`, or only `status` to move the
 * lead to the first stage of that type); `closed_at` and the pipeline
 * `position` are managed by the CRM.
 */
final class LeadsController extends RecordController {

	/**
	 * {@inheritDoc}
	 */
	protected function extra_readonly(): array {
		return array( 'closed_at', 'position' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function extra_hidden(): array {
		return array( 'position' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function filters(): array {
		return parent::filters() + array(
			'stage'  => 'stage',
			'source' => 'source',
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function sortable(): array {
		return array( 'id', 'title', 'amount', 'expected_close_date', 'closed_at', 'created_at', 'updated_at' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function embed_fields(): array {
		return array( 'title', 'status', 'stage', 'amount', 'currency' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function add_output_fields( array $data, Model $item ): array {
		$data['weighted_amount'] = null === $item->get( 'probability' ) ? null : round( (float) $item->get( 'amount' ) * (int) $item->get( 'probability' ) / 100, 2 );

		return $data;
	}

	/**
	 * {@inheritDoc}
	 */
	protected function extra_properties( array $properties ): array {
		$properties['title']['description']  = __( 'Lead name.', 'wp-leadflow-crm' );
		$properties['stage']['description']  = __( 'Pipeline stage slug (see Settings → Pipeline). Defaults to the first open stage.', 'wp-leadflow-crm' );
		$properties['status']['description'] = __( 'open, won or lost. Follows the stage type.', 'wp-leadflow-crm' );
		$properties['amount']['description']  = __( 'Deal value.', 'wp-leadflow-crm' );
		$properties['currency']['description'] = __( 'ISO 4217 code; defaults to the CRM default currency.', 'wp-leadflow-crm' );
		$properties['owner_id']['description']  = __( 'Assigned user. Defaults to the current user.', 'wp-leadflow-crm' );

		$properties['weighted_amount'] = array(
			'description' => __( 'Amount × win probability.', 'wp-leadflow-crm' ),
			'type'        => array( 'number', 'null' ),
			'readonly'    => true,
			'context'     => array( 'view', 'edit' ),
		);

		return $properties;
	}
}
