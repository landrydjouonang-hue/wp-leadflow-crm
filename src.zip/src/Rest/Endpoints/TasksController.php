<?php
/**
 * Tasks REST endpoints.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Rest\Endpoints;

use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\Task;
use LeadFlow\CRM\Rest\RecordController;

defined( 'ABSPATH' ) || exit;

/**
 * /leadflow-crm/v1/tasks[/{id}]
 *
 * A task belongs to its assignee and its creator: either may edit it with
 * `leadflow_edit_tasks`. Completing it (status "completed") stamps
 * `completed_at` / `completed_by`.
 */
final class TasksController extends RecordController {

	/**
	 * {@inheritDoc}
	 */
	protected function owner_field(): string {
		return 'assigned_to';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function extra_readonly(): array {
		return array( 'completed_at', 'completed_by' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function filters(): array {
		return parent::filters() + array( 'priority' => 'priority' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function sortable(): array {
		return array( 'id', 'title', 'due_at', 'priority', 'created_at', 'updated_at' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function embed_fields(): array {
		return array( 'title', 'status', 'due_at' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function add_output_fields( array $data, Model $item ): array {
		$data['overdue'] = $item instanceof Task && ! in_array( $item->get( 'status' ), Task::CLOSED_STATUSES, true )
			&& null !== $item->get( 'due_at' ) && (string) $item->get( 'due_at' ) < current_time( 'mysql', true );

		return $data;
	}

	/**
	 * {@inheritDoc}
	 */
	protected function extra_properties( array $properties ): array {
		$properties['due_at']['description']      = __( 'Due date and time (ISO 8601; UTC unless an offset is given).', 'wp-leadflow-crm' );
		$properties['assigned_to']['description'] = __( 'Assignee. Defaults to the current user.', 'wp-leadflow-crm' );

		$properties['overdue'] = array(
			'description' => __( 'Open and past its due date.', 'wp-leadflow-crm' ),
			'type'        => 'boolean',
			'readonly'    => true,
			'context'     => array( 'view', 'edit' ),
		);

		return $properties;
	}
}
