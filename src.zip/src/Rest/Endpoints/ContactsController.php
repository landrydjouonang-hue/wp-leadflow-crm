<?php
/**
 * Contacts REST endpoints.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Rest\Endpoints;

use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\Models\Contact;
use LeadFlow\CRM\Rest\RecordController;

defined( 'ABSPATH' ) || exit;

/**
 * /leadflow-crm/v1/contacts[/{id}]
 *
 * A contact needs a first name, a last name or an email address.
 */
final class ContactsController extends RecordController {

	/**
	 * {@inheritDoc}
	 */
	protected function filters(): array {
		return parent::filters() + array( 'source' => 'source' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function sortable(): array {
		return array( 'id', 'first_name', 'last_name', 'email', 'created_at', 'updated_at' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function embed_fields(): array {
		return array( 'full_name', 'email', 'phone', 'company_id' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function add_output_fields( array $data, Model $item ): array {
		$data['full_name'] = $item instanceof Contact ? $item->full_name() : '';

		return $data;
	}

	/**
	 * {@inheritDoc}
	 */
	protected function extra_properties( array $properties ): array {
		$properties['full_name'] = array(
			'description' => __( 'First and last name (or the email address).', 'wp-leadflow-crm' ),
			'type'        => 'string',
			'readonly'    => true,
			'context'     => array( 'view', 'edit', 'embed' ),
		);

		return $properties;
	}
}
