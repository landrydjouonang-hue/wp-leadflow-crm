<?php
/**
 * Companies REST endpoints.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Rest\Endpoints;

use LeadFlow\CRM\Rest\RecordController;

defined( 'ABSPATH' ) || exit;

/**
 * /leadflow-crm/v1/companies[/{id}]
 *
 * Permanently deleting a company unlinks its contacts and leads and
 * removes the notes, tasks and activities that belong only to it.
 */
final class CompaniesController extends RecordController {

	/**
	 * {@inheritDoc}
	 */
	protected function filters(): array {
		return parent::filters() + array( 'country' => 'country' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function sortable(): array {
		return array( 'id', 'name', 'created_at', 'updated_at' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function embed_fields(): array {
		return array( 'name', 'email', 'website', 'status' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function extra_properties( array $properties ): array {
		$properties['name']['description']    = __( 'Company name.', 'wp-leadflow-crm' );
		$properties['country']['description'] = __( 'ISO 3166-1 alpha-2 country code, e.g. CM.', 'wp-leadflow-crm' );

		return $properties;
	}
}
