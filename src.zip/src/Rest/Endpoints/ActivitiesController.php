<?php
/**
 * Activities REST endpoints.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Rest\Endpoints;

use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Modules\Activities\ActivitiesModule;
use LeadFlow\CRM\Rest\RecordController;
use LeadFlow\CRM\Security\Permissions;

defined( 'ABSPATH' ) || exit;

/**
 * /leadflow-crm/v1/activities[/{id}]
 *
 * The activity timeline. Activities have no trash: DELETE removes them.
 *
 * - Read: permission to view the record the activity belongs to.
 * - Log (POST): a call, email or meeting on a company, contact or lead the
 *   user may edit (same rule as "Log activity" in the admin).
 * - Update / delete: only manually logged activities. The author may
 *   change their own entries while they can edit the record;
 *   `leadflow_manage_activities` allows changing anyone's. Automatic
 *   entries (stage changes, "Email sent", …) are history and read-only.
 */
final class ActivitiesController extends RecordController {

	/** Parent type => plural. */
	private const PARENTS = ActivitiesModule::PARENTS;

	/**
	 * {@inheritDoc}
	 */
	protected function owner_field(): string {
		return '';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function extra_readonly(): array {
		return array( 'user_id', 'meta' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function filters(): array {
		return array(
			'company_id' => 'company_id',
			'contact_id' => 'contact_id',
			'lead_id'    => 'lead_id',
			'type'       => 'type',
			'user_id'    => 'user_id',
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function sortable(): array {
		return array( 'id', 'occurred_at', 'created_at' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function default_orderby(): string {
		return 'occurred_at';
	}

	/**
	 * {@inheritDoc}
	 */
	protected function embed_fields(): array {
		return array( 'type', 'subject', 'occurred_at' );
	}

	/**
	 * Most specific record an activity (or request) points to.
	 *
	 * @param callable(string): mixed $get Column getter.
	 * @return array{0: string|null, 1: int}
	 */
	private static function parent_of( callable $get ): array {
		foreach ( array( 'lead', 'contact', 'company' ) as $type ) {
			$id = (int) $get( $type . '_id' );

			if ( $id > 0 ) {
				return array( $type, $id );
			}
		}

		return array( null, 0 );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function can_read( Model $record ): bool {
		list( $type ) = self::parent_of( static fn( string $c ) => $record->get( $c ) );

		return null !== $type && current_user_can( 'leadflow_view_' . self::PARENTS[ $type ] );
	}

	/**
	 * Whether the current user may change a (manual) activity.
	 *
	 * @param Model $record Activity.
	 * @return true|\WP_Error
	 */
	private function can_change( Model $record ): bool|\WP_Error {
		if ( ! empty( $record->get( 'meta', array() )['auto'] ) ) {
			return new \WP_Error( 'leadflow_crm_activity_locked', __( 'Automatic activity entries are history and cannot be changed.', 'wp-leadflow-crm' ), array( 'status' => 403 ) );
		}

		if ( current_user_can( Permissions::MANAGE_ACTIVITIES ) ) {
			return true;
		}

		list( $type, $id ) = self::parent_of( static fn( string $c ) => $record->get( $c ) );

		if ( null !== $type && (int) $record->get( 'user_id' ) === get_current_user_id() && current_user_can( 'leadflow_edit_' . $type, $id ) ) {
			return true;
		}

		return $this->forbidden( __( 'You can only change activities you logged yourself.', 'wp-leadflow-crm' ) );
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_items_permissions_check( $request ) {
		$access = $this->check_access();

		if ( true !== $access ) {
			return $access;
		}

		foreach ( self::PARENTS as $plural ) {
			if ( current_user_can( 'leadflow_view_' . $plural ) ) {
				return true;
			}
		}

		return $this->forbidden();
	}

	/**
	 * Hides activities of record types the user cannot view.
	 *
	 * {@inheritDoc}
	 */
	protected function collection_where( \WP_REST_Request $request ): array {
		$where = array();

		foreach ( self::PARENTS as $type => $plural ) {
			if ( ! current_user_can( 'leadflow_view_' . $plural ) ) {
				$where[ $type . '_id' ] = null;
			}
		}

		return $where;
	}

	/**
	 * {@inheritDoc}
	 */
	public function create_item_permissions_check( $request ) {
		$access = $this->check_access();

		if ( true !== $access ) {
			return $access;
		}

		list( $type, $id ) = self::parent_of( static fn( string $c ) => $request[ $c ] );

		if ( null === $type ) {
			return new \WP_Error(
				'rest_missing_callback_param',
				__( 'Link the activity to a company, contact or lead (company_id, contact_id or lead_id).', 'wp-leadflow-crm' ),
				array( 'status' => 400 )
			);
		}

		return current_user_can( 'leadflow_edit_' . $type, $id )
			? true
			: $this->forbidden( __( 'You are not allowed to log activities on this record.', 'wp-leadflow-crm' ) );
	}

	/**
	 * {@inheritDoc}
	 */
	public function update_item_permissions_check( $request ) {
		$access = $this->check_access();

		if ( true !== $access ) {
			return $access;
		}

		$record = $this->get_record( $request );

		if ( is_wp_error( $record ) ) {
			return $record;
		}

		if ( ! $this->can_read( $record ) ) {
			return $this->forbidden();
		}

		$allowed = $this->can_change( $record );

		if ( true !== $allowed ) {
			return $allowed;
		}

		// Moving an activity to another record needs edit permission there too.
		list( $type, $id ) = self::parent_of( static fn( string $c ) => $request->has_param( $c ) ? $request[ $c ] : $record->get( $c ) );

		return null !== $type && current_user_can( 'leadflow_edit_' . $type, $id ) ? true : $this->forbidden();
	}

	/**
	 * {@inheritDoc}
	 */
	public function delete_item_permissions_check( $request ) {
		$access = $this->check_access();

		if ( true !== $access ) {
			return $access;
		}

		$record = $this->get_record( $request );

		if ( is_wp_error( $record ) ) {
			return $record;
		}

		return $this->can_read( $record ) ? $this->can_change( $record ) : $this->forbidden();
	}

	/**
	 * Manual types only, and no future dates (schedule a follow-up instead).
	 *
	 * {@inheritDoc}
	 */
	protected function prepare_item_for_database( $request, ?Model $existing = null ) {
		$data = parent::prepare_item_for_database( $request, $existing );

		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$errors = array();

		if ( null === $existing && empty( $data['type'] ) ) {
			$errors['type'] = __( 'Please choose what kind of activity this was.', 'wp-leadflow-crm' );
		} elseif ( isset( $data['type'] ) && ! isset( ActivitiesModule::manual_types()[ $data['type'] ] ) ) {
			$errors['type'] = sprintf(
				/* translators: %s: Allowed types. */
				__( 'Only these types can be logged: %s.', 'wp-leadflow-crm' ),
				implode( ', ', array_keys( ActivitiesModule::manual_types() ) )
			);
		}

		if ( ! empty( $data['occurred_at'] ) && (string) $data['occurred_at'] > gmdate( 'Y-m-d H:i:s', time() + 5 * MINUTE_IN_SECONDS ) ) {
			$errors['occurred_at'] = __( 'An activity cannot be in the future. Schedule a follow-up instead.', 'wp-leadflow-crm' );
		}

		if ( null === $existing && '' === trim( (string) ( $data['subject'] ?? '' ) ) && isset( $data['type'] ) && ! isset( $errors['type'] ) ) {
			$data['subject'] = ActivitiesModule::manual_types()[ $data['type'] ];
		}

		if ( ! empty( $errors ) ) {
			return new \WP_Error(
				'rest_invalid_param',
				__( 'Some fields are invalid.', 'wp-leadflow-crm' ),
				array(
					'status' => 400,
					'params' => $errors,
				)
			);
		}

		return $data;
	}

	/**
	 * {@inheritDoc}
	 */
	protected function add_output_fields( array $data, Model $item ): array {
		$data['auto'] = ! empty( $item->get( 'meta', array() )['auto'] );

		return $data;
	}

	/**
	 * {@inheritDoc}
	 */
	protected function extra_properties( array $properties ): array {
		$properties['type']['description']        = __( 'Activity type. call, email and meeting can be logged; other types are written by the CRM.', 'wp-leadflow-crm' );
		$properties['occurred_at']['description'] = __( 'When it happened (ISO 8601). Defaults to now; cannot be in the future.', 'wp-leadflow-crm' );
		$properties['user_id']['description']     = __( 'Who logged it.', 'wp-leadflow-crm' );

		$properties['auto'] = array(
			'description' => __( 'Written automatically by the CRM (read-only history).', 'wp-leadflow-crm' ),
			'type'        => 'boolean',
			'readonly'    => true,
			'context'     => array( 'view', 'edit' ),
		);

		return $properties;
	}
}
