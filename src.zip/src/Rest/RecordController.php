<?php
/**
 * Base CRUD controller for CRM records.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Rest;

use LeadFlow\CRM\Data\DataException;
use LeadFlow\CRM\Data\Model;
use LeadFlow\CRM\Data\RecordNotFoundException;
use LeadFlow\CRM\Data\Repository;
use LeadFlow\CRM\Data\ValidationException;
use LeadFlow\CRM\Security\Capabilities;

defined( 'ABSPATH' ) || exit;

/**
 * `/{base}` and `/{base}/{id}` routes for one repository:
 *
 *   GET    /{base}        list (paging, search, sorting, filters)
 *   POST   /{base}        create                               → 201
 *   GET    /{base}/{id}   read
 *   PUT    /{base}/{id}   update (PATCH semantics: only sent fields change)
 *   DELETE /{base}/{id}   move to the trash; `?force=true` deletes permanently
 *
 * The JSON schema, argument validation and sanitization are derived from
 * the repository's column definitions, and every write still goes through
 * the repository (the same validation as the admin forms). Permission
 * callbacks run before any data is read or written:
 *
 * - authentication and `leadflow_access_crm` (401 when logged out, 403 otherwise);
 * - list/read `leadflow_view_{plural}`, create `leadflow_edit_{plural}`,
 *   update `leadflow_edit_{entity}` (meta, record id), delete
 *   `leadflow_delete_{entity}` (meta); trashed records need the delete permission;
 * - assigning a record to someone else needs `leadflow_edit_others_{plural}`.
 *
 * Subclasses configure the entity and may override any check.
 */
abstract class RecordController extends Controller {

	/** Columns never sent to clients. */
	protected const HIDDEN = array( 'deleted_by' );

	/** Columns clients cannot write. */
	protected const READONLY = array( 'id', 'created_at', 'updated_at', 'created_by', 'updated_by', 'deleted_at', 'deleted_by' );

	/** Largest page size. */
	public const MAX_PER_PAGE = 100;

	/**
	 * Constructor.
	 *
	 * @param Repository $repository Repository.
	 * @param string     $rest_base  Route base, e.g. "leads".
	 */
	public function __construct( protected Repository $repository, string $rest_base ) {
		$this->namespace = self::REST_NAMESPACE;
		$this->rest_base = $rest_base;
	}

	// ------------------------------------------------------------------
	// Entity configuration.
	// ------------------------------------------------------------------

	/**
	 * Entity key used in capabilities, e.g. "lead".
	 *
	 * @return string
	 */
	protected function entity(): string {
		return $this->repository->entity();
	}

	/**
	 * Plural key used in capabilities, e.g. "leads".
	 *
	 * @return string
	 */
	protected function plural(): string {
		return $this->rest_base;
	}

	/**
	 * Column holding the responsible user ('' when none).
	 *
	 * @return string
	 */
	protected function owner_field(): string {
		return 'owner_id';
	}

	/**
	 * Additional read-only columns.
	 *
	 * @return string[]
	 */
	protected function extra_readonly(): array {
		return array();
	}

	/**
	 * Additional hidden columns.
	 *
	 * @return string[]
	 */
	protected function extra_hidden(): array {
		return array();
	}

	/**
	 * Equality filters for the collection: query parameter => column.
	 *
	 * @return array<string, string>
	 */
	protected function filters(): array {
		$filters = array();

		foreach ( array( 'status', 'company_id', 'contact_id', 'lead_id' ) as $column ) {
			if ( isset( $this->repository->definitions()[ $column ] ) ) {
				$filters[ $column ] = $column;
			}
		}

		if ( '' !== $this->owner_field() ) {
			$filters[ $this->owner_field() ] = $this->owner_field();
		}

		return $filters;
	}

	/**
	 * Columns the collection can be sorted by.
	 *
	 * @return string[]
	 */
	protected function sortable(): array {
		return array( 'id', 'created_at', 'updated_at' );
	}

	/**
	 * Default sort column.
	 *
	 * @return string
	 */
	protected function default_orderby(): string {
		return 'created_at';
	}

	/**
	 * Columns shown in the `embed` context (besides id).
	 *
	 * @return string[]
	 */
	protected function embed_fields(): array {
		return array();
	}

	// ------------------------------------------------------------------
	// Routes.
	// ------------------------------------------------------------------

	/**
	 * {@inheritDoc}
	 */
	public function register_routes(): void {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_items' ),
					'permission_callback' => array( $this, 'get_items_permissions_check' ),
					'args'                => $this->get_collection_params(),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_item' ),
					'permission_callback' => array( $this, 'create_item_permissions_check' ),
					'args'                => $this->get_endpoint_args_for_item_schema( \WP_REST_Server::CREATABLE ),
				),
				'schema' => array( $this, 'get_public_item_schema' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/(?P<id>[\d]+)',
			array(
				'args'   => array(
					'id' => array(
						'description' => __( 'Unique identifier of the record.', 'wp-leadflow-crm' ),
						'type'        => 'integer',
						'minimum'     => 1,
					),
				),
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_item' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => array( 'context' => $this->get_context_param( array( 'default' => 'view' ) ) ),
				),
				array(
					'methods'             => \WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'update_item' ),
					'permission_callback' => array( $this, 'update_item_permissions_check' ),
					'args'                => $this->update_args(),
				),
				array(
					'methods'             => \WP_REST_Server::DELETABLE,
					'callback'            => array( $this, 'delete_item' ),
					'permission_callback' => array( $this, 'delete_item_permissions_check' ),
					'args'                => array(
						'force' => array(
							'type'        => 'boolean',
							'default'     => false,
							'description' => __( 'Delete permanently instead of moving to the trash.', 'wp-leadflow-crm' ),
						),
					),
				),
				'schema' => array( $this, 'get_public_item_schema' ),
			)
		);
	}

	/**
	 * Update arguments: schema fields plus `trashed` (restore / trash).
	 *
	 * @return array<string, array<string, mixed>>
	 */
	protected function update_args(): array {
		$args = $this->get_endpoint_args_for_item_schema( \WP_REST_Server::EDITABLE );

		if ( $this->repository->soft_deletes() ) {
			$args['trashed'] = array(
				'type'        => 'boolean',
				'description' => __( 'false restores the record from the trash; true moves it to the trash.', 'wp-leadflow-crm' ),
			);
		}

		return $args;
	}

	// ------------------------------------------------------------------
	// Permissions.
	// ------------------------------------------------------------------

	/**
	 * Authentication and CRM access.
	 *
	 * @return true|\WP_Error
	 */
	protected function check_access(): bool|\WP_Error {
		if ( ! is_user_logged_in() ) {
			return new \WP_Error( 'rest_not_logged_in', __( 'You must be authenticated to use the LeadFlow CRM API.', 'wp-leadflow-crm' ), array( 'status' => 401 ) );
		}

		return current_user_can( Capabilities::ACCESS_CRM ) ? true : $this->forbidden();
	}

	/**
	 * 401/403 error.
	 *
	 * @param string $message Optional message.
	 * @return \WP_Error
	 */
	protected function forbidden( string $message = '' ): \WP_Error {
		return new \WP_Error(
			'leadflow_crm_forbidden',
			'' !== $message ? $message : __( 'Sorry, you are not allowed to do that.', 'wp-leadflow-crm' ),
			array( 'status' => rest_authorization_required_code() )
		);
	}

	/**
	 * 404 error.
	 *
	 * @return \WP_Error
	 */
	protected function not_found(): \WP_Error {
		return new \WP_Error( 'leadflow_crm_not_found', __( 'Record not found.', 'wp-leadflow-crm' ), array( 'status' => 404 ) );
	}

	/**
	 * Loads the record of a request (trashed included).
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return Model|\WP_Error
	 */
	protected function get_record( \WP_REST_Request $request ): Model|\WP_Error {
		$record = $this->repository->find( (int) $request['id'], true );

		return null === $record ? $this->not_found() : $record;
	}

	/**
	 * Whether the current user may see a record.
	 *
	 * @param Model $record Record.
	 * @return bool
	 */
	protected function can_read( Model $record ): bool {
		if ( ! current_user_can( 'leadflow_view_' . $this->plural() ) ) {
			return false;
		}

		return ! $record->is_trashed() || current_user_can( 'leadflow_delete_' . $this->entity(), $record->id() );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return true|\WP_Error
	 */
	public function get_items_permissions_check( $request ) {
		$access = $this->check_access();

		if ( true !== $access ) {
			return $access;
		}

		if ( ! current_user_can( 'leadflow_view_' . $this->plural() ) ) {
			return $this->forbidden();
		}

		if ( 'exclude' !== ( $request['trashed'] ?? 'exclude' ) && ! current_user_can( 'leadflow_delete_' . $this->plural() ) ) {
			return $this->forbidden( __( 'You are not allowed to list trashed records.', 'wp-leadflow-crm' ) );
		}

		return true;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return true|\WP_Error
	 */
	public function get_item_permissions_check( $request ) {
		$access = $this->check_access();

		if ( true !== $access ) {
			return $access;
		}

		$record = $this->get_record( $request );

		if ( is_wp_error( $record ) ) {
			return $record;
		}

		if ( ! $this->can_read( $record ) ) {
			// Trashed records are hidden from users who cannot restore them.
			return $record->is_trashed() ? $this->not_found() : $this->forbidden();
		}

		return true;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return true|\WP_Error
	 */
	public function create_item_permissions_check( $request ) {
		$access = $this->check_access();

		if ( true !== $access ) {
			return $access;
		}

		if ( ! current_user_can( 'leadflow_edit_' . $this->plural() ) ) {
			return $this->forbidden( __( 'You are not allowed to create this kind of record.', 'wp-leadflow-crm' ) );
		}

		return $this->check_assignment( $request );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return true|\WP_Error
	 */
	public function update_item_permissions_check( $request ) {
		$access = $this->check_access();

		if ( true !== $access ) {
			return $access;
		}

		$record = $this->get_record( $request );

		if ( is_wp_error( $record ) ) {
			return $record;
		}

		if ( ! $this->can_read( $record ) ) {
			return $record->is_trashed() ? $this->not_found() : $this->forbidden();
		}

		if ( ! current_user_can( 'leadflow_edit_' . $this->entity(), $record->id() ) ) {
			return $this->forbidden( __( 'You are not allowed to edit this record.', 'wp-leadflow-crm' ) );
		}

		if ( $request->has_param( 'trashed' ) && ! current_user_can( 'leadflow_delete_' . $this->entity(), $record->id() ) ) {
			return $this->forbidden( __( 'You are not allowed to trash or restore this record.', 'wp-leadflow-crm' ) );
		}

		return $this->check_assignment( $request, $record );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return true|\WP_Error
	 */
	public function delete_item_permissions_check( $request ) {
		$access = $this->check_access();

		if ( true !== $access ) {
			return $access;
		}

		$record = $this->get_record( $request );

		if ( is_wp_error( $record ) ) {
			return $record;
		}

		if ( ! current_user_can( 'leadflow_delete_' . $this->entity(), $record->id() ) ) {
			return $record->is_trashed() ? $this->not_found() : $this->forbidden( __( 'You are not allowed to delete this record.', 'wp-leadflow-crm' ) );
		}

		return true;
	}

	/**
	 * Assigning a record to another user needs the "others" capability.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @param Model|null       $record  Current record (update).
	 * @return true|\WP_Error
	 */
	protected function check_assignment( \WP_REST_Request $request, ?Model $record = null ): bool|\WP_Error {
		$field = $this->owner_field();

		if ( '' === $field || ! $request->has_param( $field ) ) {
			return true;
		}

		$owner   = (int) $request[ $field ];
		$current = null === $record ? 0 : (int) $record->get( $field, 0 );

		if ( $owner === $current || $owner === get_current_user_id() ) {
			return true;
		}

		return current_user_can( 'leadflow_edit_others_' . $this->plural() )
			? true
			: $this->forbidden( __( 'You are not allowed to assign records to other users.', 'wp-leadflow-crm' ) );
	}

	// ------------------------------------------------------------------
	// Handlers.
	// ------------------------------------------------------------------

	/**
	 * Extra query arguments for the collection (subclass restrictions).
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return array<string, mixed> Where conditions.
	 */
	protected function collection_where( \WP_REST_Request $request ): array {
		return array();
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function get_items( $request ) {
		$where = $this->collection_where( $request );

		foreach ( $this->filters() as $param => $column ) {
			if ( null !== $request[ $param ] && '' !== $request[ $param ] ) {
				$where[ $column ] = $request[ $param ];
			}
		}

		if ( ! empty( $request['modified_after'] ) ) {
			$where['updated_at'] = array(
				'op'    => '>',
				'value' => gmdate( 'Y-m-d H:i:s', (int) rest_parse_date( (string) $request['modified_after'] ) ),
			);
		}

		$args = array(
			'where'    => $where,
			'search'   => (string) $request['search'],
			'orderby'  => (string) $request['orderby'],
			'order'    => (string) $request['order'],
			'per_page' => (int) $request['per_page'],
			'page'     => (int) $request['page'],
		);

		if ( $this->repository->soft_deletes() ) {
			$args['trashed'] = 'include' === $request['trashed'] ? 'with' : ( 'only' === $request['trashed'] ? 'only' : 'without' );
		}

		try {
			$result = $this->repository->paginate( $args );
		} catch ( \InvalidArgumentException | DataException $e ) {
			return new \WP_Error( 'rest_invalid_param', __( 'Invalid query.', 'wp-leadflow-crm' ), array( 'status' => 400 ) );
		}

		$items = array();

		foreach ( $result['items'] as $record ) {
			if ( $this->can_read( $record ) ) {
				$items[] = $this->prepare_response_for_collection( $this->prepare_item_for_response( $record, $request ) );
			}
		}

		$response = rest_ensure_response( $items );
		$response->header( 'X-WP-Total', (string) $result['total'] );
		$response->header( 'X-WP-TotalPages', (string) $result['pages'] );

		$base = add_query_arg( urlencode_deep( $request->get_query_params() ), rest_url( $this->namespace . '/' . $this->rest_base ) );

		if ( $result['page'] > 1 ) {
			$response->link_header( 'prev', add_query_arg( 'page', $result['page'] - 1, $base ) );
		}

		if ( $result['page'] < $result['pages'] ) {
			$response->link_header( 'next', add_query_arg( 'page', $result['page'] + 1, $base ) );
		}

		return $response;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function get_item( $request ) {
		$record = $this->get_record( $request );

		return is_wp_error( $record ) ? $record : $this->prepare_item_for_response( $record, $request );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function create_item( $request ) {
		if ( ! empty( $request['id'] ) ) {
			return new \WP_Error( 'rest_exists', __( 'Cannot create an existing record; use PUT to update it.', 'wp-leadflow-crm' ), array( 'status' => 400 ) );
		}

		$data = $this->prepare_item_for_database( $request );

		if ( is_wp_error( $data ) ) {
			return $data;
		}

		try {
			$record = $this->repository->create( $data );
		} catch ( ValidationException $e ) {
			return $this->validation_error( $e );
		} catch ( DataException $e ) {
			return $this->server_error();
		}

		$this->after_save( $record, $request, true );

		$request->set_param( 'context', 'edit' );

		$response = $this->prepare_item_for_response( $record, $request );
		$response->set_status( 201 );
		$response->header( 'Location', rest_url( sprintf( '%s/%s/%d', $this->namespace, $this->rest_base, $record->id() ) ) );

		return $response;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function update_item( $request ) {
		$record = $this->get_record( $request );

		if ( is_wp_error( $record ) ) {
			return $record;
		}

		$data = $this->prepare_item_for_database( $request, $record );

		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$restore = $request->has_param( 'trashed' ) && false === (bool) $request['trashed'];
		$trash   = $request->has_param( 'trashed' ) && true === (bool) $request['trashed'];

		if ( $record->is_trashed() && ! $restore && ! empty( $data ) ) {
			return new \WP_Error( 'leadflow_crm_trashed', __( 'This record is in the trash. Restore it first ("trashed": false).', 'wp-leadflow-crm' ), array( 'status' => 409 ) );
		}

		try {
			if ( $restore && $record->is_trashed() ) {
				$this->repository->restore( $record->id() );
			}

			if ( ! empty( $data ) ) {
				$record = $this->repository->update( $record->id(), $data );
			}

			if ( $trash && ! $record->is_trashed() ) {
				$this->repository->trash( $record->id() );
			}
		} catch ( ValidationException $e ) {
			return $this->validation_error( $e );
		} catch ( RecordNotFoundException $e ) {
			return $this->not_found();
		} catch ( DataException $e ) {
			return $this->server_error();
		}

		$record = $this->repository->find( $record->id(), true );

		if ( null === $record ) {
			return $this->not_found();
		}

		$this->after_save( $record, $request, false );

		$request->set_param( 'context', 'edit' );

		return $this->prepare_item_for_response( $record, $request );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function delete_item( $request ) {
		$record = $this->get_record( $request );

		if ( is_wp_error( $record ) ) {
			return $record;
		}

		$request->set_param( 'context', 'edit' );

		$force    = (bool) $request['force'] || ! $this->repository->soft_deletes();
		$previous = $this->prepare_item_for_response( $record, $request );

		if ( ! $force ) {
			if ( $record->is_trashed() ) {
				return new \WP_Error( 'rest_already_trashed', __( 'The record is already in the trash. Use force=true to delete it permanently.', 'wp-leadflow-crm' ), array( 'status' => 410 ) );
			}

			$this->repository->trash( $record->id() );

			return $this->prepare_item_for_response( $this->repository->find( $record->id(), true ), $request );
		}

		try {
			$this->repository->delete( $record->id() );
		} catch ( DataException $e ) {
			return $this->server_error();
		}

		return rest_ensure_response(
			array(
				'deleted'  => true,
				'previous' => $previous->get_data(),
			)
		);
	}

	/**
	 * Runs after a successful create or update.
	 *
	 * @param Model            $record  Saved record.
	 * @param \WP_REST_Request $request Request.
	 * @param bool             $created Whether it was created.
	 * @return void
	 */
	protected function after_save( Model $record, \WP_REST_Request $request, bool $created ): void {
		/**
		 * Fires after a CRM record was created or updated through the REST API.
		 *
		 * @param Model            $record  Record.
		 * @param \WP_REST_Request $request Request.
		 * @param bool             $created Whether it was created.
		 */
		do_action( 'leadflow_crm_rest_insert_' . $this->entity(), $record, $request, $created );
	}

	// ------------------------------------------------------------------
	// Data mapping.
	// ------------------------------------------------------------------

	/**
	 * Request → repository data (only sent, writable fields).
	 *
	 * @param \WP_REST_Request $request  Request.
	 * @param Model|null       $existing Current record on update.
	 * @return array<string, mixed>|\WP_Error
	 */
	protected function prepare_item_for_database( $request, ?Model $existing = null ) {
		$data     = array();
		$readonly = $this->readonly_fields();

		foreach ( $this->repository->writable() as $column => $def ) {
			if ( in_array( $column, $readonly, true ) || ! $request->has_param( $column ) ) {
				continue;
			}

			$value = $request[ $column ];

			if ( 'datetime' === $def['type'] && is_string( $value ) && '' !== $value ) {
				$timestamp = rest_parse_date( $value );

				if ( false === $timestamp ) {
					return new \WP_Error(
						'rest_invalid_param',
						__( 'Some fields are invalid.', 'wp-leadflow-crm' ),
						array(
							'status' => 400,
							'params' => array( $column => __( 'Please use an ISO 8601 date and time.', 'wp-leadflow-crm' ) ),
						)
					);
				}

				$value = gmdate( 'Y-m-d H:i:s', (int) $timestamp );
			}

			$data[ $column ] = $value;
		}

		return $data;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param Model            $item    Record.
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public function prepare_item_for_response( $item, $request ) {
		$definitions = $this->repository->definitions();
		$hidden      = array_merge( static::HIDDEN, $this->extra_hidden() );
		$data        = array();

		foreach ( $definitions as $column => $def ) {
			if ( in_array( $column, $hidden, true ) ) {
				continue;
			}

			$data[ $column ] = self::output( $item->get( $column ), (string) $def['type'] );
		}

		if ( $this->repository->soft_deletes() ) {
			$data['trashed'] = $item->is_trashed();
		}

		$data = $this->add_output_fields( $data, $item );

		$context  = ! empty( $request['context'] ) ? (string) $request['context'] : 'view';
		$data     = $this->filter_response_by_context( $data, $context );
		$response = rest_ensure_response( $data );

		$response->add_links( $this->prepare_links( $item ) );

		/**
		 * Filters a record's REST response.
		 *
		 * @param \WP_REST_Response $response Response.
		 * @param Model             $item     Record.
		 * @param \WP_REST_Request  $request  Request.
		 */
		return apply_filters( 'leadflow_crm_rest_prepare_' . $this->entity(), $response, $item, $request );
	}

	/**
	 * Computed output fields (subclasses).
	 *
	 * @param array<string, mixed> $data Output.
	 * @param Model                $item Record.
	 * @return array<string, mixed>
	 */
	protected function add_output_fields( array $data, Model $item ): array {
		return $data;
	}

	/**
	 * Stored value → JSON value.
	 *
	 * @param mixed  $value Value.
	 * @param string $type  Column type.
	 * @return mixed
	 */
	protected static function output( mixed $value, string $type ): mixed {
		if ( null === $value ) {
			return null;
		}

		return match ( $type ) {
			'datetime' => '' === $value ? null : str_replace( ' ', 'T', (string) $value ) . 'Z',
			'int', 'user', 'relation' => (int) $value,
			'decimal' => (float) $value,
			'bool' => (bool) $value,
			'json' => is_array( $value ) ? $value : array(),
			default => (string) $value,
		};
	}

	/**
	 * Links: self, collection, related records and users (embeddable).
	 *
	 * @param Model $item Record.
	 * @return array<string, array<int|string, mixed>>
	 */
	protected function prepare_links( $item ): array {
		$links = array(
			'self'       => array( 'href' => rest_url( sprintf( '%s/%s/%d', $this->namespace, $this->rest_base, $item->id() ) ) ),
			'collection' => array( 'href' => rest_url( sprintf( '%s/%s', $this->namespace, $this->rest_base ) ) ),
		);

		// Related CRM records (embeddable with ?_embed).
		$related = array(
			'company_id' => array( 'companies', 'leadflow:company' ),
			'contact_id' => array( 'contacts', 'leadflow:contact' ),
			'lead_id'    => array( 'leads', 'leadflow:lead' ),
		);

		foreach ( $related as $column => list( $base, $rel ) ) {
			$id = (int) $item->get( $column, 0 );

			if ( $id > 0 && $base !== $this->rest_base ) {
				$links[ $rel ] = array(
					'href'       => rest_url( sprintf( '%s/%s/%d', $this->namespace, $base, $id ) ),
					'embeddable' => true,
				);
			}
		}

		// Responsible users.
		foreach ( $this->repository->definitions() as $column => $def ) {
			$user = (int) $item->get( $column, 0 );

			if ( 'user' === $def['type'] && $user > 0 && ! in_array( $column, array( 'created_by', 'updated_by', 'deleted_by' ), true ) ) {
				$links['leadflow:user'][] = array(
					'href'  => rest_url( 'wp/v2/users/' . $user ),
					'field' => $column,
				);
			}
		}

		return $links;
	}

	/**
	 * Read-only columns.
	 *
	 * @return string[]
	 */
	protected function readonly_fields(): array {
		return array_merge( static::READONLY, $this->extra_readonly() );
	}

	// ------------------------------------------------------------------
	// Schema.
	// ------------------------------------------------------------------

	/**
	 * {@inheritDoc}
	 *
	 * @return array<string, mixed>
	 */
	public function get_item_schema() {
		if ( $this->schema ) {
			return $this->add_additional_fields_schema( $this->schema );
		}

		$readonly   = $this->readonly_fields();
		$hidden     = array_merge( static::HIDDEN, $this->extra_hidden() );
		$writable   = $this->repository->writable();
		$embed      = array_merge( array( 'id' ), $this->embed_fields() );
		$properties = array();

		foreach ( $this->repository->definitions() as $column => $def ) {
			if ( in_array( $column, $hidden, true ) ) {
				continue;
			}

			$property = self::property( $column, $def );

			$property['context'] = in_array( $column, $embed, true ) ? array( 'view', 'edit', 'embed' ) : array( 'view', 'edit' );

			if ( in_array( $column, $readonly, true ) || ! isset( $writable[ $column ] ) ) {
				$property['readonly'] = true;
				unset( $property['required'] );
			}

			$properties[ $column ] = $property;
		}

		if ( $this->repository->soft_deletes() ) {
			$properties['trashed'] = array(
				'description' => __( 'Whether the record is in the trash.', 'wp-leadflow-crm' ),
				'type'        => 'boolean',
				'readonly'    => true,
				'context'     => array( 'view', 'edit' ),
			);
		}

		$this->schema = array(
			'$schema'    => 'http://json-schema.org/draft-04/schema#',
			'title'      => 'leadflow-' . $this->entity(),
			'type'       => 'object',
			'properties' => $this->extra_properties( $properties ),
		);

		return $this->add_additional_fields_schema( $this->schema );
	}

	/**
	 * Adjusts schema properties (subclasses).
	 *
	 * @param array<string, array<string, mixed>> $properties Properties.
	 * @return array<string, array<string, mixed>>
	 */
	protected function extra_properties( array $properties ): array {
		return $properties;
	}

	/**
	 * JSON schema of one column.
	 *
	 * @param string               $column Column.
	 * @param array<string, mixed> $def    Repository definition.
	 * @return array<string, mixed>
	 */
	protected static function property( string $column, array $def ): array {
		$nullable = ! empty( $def['nullable'] );
		$property = array( 'description' => ucfirst( str_replace( '_', ' ', $column ) ) . '.' );

		switch ( $def['type'] ) {
			case 'int':
			case 'user':
			case 'relation':
				$property['type'] = 'integer';
				break;
			case 'decimal':
				$property['type'] = 'number';
				break;
			case 'bool':
				$property['type'] = 'boolean';
				break;
			case 'json':
				$property['type'] = 'object';
				break;
			case 'enum':
				$property['type'] = 'string';
				$property['enum'] = array_values( (array) $def['values'] );
				break;
			case 'datetime':
				$property['type']   = 'string';
				$property['format'] = 'date-time';
				break;
			case 'date':
				$property['type']    = 'string';
				$property['pattern'] = '^(\d{4}-\d{2}-\d{2})?$';
				break;
			default:
				$property['type'] = 'string';

				if ( isset( $def['max'] ) ) {
					$property['maxLength'] = (int) $def['max'];
				}
		}

		foreach ( array( 'min' => 'minimum', 'max' => 'maximum' ) as $key => $schema_key ) {
			if ( isset( $def[ $key ] ) && in_array( $property['type'], array( 'integer', 'number' ), true ) ) {
				$property[ $schema_key ] = $def[ $key ];
			}
		}

		if ( $nullable ) {
			$property['type'] = array( $property['type'], 'null' );

			if ( isset( $property['enum'] ) ) {
				$property['enum'][] = null;
			}
		}

		if ( ! empty( $def['required'] ) ) {
			$property['required'] = true;
		}

		return $property;
	}

	/**
	 * {@inheritDoc}
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public function get_collection_params() {
		$params = parent::get_collection_params();

		$params['per_page']['maximum'] = self::MAX_PER_PAGE;
		$params['context']['default']  = 'view';

		$params['orderby'] = array(
			'description' => __( 'Sort collection by attribute.', 'wp-leadflow-crm' ),
			'type'        => 'string',
			'default'     => $this->default_orderby(),
			'enum'        => $this->sortable(),
		);

		$params['order'] = array(
			'description' => __( 'Order sort attribute ascending or descending.', 'wp-leadflow-crm' ),
			'type'        => 'string',
			'default'     => 'desc',
			'enum'        => array( 'asc', 'desc' ),
		);

		$params['modified_after'] = array(
			'description' => __( 'Only records changed after this date and time (ISO 8601), for synchronization.', 'wp-leadflow-crm' ),
			'type'        => 'string',
			'format'      => 'date-time',
		);

		if ( $this->repository->soft_deletes() ) {
			$params['trashed'] = array(
				'description' => __( 'Trashed records: exclude (default), include or only. Needs the delete permission.', 'wp-leadflow-crm' ),
				'type'        => 'string',
				'default'     => 'exclude',
				'enum'        => array( 'exclude', 'include', 'only' ),
			);
		}

		$definitions = $this->repository->definitions();

		foreach ( $this->filters() as $param => $column ) {
			$property = self::property( $column, $definitions[ $column ] ?? array( 'type' => 'string' ) );

			unset( $property['required'] );

			if ( is_array( $property['type'] ) ) {
				$property['type'] = $property['type'][0];
			}

			if ( isset( $property['enum'] ) ) {
				$property['enum'] = array_values( array_filter( $property['enum'], static fn( $v ): bool => null !== $v ) );
			}

			/* translators: %s: Field name. */
			$property['description'] = sprintf( __( 'Limit results to this %s.', 'wp-leadflow-crm' ), str_replace( '_', ' ', $param ) );
			$params[ $param ]        = $property;
		}

		return $params;
	}

	// ------------------------------------------------------------------
	// Errors.
	// ------------------------------------------------------------------

	/**
	 * 400 with field errors.
	 *
	 * @param ValidationException $e Exception.
	 * @return \WP_Error
	 */
	protected function validation_error( ValidationException $e ): \WP_Error {
		return new \WP_Error(
			'rest_invalid_param',
			__( 'Some fields are invalid.', 'wp-leadflow-crm' ),
			array(
				'status' => 400,
				'params' => $e->errors(),
			)
		);
	}

	/**
	 * 500 without internals.
	 *
	 * @return \WP_Error
	 */
	protected function server_error(): \WP_Error {
		\LeadFlow\CRM\Support\Logger::error( 'REST write failed', array( 'entity' => $this->entity() ) );

		return new \WP_Error( 'leadflow_crm_server_error', __( 'The record could not be saved. Please try again.', 'wp-leadflow-crm' ), array( 'status' => 500 ) );
	}
}
