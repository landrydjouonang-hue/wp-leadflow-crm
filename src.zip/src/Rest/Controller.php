<?php
/**
 * Base REST controller.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Rest;

defined( 'ABSPATH' ) || exit;

/**
 * Shared namespace and permission helpers for all plugin endpoints.
 *
 * Requests from the admin UI authenticate with the `wp_rest` nonce sent
 * in the X-WP-Nonce header (see Admin\Assets); external clients use
 * WordPress Application Passwords (see docs/API.md).
 */
abstract class Controller extends \WP_REST_Controller {

	/** REST namespace. */
	public const REST_NAMESPACE = 'leadflow-crm/v1';

	/**
	 * Builds a permission callback requiring a capability.
	 *
	 * @param string $capability Capability.
	 * @return callable(\WP_REST_Request): (true|\WP_Error)
	 */
	protected function require_capability( string $capability ): callable {
		return static function () use ( $capability ) {
			if ( current_user_can( $capability ) ) {
				return true;
			}

			return new \WP_Error(
				'leadflow_crm_forbidden',
				__( 'Sorry, you are not allowed to do that.', 'wp-leadflow-crm' ),
				array( 'status' => rest_authorization_required_code() )
			);
		};
	}
}
