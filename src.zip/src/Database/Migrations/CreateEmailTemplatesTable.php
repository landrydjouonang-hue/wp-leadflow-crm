<?php
/**
 * Creates and seeds the email templates table.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Database\Migrations;

use LeadFlow\CRM\Database\AbstractMigration;
use LeadFlow\CRM\Database\Schema;
use LeadFlow\CRM\Database\Table;

defined( 'ABSPATH' ) || exit;

/**
 * Reusable email templates with {{placeholders}}.
 */
final class CreateEmailTemplatesTable extends AbstractMigration {

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return '2026_09_21_000010_create_email_templates_table';
	}

	/**
	 * {@inheritDoc}
	 */
	public function up(): void {
		$this->create_table(
			Schema::EMAIL_TEMPLATES,
			"id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
name varchar(191) NOT NULL,
subject varchar(255) NOT NULL,
body longtext NOT NULL,
status varchar(20) NOT NULL DEFAULT 'active',
" . Schema::audit_columns() . 'PRIMARY KEY  (id),
KEY name (name),
KEY status (status),
KEY deleted_at (deleted_at)'
		);

		$this->seed();
	}

	/**
	 * Starter templates, only when the table is empty.
	 *
	 * @return void
	 */
	private function seed(): void {
		global $wpdb;

		$table = Table::name( Schema::EMAIL_TEMPLATES );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Seeding.
		if ( (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i', $table ) ) > 0 ) {
			return;
		}

		$now       = current_time( 'mysql', true );
		$templates = array(
			array(
				__( 'Introduction', 'wp-leadflow-crm' ),
				__( 'Nice to meet you, {{first_name|there}}', 'wp-leadflow-crm' ),
				__( "<p>Hi {{first_name|there}},</p>\n<p>Thank you for your interest in {{business_name}}. I would love to learn more about {{company|your team}} and how we can help.</p>\n<p>Would you have 20 minutes this week for a short call?</p>\n<p>Best regards,<br>{{sender_name}}</p>", 'wp-leadflow-crm' ),
			),
			array(
				__( 'Follow-up after meeting', 'wp-leadflow-crm' ),
				__( 'Next steps for {{lead_title}}', 'wp-leadflow-crm' ),
				__( "<p>Hi {{first_name|there}},</p>\n<p>Thanks again for your time today. As discussed, here are the next steps for <strong>{{lead_title}}</strong>:</p>\n<ul>\n<li>…</li>\n</ul>\n<p>Talk soon,<br>{{sender_name}}</p>", 'wp-leadflow-crm' ),
			),
			array(
				__( 'Proposal sent', 'wp-leadflow-crm' ),
				__( 'Your proposal from {{business_name}}', 'wp-leadflow-crm' ),
				__( "<p>Hi {{first_name|there}},</p>\n<p>Please find our proposal for {{lead_title}} ({{lead_value}}).</p>\n<p>I am happy to walk you through it — just reply to this email or call me.</p>\n<p>Kind regards,<br>{{sender_name}}</p>", 'wp-leadflow-crm' ),
			),
		);

		foreach ( $templates as list( $name, $subject, $body ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Seeding.
			$wpdb->insert(
				$table,
				array(
					'name'       => $name,
					'subject'    => $subject,
					'body'       => $body,
					'status'     => 'active',
					'created_at' => $now,
					'updated_at' => $now,
				),
				array( '%s', '%s', '%s', '%s', '%s', '%s' )
			);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public function down(): void {
		$this->drop_table( Schema::EMAIL_TEMPLATES );
	}
}
