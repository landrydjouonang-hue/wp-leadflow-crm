<?php
/**
 * Creates the notes table.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Database\Migrations;

use LeadFlow\CRM\Database\AbstractMigration;
use LeadFlow\CRM\Database\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Free-form notes written by users on companies, contacts or leads.
 */
final class CreateNotesTable extends AbstractMigration {

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return '2026_09_19_000005_create_notes_table';
	}

	/**
	 * {@inheritDoc}
	 */
	public function up(): void {
		$this->create_table(
			Schema::NOTES,
			'id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
' . Schema::parent_columns() . 'content longtext NOT NULL,
is_pinned tinyint(1) unsigned NOT NULL DEFAULT 0,
' . Schema::audit_columns() . 'PRIMARY KEY  (id),
KEY company_id (company_id),
KEY contact_id (contact_id),
KEY lead_id (lead_id),
KEY created_by (created_by),
KEY created_at (created_at),
KEY deleted_at (deleted_at)'
		);

		$this->add_parent_keys( Schema::NOTES );
	}

	/**
	 * {@inheritDoc}
	 */
	public function down(): void {
		$this->drop_table( Schema::NOTES );
	}
}
