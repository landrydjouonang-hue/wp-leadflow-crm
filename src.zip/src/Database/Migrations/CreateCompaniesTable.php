<?php
/**
 * Creates the companies table.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Database\Migrations;

use LeadFlow\CRM\Database\AbstractMigration;
use LeadFlow\CRM\Database\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Organizations the business works with.
 */
final class CreateCompaniesTable extends AbstractMigration {

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return '2026_09_19_000001_create_companies_table';
	}

	/**
	 * {@inheritDoc}
	 */
	public function up(): void {
		$this->create_table(
			Schema::COMPANIES,
			"id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
name varchar(191) NOT NULL,
industry varchar(100) NOT NULL DEFAULT '',
website varchar(255) NOT NULL DEFAULT '',
email varchar(100) NOT NULL DEFAULT '',
phone varchar(50) NOT NULL DEFAULT '',
address_line_1 varchar(255) NOT NULL DEFAULT '',
address_line_2 varchar(255) NOT NULL DEFAULT '',
city varchar(100) NOT NULL DEFAULT '',
state varchar(100) NOT NULL DEFAULT '',
postal_code varchar(20) NOT NULL DEFAULT '',
country char(2) NOT NULL DEFAULT '',
description text NULL,
status varchar(20) NOT NULL DEFAULT 'prospect',
owner_id bigint(20) unsigned NULL DEFAULT NULL,
" . Schema::audit_columns() . 'PRIMARY KEY  (id),
KEY name (name),
KEY status (status),
KEY owner_id (owner_id),
KEY email (email),
KEY created_at (created_at),
KEY deleted_at (deleted_at)'
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function down(): void {
		$this->drop_table( Schema::COMPANIES );
	}
}
