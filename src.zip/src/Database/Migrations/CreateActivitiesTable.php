<?php
/**
 * Creates the activities table.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Database\Migrations;

use LeadFlow\CRM\Database\AbstractMigration;
use LeadFlow\CRM\Database\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Append-only timeline of what happened (calls, emails, changes, ...).
 * No soft deletes: the history is not edited, only purged with its parent.
 */
final class CreateActivitiesTable extends AbstractMigration {

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return '2026_09_19_000004_create_activities_table';
	}

	/**
	 * {@inheritDoc}
	 */
	public function up(): void {
		$this->create_table(
			Schema::ACTIVITIES,
			'id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
' . Schema::parent_columns() . "type varchar(30) NOT NULL,
subject varchar(255) NOT NULL DEFAULT '',
description text NULL,
meta longtext NULL,
user_id bigint(20) unsigned NULL DEFAULT NULL,
occurred_at datetime NOT NULL,
" . Schema::audit_columns( false ) . 'PRIMARY KEY  (id),
KEY company_timeline (company_id,occurred_at),
KEY contact_timeline (contact_id,occurred_at),
KEY lead_timeline (lead_id,occurred_at),
KEY type (type),
KEY user_id (user_id),
KEY occurred_at (occurred_at)'
		);

		$this->add_parent_keys( Schema::ACTIVITIES );
	}

	/**
	 * {@inheritDoc}
	 */
	public function down(): void {
		$this->drop_table( Schema::ACTIVITIES );
	}
}
