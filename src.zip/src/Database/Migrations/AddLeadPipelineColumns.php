<?php
/**
 * Adds contact details and board position to leads.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Database\Migrations;

use LeadFlow\CRM\Database\AbstractMigration;
use LeadFlow\CRM\Database\Schema;
use LeadFlow\CRM\Database\Table;

defined( 'ABSPATH' ) || exit;

/**
 * leads.email, leads.phone (lead-level contact details) and
 * leads.position (order of cards within a pipeline column).
 */
final class AddLeadPipelineColumns extends AbstractMigration {

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return '2026_09_21_000009_add_lead_pipeline_columns';
	}

	/**
	 * {@inheritDoc}
	 */
	public function up(): void {
		global $wpdb;

		$this->add_column( Schema::LEADS, 'email', "varchar(100) NOT NULL DEFAULT ''", 'contact_id' );
		$this->add_column( Schema::LEADS, 'phone', "varchar(50) NOT NULL DEFAULT ''", 'email' );
		$this->add_column( Schema::LEADS, 'position', 'int(11) NOT NULL DEFAULT 0', 'stage' );
		$this->add_index( Schema::LEADS, 'stage_position', array( 'stage', 'position' ) );

		// Leads on a stage that does not exist are moved to the first stage of their status.
		$leads  = Table::name( Schema::LEADS );
		$stages = Table::name( Schema::PIPELINE_STAGES );

		foreach ( array( 'open', 'won', 'lost' ) as $type ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Data migration.
			$target = $wpdb->get_var( $wpdb->prepare( 'SELECT slug FROM %i WHERE type = %s ORDER BY position ASC LIMIT 1', $stages, $type ) );

			if ( null === $target ) {
				continue;
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Data migration.
			$wpdb->query( $wpdb->prepare( 'UPDATE %i SET stage = %s WHERE status = %s AND stage NOT IN (SELECT slug FROM %i)', $leads, $target, $type, $stages ) );
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public function down(): void {
		global $wpdb;

		$leads = Table::name( Schema::LEADS );

		foreach ( array( 'email', 'phone', 'position' ) as $column ) {
			if ( Table::column_exists( $leads, $column ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange -- Rollback.
				$wpdb->query( $wpdb->prepare( 'ALTER TABLE %i DROP COLUMN %i', $leads, $column ) );
			}
		}
	}
}
