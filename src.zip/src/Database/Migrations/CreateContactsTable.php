<?php
/**
 * Creates the contacts table.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Database\Migrations;

use LeadFlow\CRM\Database\AbstractMigration;
use LeadFlow\CRM\Database\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * People, optionally belonging to a company.
 */
final class CreateContactsTable extends AbstractMigration {

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return '2026_09_19_000002_create_contacts_table';
	}

	/**
	 * {@inheritDoc}
	 */
	public function up(): void {
		$this->create_table(
			Schema::CONTACTS,
			"id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
company_id bigint(20) unsigned NULL DEFAULT NULL,
first_name varchar(100) NOT NULL DEFAULT '',
last_name varchar(100) NOT NULL DEFAULT '',
email varchar(100) NOT NULL DEFAULT '',
phone varchar(50) NOT NULL DEFAULT '',
mobile varchar(50) NOT NULL DEFAULT '',
job_title varchar(150) NOT NULL DEFAULT '',
address_line_1 varchar(255) NOT NULL DEFAULT '',
address_line_2 varchar(255) NOT NULL DEFAULT '',
city varchar(100) NOT NULL DEFAULT '',
state varchar(100) NOT NULL DEFAULT '',
postal_code varchar(20) NOT NULL DEFAULT '',
country char(2) NOT NULL DEFAULT '',
source varchar(50) NOT NULL DEFAULT '',
status varchar(20) NOT NULL DEFAULT 'active',
owner_id bigint(20) unsigned NULL DEFAULT NULL,
" . Schema::audit_columns() . 'PRIMARY KEY  (id),
KEY company_id (company_id),
KEY email (email),
KEY full_name (last_name(80),first_name(80)),
KEY status (status),
KEY owner_id (owner_id),
KEY created_at (created_at),
KEY deleted_at (deleted_at)'
		);

		$this->add_foreign_key( Schema::CONTACTS, 'company_id', Schema::COMPANIES, 'SET NULL' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function down(): void {
		$this->drop_table( Schema::CONTACTS );
	}
}
