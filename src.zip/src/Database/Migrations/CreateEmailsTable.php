<?php
/**
 * Creates the emails table.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Database\Migrations;

use LeadFlow\CRM\Database\AbstractMigration;
use LeadFlow\CRM\Database\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Log of emails sent from the CRM (successful and failed attempts), linked
 * to the company, contact and/or lead they were sent from.
 */
final class CreateEmailsTable extends AbstractMigration {

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return '2026_09_22_000011_create_emails_table';
	}

	/**
	 * {@inheritDoc}
	 */
	public function up(): void {
		$this->create_table(
			Schema::EMAILS,
			"id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
" . Schema::parent_columns() . "template_id bigint(20) unsigned NULL DEFAULT NULL,
to_email varchar(191) NOT NULL,
to_name varchar(191) NOT NULL DEFAULT '',
cc text NULL,
bcc text NULL,
from_name varchar(191) NOT NULL DEFAULT '',
from_email varchar(191) NOT NULL DEFAULT '',
reply_to varchar(191) NOT NULL DEFAULT '',
subject varchar(255) NOT NULL,
body longtext NOT NULL,
status varchar(20) NOT NULL DEFAULT 'sent',
error text NULL,
meta longtext NULL,
sent_by bigint(20) unsigned NULL DEFAULT NULL,
sent_at datetime NULL DEFAULT NULL,
" . Schema::audit_columns( false ) . 'PRIMARY KEY  (id),
KEY sender_created (sent_by,created_at),
KEY status_created (status,created_at),
KEY to_email (to_email),
KEY template_id (template_id),
KEY company_id (company_id),
KEY contact_id (contact_id),
KEY lead_id (lead_id)'
		);

		$this->add_parent_keys( Schema::EMAILS );
		$this->add_foreign_key( Schema::EMAILS, 'template_id', Schema::EMAIL_TEMPLATES, 'SET NULL' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function down(): void {
		$this->drop_table( Schema::EMAILS );
	}
}
