<?php
/**
 * Creates the leads table.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Database\Migrations;

use LeadFlow\CRM\Database\AbstractMigration;
use LeadFlow\CRM\Database\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Sales opportunities moving through the pipeline.
 */
final class CreateLeadsTable extends AbstractMigration {

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return '2026_09_19_000003_create_leads_table';
	}

	/**
	 * {@inheritDoc}
	 */
	public function up(): void {
		$this->create_table(
			Schema::LEADS,
			"id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
title varchar(191) NOT NULL,
company_id bigint(20) unsigned NULL DEFAULT NULL,
contact_id bigint(20) unsigned NULL DEFAULT NULL,
status varchar(20) NOT NULL DEFAULT 'open',
stage varchar(50) NOT NULL DEFAULT 'new',
source varchar(50) NOT NULL DEFAULT '',
priority varchar(10) NOT NULL DEFAULT 'normal',
amount decimal(15,2) NOT NULL DEFAULT '0.00',
currency char(3) NOT NULL DEFAULT '',
probability tinyint(3) unsigned NULL DEFAULT NULL,
expected_close_date date NULL DEFAULT NULL,
closed_at datetime NULL DEFAULT NULL,
lost_reason varchar(255) NOT NULL DEFAULT '',
description text NULL,
owner_id bigint(20) unsigned NULL DEFAULT NULL,
" . Schema::audit_columns() . 'PRIMARY KEY  (id),
KEY status_stage (status,stage),
KEY company_id (company_id),
KEY contact_id (contact_id),
KEY owner_status (owner_id,status),
KEY expected_close_date (expected_close_date),
KEY created_at (created_at),
KEY deleted_at (deleted_at)'
		);

		$this->add_foreign_key( Schema::LEADS, 'company_id', Schema::COMPANIES, 'SET NULL' );
		$this->add_foreign_key( Schema::LEADS, 'contact_id', Schema::CONTACTS, 'SET NULL' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function down(): void {
		$this->drop_table( Schema::LEADS );
	}
}
