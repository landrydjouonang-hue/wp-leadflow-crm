<?php
/**
 * Creates and seeds the pipeline stages table.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Database\Migrations;

use LeadFlow\CRM\Database\AbstractMigration;
use LeadFlow\CRM\Database\Schema;
use LeadFlow\CRM\Database\Table;

defined( 'ABSPATH' ) || exit;

/**
 * Configurable sales stages. Leads reference a stage by its slug, which
 * never changes after creation (renaming a stage keeps its leads).
 */
final class CreatePipelineStagesTable extends AbstractMigration {

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return '2026_09_21_000008_create_pipeline_stages_table';
	}

	/**
	 * {@inheritDoc}
	 */
	public function up(): void {
		$this->create_table(
			Schema::PIPELINE_STAGES,
			"id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
name varchar(100) NOT NULL,
slug varchar(50) NOT NULL,
color varchar(7) NOT NULL DEFAULT '#64748b',
probability tinyint(3) unsigned NULL DEFAULT NULL,
type varchar(10) NOT NULL DEFAULT 'open',
position int(11) NOT NULL DEFAULT 0,
" . Schema::audit_columns( false ) . 'PRIMARY KEY  (id),
UNIQUE KEY slug (slug),
KEY position (position)'
		);

		$this->seed();
	}

	/**
	 * Default stages, only when the table is empty.
	 *
	 * @return void
	 */
	private function seed(): void {
		global $wpdb;

		$table = Table::name( Schema::PIPELINE_STAGES );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Seeding.
		if ( (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i', $table ) ) > 0 ) {
			return;
		}

		$now      = current_time( 'mysql', true );
		$defaults = array(
			array( 'new', __( 'New', 'wp-leadflow-crm' ), '#64748b', 10, 'open' ),
			array( 'contacted', __( 'Contacted', 'wp-leadflow-crm' ), '#0ea5e9', 20, 'open' ),
			array( 'qualified', __( 'Qualified', 'wp-leadflow-crm' ), '#6366f1', 40, 'open' ),
			array( 'proposal', __( 'Proposal', 'wp-leadflow-crm' ), '#a855f7', 60, 'open' ),
			array( 'negotiation', __( 'Negotiation', 'wp-leadflow-crm' ), '#f59e0b', 80, 'open' ),
			array( 'won', __( 'Won', 'wp-leadflow-crm' ), '#16a34a', 100, 'won' ),
			array( 'lost', __( 'Lost', 'wp-leadflow-crm' ), '#dc2626', 0, 'lost' ),
		);

		foreach ( $defaults as $index => list( $slug, $name, $color, $probability, $type ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Seeding.
			$wpdb->insert(
				$table,
				array(
					'name'        => $name,
					'slug'        => $slug,
					'color'       => $color,
					'probability' => $probability,
					'type'        => $type,
					'position'    => ( $index + 1 ) * 10,
					'created_at'  => $now,
					'updated_at'  => $now,
				),
				array( '%s', '%s', '%s', '%d', '%s', '%d', '%s', '%s' )
			);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public function down(): void {
		$this->drop_table( Schema::PIPELINE_STAGES );
	}
}
