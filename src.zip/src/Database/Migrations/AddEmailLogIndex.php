<?php
/**
 * Index for the email log and retention clean-up.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Database\Migrations;

use LeadFlow\CRM\Database\AbstractMigration;
use LeadFlow\CRM\Database\Schema;
use LeadFlow\CRM\Database\Table;

defined( 'ABSPATH' ) || exit;

/**
 * `emails.created_at`: the email log sorts by date without a status
 * filter, and the retention clean-up deletes the oldest rows first.
 */
final class AddEmailLogIndex extends AbstractMigration {

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return '2026_09_23_000013_add_email_log_index';
	}

	/**
	 * {@inheritDoc}
	 */
	public function up(): void {
		$this->add_index( Schema::EMAILS, 'created_at', array( 'created_at' ) );
	}

	/**
	 * {@inheritDoc}
	 */
	public function down(): void {
		global $wpdb;

		$table = Table::name( Schema::EMAILS );

		if ( Table::index_exists( $table, 'created_at' ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange -- Rollback.
			$wpdb->query( $wpdb->prepare( 'ALTER TABLE %i DROP INDEX %i', $table, 'created_at' ) );
		}
	}
}
