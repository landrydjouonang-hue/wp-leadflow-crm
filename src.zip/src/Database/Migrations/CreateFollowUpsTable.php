<?php
/**
 * Creates the follow-ups table.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Database\Migrations;

use LeadFlow\CRM\Database\AbstractMigration;
use LeadFlow\CRM\Database\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Scheduled customer touchpoints (call, email, meeting) with an optional
 * reminder. Unlike tasks, a follow-up always concerns a customer record
 * and records an outcome.
 */
final class CreateFollowUpsTable extends AbstractMigration {

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return '2026_09_19_000007_create_follow_ups_table';
	}

	/**
	 * {@inheritDoc}
	 */
	public function up(): void {
		$this->create_table(
			Schema::FOLLOW_UPS,
			"id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
" . Schema::parent_columns() . "type varchar(20) NOT NULL DEFAULT 'call',
subject varchar(255) NOT NULL,
notes text NULL,
status varchar(20) NOT NULL DEFAULT 'scheduled',
scheduled_at datetime NOT NULL,
remind_at datetime NULL DEFAULT NULL,
reminder_sent_at datetime NULL DEFAULT NULL,
completed_at datetime NULL DEFAULT NULL,
outcome varchar(255) NOT NULL DEFAULT '',
assigned_to bigint(20) unsigned NULL DEFAULT NULL,
" . Schema::audit_columns() . 'PRIMARY KEY  (id),
KEY assignee_status_scheduled (assigned_to,status,scheduled_at),
KEY status_scheduled (status,scheduled_at),
KEY reminder_queue (reminder_sent_at,remind_at),
KEY company_id (company_id),
KEY contact_id (contact_id),
KEY lead_id (lead_id),
KEY deleted_at (deleted_at)'
		);

		$this->add_parent_keys( Schema::FOLLOW_UPS );
	}

	/**
	 * {@inheritDoc}
	 */
	public function down(): void {
		$this->drop_table( Schema::FOLLOW_UPS );
	}
}
