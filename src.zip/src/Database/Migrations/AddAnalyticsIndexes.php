<?php
/**
 * Indexes for the analytics dashboard.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Database\Migrations;

use LeadFlow\CRM\Database\AbstractMigration;
use LeadFlow\CRM\Database\Schema;
use LeadFlow\CRM\Database\Table;

defined( 'ABSPATH' ) || exit;

/**
 * - `status_closed (status, closed_at)`: won / lost in a period.
 * - `owner_created (owner_id, created_at)`: "my" leads created in a period.
 *
 * Leads created in a period use the existing `created_at` index, the open
 * pipeline uses `status_stage`, tasks `status_due` and follow-ups
 * `status_scheduled`.
 */
final class AddAnalyticsIndexes extends AbstractMigration {

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return '2026_09_22_000012_add_analytics_indexes';
	}

	/**
	 * {@inheritDoc}
	 */
	public function up(): void {
		$this->add_index( Schema::LEADS, 'status_closed', array( 'status', 'closed_at' ) );
		$this->add_index( Schema::LEADS, 'owner_created', array( 'owner_id', 'created_at' ) );
	}

	/**
	 * {@inheritDoc}
	 */
	public function down(): void {
		global $wpdb;

		$table = Table::name( Schema::LEADS );

		foreach ( array( 'status_closed', 'owner_created' ) as $index ) {
			if ( Table::index_exists( $table, $index ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange -- Rollback.
				$wpdb->query( $wpdb->prepare( 'ALTER TABLE %i DROP INDEX %i', $table, $index ) );
			}
		}
	}
}
