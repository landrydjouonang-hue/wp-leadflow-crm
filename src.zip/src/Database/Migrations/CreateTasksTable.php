<?php
/**
 * Creates the tasks table.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Database\Migrations;

use LeadFlow\CRM\Database\AbstractMigration;
use LeadFlow\CRM\Database\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Internal to-dos assigned to users. May stand alone or belong to a
 * company, contact or lead.
 */
final class CreateTasksTable extends AbstractMigration {

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return '2026_09_19_000006_create_tasks_table';
	}

	/**
	 * {@inheritDoc}
	 */
	public function up(): void {
		$this->create_table(
			Schema::TASKS,
			"id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
" . Schema::parent_columns() . "title varchar(255) NOT NULL,
description text NULL,
status varchar(20) NOT NULL DEFAULT 'pending',
priority varchar(10) NOT NULL DEFAULT 'normal',
due_at datetime NULL DEFAULT NULL,
completed_at datetime NULL DEFAULT NULL,
completed_by bigint(20) unsigned NULL DEFAULT NULL,
assigned_to bigint(20) unsigned NULL DEFAULT NULL,
" . Schema::audit_columns() . 'PRIMARY KEY  (id),
KEY assignee_status_due (assigned_to,status,due_at),
KEY status_due (status,due_at),
KEY company_id (company_id),
KEY contact_id (contact_id),
KEY lead_id (lead_id),
KEY deleted_at (deleted_at)'
		);

		$this->add_parent_keys( Schema::TASKS );
	}

	/**
	 * {@inheritDoc}
	 */
	public function down(): void {
		$this->drop_table( Schema::TASKS );
	}
}
