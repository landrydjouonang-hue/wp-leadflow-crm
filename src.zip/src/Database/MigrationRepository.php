<?php
/**
 * Stores which migrations have run.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Database;

defined( 'ABSPATH' ) || exit;

/**
 * Persistence for the `{prefix}leadflow_migrations` table.
 */
final class MigrationRepository {

	/**
	 * Short table name.
	 */
	public const TABLE = 'migrations';

	/**
	 * Full table name.
	 *
	 * @return string
	 */
	public function table(): string {
		return Table::name( self::TABLE );
	}

	/**
	 * Creates the tracking table if needed.
	 *
	 * @return bool Whether the table exists afterwards.
	 */
	public function ensure_table(): bool {
		$table = $this->table();

		if ( Table::exists( $table ) ) {
			return true;
		}

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		dbDelta(
			"CREATE TABLE {$table} (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
migration varchar(191) NOT NULL,
batch int(10) unsigned NOT NULL DEFAULT 1,
applied_at datetime NOT NULL,
PRIMARY KEY  (id),
UNIQUE KEY migration (migration),
KEY batch (batch)
) " . Table::charset_collate() . ';'
		);

		return Table::exists( $table );
	}

	/**
	 * Ids of applied migrations.
	 *
	 * @return string[]
	 */
	public function applied(): array {
		global $wpdb;

		if ( ! Table::exists( $this->table() ) ) {
			return array();
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table, must be fresh.
		return array_map( 'strval', (array) $wpdb->get_col( $wpdb->prepare( 'SELECT migration FROM %i ORDER BY id ASC', $this->table() ) ) );
	}

	/**
	 * Next batch number.
	 *
	 * @return int
	 */
	public function next_batch(): int {
		return $this->last_batch() + 1;
	}

	/**
	 * Highest batch number, 0 when none.
	 *
	 * @return int
	 */
	public function last_batch(): int {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table, must be fresh.
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT MAX(batch) FROM %i', $this->table() ) );
	}

	/**
	 * Migrations of a batch, newest first.
	 *
	 * @param int $batch Batch number.
	 * @return string[]
	 */
	public function in_batch( int $batch ): array {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table, must be fresh.
		return array_map( 'strval', (array) $wpdb->get_col( $wpdb->prepare( 'SELECT migration FROM %i WHERE batch = %d ORDER BY id DESC', $this->table(), $batch ) ) );
	}

	/**
	 * Records a migration as applied.
	 *
	 * @param string $migration Migration id.
	 * @param int    $batch     Batch number.
	 * @return void
	 */
	public function log( string $migration, int $batch ): void {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Custom table insert.
		$wpdb->insert(
			$this->table(),
			array(
				'migration'  => $migration,
				'batch'      => $batch,
				'applied_at' => current_time( 'mysql', true ),
			),
			array( '%s', '%d', '%s' )
		);
	}

	/**
	 * Removes a migration record.
	 *
	 * @param string $migration Migration id.
	 * @return void
	 */
	public function delete( string $migration ): void {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table delete.
		$wpdb->delete( $this->table(), array( 'migration' => $migration ), array( '%s' ) );
	}
}
