<?php
/**
 * Core CRM schema.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Database;

use LeadFlow\CRM\Contracts\Migration;

defined( 'ABSPATH' ) || exit;

/**
 * Names of the core CRM tables and the migrations that create them.
 *
 * Relationships (→ = foreign key):
 *
 *   contacts.company_id  → companies    ON DELETE SET NULL
 *   leads.company_id     → companies    ON DELETE SET NULL
 *   leads.contact_id     → contacts     ON DELETE SET NULL
 *   {activities,notes,tasks,follow_ups}.company_id → companies  SET NULL
 *   {activities,notes,tasks,follow_ups}.contact_id → contacts   SET NULL
 *   {activities,notes,tasks,follow_ups}.lead_id    → leads      CASCADE
 *   emails: same parent keys as above
 *   emails.template_id   → email_templates ON DELETE SET NULL
 *
 * See docs/DATABASE.md for the full design.
 */
final class Schema {

	public const COMPANIES  = 'companies';
	public const CONTACTS   = 'contacts';
	public const LEADS      = 'leads';
	public const ACTIVITIES = 'activities';
	public const NOTES      = 'notes';
	public const TASKS      = 'tasks';
	public const FOLLOW_UPS = 'follow_ups';

	public const PIPELINE_STAGES = 'pipeline_stages';

	public const EMAIL_TEMPLATES = 'email_templates';

	public const EMAILS = 'emails';

	/**
	 * Tables whose rows belong to a company, contact and/or lead.
	 */
	public const RELATED_TABLES = array( self::ACTIVITIES, self::NOTES, self::TASKS, self::FOLLOW_UPS, self::EMAILS );

	/**
	 * Core migrations in order.
	 *
	 * @return Migration[]
	 */
	public static function migrations(): array {
		return array(
			new Migrations\CreateCompaniesTable(),
			new Migrations\CreateContactsTable(),
			new Migrations\CreateLeadsTable(),
			new Migrations\CreateActivitiesTable(),
			new Migrations\CreateNotesTable(),
			new Migrations\CreateTasksTable(),
			new Migrations\CreateFollowUpsTable(),
			new Migrations\CreatePipelineStagesTable(),
			new Migrations\AddLeadPipelineColumns(),
			new Migrations\CreateEmailTemplatesTable(),
			new Migrations\CreateEmailsTable(),
			new Migrations\AddAnalyticsIndexes(),
			new Migrations\AddEmailLogIndex(),
		);
	}

	/**
	 * Column definitions shared by every table that stores user ownership,
	 * timestamps and soft deletes.
	 *
	 * @param bool $soft_deletes Include deleted_at/deleted_by.
	 * @return string dbDelta column lines.
	 */
	public static function audit_columns( bool $soft_deletes = true ): string {
		$columns = "created_by bigint(20) unsigned NULL DEFAULT NULL,\n"
			. "updated_by bigint(20) unsigned NULL DEFAULT NULL,\n"
			. "created_at datetime NOT NULL,\n"
			. "updated_at datetime NOT NULL,\n";

		if ( $soft_deletes ) {
			$columns .= "deleted_at datetime NULL DEFAULT NULL,\n"
				. "deleted_by bigint(20) unsigned NULL DEFAULT NULL,\n";
		}

		return $columns;
	}

	/**
	 * Parent reference columns of related tables.
	 *
	 * @return string dbDelta column lines.
	 */
	public static function parent_columns(): string {
		return "company_id bigint(20) unsigned NULL DEFAULT NULL,\n"
			. "contact_id bigint(20) unsigned NULL DEFAULT NULL,\n"
			. "lead_id bigint(20) unsigned NULL DEFAULT NULL,\n";
	}
}
