<?php
/**
 * Runs module migrations.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Database;

use LeadFlow\CRM\Contracts\Migration;
use LeadFlow\CRM\Modules\ModuleManager;

defined( 'ABSPATH' ) || exit;

/**
 * Applies pending migrations in id order and rolls back batches.
 */
final class Migrator {

	/**
	 * Option holding the last migration error.
	 */
	public const ERROR_OPTION = 'leadflow_crm_migration_error';

	/**
	 * Constructor.
	 *
	 * @param MigrationRepository $repository Migration log.
	 * @param ModuleManager       $modules    Module manager.
	 */
	public function __construct(
		private MigrationRepository $repository,
		private ModuleManager $modules
	) {}

	/**
	 * All known migrations keyed and sorted by id.
	 *
	 * @return array<string, Migration>
	 */
	public function migrations(): array {
		/**
		 * Filters the migrations LeadFlow CRM knows about.
		 *
		 * @param Migration[] $migrations Core schema plus module migrations.
		 */
		$list = (array) apply_filters(
			'leadflow_crm_migrations',
			array_merge( Schema::migrations(), $this->modules->migrations() )
		);

		$migrations = array();

		foreach ( $list as $migration ) {
			if ( $migration instanceof Migration ) {
				$migrations[ $migration->id() ] = $migration;
			}
		}

		ksort( $migrations, SORT_STRING );

		return $migrations;
	}

	/**
	 * Migrations not yet applied.
	 *
	 * @return array<string, Migration>
	 */
	public function pending(): array {
		return array_diff_key( $this->migrations(), array_flip( $this->repository->applied() ) );
	}

	/**
	 * Applies all pending migrations as one batch.
	 *
	 * Stops at the first failure; already-applied migrations stay recorded.
	 *
	 * @return bool True when everything is up to date.
	 */
	public function migrate(): bool {
		if ( ! $this->repository->ensure_table() ) {
			$this->record_error( 'migrations_table', __( 'The migrations table could not be created.', 'wp-leadflow-crm' ) );
			return false;
		}

		$pending = $this->pending();

		if ( empty( $pending ) ) {
			delete_option( self::ERROR_OPTION );
			return true;
		}

		$batch = $this->repository->next_batch();

		foreach ( $pending as $id => $migration ) {
			try {
				$migration->up();
				$this->repository->log( $id, $batch );
			} catch ( \Throwable $e ) {
				$this->record_error( $id, $e->getMessage() );
				return false;
			}
		}

		delete_option( self::ERROR_OPTION );

		/**
		 * Fires after a batch of migrations was applied.
		 *
		 * @param string[] $ids   Applied migration ids.
		 * @param int      $batch Batch number.
		 */
		do_action( 'leadflow_crm_migrated', array_keys( $pending ), $batch );

		return true;
	}

	/**
	 * Rolls back the most recent batch.
	 *
	 * @return string[] Rolled-back migration ids.
	 */
	public function rollback(): array {
		$batch = $this->repository->last_batch();

		if ( $batch < 1 ) {
			return array();
		}

		$known       = $this->migrations();
		$rolled_back = array();

		foreach ( $this->repository->in_batch( $batch ) as $id ) {
			if ( isset( $known[ $id ] ) ) {
				$known[ $id ]->down();
			}

			$this->repository->delete( $id );
			$rolled_back[] = $id;
		}

		return $rolled_back;
	}

	/**
	 * Schema version: id of the most recently applied migration.
	 *
	 * @return string|null Null when nothing was applied.
	 */
	public function current_version(): ?string {
		$applied = $this->repository->applied();

		if ( empty( $applied ) ) {
			return null;
		}

		sort( $applied, SORT_STRING );

		return (string) end( $applied );
	}

	/**
	 * Last recorded error, if any.
	 *
	 * @return array{migration: string, message: string, time: int}|null
	 */
	public function last_error(): ?array {
		$error = get_option( self::ERROR_OPTION );

		return is_array( $error ) ? $error : null;
	}

	/**
	 * Stores an error for display to administrators.
	 *
	 * @param string $migration Migration id.
	 * @param string $message   Error message.
	 * @return void
	 */
	private function record_error( string $migration, string $message ): void {
		\LeadFlow\CRM\Support\Logger::error(
			'Migration failed',
			array(
				'migration' => $migration,
				'message'   => $message,
			)
		);

		update_option(
			self::ERROR_OPTION,
			array(
				'migration' => $migration,
				'message'   => $message,
				'time'      => time(),
			),
			false
		);
	}
}
