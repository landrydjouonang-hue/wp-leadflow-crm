<?php
/**
 * Table name helper.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Database;

defined( 'ABSPATH' ) || exit;

/**
 * Resolves plugin table names for the current site.
 */
final class Table {

	/**
	 * Prefix added after the WordPress table prefix.
	 */
	public const PREFIX = 'leadflow_';

	/**
	 * Full table name, e.g. "wp_leadflow_leads".
	 *
	 * @param string $name Short name, e.g. "leads".
	 * @return string
	 */
	public static function name( string $name ): string {
		global $wpdb;

		return $wpdb->prefix . self::PREFIX . $name;
	}

	/**
	 * Whether a table exists.
	 *
	 * @param string $table Full table name.
	 * @return bool
	 */
	public static function exists( string $table ): bool {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Schema introspection.
		$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) );

		return $found === $table;
	}

	/**
	 * All plugin tables that currently exist on this site.
	 *
	 * @return string[]
	 */
	public static function all_existing(): array {
		global $wpdb;

		$like = $wpdb->esc_like( $wpdb->prefix . self::PREFIX ) . '%';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Schema introspection.
		return array_map( 'strval', (array) $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $like ) ) );
	}

	/**
	 * Whether a column exists.
	 *
	 * @param string $table  Full table name.
	 * @param string $column Column.
	 * @return bool
	 */
	public static function column_exists( string $table, string $column ): bool {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Schema introspection.
		return (bool) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME = %s',
				$table,
				$column
			)
		);
	}

	/**
	 * Whether an index exists.
	 *
	 * @param string $table Full table name.
	 * @param string $index Index name.
	 * @return bool
	 */
	public static function index_exists( string $table, string $index ): bool {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Schema introspection.
		return (bool) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND INDEX_NAME = %s',
				$table,
				$index
			)
		);
	}

	/**
	 * Storage engine of a table ('' when unknown).
	 *
	 * @param string $table Full table name.
	 * @return string
	 */
	public static function engine( string $table ): string {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Schema introspection.
		return (string) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s',
				$table
			)
		);
	}

	/**
	 * Whether a table can hold foreign keys.
	 *
	 * @param string $table Full table name.
	 * @return bool
	 */
	public static function supports_foreign_keys( string $table ): bool {
		return 'innodb' === strtolower( self::engine( $table ) );
	}

	/**
	 * Deterministic constraint name, unique per database (max 64 chars).
	 *
	 * @param string $table  Short table name.
	 * @param string $column Column.
	 * @return string
	 */
	public static function foreign_key_name( string $table, string $column ): string {
		$name = self::name( $table ) . '_' . $column . '_fk';

		return strlen( $name ) <= 64 ? $name : 'lf_fk_' . md5( $name );
	}

	/**
	 * Whether a foreign key constraint exists on a table.
	 *
	 * @param string $table      Full table name.
	 * @param string $constraint Constraint name.
	 * @return bool
	 */
	public static function foreign_key_exists( string $table, string $constraint ): bool {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Schema introspection.
		return (bool) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = %s AND CONSTRAINT_NAME = %s AND CONSTRAINT_TYPE = 'FOREIGN KEY'",
				$table,
				$constraint
			)
		);
	}

	/**
	 * Foreign keys defined on a table.
	 *
	 * @param string $table Full table name.
	 * @return array<int, array{name: string, column: string, references: string, on_delete: string}>
	 */
	public static function foreign_keys( string $table ): array {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Schema introspection.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT k.CONSTRAINT_NAME AS name, k.COLUMN_NAME AS `column`, k.REFERENCED_TABLE_NAME AS `references`, r.DELETE_RULE AS on_delete
				FROM information_schema.KEY_COLUMN_USAGE k
				JOIN information_schema.REFERENTIAL_CONSTRAINTS r
					ON r.CONSTRAINT_SCHEMA = k.CONSTRAINT_SCHEMA AND r.CONSTRAINT_NAME = k.CONSTRAINT_NAME
				WHERE k.TABLE_SCHEMA = DATABASE() AND k.TABLE_NAME = %s AND k.REFERENCED_TABLE_NAME IS NOT NULL
				ORDER BY k.COLUMN_NAME',
				$table
			),
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Drops one table, ignoring foreign keys that point at it.
	 *
	 * @param string $table Full table name.
	 * @return void
	 */
	public static function drop( string $table ): void {
		self::drop_many( array( $table ) );
	}

	/**
	 * Drops every plugin table on the current site.
	 *
	 * @return void
	 */
	public static function drop_all(): void {
		self::drop_many( self::all_existing() );
	}

	/**
	 * Drops tables with foreign key checks disabled for this session, so
	 * the order does not matter.
	 *
	 * @param string[] $tables Full table names.
	 * @return void
	 */
	private static function drop_many( array $tables ): void {
		global $wpdb;

		if ( empty( $tables ) ) {
			return;
		}

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange -- Schema removal.
		$wpdb->query( 'SET FOREIGN_KEY_CHECKS = 0' );

		foreach ( $tables as $table ) {
			$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $table ) );
		}

		$wpdb->query( 'SET FOREIGN_KEY_CHECKS = 1' );
		// phpcs:enable
	}

	/**
	 * Charset/collation clause for CREATE TABLE.
	 *
	 * @return string
	 */
	public static function charset_collate(): string {
		global $wpdb;

		return $wpdb->get_charset_collate();
	}
}
