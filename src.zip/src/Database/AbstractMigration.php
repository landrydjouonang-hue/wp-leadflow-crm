<?php
/**
 * Base migration with dbDelta helpers.
 *
 * @package LeadFlow\CRM
 */

declare( strict_types=1 );

namespace LeadFlow\CRM\Database;

use LeadFlow\CRM\Contracts\Migration;

defined( 'ABSPATH' ) || exit;

/**
 * Helpers for table creation and removal.
 *
 * Example subclass:
 *
 *     public function id(): string { return '2026_10_01_000001_create_invoices_table'; }
 *     public function up(): void {
 *         $this->create_table( 'invoices', "id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
 *             company_id bigint(20) unsigned NULL DEFAULT NULL,
 *             PRIMARY KEY  (id),
 *             KEY company_id (company_id)" );
 *         $this->add_foreign_key( 'invoices', 'company_id', 'companies', 'SET NULL' );
 *     }
 *     public function down(): void { $this->drop_table( 'invoices' ); }
 *
 * up() must be idempotent: dbDelta and add_foreign_key() both are.
 */
abstract class AbstractMigration implements Migration {

	/**
	 * Creates or updates a table with dbDelta and verifies it exists.
	 *
	 * @param string $name    Short table name.
	 * @param string $columns Column/index definitions in dbDelta format.
	 * @return void
	 * @throws \RuntimeException When the table could not be created.
	 */
	protected function create_table( string $name, string $columns ): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table = Table::name( $name );

		// InnoDB is requested explicitly for transactions and foreign keys.
		dbDelta( "CREATE TABLE {$table} (\n{$columns}\n) ENGINE=InnoDB " . Table::charset_collate() . ';' );

		if ( ! Table::exists( $table ) ) {
			throw new \RuntimeException(
				sprintf( 'Could not create table %s: %s', esc_html( $table ), esc_html( (string) $wpdb->last_error ) )
			);
		}
	}

	/**
	 * Adds a foreign key if it does not exist yet (idempotent).
	 *
	 * Skipped silently when either table is not InnoDB (for example on
	 * hosts that force MyISAM); repositories enforce the same rules in PHP,
	 * so behavior does not depend on database constraints.
	 *
	 * @param string $table      Short table name holding the column.
	 * @param string $column     Referencing column.
	 * @param string $references Short name of the referenced table.
	 * @param string $on_delete  CASCADE|SET NULL|RESTRICT.
	 * @return void
	 * @throws \RuntimeException When the constraint could not be added.
	 */
	protected function add_foreign_key( string $table, string $column, string $references, string $on_delete = 'SET NULL' ): void {
		global $wpdb;

		$on_delete = strtoupper( $on_delete );

		if ( ! in_array( $on_delete, array( 'CASCADE', 'SET NULL', 'RESTRICT' ), true ) ) {
			throw new \InvalidArgumentException( 'Unsupported ON DELETE action.' );
		}

		$child  = Table::name( $table );
		$parent = Table::name( $references );

		if ( ! Table::supports_foreign_keys( $child ) || ! Table::supports_foreign_keys( $parent ) ) {
			return;
		}

		$constraint = Table::foreign_key_name( $table, $column );

		if ( Table::foreign_key_exists( $child, $constraint ) ) {
			return;
		}

		// ON DELETE action comes from the allow-list above; identifiers use %i.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Schema migration.
		$result = $wpdb->query( $wpdb->prepare( "ALTER TABLE %i ADD CONSTRAINT %i FOREIGN KEY (%i) REFERENCES %i (id) ON DELETE {$on_delete} ON UPDATE CASCADE", $child, $constraint, $column, $parent ) );

		if ( false === $result ) {
			throw new \RuntimeException(
				sprintf( 'Could not add foreign key %s: %s', esc_html( $constraint ), esc_html( (string) $wpdb->last_error ) )
			);
		}
	}

	/**
	 * Adds a column if it does not exist yet (idempotent; works on MySQL
	 * and MariaDB, unlike ADD COLUMN IF NOT EXISTS).
	 *
	 * @param string $table      Short table name.
	 * @param string $column     Column name.
	 * @param string $definition Column definition, e.g. "varchar(100) NOT NULL DEFAULT ''".
	 * @param string $after      Existing column to place it after ('' = end).
	 * @return void
	 * @throws \RuntimeException When the column could not be added.
	 */
	protected function add_column( string $table, string $column, string $definition, string $after = '' ): void {
		global $wpdb;

		$full = Table::name( $table );

		if ( Table::column_exists( $full, $column ) ) {
			return;
		}

		if ( 1 !== preg_match( '/^[a-z0-9(),\'\s._-]+$/i', $definition ) ) {
			throw new \InvalidArgumentException( 'Unsafe column definition.' );
		}

		$sql    = "ALTER TABLE %i ADD COLUMN %i {$definition}";
		$params = array( $full, $column );

		if ( '' !== $after ) {
			$sql     .= ' AFTER %i';
			$params[] = $after;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.NotPrepared -- Definition allow-listed above.
		if ( false === $wpdb->query( $wpdb->prepare( $sql, $params ) ) ) {
			throw new \RuntimeException( sprintf( 'Could not add column %s.%s: %s', esc_html( $full ), esc_html( $column ), esc_html( (string) $wpdb->last_error ) ) );
		}
	}

	/**
	 * Adds an index if it does not exist yet (idempotent).
	 *
	 * @param string   $table   Short table name.
	 * @param string   $name    Index name.
	 * @param string[] $columns Columns.
	 * @return void
	 * @throws \RuntimeException When the index could not be added.
	 */
	protected function add_index( string $table, string $name, array $columns ): void {
		global $wpdb;

		$full = Table::name( $table );

		if ( Table::index_exists( $full, $name ) ) {
			return;
		}

		$placeholders = implode( ', ', array_fill( 0, count( $columns ), '%i' ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Placeholders only.
		if ( false === $wpdb->query( $wpdb->prepare( "ALTER TABLE %i ADD INDEX %i ({$placeholders})", array_merge( array( $full, $name ), $columns ) ) ) ) {
			throw new \RuntimeException( sprintf( 'Could not add index %s: %s', esc_html( $name ), esc_html( (string) $wpdb->last_error ) ) );
		}
	}

	/**
	 * Foreign keys for a related table's company/contact/lead columns.
	 *
	 * The lead is the most specific parent, so its rows go with it
	 * (CASCADE). Company and contact references are unlinked (SET NULL);
	 * rows owned solely by a purged company/contact are removed by the
	 * repositories beforehand.
	 *
	 * @param string $table Short table name.
	 * @return void
	 */
	protected function add_parent_keys( string $table ): void {
		$this->add_foreign_key( $table, 'company_id', Schema::COMPANIES, 'SET NULL' );
		$this->add_foreign_key( $table, 'contact_id', Schema::CONTACTS, 'SET NULL' );
		$this->add_foreign_key( $table, 'lead_id', Schema::LEADS, 'CASCADE' );
	}

	/**
	 * Drops a table if it exists.
	 *
	 * @param string $name Short table name.
	 * @return void
	 */
	protected function drop_table( string $name ): void {
		Table::drop( Table::name( $name ) );
	}
}
